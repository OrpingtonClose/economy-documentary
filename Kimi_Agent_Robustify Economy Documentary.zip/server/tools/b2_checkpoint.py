"""
B2 checkpoint module -- immediate upload of every pipeline artifact to Backblaze B2.

Every intermediate artifact (scenario JSON, TTS WAVs, visual concepts, video
clips, QA status files, OTIO timelines, assembly outputs, final documentaries)
is uploaded to B2 **immediately** after creation.  On restart the pipeline
restores all artifacts from B2 so no stage needs to re-run.

RESILIENCE FEATURES:
- Retry with exponential backoff for all B2 operations
- Circuit breaker for failing B2 services
- Graceful degradation when B2 is unavailable (continue with local storage)
- Comprehensive timeout handling
- Proper resource cleanup with context managers
- Connection pooling for efficiency
"""

from __future__ import annotations

import io
import json
import logging
import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

# Import resilience module
try:
    from resilience import (
        with_retry, circuit_breaker, CircuitBreaker,
        B2StorageError, ExternalAPIError,
        graceful_degradation, timeout,
        resilient_context, safe_execute,
    )
    RESILIENCE_AVAILABLE = True
except ImportError:
    RESILIENCE_AVAILABLE = False
    logging.warning("Resilience module not available, using fallback error handling")

logger = logging.getLogger(__name__)

# =============================================================================
# Circuit Breaker for B2 API
# =============================================================================

_b2_circuit_breaker = None
if RESILIENCE_AVAILABLE:
    _b2_circuit_breaker = CircuitBreaker(
        name="b2_storage",
        failure_threshold=5,
        recovery_timeout=120.0,
        half_open_max_calls=2,
        expected_exception=(Exception,),
    )

# =============================================================================
# Singleton B2 client with connection pooling
# =============================================================================

_b2_api = None
_b2_bucket = None
_b2_lock = threading.Lock()
_run_id: str = ""
_b2_client_initialized = False
_b2_init_error: Optional[str] = None


class B2ClientPool:
    """Connection pool for B2 client to avoid repeated initialization."""
    
    def __init__(self):
        self._lock = threading.RLock()
        self._api = None
        self._bucket = None
        self._last_used = 0
        self._max_idle_time = 300  # 5 minutes
    
    def get_bucket(self, force_refresh: bool = False):
        """Get B2 bucket with connection pooling."""
        global _b2_init_error
        
        with self._lock:
            # Check if connection is stale
            if not force_refresh and self._api and self._bucket:
                idle_time = time.time() - self._last_used
                if idle_time < self._max_idle_time:
                    self._last_used = time.time()
                    return self._bucket
            
            # Initialize new connection
            key_id = os.environ.get("B2_KEY_ID", "")
            app_key = os.environ.get("B2_APPLICATION_KEY", "")
            bucket_name = os.environ.get("B2_BUCKET_NAME", "cloudberry-documentary-v2")

            if not key_id or not app_key:
                _b2_init_error = "B2_KEY_ID / B2_APPLICATION_KEY not set"
                logger.warning("%s -- B2 checkpoint disabled", _b2_init_error)
                return None

            try:
                from b2sdk.v2 import B2Api, InMemoryAccountInfo
                
                info = InMemoryAccountInfo()
                self._api = B2Api(info)
                self._api.authorize_account("production", key_id, app_key)
                self._bucket = self._api.get_bucket_by_name(bucket_name)
                self._last_used = time.time()
                _b2_init_error = None
                logger.info("B2 checkpoint enabled: bucket=%s", bucket_name)
                return self._bucket
                
            except Exception as e:
                _b2_init_error = str(e)
                logger.error("B2 checkpoint init failed: %s", e)
                self._api = None
                self._bucket = None
                return None
    
    def close(self):
        """Close the connection pool."""
        with self._lock:
            self._api = None
            self._bucket = None


# Global connection pool
_b2_pool = B2ClientPool()


def _get_bucket(force_refresh: bool = False):
    """Lazily initialise and return the B2 bucket handle (thread-safe)."""
    return _b2_pool.get_bucket(force_refresh)


def reset_b2_connection():
    """Reset B2 connection (useful after errors)."""
    _b2_pool.close()
    logger.info("B2 connection reset")


# =============================================================================
# Run ID management
# =============================================================================


def get_run_id() -> str:
    """Return the current run ID, creating one if needed."""
    global _run_id
    if not _run_id:
        _run_id = os.environ.get("B2_RUN_ID", "")
        if not _run_id:
            topic = os.environ.get("DOCUMENTARY_TOPIC", "unknown")
            ts = int(time.time())
            safe_topic = "".join(c if c.isalnum() else "_" for c in topic.lower())[:30]
            _run_id = f"{safe_topic}_{ts}"
            os.environ["B2_RUN_ID"] = _run_id
    return _run_id


def set_run_id(run_id: str) -> None:
    """Set the run ID explicitly (e.g. when restoring from B2)."""
    global _run_id
    _run_id = run_id
    os.environ["B2_RUN_ID"] = run_id


# =============================================================================
# Upload helpers with resilience
# =============================================================================


def _b2_key(relative_path: str) -> str:
    """Build full B2 object key from run_id + relative path."""
    return f"{get_run_id()}/{relative_path}"


def upload_file(local_path: str, b2_relative_path: str) -> bool:
    """Upload a single file to B2 immediately with retry logic.

    Args:
        local_path: Absolute path to the local file.
        b2_relative_path: Path within the run directory.

    Returns:
        True on success, False on failure (never raises).
    """
    bucket = _get_bucket()
    if bucket is None:
        logger.debug("B2 upload skipped -- not configured")
        return False

    if not os.path.exists(local_path):
        logger.warning("B2 upload skipped -- file not found: %s", local_path)
        return False

    key = _b2_key(b2_relative_path)
    
    def _do_upload():
        t0 = time.time()
        size = os.path.getsize(local_path)
        bucket.upload_local_file(
            local_file=local_path,
            file_name=key,
        )
        elapsed = time.time() - t0
        logger.info("B2 uploaded %s (%.1f MB, %.1fs) -> %s", local_path, size / 1e6, elapsed, key)
        return True
    
    # Apply retry and circuit breaker
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=1.0,
            max_wait=30.0,
            exceptions=(Exception,),
        )
        def _upload_with_retry():
            if _b2_circuit_breaker:
                return _b2_circuit_breaker(_do_upload)()
            return _do_upload()
        
        try:
            return _upload_with_retry()
        except Exception as e:
            logger.error("B2 upload failed %s -> %s: %s", local_path, key, e)
            return False
    else:
        # Fallback without resilience module
        for attempt in range(3):
            try:
                return _do_upload()
            except Exception as e:
                if attempt < 2:
                    wait_time = 1.0 * (attempt + 1)
                    logger.warning("Retry %d/3 for B2 upload: %s", attempt + 1, e)
                    time.sleep(wait_time)
                else:
                    logger.error("B2 upload failed %s -> %s: %s", local_path, key, e)
                    return False


def upload_json(data: dict | list | str, b2_relative_path: str) -> bool:
    """Upload JSON data directly to B2 with retry logic.

    Args:
        data: Dict/list to serialise, or a pre-serialised JSON string.
        b2_relative_path: Path within the run directory.

    Returns:
        True on success.
    """
    bucket = _get_bucket()
    if bucket is None:
        return False

    key = _b2_key(b2_relative_path)
    
    def _do_upload():
        if isinstance(data, str):
            payload = data.encode("utf-8")
        else:
            payload = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")

        from b2sdk.v2 import UploadSourceBytes
        bucket.upload(UploadSourceBytes(payload), key)
        logger.info("B2 uploaded JSON (%d bytes) -> %s", len(payload), key)
        return True
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=1.0,
            max_wait=30.0,
            exceptions=(Exception,),
        )
        def _upload_with_retry():
            if _b2_circuit_breaker:
                return _b2_circuit_breaker(_do_upload)()
            return _do_upload()
        
        try:
            return _upload_with_retry()
        except Exception as e:
            logger.error("B2 upload JSON failed -> %s: %s", key, e)
            return False
    else:
        for attempt in range(3):
            try:
                return _do_upload()
            except Exception as e:
                if attempt < 2:
                    wait_time = 1.0 * (attempt + 1)
                    logger.warning("Retry %d/3 for B2 JSON upload: %s", attempt + 1, e)
                    time.sleep(wait_time)
                else:
                    logger.error("B2 upload JSON failed -> %s: %s", key, e)
                    return False


def upload_stage_marker(stage: str) -> bool:
    """Mark a pipeline stage as complete in B2.

    Args:
        stage: Stage name (scenario, audio, visual_direction, production, assembly).
    """
    return upload_json(
        {"stage": stage, "completed_at": time.time()},
        f"stage_markers/{stage}.done",
    )


# =============================================================================
# Convenience uploaders with graceful degradation
# =============================================================================


def upload_scenario(scenes_json: str, visual_style_json: str) -> bool:
    """Upload scenario output (scenes + visual_style) immediately.

    Returns True if both uploads succeeded.
    """
    ok1 = upload_json(scenes_json, "state/scenes.json")
    ok2 = upload_json(visual_style_json, "state/visual_style.json")
    logger.info("B2: scenario artifacts uploaded (ok=%s)", ok1 and ok2)
    return ok1 and ok2


def upload_tts_clip(wav_path: str, sidecar_path: str = "") -> None:
    """Upload a TTS WAV file (and its text-hash sidecar) immediately."""
    basename = os.path.basename(wav_path)
    upload_file(wav_path, f"audio/{basename}")
    if sidecar_path and os.path.exists(sidecar_path):
        upload_file(sidecar_path, f"audio/{os.path.basename(sidecar_path)}")


def upload_visual_concepts(visual_concepts_json: str) -> bool:
    """Upload visual direction output immediately.

    Returns True if the upload succeeded.
    """
    ok = upload_json(visual_concepts_json, "state/visual_concepts.json")
    logger.info("B2: visual concepts uploaded (ok=%s)", ok)
    return ok


def upload_video_clip(mp4_path: str, status_path: str = "") -> None:
    """Upload a video clip (and its QA status file) immediately."""
    basename = os.path.basename(mp4_path)
    upload_file(mp4_path, f"video/{basename}")
    if status_path and os.path.exists(status_path):
        upload_file(status_path, f"video/{os.path.basename(status_path)}")


def upload_timeline(otio_path: str) -> None:
    """Upload OTIO timeline immediately."""
    basename = os.path.basename(otio_path)
    upload_file(otio_path, f"timelines/{basename}")


def upload_assembly_file(local_path: str) -> None:
    """Upload an assembly intermediate file."""
    basename = os.path.basename(local_path)
    upload_file(local_path, f"assembly/{basename}")


def upload_gatekeeper_report(report: dict, stage: str) -> bool:
    """Upload a gatekeeper audit report to B2.

    Called AFTER all artifacts for the stage are already in B2,
    so the audit trail is: artifacts first, then validation verdict.

    Args:
        report: Structured audit report from gatekeeper.format_audit_report().
        stage: Pipeline stage name (audio, production, etc.).

    Returns:
        True on success.
    """
    ok = upload_json(report, f"gatekeeper/{stage}_audit.json")
    verdict = report.get("verdict", "UNKNOWN")
    rejects = report.get("rejects", 0)
    total = report.get("total_checks", 0)
    logger.info(
        "B2: gatekeeper audit uploaded for %s (verdict=%s, %d/%d checks, %d rejects)",
        stage, verdict, total, total, rejects,
    )
    return ok


def upload_final_output(local_path: str) -> bool:
    """Upload final documentary MP4.

    Returns True if the upload succeeded.
    """
    basename = os.path.basename(local_path)
    return upload_file(local_path, f"output/{basename}")


def upload_pipeline_state(state: dict) -> bool:
    """Upload full pipeline state snapshot.

    Returns True if the upload succeeded.
    """
    # Filter non-serialisable values
    serialisable = {}
    for k, v in state.items():
        try:
            json.dumps(v)
            serialisable[k] = v
        except (TypeError, ValueError):
            serialisable[k] = str(v)
    return upload_json(serialisable, "state/pipeline_state.json")


# =============================================================================
# Restore helpers with resilience
# =============================================================================


def check_stage_complete(stage: str) -> bool:
    """Check if a pipeline stage was already completed in B2.

    Returns True if the stage marker exists in B2.
    """
    bucket = _get_bucket()
    if bucket is None:
        return False

    target_name = f"stage_markers/{stage}.done"
    prefix = _b2_key("stage_markers/")
    target_key = _b2_key(target_name)
    
    def _check():
        for file_version, _ in bucket.ls(prefix):
            if file_version.file_name == target_key:
                return True
        return False
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=1.0,
            max_wait=10.0,
            exceptions=(Exception,),
        )
        def _check_with_retry():
            return _check()
        
        try:
            return _check_with_retry()
        except Exception:
            return False
    else:
        try:
            return _check()
        except Exception:
            return False


def restore_state_json(b2_relative_path: str) -> Optional[str]:
    """Download a JSON file from B2 and return its contents as a string.

    Returns None if the file doesn't exist or download fails.
    """
    bucket = _get_bucket()
    if bucket is None:
        return None

    key = _b2_key(b2_relative_path)
    
    def _download():
        buffer = io.BytesIO()
        bucket.download_file_by_name(key).save(buffer)
        return buffer.getvalue().decode("utf-8")
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=1.0,
            max_wait=10.0,
            exceptions=(Exception,),
        )
        def _download_with_retry():
            return _download()
        
        try:
            return _download_with_retry()
        except Exception:
            return None
    else:
        try:
            return _download()
        except Exception:
            return None


def restore_directory(b2_prefix: str, local_dir: str) -> int:
    """Download all files under a B2 prefix to a local directory.

    Args:
        b2_prefix: Prefix within the run directory (e.g. "audio/").
        local_dir: Local directory to write files to.

    Returns:
        Number of files restored.
    """
    bucket = _get_bucket()
    if bucket is None:
        return 0

    full_prefix = _b2_key(b2_prefix)
    os.makedirs(local_dir, exist_ok=True)
    count = 0

    def _restore():
        nonlocal count
        for file_version, _ in bucket.ls(full_prefix, recursive=True):
            fname = file_version.file_name
            rel = fname[len(get_run_id()) + 1:]
            if rel.startswith(b2_prefix):
                local_name = rel[len(b2_prefix):]
            else:
                local_name = os.path.basename(rel)

            local_path = os.path.join(local_dir, local_name)
            os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)

            if os.path.exists(local_path) and os.path.getsize(local_path) == file_version.size:
                logger.debug("B2 restore skip (already exists, same size): %s", local_path)
                count += 1
                continue

            try:
                bucket.download_file_by_name(fname).save_to(local_path)
                count += 1
                logger.info("B2 restored %s -> %s", fname, local_path)
            except Exception as e:
                logger.warning("B2 restore failed %s: %s", fname, e)
    
    if RESILIENCE_AVAILABLE:
        try:
            _restore()
        except Exception as e:
            logger.error("B2 restore_directory failed for prefix %s: %s", full_prefix, e)
    else:
        try:
            _restore()
        except Exception as e:
            logger.error("B2 restore_directory failed for prefix %s: %s", full_prefix, e)

    return count


# =============================================================================
# Run discovery and pipeline restore
# =============================================================================


def _list_all_run_ids() -> list[str]:
    """List all run IDs in the B2 bucket."""
    bucket = _get_bucket()
    if bucket is None:
        return []

    def _list():
        seen_runs = []
        for file_version, _ in bucket.ls("", recursive=True):
            fname = file_version.file_name
            parts = fname.split("/", 1)
            if len(parts) >= 2:
                run_id = parts[0]
                if run_id and run_id not in seen_runs:
                    seen_runs.append(run_id)
        seen_runs.sort()
        return seen_runs
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=1.0,
            max_wait=10.0,
            exceptions=(Exception,),
        )
        def _list_with_retry():
            return _list()
        
        try:
            return _list_with_retry()
        except Exception as e:
            logger.error("B2 _list_all_run_ids failed: %s", e)
            return []
    else:
        try:
            return _list()
        except Exception as e:
            logger.error("B2 _list_all_run_ids failed: %s", e)
            return []


def _read_run_state(run_id: str) -> Optional[dict]:
    """Download and parse pipeline_state.json for a specific run."""
    bucket = _get_bucket()
    if bucket is None:
        return None

    key = f"{run_id}/state/pipeline_state.json"
    
    def _read():
        buffer = io.BytesIO()
        bucket.download_file_by_name(key).save(buffer)
        return json.loads(buffer.getvalue().decode("utf-8"))
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=2,
            min_wait=1.0,
            max_wait=5.0,
            exceptions=(Exception,),
        )
        def _read_with_retry():
            return _read()
        
        try:
            return _read_with_retry()
        except Exception:
            return None
    else:
        try:
            return _read()
        except Exception:
            return None


def find_latest_run_id(topic: str = "") -> Optional[str]:
    """Find the most recent run ID in the B2 bucket that matches the topic."""
    if not topic:
        return None

    all_runs = _list_all_run_ids()
    if not all_runs:
        return None

    safe_topic = "".join(c if c.isalnum() else "_" for c in topic.lower())[:30]

    content_matches = []
    prefix_matches = []
    
    for rid in all_runs:
        if safe_topic and rid.startswith(safe_topic):
            prefix_matches.append(rid)

        state = _read_run_state(rid)
        if state and state.get("topic", "").strip().lower() == topic.strip().lower():
            content_matches.append(rid)
            logger.info("B2: run '%s' matches topic '%s' (content match)", rid, topic)

    matches = content_matches or prefix_matches
    if not matches:
        logger.info("B2: no run matches topic '%s' (checked %d runs)", topic, len(all_runs))
        return None

    matches.sort()
    best = matches[-1]
    match_type = "content" if best in content_matches else "prefix"
    logger.info("B2: selected run '%s' for topic '%s' (%s match)", best, topic, match_type)
    return best


def restore_pipeline(topic: str, pipeline_base: str = "/tmp/documentary-pipeline") -> dict:
    """Restore full pipeline state from B2 for a given topic.

    Checks B2 for the latest run with this topic, downloads all artifacts
    to the local pipeline directories, and returns info about which stages
    are already complete.

    Args:
        topic: Documentary topic (used to find the matching run).
        pipeline_base: Local base directory for pipeline artifacts.

    Returns:
        Dict with run_id, stages_complete, restored_files, state.
    """
    result = {
        "run_id": "",
        "stages_complete": [],
        "restored_files": 0,
        "state": {},
    }

    run_id = find_latest_run_id(topic)
    if not run_id:
        logger.info("B2: no previous run found for topic '%s'", topic)
        return result

    logger.info("B2: found previous run '%s', restoring...", run_id)
    set_run_id(run_id)
    result["run_id"] = run_id

    # Check which stages are complete
    for stage in ("scenario", "audio", "visual_direction", "production", "assembly"):
        if check_stage_complete(stage):
            result["stages_complete"].append(stage)
            logger.info("B2: stage '%s' already complete", stage)

    # Restore pipeline state
    state_json = restore_state_json("state/pipeline_state.json")
    if state_json:
        try:
            result["state"] = json.loads(state_json)
            logger.info("B2: restored pipeline state (%d keys)", len(result["state"]))
        except json.JSONDecodeError:
            pass

    # Restore individual state files
    for name in ("scenes", "visual_style", "visual_concepts"):
        content = restore_state_json(f"state/{name}.json")
        if content:
            result["state"][name] = content
            logger.info("B2: restored state/%s.json", name)

    # Restore directories
    dirs_to_restore = {
        "audio/": os.path.join(pipeline_base, "audio"),
        "video/": os.path.join(pipeline_base, "video"),
        "timelines/": os.path.join(pipeline_base, "timelines"),
        "assembly/": os.path.join(pipeline_base, "assembly"),
        "output/": os.path.join(pipeline_base, "output"),
    }

    total = 0
    for b2_prefix, local_dir in dirs_to_restore.items():
        n = restore_directory(b2_prefix, local_dir)
        total += n
        if n > 0:
            logger.info("B2: restored %d files from %s -> %s", n, b2_prefix, local_dir)

    result["restored_files"] = total

    # Validate restored stages
    _STAGE_FILE_REQUIREMENTS = {
        "audio": (os.path.join(pipeline_base, "audio"), ".wav"),
        "production": (os.path.join(pipeline_base, "video"), ".mp4"),
        "assembly": (os.path.join(pipeline_base, "output"), ".mp4"),
    }
    invalid_stages = []
    for stage, (required_dir, required_ext) in _STAGE_FILE_REQUIREMENTS.items():
        if stage not in result["stages_complete"]:
            continue
        if not os.path.isdir(required_dir):
            invalid_stages.append(stage)
            logger.warning(
                "B2: stage '%s' marked complete but directory %s missing — will re-run",
                stage, required_dir,
            )
            continue
        matching = [f for f in os.listdir(required_dir) if f.endswith(required_ext)]
        if not matching:
            invalid_stages.append(stage)
            logger.warning(
                "B2: stage '%s' marked complete but no %s files in %s — will re-run",
                stage, required_ext, required_dir,
            )

    # Remove invalid stages and all stages that depend on them
    if invalid_stages:
        stage_order = ["scenario", "audio", "visual_direction", "production", "assembly"]
        earliest_idx = min(stage_order.index(s) for s in invalid_stages if s in stage_order)
        for s in stage_order[earliest_idx:]:
            if s in result["stages_complete"]:
                result["stages_complete"].remove(s)
                logger.info("B2: invalidated stage '%s' (missing files or downstream dependency)", s)

    logger.info(
        "B2 restore complete: run_id=%s, stages=%s, files=%d",
        run_id, result["stages_complete"], total,
    )
    return result


# =============================================================================
# Health check
# =============================================================================


def check_b2_health() -> dict:
    """Check B2 storage health."""
    try:
        start = time.time()
        bucket = _get_bucket()
        elapsed = time.time() - start
        
        if bucket:
            return {
                "status": "healthy",
                "response_time_ms": round(elapsed * 1000, 2),
                "bucket": bucket.name,
            }
        return {
            "status": "unhealthy",
            "error": _b2_init_error or "Failed to initialize B2 connection",
        }
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}


# Register health check
if RESILIENCE_AVAILABLE:
    from resilience import health_checker
    health_checker.register("b2_storage", check_b2_health)
