"""
Video generation tools -- LTX-2.3 + ffprobe wrappers with resilience patterns.

For production: generates video clips using LTX-2.3 on GPU VM.
For test run: generates solid-color MP4 files with correct duration using ffmpeg.

RESILIENCE FEATURES:
- Retry with exponential backoff for video worker calls
- Circuit breaker for failing video workers
- Graceful degradation (fallback to solid-color video in test mode)
- Round-robin load balancing across multiple workers
- Comprehensive timeout handling
- Connection pooling and keep-alive
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import subprocess
import threading
import time
from typing import Optional
from urllib.error import URLError, HTTPError
from urllib.request import Request, urlopen

from google.adk.tools import FunctionTool

# Import resilience module
try:
    from resilience import (
        with_retry, circuit_breaker, CircuitBreaker,
        GPUWorkerError, TimeoutError, ExternalAPIError,
        graceful_degradation, timeout, resilient_context,
        retry_with_backoff, safe_execute,
    )
    RESILIENCE_AVAILABLE = True
except ImportError:
    RESILIENCE_AVAILABLE = False
    logging.warning("Resilience module not available, using fallback error handling")

logger = logging.getLogger(__name__)

_OUTPUT_BASE = os.environ.get("VIDEO_OUTPUT_DIR", "/tmp/documentary-pipeline/video")
_TEST_MODE = os.environ.get("DOCUMENTARY_TEST_MODE", "").strip().lower() in ("1", "true")
_TRIM_MARGIN = 1.15  # 15% longer for trim margin

# =============================================================================
# Circuit Breaker for Video Worker
# =============================================================================

_video_circuit_breaker = None
if RESILIENCE_AVAILABLE:
    _video_circuit_breaker = CircuitBreaker(
        name="video_worker",
        failure_threshold=5,
        recovery_timeout=120.0,
        half_open_max_calls=2,
        expected_exception=(Exception,),
    )

# =============================================================================
# Round-robin load balancing for multiple workers
# =============================================================================

_worker_lock = threading.Lock()
_worker_index = 0
_worker_failures: dict[str, int] = {}
_worker_failure_lock = threading.Lock()


def _get_next_worker_url() -> str:
    """Get the next GPU worker URL using round-robin distribution.

    Reads VIDEO_WORKER_URLS (comma-separated) for multiple workers,
    falls back to VIDEO_WORKER_URL or GPU_WORKER_URL for single worker.
    
    Tracks worker failures and temporarily excludes failing workers.
    """
    global _worker_index

    # Check for multiple workers first
    urls_str = os.environ.get("VIDEO_WORKER_URLS", "")
    if urls_str:
        urls = [u.strip() for u in urls_str.split(",") if u.strip()]
        
        # Filter out workers with too many recent failures
        with _worker_failure_lock:
            healthy_urls = [
                u for u in urls 
                if _worker_failures.get(u, 0) < 3
            ]
        
        # Use healthy workers if available, otherwise reset and use all
        if healthy_urls:
            urls = healthy_urls
        else:
            # All workers failing, reset failure counts
            with _worker_failure_lock:
                _worker_failures.clear()
        
        if urls:
            with _worker_lock:
                url = urls[_worker_index % len(urls)]
                _worker_index += 1
            return url

    # Single worker fallback
    return os.environ.get("VIDEO_WORKER_URL", "") or os.environ.get("GPU_WORKER_URL", "")


def _record_worker_failure(url: str):
    """Record a worker failure."""
    with _worker_failure_lock:
        _worker_failures[url] = _worker_failures.get(url, 0) + 1
        logger.warning("Recorded failure for worker %s (count: %d)", url, _worker_failures[url])


def _record_worker_success(url: str):
    """Record a worker success (resets failure count)."""
    with _worker_failure_lock:
        if url in _worker_failures:
            del _worker_failures[url]


# =============================================================================
# Test mode video generation
# =============================================================================


def _generate_solid_color_mp4(
    output_path: str,
    duration: float,
    width: int = 1280,
    height: int = 720,
    fps: int = 24,
    color: str = "0x336699",
) -> bool:
    """Generate a solid-color MP4 file using ffmpeg (for testing)."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    cmd = [
        "ffmpeg",
        "-y",
        "-f", "lavfi",
        "-i", f"color=c={color}:s={width}x{height}:d={duration:.2f}:r={fps}",
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-t", f"{duration:.2f}",
        output_path,
    ]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        logger.error("ffmpeg failed: %s", e)
        return False


# =============================================================================
# Video worker communication with resilience
# =============================================================================


def _call_video_worker(
    video_url: str,
    prompt: str,
    negative_prompt: str,
    visual_style: str,
    duration_sec: float,
    width: int,
    height: int,
    num_frames: int,
    seed: int,
    num_inference_steps: int = 30,
    guidance_scale: float = 3.0,
    stg_scale: float = 1.0,
    modality_scale: float = 3.0,
    guidance_rescale: float = 0.7,
    stg_blocks: Optional[list] = None,
    timeout_sec: float = 3600.0,
) -> dict:
    """Call video worker with retry logic and circuit breaker.
    
    Args:
        video_url: URL of the video worker endpoint
        prompt: Visual description prompt
        negative_prompt: Negative prompt
        visual_style: Visual style description
        duration_sec: Target duration
        width: Video width
        height: Video height
        num_frames: Number of frames
        seed: Random seed
        num_inference_steps: Number of inference steps
        guidance_scale: Guidance scale
        stg_scale: STG scale
        modality_scale: Modality scale
        guidance_rescale: Guidance rescale
        stg_blocks: STG block indices
        timeout_sec: Request timeout
    
    Returns:
        Dict with mp4_bytes, gen_time, qa_quality, qa_reason, qa_attempts, qa_seed
    
    Raises:
        GPUWorkerError: If video worker call fails
        TimeoutError: If request times out
    """
    payload = json.dumps({
        "prompt": prompt,
        "negative_prompt": negative_prompt,
        "visual_style": visual_style,
        "duration_sec": duration_sec,
        "width": width,
        "height": height,
        "num_frames": num_frames,
        "seed": seed,
        "num_inference_steps": num_inference_steps,
        "guidance_scale": guidance_scale,
        "stg_scale": stg_scale,
        "modality_scale": modality_scale,
        "guidance_rescale": guidance_rescale,
        "stg_blocks": stg_blocks if stg_blocks is not None else [28],
    }).encode("utf-8")
    
    req = Request(video_url, data=payload, headers={
        "Content-Type": "application/json",
        "Connection": "keep-alive",
    })
    
    def _make_request():
        start = time.time()
        with urlopen(req, timeout=timeout_sec) as resp:
            result_bytes = resp.read()
            elapsed = time.time() - start
            
            qa_quality = resp.headers.get("X-QA-Quality", "unknown")
            qa_reason_raw = resp.headers.get("X-QA-Reason", "")
            
            # Decode QA reason
            try:
                qa_reason = base64.b64decode(qa_reason_raw).decode("utf-8") if qa_reason_raw else ""
            except Exception:
                qa_reason = qa_reason_raw
            
            # Check for QA rejection
            if qa_quality == "rejected":
                raise GPUWorkerError(
                    f"QA REJECTED: {qa_reason}",
                    worker_type="video",
                    details={"qa_reason": qa_reason}
                )
            
            return {
                "mp4_bytes": result_bytes,
                "gen_time": float(resp.headers.get("X-Gen-Time", str(elapsed))),
                "qa_quality": qa_quality,
                "qa_reason": qa_reason,
                "qa_attempts": int(resp.headers.get("X-QA-Attempts", "1")),
                "qa_seed": int(resp.headers.get("X-QA-Seed", str(seed))),
            }
    
    # Apply retry logic
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=5.0,
            max_wait=60.0,
            exceptions=(URLError, HTTPError, TimeoutError, Exception),
            retry_on_result=lambda r: r.get("qa_quality") == "poor",
        )
        def _request_with_retry():
            if _video_circuit_breaker:
                return _video_circuit_breaker(_make_request)()
            return _make_request()
        
        try:
            return _request_with_retry()
        except Exception as e:
            raise GPUWorkerError(
                f"Video worker call failed: {e}",
                worker_type="video",
                details={"url": video_url, "prompt_preview": prompt[:100]}
            )
    else:
        # Fallback without resilience module
        last_error = None
        for attempt in range(3):
            try:
                return _make_request()
            except Exception as e:
                last_error = e
                if attempt < 2:
                    wait_time = 5.0 * (attempt + 1)
                    logger.warning("Retry %d/3 for video: %s", attempt + 1, e)
                    time.sleep(wait_time)
        
        raise RuntimeError(f"Video worker call failed after 3 attempts: {last_error}")


# =============================================================================
# Main video generation function
# =============================================================================


def generate_video_clip(
    prompt: str,
    duration_sec: float,
    lora_id: str,
    lora_weight: float,
    output_path: str,
    negative_prompt: str = "",
    visual_style: str = "",
    tool_context=None,
) -> str:
    """Generate a video clip using LTX-2.3 with resilience patterns.

    Args:
        prompt: Visual description prompt for video generation.
        duration_sec: Target duration in seconds (will be extended by 15%).
        lora_id: LoRA style identifier.
        lora_weight: LoRA weight (0.0-1.0).
        output_path: Path for the output MP4 file.
        negative_prompt: Per-clip negative prompt from visual_style.avoid.
        visual_style: Movie-level visual style description for QA enforcement.

    Returns:
        JSON string with generation results.
    """
    actual_duration = duration_sec * _TRIM_MARGIN

    if _TEST_MODE:
        success = _generate_solid_color_mp4(output_path, actual_duration)
        if not success:
            return json.dumps({
                "status": "error",
                "error": "Failed to generate test video via ffmpeg",
            })

        logger.info("Test mode: generated solid-color MP4 %s (%.2fs)", output_path, actual_duration)
        return json.dumps({
            "status": "generated",
            "mode": "test",
            "output_path": output_path,
            "target_duration": round(duration_sec, 2),
            "actual_duration": round(actual_duration, 2),
            "lora_id": lora_id,
            "lora_weight": lora_weight,
            "resolution": "1280x720",
            "fps": 24,
        })

    # Production mode: call LTX-2.3 on GPU worker
    gpu_worker_url = _get_next_worker_url()
    if not gpu_worker_url:
        raise RuntimeError(
            "No video worker URL configured. Set VIDEO_WORKER_URLS or "
            "GPU_WORKER_URL to at least one LTX-dedicated GPU VM. "
            "The pipeline MUST NOT fall back to placeholder video."
        )

    # Calculate frame count: LTX-2.3 works with 8k+1 frames at 24fps
    fps = 24
    raw_frames = int(actual_duration * fps)
    num_frames = max(9, ((raw_frames - 1) // 8) * 8 + 1)

    # Deterministic seed
    seed = int(hashlib.sha256(prompt.encode()).hexdigest()[:8], 16) % (2**31)

    video_url = f"{gpu_worker_url.rstrip('/')}/video"
    
    try:
        # Call video worker with retry and load balancing
        gpu_result = _call_video_worker(
            video_url=video_url,
            prompt=prompt,
            negative_prompt=negative_prompt,
            visual_style=visual_style,
            duration_sec=actual_duration,
            width=512,
            height=320,
            num_frames=num_frames,
            seed=seed,
            num_inference_steps=30,
            guidance_scale=3.0,
            stg_scale=1.0,
            modality_scale=3.0,
            guidance_rescale=0.7,
            stg_blocks=[28],
            timeout_sec=3600.0,
        )
        
        # Record success for load balancing
        _record_worker_success(gpu_worker_url)
        
        mp4_bytes = gpu_result["mp4_bytes"]
        gen_time = gpu_result["gen_time"]
        qa_quality = gpu_result["qa_quality"]
        qa_reason = gpu_result["qa_reason"]
        qa_attempts = gpu_result["qa_attempts"]
        qa_seed = gpu_result["qa_seed"]

        # Client-side QA rejection gate
        if qa_quality == "poor":
            raise GPUWorkerError(
                f"Video clip REJECTED by QA (quality='poor'): {qa_reason}",
                worker_type="video",
                details={"qa_reason": qa_reason, "output_path": output_path}
            )
        
        if qa_quality == "unknown":
            logger.warning("Video clip QA returned 'unknown' for %s", output_path)
            if os.environ.get("STRICT_QA", "").lower() in ("1", "true"):
                raise GPUWorkerError(
                    f"Video clip QA unavailable (quality='unknown'): {qa_reason}",
                    worker_type="video",
                )

        # Write video to disk
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(mp4_bytes)

        # Write per-clip status
        clip_dir = os.path.dirname(output_path) or "."
        clip_name = os.path.splitext(os.path.basename(output_path))[0]
        status_path = os.path.join(clip_dir, f"{clip_name}_status.json")
        clip_status = {
            "quality": qa_quality,
            "qa_reason": qa_reason,
            "attempts": qa_attempts,
            "seed": qa_seed,
            "status": "completed",
            "prompt_preview": prompt[:200],
            "prompt_full": prompt,
        }
        try:
            with open(status_path, "w") as sf:
                json.dump(clip_status, sf, indent=2)
            logger.info("Wrote clip status: %s (quality=%s)", status_path, qa_quality)
        except OSError as e:
            logger.warning("Failed to write clip status %s: %s", status_path, e)

        # Upload to B2
        try:
            from tools.b2_checkpoint import upload_video_clip
            upload_video_clip(output_path, status_path)
        except Exception as b2_err:
            logger.warning("B2 upload failed for video clip %s: %s", output_path, b2_err)

        # Probe actual duration
        actual_dur = actual_duration
        try:
            probe_result = json.loads(probe_clip(output_path))
            actual_dur = probe_result.get("duration", actual_duration)
        except Exception as probe_exc:
            logger.warning("probe_clip failed (non-fatal): %s", probe_exc)

        logger.info(
            "Generated video clip %s (%.2fs, gen=%.1fs, lora=%s@%.2f, qa=%s)",
            output_path, actual_dur, gen_time, lora_id, lora_weight, qa_quality,
        )
        
        return json.dumps({
            "status": "generated",
            "mode": "production",
            "output_path": output_path,
            "target_duration": round(duration_sec, 2),
            "actual_duration": round(actual_dur, 2),
            "lora_id": lora_id,
            "lora_weight": lora_weight,
            "prompt_preview": prompt[:200],
            "prompt_full": prompt,
            "gen_time": round(gen_time, 2),
            "num_frames": num_frames,
            "resolution": "512x320",
            "qa_quality": qa_quality,
            "qa_reason": qa_reason,
            "qa_attempts": qa_attempts,
            "qa_seed": qa_seed,
        })
        
    except Exception as e:
        # Record failure for load balancing
        _record_worker_failure(gpu_worker_url)
        
        logger.error("Video generation failed for %s: %s", output_path, e)
        if RESILIENCE_AVAILABLE:
            if isinstance(e, GPUWorkerError):
                raise
            raise GPUWorkerError(
                f"Video generation failed: {e}",
                worker_type="video",
                details={"output_path": output_path, "prompt_preview": prompt[:100]}
            )
        raise


# =============================================================================
# Video probe with resilience
# =============================================================================


def probe_clip(mp4_path: str, tool_context=None) -> str:
    """Probe an MP4 file for duration, resolution, and FPS using ffprobe.

    Args:
        mp4_path: Path to the MP4 file.

    Returns:
        JSON string with clip metadata.
    """
    if not os.path.exists(mp4_path):
        return json.dumps({"error": f"File not found: {mp4_path}"})

    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        mp4_path,
    ]
    
    def _probe():
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return json.dumps({
                "error": f"ffprobe failed (rc={result.returncode})",
                "stderr": result.stderr[:500],
            })

        probe_data = json.loads(result.stdout)

        # Extract info from first video stream
        video_stream = None
        for stream in probe_data.get("streams", []):
            if stream.get("codec_type") == "video":
                video_stream = stream
                break

        duration = float(probe_data.get("format", {}).get("duration", 0))
        width = int(video_stream.get("width", 0)) if video_stream else 0
        height = int(video_stream.get("height", 0)) if video_stream else 0
        fps_str = video_stream.get("r_frame_rate", "0/1") if video_stream else "0/1"

        # Parse fractional FPS
        fps_parts = fps_str.split("/")
        if len(fps_parts) == 2 and int(fps_parts[1]) > 0:
            fps = round(int(fps_parts[0]) / int(fps_parts[1]), 2)
        else:
            fps = float(fps_parts[0]) if fps_parts[0] else 0.0

        return json.dumps({
            "mp4_path": mp4_path,
            "duration": round(duration, 3),
            "width": width,
            "height": height,
            "fps": fps,
            "resolution": f"{width}x{height}",
        })
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=2,
            min_wait=1.0,
            max_wait=5.0,
            exceptions=(Exception,),
        )
        def _probe_with_retry():
            return _probe()
        
        try:
            return _probe_with_retry()
        except Exception as e:
            return json.dumps({"error": f"ffprobe failed: {e}"})
    else:
        try:
            return _probe()
        except subprocess.TimeoutExpired:
            return json.dumps({"error": "ffprobe timed out"})
        except (json.JSONDecodeError, ValueError) as e:
            return json.dumps({"error": f"ffprobe output parse error: {e}"})


# =============================================================================
# Health check
# =============================================================================


def check_video_worker_health() -> dict:
    """Check video worker health."""
    urls_str = os.environ.get("VIDEO_WORKER_URLS", "")
    if urls_str:
        urls = [u.strip() for u in urls_str.split(",") if u.strip()]
    else:
        url = os.environ.get("VIDEO_WORKER_URL", "") or os.environ.get("GPU_WORKER_URL", "")
        urls = [url] if url else []
    
    if not urls:
        return {"status": "unconfigured", "error": "No video worker URLs configured"}
    
    results = []
    for url in urls:
        try:
            health_url = f"{url.rstrip('/')}/health"
            req = Request(health_url)
            start = time.time()
            with urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            elapsed = time.time() - start
            
            if data.get("status") == "ok" and data.get("ltx_loaded", False):
                results.append({
                    "url": url,
                    "status": "healthy",
                    "response_time_ms": round(elapsed * 1000, 2),
                    "gpu": data.get("gpu", "unknown"),
                    "vram_used_gb": data.get("vram_used_gb", 0),
                })
            else:
                results.append({
                    "url": url,
                    "status": "unhealthy",
                    "ltx_loaded": data.get("ltx_loaded", False),
                    "bootstrap_phase": data.get("bootstrap", {}).get("phase", "unknown"),
                })
        except Exception as e:
            results.append({"url": url, "status": "unhealthy", "error": str(e)})
    
    healthy_count = sum(1 for r in results if r.get("status") == "healthy")
    return {
        "status": "healthy" if healthy_count > 0 else "unhealthy",
        "workers": results,
        "healthy_count": healthy_count,
        "total_count": len(results),
    }


# Register health check
if RESILIENCE_AVAILABLE:
    from resilience import health_checker
    health_checker.register("video_worker", check_video_worker_health)


# =============================================================================
# ADK FunctionTool wrappers
# =============================================================================

generate_video_clip_tool = FunctionTool(generate_video_clip)
probe_clip_tool = FunctionTool(probe_clip)

video_tools = [generate_video_clip_tool, probe_clip_tool]
