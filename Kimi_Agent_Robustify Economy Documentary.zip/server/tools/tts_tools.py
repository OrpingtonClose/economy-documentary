"""
TTS tools -- Qwen3-TTS generation wrapper with resilience patterns.

For production: generates narration WAV files using Qwen3-TTS on GPU.
For test run: generates silent WAV files with correct estimated duration (no GPU).

RESILIENCE FEATURES:
- Retry with exponential backoff for TTS worker calls
- Circuit breaker for failing TTS workers
- Graceful degradation (fallback to silent audio in test mode)
- Comprehensive timeout handling
- Connection pooling and keep-alive
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import wave
from contextlib import contextmanager
from typing import Optional
from urllib.error import URLError, HTTPError
from urllib.request import Request, urlopen

from google.adk.tools import FunctionTool

# Import resilience module
try:
    from resilience import (
        with_retry, circuit_breaker, CircuitBreaker,
        GPUWorkerError, TimeoutError, ExternalAPIError,
        graceful_degradation, timeout, resilient_context,
        retry_with_backoff, safe_execute,
    )
    RESILIENCE_AVAILABLE = True
except ImportError:
    RESILIENCE_AVAILABLE = False
    logging.warning("Resilience module not available, using fallback error handling")

logger = logging.getLogger(__name__)

_OUTPUT_BASE = os.environ.get("TTS_OUTPUT_DIR", "/tmp/documentary-pipeline/audio")
_TEST_MODE = os.environ.get("DOCUMENTARY_TEST_MODE", "").strip().lower() in ("1", "true")

# Approximate speech rate: ~0.3s per word (for test duration estimation)
_SECONDS_PER_WORD = 0.3
_SAMPLE_RATE = 24000

# =============================================================================
# Circuit Breaker for TTS Worker
# =============================================================================

_tts_circuit_breaker = None
if RESILIENCE_AVAILABLE:
    _tts_circuit_breaker = CircuitBreaker(
        name="tts_worker",
        failure_threshold=5,
        recovery_timeout=60.0,
        half_open_max_calls=2,
        expected_exception=(Exception,),
    )


# =============================================================================
# Utility functions
# =============================================================================


def _estimate_duration(text: str) -> float:
    """Estimate speech duration from text length."""
    word_count = len(text.split())
    return max(1.0, word_count * _SECONDS_PER_WORD)


def _generate_silent_wav(output_path: str, duration: float) -> None:
    """Generate a silent WAV file with the specified duration."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    num_frames = int(_SAMPLE_RATE * duration)
    with wave.open(output_path, "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(_SAMPLE_RATE)
        silent_data = b'\x00' * (num_frames * 2)
        wf.writeframes(silent_data)


# =============================================================================
# TTS Worker communication with resilience
# =============================================================================


def _call_tts_worker(
    tts_url: str,
    text: str,
    voice: str,
    language: str,
    scene_num: int,
    timeout_sec: float = 300.0,
) -> dict:
    """Call TTS worker with retry logic and circuit breaker.
    
    Args:
        tts_url: URL of the TTS worker endpoint
        text: Text to synthesize
        voice: Voice identifier
        language: Language code
        scene_num: Scene number
        timeout_sec: Request timeout in seconds
    
    Returns:
        Dict with wav_bytes, actual_duration, actual_sample_rate, gen_time
    
    Raises:
        GPUWorkerError: If TTS worker call fails
        TimeoutError: If request times out
    """
    payload = json.dumps({
        "text": text,
        "voice": voice,
        "language": language,
        "scene_num": scene_num,
    }).encode("utf-8")
    
    req = Request(tts_url, data=payload, headers={
        "Content-Type": "application/json",
        "Connection": "keep-alive",
    })
    
    def _make_request():
        start = time.time()
        with urlopen(req, timeout=timeout_sec) as resp:
            result_bytes = resp.read()
            elapsed = time.time() - start
            
            return {
                "wav_bytes": result_bytes,
                "actual_duration": float(resp.headers.get("X-Audio-Duration", "0")),
                "actual_sample_rate": int(resp.headers.get("X-Sample-Rate", str(_SAMPLE_RATE))),
                "gen_time": float(resp.headers.get("X-Gen-Time", str(elapsed))),
            }
    
    # Apply retry logic
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=2.0,
            max_wait=30.0,
            exceptions=(URLError, HTTPError, TimeoutError, Exception),
            retry_on_result=lambda r: len(r.get("wav_bytes", b"")) == 0,
        )
        def _request_with_retry():
            if _tts_circuit_breaker:
                return _tts_circuit_breaker(_make_request)()
            return _make_request()
        
        try:
            return _request_with_retry()
        except Exception as e:
            raise GPUWorkerError(
                f"TTS worker call failed: {e}",
                worker_type="tts",
                details={"url": tts_url, "scene": scene_num, "voice": voice}
            )
    else:
        # Fallback without resilience module
        last_error = None
        for attempt in range(3):
            try:
                return _make_request()
            except Exception as e:
                last_error = e
                if attempt < 2:
                    wait_time = 2.0 * (attempt + 1)
                    logger.warning("Retry %d/3 for TTS: %s", attempt + 1, e)
                    time.sleep(wait_time)
        
        raise RuntimeError(f"TTS worker call failed after 3 attempts: {last_error}")


# =============================================================================
# Main TTS generation function with graceful degradation
# =============================================================================


def generate_narration(
    scene_num: int,
    voice_role: str,
    text: str,
    output_dir: str = "",
    language: str = "",
    tool_context=None,
) -> str:
    """Generate narration WAV file using Qwen3-TTS with resilience patterns.

    Args:
        scene_num: Scene number (1-based).
        voice_role: Voice role identifier (e.g., "V1", "V2", "V3").
        text: Narration text to synthesize.
        output_dir: Optional output directory override.
        language: Explicit language code ("en" or "ru"). If empty,
                  inferred from voice_role suffix (e.g., "V1_RU" -> "ru").

    Returns:
        JSON string with WAV path and duration.
    """
    out_dir = output_dir or _OUTPUT_BASE
    os.makedirs(out_dir, exist_ok=True)

    filename = f"scene_{scene_num:03d}_{voice_role}.wav"
    wav_path = os.path.join(out_dir, filename)

    duration = _estimate_duration(text)

    # Skip regeneration if WAV already exists and matches current text
    text_hash = hashlib.sha256(text.encode()).hexdigest()[:12]
    sidecar_path = wav_path.replace(".wav", ".txt")
    
    if os.path.isfile(wav_path) and os.path.getsize(wav_path) > 0:
        text_matches = False
        if os.path.isfile(sidecar_path):
            try:
                with open(sidecar_path, "r") as sf:
                    cached_hash = sf.read().strip()
                text_matches = cached_hash == text_hash
            except OSError:
                pass
        
        if not text_matches:
            logger.info("Text changed for %s, regenerating", wav_path)
        else:
            # Read actual duration from WAV header
            try:
                with wave.open(wav_path, "r") as wf:
                    actual_duration = wf.getnframes() / wf.getframerate()
                    actual_sr = wf.getframerate()
                logger.info("Skipping existing WAV %s (%.2fs)", wav_path, actual_duration)
                return json.dumps({
                    "status": "skipped",
                    "mode": "cached",
                    "wav_path": wav_path,
                    "duration": round(actual_duration, 2),
                    "sample_rate": actual_sr,
                    "text_length": len(text),
                    "word_count": len(text.split()),
                })
            except wave.Error:
                logger.warning("Corrupt WAV %s, regenerating", wav_path)

    def _write_sidecar(path: str, h: str) -> None:
        """Write text hash sidecar so cache can detect stale content."""
        try:
            with open(path, "w") as f:
                f.write(h)
        except OSError:
            pass

    if _TEST_MODE:
        # Test mode: generate silent WAV with correct duration
        _generate_silent_wav(wav_path, duration)
        if os.path.isfile(sidecar_path):
            os.remove(sidecar_path)
        logger.info("Test mode: generated silent WAV %s (%.2fs)", wav_path, duration)
        return json.dumps({
            "status": "generated",
            "mode": "test",
            "wav_path": wav_path,
            "duration": round(duration, 2),
            "sample_rate": _SAMPLE_RATE,
            "text_length": len(text),
            "word_count": len(text.split()),
        })

    # Production mode: call Qwen3-TTS on GPU worker
    gpu_worker_url = os.environ.get("TTS_WORKER_URL", "")
    if not gpu_worker_url:
        raise RuntimeError(
            "TTS_WORKER_URL is not set. A dedicated TTS worker VM is REQUIRED "
            "for production runs. The pipeline MUST NOT fall back to silent audio "
            "because all video timing depends on real narration. "
            "Provision a TTS VM and set TTS_WORKER_URL before restarting."
        )

    # Determine language
    voice = voice_role
    if voice_role.endswith("_RU"):
        voice = voice_role[:-3]
        lang = language if language else "ru"
    elif voice_role.endswith("_EN"):
        voice = voice_role[:-3]
        lang = language if language else "en"
    else:
        lang = language if language else "en"

    tts_url = f"{gpu_worker_url.rstrip('/')}/tts"
    
    try:
        # Call TTS worker with retry logic
        tts_result = _call_tts_worker(
            tts_url=tts_url,
            text=text,
            voice=voice,
            language=lang,
            scene_num=scene_num,
            timeout_sec=300.0,
        )
        
        wav_bytes = tts_result["wav_bytes"]
        actual_duration = tts_result["actual_duration"]
        actual_sample_rate = tts_result["actual_sample_rate"]
        gen_time = tts_result["gen_time"]

        # Write WAV file
        os.makedirs(os.path.dirname(wav_path) or ".", exist_ok=True)
        with open(wav_path, "wb") as f:
            f.write(wav_bytes)
        
        # Write sidecar for caching
        _write_sidecar(sidecar_path, text_hash)

        logger.info(
            "Generated narration WAV %s (%.2fs, gen=%.1fs, %d words)",
            wav_path, actual_duration, gen_time, len(text.split()),
        )

        # Upload to B2
        try:
            from tools.b2_checkpoint import upload_tts_clip
            upload_tts_clip(wav_path, sidecar_path)
        except Exception as b2_err:
            logger.warning("B2 upload failed for TTS clip %s: %s", wav_path, b2_err)

        return json.dumps({
            "status": "generated",
            "mode": "production",
            "wav_path": wav_path,
            "duration": round(actual_duration, 2),
            "sample_rate": actual_sample_rate,
            "text_length": len(text),
            "word_count": len(text.split()),
            "gen_time": round(gen_time, 2),
        })
        
    except Exception as e:
        logger.error("TTS generation failed for scene %d %s: %s", scene_num, voice_role, e)
        if RESILIENCE_AVAILABLE:
            raise GPUWorkerError(
                f"TTS generation failed: {e}",
                worker_type="tts",
                details={"scene": scene_num, "voice": voice_role, "text_len": len(text)}
            )
        raise


# =============================================================================
# Graceful degradation fallback
# =============================================================================


def generate_narration_with_fallback(
    scene_num: int,
    voice_role: str,
    text: str,
    output_dir: str = "",
    language: str = "",
    tool_context=None,
) -> str:
    """Generate narration with graceful degradation to silent audio on failure."""
    
    def _fallback(*args, **kwargs):
        """Fallback: generate silent audio."""
        logger.warning("Falling back to silent audio for scene %d %s", scene_num, voice_role)
        out_dir = output_dir or _OUTPUT_BASE
        os.makedirs(out_dir, exist_ok=True)
        
        filename = f"scene_{scene_num:03d}_{voice_role}.wav"
        wav_path = os.path.join(out_dir, filename)
        duration = _estimate_duration(text)
        
        _generate_silent_wav(wav_path, duration)
        
        return json.dumps({
            "status": "generated",
            "mode": "fallback_silent",
            "wav_path": wav_path,
            "duration": round(duration, 2),
            "sample_rate": _SAMPLE_RATE,
            "text_length": len(text),
            "word_count": len(text.split()),
            "warning": "Used fallback silent audio due to TTS worker failure",
        })
    
    if RESILIENCE_AVAILABLE:
        # Apply graceful degradation decorator
        decorated = graceful_degradation(
            fallback=_fallback,
            exceptions=(GPUWorkerError, RuntimeError, Exception),
            log_degradation=True,
        )(generate_narration)
        return decorated(scene_num, voice_role, text, output_dir, language, tool_context)
    else:
        try:
            return generate_narration(scene_num, voice_role, text, output_dir, language, tool_context)
        except Exception as e:
            logger.error("TTS failed, using fallback: %s", e)
            return _fallback()


# =============================================================================
# Health check
# =============================================================================


def check_tts_worker_health() -> dict:
    """Check TTS worker health."""
    gpu_worker_url = os.environ.get("TTS_WORKER_URL", "")
    if not gpu_worker_url:
        return {"status": "unconfigured", "error": "TTS_WORKER_URL not set"}
    
    try:
        health_url = f"{gpu_worker_url.rstrip('/')}/health"
        req = Request(health_url)
        start = time.time()
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        elapsed = time.time() - start
        
        if data.get("status") == "ok" and data.get("tts_loaded", False):
            return {
                "status": "healthy",
                "response_time_ms": round(elapsed * 1000, 2),
                "gpu": data.get("gpu", "unknown"),
                "vram_used_gb": data.get("vram_used_gb", 0),
            }
        return {
            "status": "unhealthy",
            "tts_loaded": data.get("tts_loaded", False),
            "bootstrap_phase": data.get("bootstrap", {}).get("phase", "unknown"),
        }
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}


# Register health check
if RESILIENCE_AVAILABLE:
    from resilience import health_checker
    health_checker.register("tts_worker", check_tts_worker_health)


# =============================================================================
# ADK FunctionTool wrapper
# =============================================================================

generate_narration_tool = FunctionTool(generate_narration)

tts_tools = [generate_narration_tool]
