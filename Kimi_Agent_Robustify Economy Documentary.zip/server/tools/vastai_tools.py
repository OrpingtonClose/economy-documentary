"""
Vast.ai API tools -- GPU VM provisioning, status, and termination with resilience patterns.

All credentials via VAST_API_KEY env var.

RESILIENCE FEATURES:
- Retry with exponential backoff for all API calls
- Circuit breaker for failing Vast.ai services
- Comprehensive error handling with specific exception types
- Timeout handling for long-running operations
- Proper resource cleanup
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from contextlib import contextmanager
from typing import Optional

from google.adk.tools import FunctionTool

# Import resilience module
try:
    from resilience import (
        with_retry, circuit_breaker, CircuitBreaker,
        VastAIError, TimeoutError, ExternalAPIError,
        timeout, resilient_context, safe_execute,
        retry_with_backoff,
    )
    RESILIENCE_AVAILABLE = True
except ImportError:
    RESILIENCE_AVAILABLE = False
    logging.warning("Resilience module not available, using fallback error handling")

from worker_provisioner import resolve_docker_image

logger = logging.getLogger(__name__)

_TEST_MODE = os.environ.get("DOCUMENTARY_TEST_MODE", "").strip().lower() in ("1", "true")

# =============================================================================
# Circuit Breaker for Vast.ai API
# =============================================================================

_vastai_circuit_breaker = None
if RESILIENCE_AVAILABLE:
    _vastai_circuit_breaker = CircuitBreaker(
        name="vastai_tools_api",
        failure_threshold=5,
        recovery_timeout=120.0,
        half_open_max_calls=2,
        expected_exception=(Exception,),
    )

# =============================================================================
# VM ownership registry (GAP 2.1)
# =============================================================================
_OWNED_VMS_FILE = "/tmp/documentary-pipeline/_owned_instances.json"


def _load_owned_vms() -> set[str]:
    """Load the set of VM IDs created by this pipeline run."""
    try:
        with open(_OWNED_VMS_FILE) as f:
            return set(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        return set()


def _save_owned_vms(vms: set[str]) -> None:
    """Persist the owned-VM set to disk."""
    os.makedirs(os.path.dirname(_OWNED_VMS_FILE), exist_ok=True)
    with open(_OWNED_VMS_FILE, "w") as f:
        json.dump(sorted(vms), f)


def register_owned_vm(vm_id: str) -> None:
    """Register a VM as owned by this pipeline run."""
    vms = _load_owned_vms()
    vms.add(str(vm_id))
    _save_owned_vms(vms)
    logger.info("Registered owned VM: %s (total owned: %d)", vm_id, len(vms))


# =============================================================================
# Vast.ai CLI with resilience
# =============================================================================

import ast as _ast
import re as _re


def _vast_cmd(args: list[str], timeout: int = 60) -> dict | list:
    """Run a vastai CLI command and return parsed output.

    The vastai CLI v1.0 has inconsistent output formats:
    - ``search offers --raw`` returns JSON arrays
    - ``show instance --raw`` returns JSON objects
    - ``create instance`` returns Python-repr text
    - ``create instance --raw`` returns **empty** output
    - ``destroy instance`` returns plain text

    We try JSON first, then fall back to Python ``ast.literal_eval``
    to handle the repr-style create output.
    
    Args:
        args: Command arguments
        timeout: Command timeout in seconds
    """
    api_key = os.environ.get("VAST_API_KEY", "")
    if not api_key:
        error_msg = "VAST_API_KEY not set"
        if RESILIENCE_AVAILABLE:
            raise VastAIError(error_msg)
        return {"error": error_msg}

    cmd = ["vastai", "--api-key", api_key] + args
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            error_details = {
                "cmd": cmd[0],
                "args": args,
                "returncode": result.returncode,
                "stderr": result.stderr[:500],
            }
            if RESILIENCE_AVAILABLE:
                raise VastAIError(
                    f"vastai command failed (rc={result.returncode})",
                    details=error_details
                )
            return {
                "error": f"vastai command failed (rc={result.returncode})",
                "stderr": result.stderr[:500],
            }
        
        stdout = result.stdout.strip()
        if not stdout:
            return {"output": ""}
        
        # Try JSON first
        try:
            return json.loads(stdout)
        except json.JSONDecodeError:
            pass
        
        # Try Python repr
        match = _re.search(r"(\{.*\})", stdout, _re.DOTALL)
        if match:
            try:
                return _ast.literal_eval(match.group(1))
            except (ValueError, SyntaxError):
                pass
        
        return {"output": stdout}
        
    except FileNotFoundError:
        error_msg = "vastai CLI not installed"
        if RESILIENCE_AVAILABLE:
            raise VastAIError(error_msg)
        return {"error": error_msg}
    except subprocess.TimeoutExpired:
        error_msg = f"vastai command timed out after {timeout}s"
        if RESILIENCE_AVAILABLE:
            raise TimeoutError(error_msg, operation="vastai_cmd", timeout_sec=timeout)
        return {"error": error_msg}


def _vast_cmd_with_retry(args: list[str], timeout: int = 60, max_retries: int = 3) -> dict | list:
    """Run vastai CLI command with retry logic."""
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=max_retries,
            min_wait=1.0,
            max_wait=30.0,
            exceptions=(VastAIError, TimeoutError, Exception),
        )
        def _execute():
            return _vast_cmd(args, timeout)
        return _execute()
    else:
        for attempt in range(max_retries):
            try:
                return _vast_cmd(args, timeout)
            except Exception as e:
                if attempt < max_retries - 1:
                    wait_time = 1.0 * (attempt + 1)
                    logger.warning("Retry %d/%d for vastai command: %s", attempt + 1, max_retries, e)
                    time.sleep(wait_time)
                else:
                    raise


# =============================================================================
# GPU VM Provisioning with resilience
# =============================================================================


def provision_gpu_vm(
    gpu_type: str = "A100_SXM4",
    min_vram_gb: int = 48,
    max_price: float = 1.50,
    tool_context=None,
) -> str:
    """Provision a GPU VM via Vast.ai API with resilience patterns.

    LTX-2.3 with enable_model_cpu_offload() requires 48GB+ VRAM
    (Gemma3 text encoder alone is ~46GB bf16).

    Args:
        gpu_type: GPU type to request (e.g., "A100_SXM4", "L40S",
            "RTX_5090", "H200").  Use "any" to skip GPU name filter.
        min_vram_gb: Minimum VRAM in GB (must be >= 48 for LTX-2.3).
        max_price: Maximum price per hour in USD.

    Returns:
        JSON string with VM details or error.
    """
    if _TEST_MODE:
        return json.dumps({
            "status": "test_mode",
            "vm_id": "test-vm-001",
            "message": "Test mode: no actual VM provisioned",
            "gpu_type": gpu_type,
            "min_vram_gb": min_vram_gb,
            "max_price": max_price,
        })

    try:
        # Fetch offers with retry
        search_result = _vast_cmd_with_retry(
            ["search", "offers", "--type", "on-demand", "--raw"],
            timeout=60,
            max_retries=3,
        )

        if isinstance(search_result, dict) and "error" in search_result:
            return json.dumps(search_result)

        all_offers = search_result if isinstance(search_result, list) else []
        if not all_offers:
            return json.dumps({
                "status": "no_offers",
                "error": "Vast.ai returned no offers at all"
            })

        # Filter offers in Python
        min_vram_mb = min_vram_gb * 1024
        gpu_display = gpu_type.replace("_", " ").lower() if gpu_type else ""

        offers = []
        for o in all_offers:
            vram = float(o.get("gpu_ram", 0))
            price = float(o.get("dph_total", 999))
            rentable = o.get("rentable", False)
            verified = o.get("verification") not in ("unverified",)
            gpu_name = (o.get("gpu_name", "") or "").lower()

            if vram < min_vram_mb:
                continue
            if price > max_price:
                continue
            if not rentable:
                continue
            if not verified:
                continue
            if gpu_display and gpu_display != "any" and gpu_display not in gpu_name:
                continue
            offers.append(o)

        logger.info(
            "Vast.ai: %d/%d offers match (gpu_type=%s, min_vram=%dGB, max_price=$%.2f/hr)",
            len(offers), len(all_offers), gpu_type, min_vram_gb, max_price,
        )

        if not offers:
            return json.dumps({
                "status": "no_offers",
                "error": f"No matching GPU offers found (gpu_type={gpu_type}, "
                         f"min_vram_gb={min_vram_gb}, max_price=${max_price}/hr)",
                "total_offers_checked": len(all_offers),
            })

        # Sort by price
        sorted_offers = sorted(offers, key=lambda o: float(o.get("dph_total", 999)))
        best = sorted_offers[0]
        offer_id = best.get("id")
        
        if not offer_id:
            return json.dumps({
                "status": "error",
                "error": "Best offer has no ID",
                "offer": best
            })

        logger.info(
            "Selected offer %s: %s, %.1fGB VRAM, $%.3f/hr",
            offer_id,
            best.get("gpu_name", "unknown"),
            float(best.get("gpu_ram", 0)) / 1024,
            float(best.get("dph_total", 0)),
        )

        # Create instance
        _docker_image, _torch_index = resolve_docker_image("ltx")
        
        create_result = _vast_cmd_with_retry(
            [
                "create", "instance",
                str(offer_id),
                "--image", _docker_image,
                "--disk", "224",
                "--ssh",
                "--direct",
                "--env", "-p 8880:8880",
            ],
            timeout=120,
            max_retries=2,
        )

        if isinstance(create_result, dict) and "error" in create_result:
            return json.dumps(create_result)

        instance_id = create_result.get("new_contract")
        if not instance_id:
            return json.dumps({
                "status": "error",
                "error": "No instance ID in create response",
                "response": create_result
            })

        # Register as owned
        register_owned_vm(str(instance_id))

        return json.dumps({
            "status": "provisioned",
            "vm_id": str(instance_id),
            "offer_id": str(offer_id),
            "gpu_name": best.get("gpu_name", "unknown"),
            "gpu_ram_gb": round(float(best.get("gpu_ram", 0)) / 1024, 1),
            "price_per_hour": round(float(best.get("dph_total", 0)), 3),
            "message": "VM provisioned. Wait for status=running then bootstrap.",
        })

    except Exception as e:
        logger.error("Error provisioning GPU VM: %s", e)
        if RESILIENCE_AVAILABLE:
            return json.dumps({
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__,
            })
        return json.dumps({"status": "error", "error": str(e)})


def check_vm_status(vm_id: str, tool_context=None) -> str:
    """Check if a Vast.ai VM is ready with retry logic.

    Args:
        vm_id: The VM instance ID.

    Returns:
        JSON string with VM status.
    """
    if _TEST_MODE:
        return json.dumps({
            "vm_id": vm_id,
            "status": "running",
            "mode": "test",
        })

    try:
        result = _vast_cmd_with_retry(
            ["show", "instance", vm_id, "--raw"],
            timeout=30,
            max_retries=3,
        )
        return json.dumps(result)
    except Exception as e:
        logger.error("Error checking VM status: %s", e)
        return json.dumps({"error": str(e), "vm_id": vm_id})


def terminate_vm(vm_id: str, tool_context=None) -> str:
    """Stop and destroy a Vast.ai VM — ONLY if this pipeline created it.

    Args:
        vm_id: The VM instance ID to terminate.

    Returns:
        JSON string with termination result or refusal.
    """
    if _TEST_MODE:
        return json.dumps({
            "vm_id": vm_id,
            "status": "terminated",
            "mode": "test",
        })

    # Ownership guard
    owned = _load_owned_vms()
    if str(vm_id) not in owned:
        error_msg = (
            f"REFUSED: VM {vm_id} was NOT created by this pipeline run. "
            f"Owned VMs: {sorted(owned)}. "
            f"NEVER destroy VMs you didn't create — they may belong to "
            f"other processes on the shared Vast.ai account."
        )
        logger.error(error_msg)
        return json.dumps({"error": error_msg, "status": "refused"})

    try:
        result = _vast_cmd_with_retry(
            ["destroy", "instance", vm_id],
            timeout=30,
            max_retries=2,
        )
        # Remove from registry only after confirmed destruction
        if isinstance(result, dict) and "error" not in result:
            owned.discard(str(vm_id))
            _save_owned_vms(owned)
        return json.dumps(result)
    except Exception as e:
        logger.error("Error terminating VM: %s", e)
        return json.dumps({"error": str(e), "vm_id": vm_id})


def list_active_vms(tool_context=None) -> str:
    """List all running Vast.ai VMs with retry logic.

    Returns:
        JSON string with list of active VMs.
    """
    if _TEST_MODE:
        return json.dumps({
            "vms": [],
            "mode": "test",
            "message": "No VMs in test mode",
        })

    try:
        result = _vast_cmd_with_retry(
            ["show", "instances", "--raw"],
            timeout=30,
            max_retries=3,
        )
        return json.dumps(result)
    except Exception as e:
        logger.error("Error listing VMs: %s", e)
        return json.dumps({"error": str(e)})


# =============================================================================
# Health check utilities
# =============================================================================


def check_vastai_health() -> dict:
    """Check Vast.ai API health."""
    try:
        start = time.time()
        result = _vast_cmd(["show", "user", "--raw"], timeout=10)
        elapsed = time.time() - start
        
        if isinstance(result, dict) and "error" not in result:
            return {
                "status": "healthy",
                "response_time_ms": round(elapsed * 1000, 2),
                "user": result.get("username", "unknown"),
            }
        return {
            "status": "unhealthy",
            "error": result.get("error", "Unknown error"),
        }
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}


# =============================================================================
# ADK FunctionTool wrappers
# =============================================================================

provision_gpu_vm_tool = FunctionTool(provision_gpu_vm)
check_vm_status_tool = FunctionTool(check_vm_status)
terminate_vm_tool = FunctionTool(terminate_vm)
list_active_vms_tool = FunctionTool(list_active_vms)

vastai_tools = [
    provision_gpu_vm_tool,
    check_vm_status_tool,
    terminate_vm_tool,
    list_active_vms_tool,
]


# Register health check
if RESILIENCE_AVAILABLE:
    from resilience import health_checker
    health_checker.register("vastai", check_vastai_health)
