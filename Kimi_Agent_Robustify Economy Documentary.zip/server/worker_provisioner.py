"""
Worker provisioner — automatic GPU worker lifecycle management with resilience patterns.

Architecture: **parallel lazy provisioning**

Instead of blocking the entire pipeline until all workers are ready,
provisioning runs in background threads.  The pipeline starts immediately
(scenario generation needs no GPU) and each stage waits only for the
specific worker it needs:

    t=0   Start TTS + Video provisioning in background threads
    t=0   Start scenario generation IMMEDIATELY (no GPU needed)
    t=3m  Scenario done.  Audio stage calls wait_for_worker("tts")
    t=5m  TTS ready -> audio proceeds.  Video still bootstrapping...
    t=10m Audio done -> visual direction (LLM only, no GPU)
    t=12m Visual direction done -> production calls wait_for_worker("video")
    t=20m Video ready -> production proceeds

This saves ~15-20 minutes vs the old sequential blocking approach.

VRAM calculation (bf16, no quantisation):

    TTS  (Qwen3-TTS-12Hz-1.7B):  1.7B x 2 bytes = 3.4 GB weights
         + KV cache + activations ~ 5-8 GB runtime -> min_vram = 8 GB

    Video (LTX-2.3 diffusers):   text_encoder ~46.6 GB
                                  transformer  ~37.8 GB
                                  vae + audio  ~ 6.6 GB
                                  Total loaded ~ 71 GB bf16
         + inference overhead   -> min_vram = 80 GB
         (gpu_worker.py: "Requires 80GB+ VRAM")

Budget: weighted split — video GPU costs ~20x more than TTS GPU,
so equal-splitting the budget wastes money on TTS and starves video.

Architecture invariants preserved:
- One model per VM — TTS and video on separate VMs.
- Workers must be healthy before any stage that needs them.
- VRAM requirements are **hard floors** — never lowered for cost.
- Never silently degrade — if provisioning fails, raise loud.

RESILIENCE FEATURES:
- Retry with exponential backoff for all Vast.ai API calls
- Circuit breaker for failing Vast.ai services
- Graceful degradation with fallback GPU types
- Comprehensive timeout handling
- Proper resource cleanup with context managers
"""

from __future__ import annotations

import json
import logging
import os
import re
import shlex
import subprocess
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Optional
from urllib.error import URLError
from urllib.request import Request, urlopen

# Import resilience module
try:
    from resilience import (
        with_retry, circuit_breaker, graceful_degradation,
        timeout, resilient_context, managed_resource,
        VastAIError, TimeoutError, CircuitBreakerOpenError,
        retry_with_backoff, safe_execute,
    )
    RESILIENCE_AVAILABLE = True
except ImportError:
    RESILIENCE_AVAILABLE = False
    logging.warning("Resilience module not available, using fallback error handling")

logger = logging.getLogger(__name__)

_TEST_MODE = os.environ.get("DOCUMENTARY_TEST_MODE", "").strip().lower() in (
    "1",
    "true",
)

# =============================================================================
# Circuit Breaker Configuration
# =============================================================================

# Circuit breaker for Vast.ai API - prevents cascading failures
_vastai_circuit_breaker = None

if RESILIENCE_AVAILABLE:
    from resilience import CircuitBreaker
    _vastai_circuit_breaker = CircuitBreaker(
        name="vastai_api",
        failure_threshold=5,
        recovery_timeout=120.0,  # 2 minutes recovery
        half_open_max_calls=2,
        expected_exception=(Exception,),
    )


# =============================================================================
# Data types
# =============================================================================


@dataclass
class WorkerSpec:
    """Specification for a GPU worker to provision."""

    role: str  # "tts" or "video"
    env_var: str  # e.g. "TTS_WORKER_URL"
    local_port: int  # localhost port for SSH tunnel
    remote_port: int  # port on the GPU VM
    capability: str  # health check key (e.g. "tts", "ltx")
    gpu_type: str = "A100_SXM4"
    min_vram_gb: int = 48
    max_price: float = 2.00
    min_disk_gb: int = 50  # per-worker disk search filter
    disk_gb: int = 64  # --disk arg for vast create instance
    worker_mode: str = "tts"  # gpu_worker.py --mode argument
    vm_id: str = ""  # populated after provisioning
    ssh_host: str = ""
    ssh_port: int = 0
    tunnel_proc: Optional[subprocess.Popen] = field(default=None, repr=False)
    # Parallel provisioning status — used by background threads
    status: str = "pending"  # "pending", "provisioning", "healthy", "failed"
    error: str = ""  # error message if status == "failed"
    ready_event: threading.Event = field(default_factory=threading.Event)
    # Bootstrap error detail — populated by wait_for_worker_healthy when the
    # worker's /health endpoint reports a bootstrap failure.  This gives the
    # provisioner (and recovery middleware) structured information about WHY
    # the worker failed, not just that it did.
    bootstrap_error: str = ""
    bootstrap_error_category: str = ""  # "auth", "network", "disk", "missing_file", "runtime"
    # Retry tracking
    provision_attempts: int = 0
    last_provision_error: str = ""


# =============================================================================
# Context Managers for Resource Management
# =============================================================================


@contextmanager
def managed_ssh_tunnel(spec: WorkerSpec):
    """
    Context manager for SSH tunnel lifecycle.
    
    Ensures proper cleanup of SSH tunnel processes even on failure.
    """
    tunnel_proc = None
    try:
        tunnel_proc = setup_ssh_tunnel(spec)
        yield tunnel_proc
    finally:
        if tunnel_proc and tunnel_proc.poll() is None:
            logger.info("Cleaning up SSH tunnel for %s (pid=%d)", spec.role, tunnel_proc.pid)
            try:
                tunnel_proc.terminate()
                try:
                    tunnel_proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    logger.warning("SSH tunnel did not terminate, killing...")
                    tunnel_proc.kill()
                    tunnel_proc.wait(timeout=2)
            except Exception as e:
                logger.error("Error cleaning up SSH tunnel: %s", e)


@contextmanager
def managed_vm_instance(spec: WorkerSpec, timeout_sec: int = 600):
    """
    Context manager for VM instance lifecycle.
    
    Ensures VM is properly destroyed on failure if needed.
    """
    vm_id = None
    try:
        yield spec
        vm_id = spec.vm_id
    except Exception as e:
        # On failure, optionally destroy the VM to stop billing
        if spec.vm_id and os.environ.get("DESTROY_FAILED_VMS", "").lower() in ("1", "true"):
            logger.warning("Destroying failed VM %s to stop billing", spec.vm_id)
            try:
                _vast_cmd(["destroy", "instance", spec.vm_id], timeout=30)
            except Exception as destroy_err:
                logger.error("Failed to destroy VM %s: %s", spec.vm_id, destroy_err)
        raise


# =============================================================================
# GAP 1.2: Model manifest — machine-readable model resource requirements
# =============================================================================

def _load_model_manifest() -> dict:
    """Load config/model_manifest.json if available.

    Returns the full manifest dict with 'models' and 'docker_images' sections.
    Falls back to empty dict if file is missing.
    """
    manifest_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "config", "model_manifest.json",
    )
    try:
        with open(manifest_path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning("Could not load model manifest from %s: %s", manifest_path, e)
        return {}


_FULL_MANIFEST = _load_model_manifest()
_MODEL_MANIFEST = _FULL_MANIFEST.get("models", {})


def _parse_version(v: str) -> tuple:
    """Parse a version string like '2.10.0' into a comparable tuple (2, 10, 0)."""
    # Strip build metadata (e.g. '2.7.0+cu126' -> '2.7.0') per PEP 440
    v = v.split("+")[0]
    parts = []
    for p in v.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            break
    return tuple(parts)


def resolve_docker_image(worker_mode: str) -> tuple[str, str]:
    """Pick the best Docker image for a worker mode from the model manifest.

    Reads the model's min_torch / min_cuda requirements and the docker_images
    registry from model_manifest.json.  Returns the first image whose torch
    and CUDA versions satisfy the model constraints.

    Returns:
        (docker_image_tag, torch_wheel_index_url)
    """
    # Find the model entry that matches this worker_mode
    model_spec = None
    for _key, spec in _MODEL_MANIFEST.items():
        if spec.get("worker_mode") == worker_mode:
            model_spec = spec
            break

    # Defaults if manifest is missing or incomplete
    default_image = "pytorch/pytorch:2.10.0-cuda12.6-cudnn9-devel"
    default_index = "https://download.pytorch.org/whl/cu126"

    if not model_spec:
        logger.warning(
            "No model manifest entry for worker_mode=%s, using default image %s",
            worker_mode, default_image,
        )
        return default_image, default_index

    min_torch = _parse_version(model_spec.get("min_torch", "2.6.0"))
    min_cuda = _parse_version(model_spec.get("min_cuda", "12.4"))
    wheel_suffix = model_spec.get("torch_wheel_suffix", "cu126")
    torch_index = f"https://download.pytorch.org/whl/{wheel_suffix}"

    # Search the image registry for the first image that satisfies constraints
    images = _FULL_MANIFEST.get("docker_images", {}).get("images", [])
    for img in images:
        img_torch = _parse_version(img.get("torch_version", "0.0.0"))
        img_cuda = _parse_version(img.get("cuda_version", "0.0"))
        if img_torch >= min_torch and img_cuda >= min_cuda:
            tag = img["tag"]
            logger.info(
                "Resolved Docker image for %s: %s (torch %s >= %s, cuda %s >= %s)",
                worker_mode, tag,
                img.get("torch_version"), model_spec.get("min_torch"),
                img.get("cuda_version"), model_spec.get("min_cuda"),
            )
            return tag, torch_index

    # No image in registry satisfies constraints — use the first one and warn
    if images:
        fallback = images[0]["tag"]
        logger.warning(
            "No image satisfies min_torch=%s min_cuda=%s for %s, falling back to %s",
            model_spec.get("min_torch"), model_spec.get("min_cuda"),
            worker_mode, fallback,
        )
        return fallback, torch_index

    logger.warning("No docker_images in manifest, using default %s", default_image)
    return default_image, default_index


# =============================================================================
# Default worker specs — VRAM calculated from actual model sizes
# =============================================================================

TTS_SPEC = WorkerSpec(
    role="tts",
    env_var="TTS_WORKER_URL",
    local_port=8880,
    remote_port=8880,
    capability="tts",
    gpu_type="RTX_4000",      # cheap GPU; broadened automatically if unavailable
    min_vram_gb=8,             # 1.7B model at bf16 = 3.4 GB + overhead
    max_price=1.00,            # fallback ceiling; overridden by weighted budget
    min_disk_gb=50,            # ~4.3 GB TTS model + ~30 GB OS/software (WORKER_MODE=tts skips LTX)
    disk_gb=64,                # --disk arg (comfortable headroom for TTS-only)
    worker_mode="tts",
)

VIDEO_SPEC = WorkerSpec(
    role="video",
    env_var="GPU_WORKER_URL",
    local_port=8881,
    remote_port=8880,
    capability="ltx",
    gpu_type="A100_SXM4",     # 80 GB VRAM; broadened to H100/H200 if unavailable
    min_vram_gb=80,            # ~71 GB bf16 model loaded fully on GPU
    max_price=5.00,            # fallback ceiling; overridden by weighted budget
    min_disk_gb=200,           # ~95 GB models + OS + output
    disk_gb=224,               # --disk arg
    worker_mode="ltx",
)


# =============================================================================
# Health check with retry
# =============================================================================


def check_worker_health(url: str, capability: str, timeout: int = 10) -> bool:
    """Check if a worker at the given URL is healthy and has the capability loaded.

    Returns True if healthy, False otherwise.
    """
    health_url = f"{url.rstrip('/')}/health"
    try:
        req = Request(health_url)
        with urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode())
        if data.get("status") != "ok":
            return False
        loaded_key = f"{capability}_loaded"
        return bool(data.get(loaded_key, False))
    except (URLError, OSError, json.JSONDecodeError, TimeoutError, Exception):
        return False


def check_worker_health_with_retry(url: str, capability: str, timeout: int = 10, retries: int = 2) -> bool:
    """Check worker health with retry logic."""
    if RESILIENCE_AVAILABLE:
        @with_retry(max_attempts=retries, min_wait=1.0, max_wait=5.0, exceptions=(Exception,))
        def _check():
            return check_worker_health(url, capability, timeout)
        return _check()
    else:
        for attempt in range(retries):
            result = check_worker_health(url, capability, timeout)
            if result:
                return True
            if attempt < retries - 1:
                time.sleep(1.0 * (attempt + 1))
        return False


def check_worker_reachable(url: str, timeout: int = 5) -> bool:
    """Check if a worker URL is reachable (responds to /health, any status)."""
    health_url = f"{url.rstrip('/')}/health"
    try:
        req = Request(health_url)
        with urlopen(req, timeout=timeout) as resp:
            resp.read()
        return True
    except Exception:
        return False


# =============================================================================
# Vast.ai account & budget
# =============================================================================

# Minimum credit reserve — never spend the last few dollars so the account
# doesn't hit zero mid-run.
_CREDIT_RESERVE = 5.0

# Estimated maximum pipeline duration in hours.  Used to convert credits
# into a safe per-worker $/hr ceiling.
_ESTIMATED_RUN_HOURS = 2.0

# Per-worker price ceilings by GPU tier.
_TTS_PRICE_CEILING = 1.00
_VIDEO_PRICE_CEILING = 10.00

# Budget weight — video uses ~90% of the GPU budget
_TTS_BUDGET_WEIGHT = 0.10
_VIDEO_BUDGET_WEIGHT = 0.90


def _vast_cmd(args: list[str], timeout: int = 120) -> dict | list | str:
    """Run a vastai CLI command and return parsed output.
    
    Args:
        args: Command arguments
        timeout: Command timeout in seconds
    """
    api_key = os.environ.get("VAST_API_KEY", "")
    if not api_key:
        raise VastAIError("VAST_API_KEY not set — cannot provision GPU workers") if RESILIENCE_AVAILABLE else \
              RuntimeError("VAST_API_KEY not set — cannot provision GPU workers")

    cmd = ["vastai", "--api-key", api_key] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            error_msg = f"vastai command failed (rc={result.returncode}): {result.stderr[:500]}"
            if RESILIENCE_AVAILABLE:
                raise VastAIError(error_msg, details={"cmd": cmd, "stderr": result.stderr[:1000]})
            raise RuntimeError(error_msg)
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return result.stdout.strip()
    except FileNotFoundError:
        error_msg = "vastai CLI not installed"
        if RESILIENCE_AVAILABLE:
            raise VastAIError(error_msg)
        raise RuntimeError(error_msg)
    except subprocess.TimeoutExpired:
        error_msg = f"vastai command timed out after {timeout}s"
        if RESILIENCE_AVAILABLE:
            raise TimeoutError(error_msg, operation="vastai_cmd", timeout_sec=timeout)
        raise RuntimeError(error_msg)


def get_account_credits() -> float:
    """Query Vast.ai account and return available credit balance in USD."""
    result = _vast_cmd(["show", "user", "--raw"], timeout=30)
    if isinstance(result, dict):
        credit = float(result.get("credit", 0.0))
        balance = float(result.get("balance", 0.0))
        total = credit + balance
        logger.info(
            "Vast.ai account: credit=$%.2f, balance=$%.2f, total=$%.2f",
            credit, balance, total,
        )
        return total
    raise VastAIError(f"Could not read Vast.ai account info: {result}", details={"result": result}) if RESILIENCE_AVAILABLE else \
          RuntimeError(f"Could not read Vast.ai account info: {result}")


def get_account_credits_with_retry(max_retries: int = 3) -> float:
    """Get account credits with retry logic."""
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=max_retries,
            min_wait=1.0,
            max_wait=10.0,
            exceptions=(VastAIError, RuntimeError, Exception),
        )
        def _get():
            return get_account_credits()
        return _get()
    else:
        for attempt in range(max_retries):
            try:
                return get_account_credits()
            except Exception as e:
                if attempt < max_retries - 1:
                    wait_time = 1.0 * (attempt + 1)
                    logger.warning("Retry %d/%d getting account credits: %s", attempt + 1, max_retries, e)
                    time.sleep(wait_time)
                else:
                    raise


def calculate_weighted_budgets(
    estimated_hours: float = _ESTIMATED_RUN_HOURS,
) -> tuple[float, float]:
    """Calculate per-worker $/hr budgets weighted by GPU tier.

    Video GPUs cost ~20x more than TTS GPUs, so equal-splitting the
    budget wastes money on TTS and leaves too little for video.

    Returns (tts_budget, video_budget) in $/hr.
    """
    credits = get_account_credits_with_retry()
    usable = credits - _CREDIT_RESERVE
    if usable <= 0:
        error_msg = (
            f"Insufficient Vast.ai credits: ${credits:.2f} "
            f"(reserve=${_CREDIT_RESERVE:.2f}). "
            f"Top up at https://cloud.vast.ai/billing/"
        )
        if RESILIENCE_AVAILABLE:
            raise VastAIError(error_msg, details={"credits": credits, "reserve": _CREDIT_RESERVE})
        raise RuntimeError(error_msg)

    total_hourly = usable / max(estimated_hours, 0.5)

    tts_budget = min(total_hourly * _TTS_BUDGET_WEIGHT, _TTS_PRICE_CEILING)
    video_budget = min(total_hourly * _VIDEO_BUDGET_WEIGHT, _VIDEO_PRICE_CEILING)

    # Safety: if combined exceeds total, scale down proportionally
    combined = tts_budget + video_budget
    if combined > total_hourly:
        scale = total_hourly / combined
        tts_budget *= scale
        video_budget *= scale

    logger.info(
        "Weighted budget: $%.2f usable / %.1fh = $%.2f/hr total. "
        "TTS: $%.2f/hr (weight %.0f%%, ceiling $%.2f). "
        "Video: $%.2f/hr (weight %.0f%%, ceiling $%.2f).",
        usable, estimated_hours, total_hourly,
        tts_budget, _TTS_BUDGET_WEIGHT * 100, _TTS_PRICE_CEILING,
        video_budget, _VIDEO_BUDGET_WEIGHT * 100, _VIDEO_PRICE_CEILING,
    )
    return tts_budget, video_budget


# Keep the old function for backward compatibility (infra_agent etc.)
def calculate_budget_per_worker(
    num_workers: int,
    estimated_hours: float = _ESTIMATED_RUN_HOURS,
) -> float:
    """Legacy equal-split budget.  Prefer calculate_weighted_budgets()."""
    credits = get_account_credits_with_retry()
    usable = credits - _CREDIT_RESERVE
    if usable <= 0:
        error_msg = (
            f"Insufficient Vast.ai credits: ${credits:.2f} "
            f"(reserve=${_CREDIT_RESERVE:.2f}). "
            f"Top up at https://cloud.vast.ai/billing/"
        )
        if RESILIENCE_AVAILABLE:
            raise VastAIError(error_msg)
        raise RuntimeError(error_msg)
    budget = usable / max(num_workers, 1) / max(estimated_hours, 0.5)
    capped = min(budget, _VIDEO_PRICE_CEILING)
    return capped


# =============================================================================
# Vast.ai provisioning with resilience
# =============================================================================


def _search_offers_with_retry(
    query: str,
    excluded_offer_ids: Optional[set[int]] = None,
    max_retries: int = 3,
) -> list:
    """Search for GPU offers with retry logic."""
    
    def _search():
        search_result = _vast_cmd([
            "search", "offers",
            "--type", "on-demand",
            "--order", "inet_down-",  # fastest download first
            "--raw",
            query,
        ], timeout=60)
        
        offers = search_result if isinstance(search_result, list) else []
        
        # Exclude previously-tried offers
        if excluded_offer_ids and offers:
            offers = [o for o in offers if int(o.get("id", 0)) not in excluded_offer_ids]
        
        return offers
    
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=max_retries,
            min_wait=2.0,
            max_wait=30.0,
            exceptions=(VastAIError, RuntimeError, Exception),
        )
        def _search_retry():
            return _search()
        return _search_retry()
    else:
        for attempt in range(max_retries):
            try:
                return _search()
            except Exception as e:
                if attempt < max_retries - 1:
                    wait_time = 2.0 * (attempt + 1)
                    logger.warning("Retry %d/%d searching offers: %s", attempt + 1, max_retries, e)
                    time.sleep(wait_time)
                else:
                    raise


def provision_vm(spec: WorkerSpec, excluded_offer_ids: set[int] | None = None) -> int:
    """Provision a Vast.ai GPU VM for the given worker spec.

    Returns the selected **offer** ID so callers can track it for retries
    (distinct from the instance ID stored in ``spec.vm_id``).
    *excluded_offer_ids* — offer IDs to skip (e.g. previously-tried slow hosts).
    """
    logger.info(
        "Provisioning %s worker: gpu=%s, vram>=%dGB, max $%.2f/hr, "
        "disk>=%dGB (--disk %d)",
        spec.role, spec.gpu_type, spec.min_vram_gb, spec.max_price,
        spec.min_disk_gb, spec.disk_gb,
    )
    
    spec.provision_attempts += 1

    # Search for offers — VRAM is a hard floor, never compromised.
    vram_gb = spec.min_vram_gb
    vram_mb = spec.min_vram_gb * 1024  # for Python-side post-filter only
    query = (
        f"gpu_name={spec.gpu_type} "
        f"gpu_ram>={vram_gb} "
        f"dph_total<={spec.max_price} "
        f"rentable=true "
        f"reliability>0.95 "
        f"inet_down>200 "
        f"disk_space>={spec.min_disk_gb}"
    )

    offers = _search_offers_with_retry(query, excluded_offer_ids)

    # If no offers for exact GPU type, broaden to ANY GPU that meets the VRAM floor
    if not offers:
        logger.warning(
            "No %s offers found, broadening search to any GPU with >=%dGB VRAM",
            spec.gpu_type, spec.min_vram_gb,
        )
        query = (
            f"gpu_ram>={vram_gb} "
            f"dph_total<={spec.max_price} "
            f"rentable=true "
            f"reliability>0.90 "
            f"inet_down>100 "
            f"disk_space>={spec.min_disk_gb}"
        )
        offers = _search_offers_with_retry(query, excluded_offer_ids)

    # Python-side filtering as safety net
    if offers:
        filtered = []
        for o in offers:
            o_vram = float(o.get("gpu_ram", 0))
            o_price = float(o.get("dph_total", 999))
            o_disk = float(o.get("disk_space", 0))
            if (
                o_vram >= vram_mb
                and o_price <= spec.max_price
                and o_disk >= spec.min_disk_gb
            ):
                filtered.append(o)
        if len(filtered) < len(offers):
            logger.info(
                "Python-side filter: %d/%d offers passed "
                "(vram>=%dMB, price<=$%.2f, disk>=%dGB)",
                len(filtered), len(offers),
                vram_mb, spec.max_price, spec.min_disk_gb,
            )
        offers = filtered

    if not offers:
        error_msg = (
            f"No GPU offers found for {spec.role} worker "
            f"(min {spec.min_vram_gb}GB VRAM, max ${spec.max_price:.2f}/hr, "
            f"min disk {spec.min_disk_gb}GB). "
            f"VRAM floor is non-negotiable (no quantisation). "
            f"Current account budget allows up to ${spec.max_price:.2f}/hr."
        )
        if RESILIENCE_AVAILABLE:
            raise VastAIError(error_msg, details={
                "role": spec.role,
                "min_vram_gb": spec.min_vram_gb,
                "max_price": spec.max_price,
                "attempt": spec.provision_attempts,
            })
        raise RuntimeError(error_msg)

    # Sort by download speed (fastest first) with price as tiebreaker
    sorted_offers = sorted(
        offers,
        key=lambda o: (-float(o.get("inet_down", 0)), float(o.get("dph_total", 999))),
    )
    best = sorted_offers[0]
    offer_id = int(best.get("id", 0))

    logger.info(
        "Selected offer %s: %s %dx, %.1fGB VRAM, $%.3f/hr, %.0fGB disk",
        offer_id,
        best.get("gpu_name", "unknown"),
        best.get("num_gpus", 1),
        float(best.get("gpu_ram", 0)) / 1024,
        float(best.get("dph_total", 0)),
        float(best.get("disk_space", 0)),
    )

    # Create instance with bootstrap onstart
    b2_key_id = os.environ.get("B2_KEY_ID", "")
    b2_app_key = os.environ.get("B2_APPLICATION_KEY", "")
    dashscope_key = os.environ.get("DASHSCOPE_API_KEY", "")
    openrouter_key = os.environ.get("OPENROUTER_API_KEY", "")

    # Auto-detect the current git branch
    try:
        _branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            text=True,
        ).strip()
        if not _branch or _branch == "HEAD":
            _branch = "main"
    except Exception:
        _branch = "main"
    logger.info("VMs will clone branch: %s", _branch)

    # Resolve Docker image + torch wheel index from model manifest
    _docker_image, _torch_index = resolve_docker_image(spec.worker_mode)
    logger.info("Docker image for %s worker: %s", spec.role, _docker_image)

    # Look up min_torch from the manifest
    _min_torch = "2.7.0"  # safe default
    for _key, _mspec in _MODEL_MANIFEST.items():
        if _mspec.get("worker_mode") == spec.worker_mode:
            _min_torch = _mspec.get("min_torch", "2.7.0")
            break

    # Build onstart command
    onstart = (
        f"export B2_KEY_ID={shlex.quote(b2_key_id)} && "
        f"export B2_APPLICATION_KEY={shlex.quote(b2_app_key)} && "
        f"export WORKER_MODE={shlex.quote(spec.worker_mode)} && "
        f"export DASHSCOPE_API_KEY={shlex.quote(dashscope_key)} && "
        f"export OPENROUTER_API_KEY={shlex.quote(openrouter_key)} && "
        f"export TORCH_INDEX={shlex.quote(_torch_index)} && "
        f"export MIN_TORCH_VERSION={shlex.quote(_min_torch)} && "
        "export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True && "
        "apt-get update && apt-get install -y git curl ffmpeg libsndfile1 sox libsox-dev && "
        f"git clone -b {shlex.quote(_branch)} --single-branch "
        "https://github.com/OrpingtonClose/economy-documentary.git "
        "/workspace/economy-documentary 2>/dev/null || "
        f"(cd /workspace/economy-documentary && git fetch origin {shlex.quote(_branch)} && "
        f"git checkout {shlex.quote(_branch)} && git pull origin {shlex.quote(_branch)}) && "
        "python3 -c 'import torch; print(f\"torch {torch.__version__} from {torch.__file__}\")' && "
        "pip install --break-system-packages --no-cache-dir "
        "'fastapi>=0.100.0' 'uvicorn>=0.20.0' 'pydantic>=2.0.0' "
        "'numpy>=1.26.0,<2.0.0' 'soundfile>=0.12.0' && "
        "python3 -c \""
        "import os,site,pathlib;"
        "nv_dirs=[str(p) for sp in site.getsitepackages() "
        "for p in pathlib.Path(sp,'nvidia').glob('*/lib') if p.is_dir()];"
        "open('/etc/ld.so.conf.d/nvidia-pip.conf','w').write(chr(10).join(nv_dirs)+chr(10)) if nv_dirs else None;"
        "print(f'Registered {len(nv_dirs)} nvidia lib dirs')\" && "
        "ldconfig && "
        "python3 /workspace/economy-documentary/scripts/gpu_worker.py "
        f"--mode {shlex.quote(spec.worker_mode)} --port {spec.remote_port}"
    )

    # Generate a descriptive label for the VM
    import uuid as _uuid
    _run_id = os.environ.get("DOCUMENTARY_RUN_ID", _uuid.uuid4().hex[:8])
    _label = f"documentary-{spec.role}-{_run_id}"

    # Create instance
    create_result = _vast_cmd([
        "create", "instance",
        str(offer_id),
        "--image", _docker_image,
        "--disk", str(spec.disk_gb),
        "--ssh",
        "--direct",
        "--label", _label,
        "--onstart-cmd", onstart,
    ], timeout=120)
    
    logger.info("VM label: %s", _label)

    # Parse the response
    if isinstance(create_result, dict):
        instance_id = create_result.get("new_contract")
        if instance_id:
            spec.vm_id = str(instance_id)
            # Register as owned so terminate_vm() accepts it
            try:
                from tools.vastai_tools import register_owned_vm
                register_owned_vm(spec.vm_id)
            except ImportError:
                pass
            logger.info("VM provisioned: instance_id=%s", spec.vm_id)
            return offer_id

    # Try to extract new_contract from text response
    if isinstance(create_result, str) and "new_contract" in create_result:
        match = re.search(r"'new_contract'\s*:\s*(\d+)", create_result)
        if match:
            spec.vm_id = match.group(1)
            try:
                from tools.vastai_tools import register_owned_vm
                register_owned_vm(spec.vm_id)
            except ImportError:
                pass
            logger.info("VM provisioned: instance_id=%s (parsed from text)", spec.vm_id)
            return offer_id

    error_msg = f"Failed to provision {spec.role} VM: unexpected response: {create_result}"
    if RESILIENCE_AVAILABLE:
        raise VastAIError(error_msg, details={"create_result": create_result})
    raise RuntimeError(error_msg)


def provision_vm_with_resilience(spec: WorkerSpec, excluded_offer_ids: set[int] | None = None) -> int:
    """Provision VM with retry and circuit breaker protection."""
    
    def _provision():
        return provision_vm(spec, excluded_offer_ids)
    
    # Apply circuit breaker if available
    if _vastai_circuit_breaker:
        _provision = _vastai_circuit_breaker(_provision)
    
    # Apply retry logic
    if RESILIENCE_AVAILABLE:
        @with_retry(
            max_attempts=3,
            min_wait=5.0,
            max_wait=60.0,
            exceptions=(VastAIError, RuntimeError, Exception),
        )
        def _provision_with_retry():
            return _provision()
        return _provision_with_retry()
    else:
        return _provision()


def wait_for_vm_running(spec: WorkerSpec, timeout: int = 600) -> dict:
    """Wait for a provisioned VM to reach 'running' status.

    Returns the VM info dict with SSH connection details.
    """
    logger.info(
        "Waiting for %s VM %s to start (timeout %ds)...",
        spec.role, spec.vm_id, timeout,
    )
    start = time.time()
    last_error = None
    
    while time.time() - start < timeout:
        try:
            result = _vast_cmd(["show", "instance", spec.vm_id, "--raw"], timeout=30)
            if isinstance(result, dict):
                status = result.get(
                    "actual_status", result.get("status_msg", "unknown")
                )
                elapsed = int(time.time() - start)
                logger.info(
                    "  %s VM %s: status=%s (%ds)",
                    spec.role, spec.vm_id, status, elapsed,
                )
                if status == "running":
                    spec.ssh_host = result.get("ssh_host", "")
                    spec.ssh_port = int(result.get("ssh_port", 0))
                    return result
        except Exception as exc:
            last_error = exc
            logger.warning("  Error checking VM status: %s", exc)

        time.sleep(15)

    error_msg = (
        f"{spec.role} VM {spec.vm_id} did not reach 'running' "
        f"within {timeout}s"
    )
    if RESILIENCE_AVAILABLE:
        raise TimeoutError(
            error_msg,
            operation="wait_for_vm_running",
            timeout_sec=timeout,
            details={"last_error": str(last_error)} if last_error else {},
        )
    raise RuntimeError(error_msg)


# =============================================================================
# SSH tunnel management with retry
# =============================================================================


def setup_ssh_tunnel(
    spec: WorkerSpec, max_retries: int = 12, retry_delay: int = 15,
) -> subprocess.Popen:
    """Set up an SSH tunnel from localhost:local_port to the GPU VM.

    Retries up to *max_retries* times with *retry_delay* seconds between
    attempts because the VM's SSH daemon may not be ready immediately
    after Vast.ai reports status=running.

    Returns the tunnel subprocess.
    """
    if not spec.ssh_host or not spec.ssh_port:
        raise RuntimeError(
            f"Cannot set up SSH tunnel for {spec.role}: "
            f"no SSH connection details (host={spec.ssh_host}, port={spec.ssh_port})"
        )

    # Collect all available SSH identity files
    _ssh_keys: list[str] = []
    for _name in ("id_rsa", "id_ed25519"):
        _path = os.path.expanduser(f"~/.ssh/{_name}")
        if os.path.exists(_path):
            _ssh_keys.append(_path)
    if not _ssh_keys:
        raise RuntimeError(
            f"Cannot set up SSH tunnel for {spec.role}: "
            f"no SSH identity file found at ~/.ssh/id_rsa or ~/.ssh/id_ed25519"
        )

    def _build_tunnel_cmd(key_path: str) -> list[str]:
        return [
            "ssh",
            "-i", key_path,
            "-o", "IdentitiesOnly=yes",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "ServerAliveInterval=30",
            "-o", "ServerAliveCountMax=3",
            "-N",  # no remote command
            "-L", f"{spec.local_port}:localhost:{spec.remote_port}",
            "-p", str(spec.ssh_port),
            f"root@{spec.ssh_host}",
        ]

    last_err = ""
    for attempt in range(1, max_retries + 1):
        # Rotate through available keys
        _ssh_key = _ssh_keys[(attempt - 1) % len(_ssh_keys)]
        tunnel_cmd = _build_tunnel_cmd(_ssh_key)

        logger.info(
            "Setting up SSH tunnel (attempt %d/%d, key=%s): "
            "localhost:%d -> %s:%d (via %s:%d)",
            attempt, max_retries, os.path.basename(_ssh_key),
            spec.local_port, spec.ssh_host, spec.remote_port,
            spec.ssh_host, spec.ssh_port,
        )

        proc = subprocess.Popen(
            tunnel_cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

        # Give the tunnel a moment to establish
        time.sleep(3)

        if proc.poll() is not None:
            last_err = proc.stderr.read().decode() if proc.stderr else ""
            logger.warning(
                "SSH tunnel attempt %d/%d for %s failed: %s",
                attempt, max_retries, spec.role, last_err.strip(),
            )
            if attempt < max_retries:
                time.sleep(retry_delay)
                continue
            raise RuntimeError(
                f"SSH tunnel for {spec.role} failed after {max_retries} attempts: {last_err}"
            )

        # Close stderr pipe to prevent buffer-fill blocking
        if proc.stderr:
            proc.stderr.close()

        spec.tunnel_proc = proc
        logger.info(
            "SSH tunnel established: localhost:%d -> %s VM %s",
            spec.local_port, spec.role, spec.vm_id,
        )
        return proc

    # Should not reach here
    raise RuntimeError(
        f"SSH tunnel for {spec.role} failed after {max_retries} attempts: {last_err}"
    )


# =============================================================================
# Wait for worker health with comprehensive error handling
# =============================================================================


def _get_worker_health_detail(url: str, timeout: int = 10) -> dict | None:
    """Fetch full health JSON from a worker, including bootstrap status.

    Returns the parsed dict, or None if unreachable.
    """
    health_url = f"{url.rstrip('/')}/health"
    try:
        req = Request(health_url)
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return None


def wait_for_worker_healthy(
    spec: WorkerSpec,
    timeout: int = 900,
    poll_interval: int = 15,
) -> bool:
    """Wait for a worker to become healthy after provisioning.

    The worker needs time to:
    1. Boot the VM and start gpu_worker.py (FastAPI starts immediately)
    2. Run bootstrap in background (install deps, download models)
    3. Load the model into VRAM

    The worker's /health endpoint reports structured bootstrap status so we
    can see exactly what's happening and escalate failures immediately
    rather than waiting for a blind timeout.
    """
    url = f"http://localhost:{spec.local_port}"
    logger.info(
        "Waiting for %s worker at %s to become healthy (timeout %ds)...",
        spec.role, url, timeout,
    )

    start = time.time()
    last_status = "unknown"
    last_bootstrap_phase = ""
    consecutive_errors = 0
    max_consecutive_errors = 5
    
    while time.time() - start < timeout:
        elapsed = int(time.time() - start)

        # Check if tunnel is still alive
        if spec.tunnel_proc and spec.tunnel_proc.poll() is not None:
            logger.warning("SSH tunnel for %s died — restarting...", spec.role)
            consecutive_errors += 1
            if consecutive_errors >= max_consecutive_errors:
                logger.error("Too many tunnel failures, giving up")
                return False
            try:
                setup_ssh_tunnel(spec)
                consecutive_errors = 0
            except Exception as exc:
                logger.error("Failed to restart tunnel: %s", exc)
                time.sleep(poll_interval)
                continue

        # Fetch full health detail
        try:
            health_data = _get_worker_health_detail(url, timeout=10)
            consecutive_errors = 0
        except Exception as e:
            consecutive_errors += 1
            logger.warning("Error fetching health: %s", e)
            if consecutive_errors >= max_consecutive_errors:
                logger.error("Too many health check failures")
                return False
            time.sleep(poll_interval)
            continue

        if health_data is not None:
            # --- Bootstrap error escalation ---
            bootstrap = health_data.get("bootstrap") or {}
            bootstrap_phase = bootstrap.get("phase", "")
            bootstrap_error = bootstrap.get("error", "")
            bootstrap_category = bootstrap.get("error_category", "")

            if bootstrap_phase == "error":
                logger.error(
                    "BOOTSTRAP FAILED on %s worker (category=%s): %s",
                    spec.role, bootstrap_category, bootstrap_error,
                )
                spec.bootstrap_error = bootstrap_error
                spec.bootstrap_error_category = bootstrap_category
                return False

            # Log phase transitions
            if bootstrap_phase and bootstrap_phase != last_bootstrap_phase:
                logger.info(
                    "  %s worker bootstrap phase: %s — %s (%ds)",
                    spec.role, bootstrap_phase,
                    bootstrap.get("detail", ""), elapsed,
                )
                last_bootstrap_phase = bootstrap_phase

            # Check if model is loaded (healthy)
            if health_data.get("status") == "ok":
                loaded_key = f"{spec.capability}_loaded"
                if health_data.get(loaded_key, False):
                    logger.info(
                        "%s worker at %s is HEALTHY after %ds",
                        spec.role, url, elapsed,
                    )
                    return True
                if last_status != "reachable_not_loaded":
                    logger.info(
                        "  %s worker reachable but model not loaded yet (%ds)",
                        spec.role, elapsed,
                    )
                    last_status = "reachable_not_loaded"
        else:
            if last_status != "unreachable":
                logger.info(
                    "  %s worker not yet reachable (%ds) — "
                    "VM still bootstrapping...",
                    spec.role, elapsed,
                )
                last_status = "unreachable"

        time.sleep(poll_interval)

    logger.error(
        "%s worker at %s did not become healthy within %ds",
        spec.role, url, timeout,
    )
    return False


# =============================================================================
# High-level orchestrator — parallel lazy provisioning with resilience
# =============================================================================


class WorkerProvisioner:
    """Manages the full lifecycle of GPU workers for the pipeline.

    Two-phase API for parallel lazy provisioning:

    1. ``start_provisioning()`` — **non-blocking**.  Kicks off background
       threads to provision each worker in parallel.

    2. ``wait_for_worker(role)`` — **blocking per-worker**.  Called by
       each stage's before_callback to wait for only the worker it needs.

    3. ``cleanup()`` — kill tunnels, destroy VMs, stop InfraAgent.
    """

    def __init__(self) -> None:
        self._specs: list[WorkerSpec] = []
        self._lock = threading.Lock()
        self._provisioned = False
        self._threads: dict[str, threading.Thread] = {}
        self._provision_start_error: str = ""
        self._specs_ready = threading.Event()
        self._shutdown = threading.Event()

    def start_provisioning(
        self,
        require_tts: bool = True,
        require_video: bool = True,
    ) -> None:
        """Start provisioning workers in parallel background threads.

        Returns immediately.  Each worker's status is tracked in its
        WorkerSpec.status and signalled via WorkerSpec.ready_event.

        Call ``wait_for_worker(role)`` later to block until a specific
        worker is ready.
        """
        # Clear any stale error from a previous run
        self._provision_start_error = ""
        self._specs_ready.clear()
        self._shutdown.clear()

        if _TEST_MODE:
            logger.info("WorkerProvisioner: TEST MODE — skipping worker provisioning")
            self._specs_ready.set()
            return

        # Build specs from defaults
        specs_needed: list[WorkerSpec] = []
        if require_tts:
            specs_needed.append(WorkerSpec(
                role="tts",
                env_var="TTS_WORKER_URL",
                local_port=TTS_SPEC.local_port,
                remote_port=TTS_SPEC.remote_port,
                capability="tts",
                gpu_type=TTS_SPEC.gpu_type,
                min_vram_gb=TTS_SPEC.min_vram_gb,
                max_price=TTS_SPEC.max_price,
                min_disk_gb=TTS_SPEC.min_disk_gb,
                disk_gb=TTS_SPEC.disk_gb,
                worker_mode="tts",
            ))
        if require_video:
            specs_needed.append(WorkerSpec(
                role="video",
                env_var="GPU_WORKER_URL",
                local_port=VIDEO_SPEC.local_port,
                remote_port=VIDEO_SPEC.remote_port,
                capability="ltx",
                gpu_type=VIDEO_SPEC.gpu_type,
                min_vram_gb=VIDEO_SPEC.min_vram_gb,
                max_price=VIDEO_SPEC.max_price,
                min_disk_gb=VIDEO_SPEC.min_disk_gb,
                disk_gb=VIDEO_SPEC.disk_gb,
                worker_mode="ltx",
            ))

        with self._lock:
            self._specs = specs_needed
        self._specs_ready.set()

        # Check which workers actually need provisioning
        need_tts = False
        need_video = False
        for spec in specs_needed:
            url = os.environ.get(spec.env_var, "")
            if not url:
                url = f"http://localhost:{spec.local_port}"
            if check_worker_health_with_retry(url, spec.capability, retries=2):
                logger.info("%s worker at %s already healthy — marking ready", spec.role, url)
                spec.status = "healthy"
                spec.ready_event.set()
                os.environ[spec.env_var] = url
            else:
                spec.status = "pending"
                if spec.role == "tts":
                    need_tts = True
                else:
                    need_video = True

        if need_tts or need_video:
            try:
                tts_budget, video_budget = calculate_weighted_budgets()
                for spec in specs_needed:
                    if spec.status != "healthy":
                        if spec.role == "tts":
                            spec.max_price = tts_budget
                        else:
                            spec.max_price = video_budget
                logger.info(
                    "Weighted budgets applied: TTS=$%.2f/hr, Video=$%.2f/hr. "
                    "VRAM floors: TTS>=%dGB, Video>=%dGB.",
                    tts_budget, video_budget,
                    TTS_SPEC.min_vram_gb, VIDEO_SPEC.min_vram_gb,
                )
            except Exception as exc:
                logger.error("Budget calculation failed: %s", exc)
                for spec in specs_needed:
                    if spec.status != "healthy":
                        spec.status = "failed"
                        spec.error = str(exc)
                        spec.ready_event.set()
                return

        # Launch background threads for workers that need provisioning
        for spec in specs_needed:
            if spec.status == "pending":
                t = threading.Thread(
                    target=self._provision_worker_thread,
                    args=(spec,),
                    name=f"provision-{spec.role}",
                    daemon=True,
                )
                self._threads[spec.role] = t
                t.start()
                logger.info("Background provisioning started for %s worker", spec.role)

    def _provision_worker_thread(self, spec: WorkerSpec) -> None:
        """Background thread: provision a single worker end-to-end.

        Updates spec.status and signals spec.ready_event when done.
        """
        spec.status = "provisioning"
        try:
            self._provision_and_connect(spec, timeout=2400)
            spec.status = "healthy"

            # Update env var so contracts see the new URL
            new_url = f"http://localhost:{spec.local_port}"
            os.environ[spec.env_var] = new_url
            logger.info(
                "Background provisioning COMPLETE for %s: %s=%s (VM %s)",
                spec.role, spec.env_var, new_url, spec.vm_id,
            )
        except Exception as exc:
            spec.status = "failed"
            spec.error = str(exc)
            spec.last_provision_error = str(exc)
            logger.error("Background provisioning FAILED for %s: %s", spec.role, exc)
            
            # Clean up the SSH tunnel
            if spec.tunnel_proc and spec.tunnel_proc.poll() is None:
                logger.info("Cleaning up SSH tunnel for %s (pid=%d)", spec.role, spec.tunnel_proc.pid)
                try:
                    spec.tunnel_proc.terminate()
                    spec.tunnel_proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    spec.tunnel_proc.kill()
                except Exception as cleanup_err:
                    logger.warning("Error cleaning up tunnel: %s", cleanup_err)
        finally:
            spec.ready_event.set()

    def wait_for_worker(
        self,
        role: str,
        timeout: int = 2700,
    ) -> bool:
        """Wait for a specific worker to be ready.

        Called by stage before_callbacks:
        - Audio stage calls wait_for_worker("tts")
        - Production stage calls wait_for_worker("video")

        Returns True if the worker is healthy.
        Raises RuntimeError if provisioning failed or timed out.
        """
        if _TEST_MODE:
            return True

        # Wait for start_provisioning() to populate _specs
        if not self._specs_ready.wait(timeout=120):
            raise RuntimeError(
                "Timed out waiting for start_provisioning() to "
                "populate worker specs (120s)"
            )

        if self._provision_start_error:
            raise RuntimeError(
                f"Worker provisioning failed to start: {self._provision_start_error}"
            )

        spec = self._get_spec(role)
        if spec is None:
            raise RuntimeError(
                f"No {role} worker spec found — was start_provisioning() called?"
            )

        if spec.status == "healthy":
            return True

        logger.info(
            "Stage waiting for %s worker (status=%s, timeout=%ds)...",
            role, spec.status, timeout,
        )

        # Wait for background thread to finish
        ready = spec.ready_event.wait(timeout=timeout)
        if not ready:
            raise RuntimeError(f"{role} worker provisioning timed out after {timeout}s")

        if spec.status == "failed":
            raise RuntimeError(
                f"Cannot proceed: {role} worker provisioning failed: {spec.error}"
            )

        if spec.status == "healthy":
            logger.info("%s worker is ready — stage may proceed", role)
            self._start_infra_agent_if_ready()
            return True

        raise RuntimeError(f"{role} worker in unexpected state: {spec.status}")

    def _get_spec(self, role: str) -> Optional[WorkerSpec]:
        """Get the WorkerSpec for a given role."""
        with self._lock:
            for spec in self._specs:
                if spec.role == role:
                    return spec
        return None

    def ensure_workers_ready(
        self,
        require_tts: bool = True,
        require_video: bool = True,
        provision_timeout: int = 2700,
    ) -> dict:
        """Ensure all required workers are healthy, provisioning if needed.

        Legacy blocking API — provisions all workers and blocks until all
        are healthy.  New code should use start_provisioning() +
        wait_for_worker() for parallelism.

        Returns a status dict with worker details.
        """
        self.start_provisioning(
            require_tts=require_tts,
            require_video=require_video,
        )

        if _TEST_MODE:
            return {"status": "test_mode", "workers": []}

        status = {"workers": [], "provisioned": [], "already_healthy": []}

        for spec in self._specs:
            try:
                self.wait_for_worker(spec.role, timeout=provision_timeout)
                if spec.vm_id:
                    status["provisioned"].append(spec.role)
                else:
                    status["already_healthy"].append(spec.role)
                status["workers"].append({
                    "role": spec.role,
                    "url": f"http://localhost:{spec.local_port}",
                    "status": "healthy",
                    "provisioned": bool(spec.vm_id),
                    "vm_id": spec.vm_id,
                })
            except Exception as exc:
                status["workers"].append({
                    "role": spec.role,
                    "status": "failed",
                    "error": str(exc),
                })
                self._cleanup_all_on_failure()
                raise

        with self._lock:
            self._provisioned = True

        status["status"] = "ready"
        logger.info(
            "WorkerProvisioner: all workers ready. "
            "Already healthy: %s. Provisioned: %s.",
            status["already_healthy"], status["provisioned"],
        )
        return status

    def _provision_and_connect(
        self, spec: WorkerSpec, timeout: int = 2400
    ) -> None:
        """Provision a VM, set up tunnel, and wait for health.

        Full lifecycle for a single worker with retry logic for slow hosts.
        """
        _MAX_LOADING_RETRIES = 2
        _LOADING_TIMEOUT = 300  # seconds before we consider a host "slow"
        _start = time.time()
        _excluded_offers: set[int] = set()

        for attempt in range(1 + _MAX_LOADING_RETRIES):
            # Step 1: Provision VM
            try:
                selected_offer_id = provision_vm_with_resilience(
                    spec, excluded_offer_ids=_excluded_offers or None
                )
            except Exception as e:
                logger.error("Failed to provision VM for %s: %s", spec.role, e)
                raise

            # Step 2: Wait for VM to be running
            is_final = (attempt >= _MAX_LOADING_RETRIES)
            cap = 600 if is_final else _LOADING_TIMEOUT
            elapsed = int(time.time() - _start)
            vm_timeout = max(min(timeout - elapsed, cap), 60)
            
            try:
                wait_for_vm_running(spec, timeout=vm_timeout)
                break  # VM is running — proceed to SSH + health
            except Exception:
                if attempt < _MAX_LOADING_RETRIES:
                    if selected_offer_id:
                        _excluded_offers.add(selected_offer_id)
                    logger.warning(
                        "%s VM %s (offer %s) stuck loading after %ds "
                        "— destroying and retrying on a different host",
                        spec.role, spec.vm_id, selected_offer_id, vm_timeout
                    )
                    # Destroy the slow VM
                    try:
                        _vast_cmd(["destroy", "instance", spec.vm_id], timeout=30)
                        spec.vm_id = ""
                    except Exception as exc:
                        logger.warning("Failed to destroy slow VM %s: %s", spec.vm_id, exc)
                    spec.ssh_host = ""
                    spec.ssh_port = 0
                    continue
                else:
                    raise

        # Step 3: Set up SSH tunnel
        setup_ssh_tunnel(spec)

        # Step 4: Wait for worker to be healthy
        elapsed = int(time.time() - _start)
        remaining = max(timeout - elapsed, 120)
        healthy = wait_for_worker_healthy(spec, timeout=remaining)
        
        if not healthy:
            if spec.bootstrap_error:
                raise RuntimeError(
                    f"{spec.role} worker BOOTSTRAP FAILED on VM {spec.vm_id} "
                    f"(category={spec.bootstrap_error_category}): {spec.bootstrap_error}"
                )
            raise RuntimeError(
                f"{spec.role} worker on VM {spec.vm_id} did not become "
                f"healthy within {remaining}s after provisioning"
            )

    def _cleanup_single_worker(self, spec: WorkerSpec) -> None:
        """Clean up a single worker's resources (tunnel + VM)."""
        if spec.tunnel_proc and spec.tunnel_proc.poll() is None:
            logger.info("Cleaning up SSH tunnel for %s (pid=%d)", spec.role, spec.tunnel_proc.pid)
            try:
                spec.tunnel_proc.terminate()
                spec.tunnel_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                spec.tunnel_proc.kill()
            except Exception as e:
                logger.warning("Error cleaning up tunnel: %s", e)

        if spec.vm_id:
            logger.info("Destroying %s VM %s to stop billing", spec.role, spec.vm_id)
            try:
                _vast_cmd(["destroy", "instance", spec.vm_id], timeout=30)
            except Exception as exc:
                logger.warning("Failed to destroy VM %s: %s", spec.vm_id, exc)

    def _cleanup_all_on_failure(self) -> None:
        """Clean up all provisioned resources after a failure."""
        with self._lock:
            specs = list(self._specs)
        for spec in specs:
            self._cleanup_single_worker(spec)

    def _start_infra_agent(self) -> None:
        """Start the InfraAgent and register provisioned workers."""
        try:
            from infra_agent import WorkerRole, start_infra_agent

            infra = start_infra_agent(poll_interval=30.0, max_consecutive_failures=3)
            infra.start()

            for spec in self._specs:
                if spec.vm_id:
                    role = WorkerRole.TTS if spec.role == "tts" else WorkerRole.VIDEO
                    url = f"http://localhost:{spec.local_port}"
                    infra.add_worker(url, role)
                    logger.info("Registered %s worker at %s with InfraAgent", spec.role, url)

            logger.info("InfraAgent started for continuous monitoring")
        except Exception as exc:
            logger.warning("Failed to start InfraAgent: %s", exc)

    def _start_infra_agent_if_ready(self) -> None:
        """Start InfraAgent once all workers are ready."""
        with self._lock:
            all_ready = all(s.status == "healthy" for s in self._specs)
            already_started = self._provisioned
        if all_ready and not already_started:
            with self._lock:
                self._provisioned = True
            self._start_infra_agent()

    def cleanup(self) -> None:
        """Clean up: kill SSH tunnels, destroy VMs, and stop InfraAgent."""
        self._shutdown.set()
        
        # Wait for any in-flight provisioning threads
        for role, thread in self._threads.items():
            if thread.is_alive():
                logger.info("Waiting for %s provisioning thread to finish...", role)
                thread.join(timeout=30)

        with self._lock:
            specs = list(self._specs)

        for spec in specs:
            self._cleanup_single_worker(spec)

        # Clear specs
        with self._lock:
            self._specs = []
            self._provisioned = False
            self._threads = {}
        self._provision_start_error = ""
        self._specs_ready.clear()

        # Shutdown InfraAgent
        try:
            from infra_agent import get_infra_agent
            agent = get_infra_agent()
            if agent:
                agent.shutdown()
                logger.info("InfraAgent stopped")
        except Exception:
            pass

    def get_vm_ids(self) -> list[str]:
        """Return the IDs of all provisioned VMs."""
        with self._lock:
            return [s.vm_id for s in self._specs if s.vm_id]


# =============================================================================
# Module-level singleton
# =============================================================================

_provisioner: Optional[WorkerProvisioner] = None
_provisioner_lock = threading.Lock()


def get_provisioner() -> WorkerProvisioner:
    """Return the global WorkerProvisioner singleton."""
    global _provisioner
    with _provisioner_lock:
        if _provisioner is None:
            _provisioner = WorkerProvisioner()
    return _provisioner
