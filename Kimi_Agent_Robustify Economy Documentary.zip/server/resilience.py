"""
Resilience module -- comprehensive error handling and fault tolerance patterns.

This module provides:
1. Retry logic with exponential backoff (using tenacity)
2. Circuit breaker pattern for failing services
3. Graceful degradation with fallback strategies
4. Timeout handling for long-running operations
5. Resource cleanup context managers
6. Comprehensive exception hierarchy

Usage:
    from resilience import (
        with_retry, circuit_breaker, graceful_degradation,
        timeout, resilient_context, DocumentaryError,
    )
    
    # Retry with exponential backoff
    @with_retry(max_attempts=3, exceptions=(ConnectionError, TimeoutError))
    def call_external_api():
        ...
    
    # Circuit breaker
    @circuit_breaker(failure_threshold=5, recovery_timeout=60)
    def call_vastai():
        ...
    
    # Graceful degradation
    @graceful_degradation(fallback=generate_silent_wav)
    def generate_tts():
        ...
"""

from __future__ import annotations

import functools
import logging
import os
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Type, Union

# Try to import tenacity, provide fallback if not available
try:
    from tenacity import (
        retry,
        retry_if_exception_type,
        stop_after_attempt,
        stop_after_delay,
        wait_exponential,
        wait_random,
        before_sleep_log,
        after_log,
        RetryError,
    )
    TENACITY_AVAILABLE = True
except ImportError:
    TENACITY_AVAILABLE = False
    logging.warning("tenacity not available, using fallback retry implementation")

logger = logging.getLogger(__name__)

# =============================================================================
# Custom Exception Hierarchy
# =============================================================================


class DocumentaryError(Exception):
    """Base exception for all documentary pipeline errors."""
    
    def __init__(self, message: str, error_code: str = "", details: Optional[dict] = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "UNKNOWN_ERROR"
        self.details = details or {}
        self.timestamp = time.time()
        self.trace_id = str(uuid.uuid4())[:8]
    
    def __str__(self) -> str:
        return f"[{self.error_code}:{self.trace_id}] {self.message}"
    
    def to_dict(self) -> dict:
        return {
            "error_code": self.error_code,
            "message": self.message,
            "trace_id": self.trace_id,
            "timestamp": self.timestamp,
            "details": self.details,
        }


class ExternalAPIError(DocumentaryError):
    """Error calling external APIs (Vast.ai, B2, LLM services)."""
    pass


class VastAIError(ExternalAPIError):
    """Error interacting with Vast.ai API."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, error_code="VASTAI_ERROR", details=details)


class B2StorageError(ExternalAPIError):
    """Error interacting with Backblaze B2 storage."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, error_code="B2_STORAGE_ERROR", details=details)


class LLMServiceError(ExternalAPIError):
    """Error calling LLM services (LiteLLM, OpenRouter, DashScope)."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, error_code="LLM_SERVICE_ERROR", details=details)


class GPUWorkerError(DocumentaryError):
    """Error from GPU worker (TTS or Video generation)."""
    
    def __init__(self, message: str, worker_type: str = "", details: Optional[dict] = None):
        super().__init__(message, error_code="GPU_WORKER_ERROR", details=details)
        self.worker_type = worker_type


class ResourceExhaustedError(DocumentaryError):
    """Resource exhausted (VRAM, disk space, memory)."""
    
    def __init__(self, message: str, resource_type: str = "", details: Optional[dict] = None):
        super().__init__(message, error_code="RESOURCE_EXHAUSTED", details=details)
        self.resource_type = resource_type


class TimeoutError(DocumentaryError):
    """Operation timed out."""
    
    def __init__(self, message: str, operation: str = "", timeout_sec: float = 0, details: Optional[dict] = None):
        super().__init__(message, error_code="TIMEOUT_ERROR", details=details)
        self.operation = operation
        self.timeout_sec = timeout_sec


class CircuitBreakerOpenError(DocumentaryError):
    """Circuit breaker is open - service is temporarily unavailable."""
    
    def __init__(self, message: str, service_name: str = "", details: Optional[dict] = None):
        super().__init__(message, error_code="CIRCUIT_BREAKER_OPEN", details=details)
        self.service_name = service_name


# =============================================================================
# Retry Logic with Exponential Backoff
# =============================================================================


def with_retry(
    max_attempts: int = 3,
    min_wait: float = 1.0,
    max_wait: float = 60.0,
    exceptions: tuple = (Exception,),
    retry_on_result: Optional[Callable[[Any], bool]] = None,
    stop_on_timeout: Optional[float] = None,
    reraise: bool = True,
):
    """
    Decorator for retry logic with exponential backoff.
    
    Args:
        max_attempts: Maximum number of retry attempts
        min_wait: Minimum wait time between retries (seconds)
        max_wait: Maximum wait time between retries (seconds)
        exceptions: Tuple of exception types to retry on
        retry_on_result: Optional callable to check if result should trigger retry
        stop_on_timeout: Optional total timeout for all attempts
        reraise: Whether to reraise the last exception after retries exhausted
    
    Returns:
        Decorated function with retry logic
    """
    def decorator(func: Callable) -> Callable:
        if TENACITY_AVAILABLE:
            # Use tenacity for robust retry logic
            retry_decorator = retry(
                retry=retry_if_exception_type(exceptions) if not retry_on_result else (
                    retry_if_exception_type(exceptions) | retry_on_result
                ),
                stop=(
                    stop_after_attempt(max_attempts) if not stop_on_timeout 
                    else (stop_after_attempt(max_attempts) | stop_after_delay(stop_on_timeout))
                ),
                wait=wait_exponential(multiplier=min_wait, min=min_wait, max=max_wait) + wait_random(0, 1),
                before_sleep=before_sleep_log(logger, logging.WARNING),
                after=after_log(logger, logging.INFO),
                reraise=reraise,
            )
            return retry_decorator(func)
        else:
            # Fallback implementation if tenacity not available
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                last_exception = None
                start_time = time.time()
                
                for attempt in range(1, max_attempts + 1):
                    try:
                        result = func(*args, **kwargs)
                        
                        # Check if result should trigger retry
                        if retry_on_result and retry_on_result(result):
                            if attempt < max_attempts:
                                wait_time = min(min_wait * (2 ** (attempt - 1)), max_wait)
                                logger.warning(
                                    "Retry %d/%d for %s: result check failed, waiting %.1fs",
                                    attempt, max_attempts, func.__name__, wait_time
                                )
                                time.sleep(wait_time)
                                continue
                        
                        return result
                        
                    except exceptions as e:
                        last_exception = e
                        
                        # Check timeout
                        if stop_on_timeout and (time.time() - start_time) >= stop_on_timeout:
                            logger.error(
                                "Timeout reached for %s after %.1fs",
                                func.__name__, stop_on_timeout
                            )
                            break
                        
                        if attempt < max_attempts:
                            wait_time = min(min_wait * (2 ** (attempt - 1)), max_wait)
                            logger.warning(
                                "Retry %d/%d for %s: %s, waiting %.1fs",
                                attempt, max_attempts, func.__name__, e, wait_time
                            )
                            time.sleep(wait_time)
                        else:
                            logger.error(
                                "All %d retries exhausted for %s: %s",
                                max_attempts, func.__name__, e
                            )
                
                if reraise and last_exception:
                    raise last_exception
                return None
            
            return wrapper
    
    return decorator


# =============================================================================
# Circuit Breaker Pattern
# =============================================================================


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if service recovered


@dataclass
class CircuitBreakerStats:
    """Statistics for circuit breaker."""
    failures: int = 0
    successes: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    state_changes: List[Dict] = field(default_factory=list)


class CircuitBreaker:
    """
    Circuit breaker for protecting against cascading failures.
    
    When failures exceed threshold, circuit opens and requests are rejected
    for a recovery period. After recovery timeout, circuit enters half-open
    state to test if service has recovered.
    
    Usage:
        breaker = CircuitBreaker("vastai", failure_threshold=5, recovery_timeout=60)
        
        @breaker
        def call_vastai():
            ...
    """
    
    _instances: Dict[str, "CircuitBreaker"] = {}
    _lock = threading.Lock()
    
    def __new__(cls, name: str, *args, **kwargs):
        """Singleton pattern - one circuit breaker per service name."""
        with cls._lock:
            if name not in cls._instances:
                instance = super().__new__(cls)
                cls._instances[name] = instance
            return cls._instances[name]
    
    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_calls: int = 3,
        expected_exception: Type[Exception] = Exception,
    ):
        # Only initialize once per instance
        if hasattr(self, '_initialized'):
            return
        
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        self.expected_exception = expected_exception
        
        self._state = CircuitState.CLOSED
        self._stats = CircuitBreakerStats()
        self._half_open_calls = 0
        self._lock = threading.RLock()
        self._initialized = True
        
        logger.info(
            "CircuitBreaker initialized for %s: threshold=%d, recovery=%.1fs",
            name, failure_threshold, recovery_timeout
        )
    
    @property
    def state(self) -> CircuitState:
        """Get current circuit state."""
        with self._lock:
            return self._state
    
    @property
    def stats(self) -> CircuitBreakerStats:
        """Get circuit breaker statistics."""
        with self._lock:
            return CircuitBreakerStats(
                failures=self._stats.failures,
                successes=self._stats.successes,
                last_failure_time=self._stats.last_failure_time,
                last_success_time=self._stats.last_success_time,
                state_changes=list(self._stats.state_changes),
            )
    
    def _record_state_change(self, from_state: CircuitState, to_state: CircuitState, reason: str):
        """Record a state change."""
        change = {
            "timestamp": time.time(),
            "from": from_state.value,
            "to": to_state.value,
            "reason": reason,
        }
        self._stats.state_changes.append(change)
        logger.warning(
            "CircuitBreaker %s: %s -> %s (%s)",
            self.name, from_state.value, to_state.value, reason
        )
    
    def _can_execute(self) -> bool:
        """Check if request can be executed based on circuit state."""
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True
            
            if self._state == CircuitState.OPEN:
                # Check if recovery timeout has passed
                time_since_failure = time.time() - self._stats.last_failure_time
                if time_since_failure >= self.recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_calls = 0
                    self._record_state_change(
                        CircuitState.OPEN, CircuitState.HALF_OPEN,
                        f"Recovery timeout ({self.recovery_timeout}s) elapsed"
                    )
                    return True
                return False
            
            if self._state == CircuitState.HALF_OPEN:
                if self._half_open_calls < self.half_open_max_calls:
                    self._half_open_calls += 1
                    return True
                return False
            
            return True
    
    def _record_success(self):
        """Record a successful call."""
        with self._lock:
            self._stats.successes += 1
            self._stats.last_success_time = time.time()
            
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.CLOSED
                self._half_open_calls = 0
                self._stats.failures = 0  # Reset failure count
                self._record_state_change(
                    CircuitState.HALF_OPEN, CircuitState.CLOSED,
                    "Success in half-open state"
                )
    
    def _record_failure(self, exception: Exception):
        """Record a failed call."""
        with self._lock:
            self._stats.failures += 1
            self._stats.last_failure_time = time.time()
            
            if self._state == CircuitState.HALF_OPEN:
                # Failure in half-open, go back to open
                self._state = CircuitState.OPEN
                self._half_open_calls = 0
                self._record_state_change(
                    CircuitState.HALF_OPEN, CircuitState.OPEN,
                    f"Failure in half-open: {exception}"
                )
            elif self._state == CircuitState.CLOSED:
                if self._stats.failures >= self.failure_threshold:
                    self._state = CircuitState.OPEN
                    self._record_state_change(
                        CircuitState.CLOSED, CircuitState.OPEN,
                        f"Failure threshold ({self.failure_threshold}) reached"
                    )
    
    def __call__(self, func: Callable) -> Callable:
        """Decorator to wrap function with circuit breaker."""
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if not self._can_execute():
                raise CircuitBreakerOpenError(
                    f"Circuit breaker for {self.name} is OPEN - service unavailable",
                    service_name=self.name,
                    details={
                        "recovery_in": max(0, self.recovery_timeout - (time.time() - self._stats.last_failure_time)),
                        "stats": self._stats.to_dict() if hasattr(self._stats, 'to_dict') else {
                            "failures": self._stats.failures,
                            "successes": self._stats.successes,
                        }
                    }
                )
            
            try:
                result = func(*args, **kwargs)
                self._record_success()
                return result
            except self.expected_exception as e:
                self._record_failure(e)
                raise
        
        # Attach circuit breaker instance to wrapper for inspection
        wrapper._circuit_breaker = self
        return wrapper
    
    def force_open(self, reason: str = "manual"):
        """Manually open the circuit."""
        with self._lock:
            old_state = self._state
            self._state = CircuitState.OPEN
            self._stats.last_failure_time = time.time()
            if old_state != CircuitState.OPEN:
                self._record_state_change(old_state, CircuitState.OPEN, reason)
    
    def force_close(self, reason: str = "manual"):
        """Manually close the circuit."""
        with self._lock:
            old_state = self._state
            self._state = CircuitState.CLOSED
            self._stats.failures = 0
            self._half_open_calls = 0
            if old_state != CircuitState.CLOSED:
                self._record_state_change(old_state, CircuitState.CLOSED, reason)


def circuit_breaker(
    name: Optional[str] = None,
    failure_threshold: int = 5,
    recovery_timeout: float = 60.0,
    half_open_max_calls: int = 3,
    expected_exception: Type[Exception] = Exception,
):
    """
    Decorator factory for circuit breaker pattern.
    
    Args:
        name: Circuit breaker name (defaults to function name)
        failure_threshold: Number of failures before opening circuit
        recovery_timeout: Seconds to wait before trying again
        half_open_max_calls: Max calls in half-open state
        expected_exception: Exception types that count as failures
    """
    def decorator(func: Callable) -> Callable:
        breaker_name = name or func.__name__
        breaker = CircuitBreaker(
            name=breaker_name,
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            half_open_max_calls=half_open_max_calls,
            expected_exception=expected_exception,
        )
        return breaker(func)
    
    return decorator


# =============================================================================
# Graceful Degradation
# =============================================================================


class DegradationLevel(Enum):
    """Levels of graceful degradation."""
    FULL = "full"          # Full functionality
    DEGRADED = "degraded"  # Reduced functionality
    MINIMAL = "minimal"    # Minimal functionality
    FALLBACK = "fallback"  # Fallback only


@dataclass
class DegradationStrategy:
    """Strategy for graceful degradation."""
    fallback: Optional[Callable] = None
    fallback_value: Any = None
    on_degradation: Optional[Callable[[Exception, DegradationLevel], None]] = None
    log_degradation: bool = True


def graceful_degradation(
    fallback: Optional[Callable] = None,
    fallback_value: Any = None,
    exceptions: tuple = (Exception,),
    on_degradation: Optional[Callable] = None,
    log_degradation: bool = True,
    track_degradation: bool = True,
):
    """
    Decorator for graceful degradation with fallback.
    
    When the primary function fails, falls back to:
    1. fallback callable if provided
    2. fallback_value if provided
    3. Returns None if no fallback
    
    Args:
        fallback: Optional fallback function to call on failure
        fallback_value: Optional static value to return on failure
        exceptions: Tuple of exceptions to catch
        on_degradation: Optional callback when degradation occurs
        log_degradation: Whether to log degradation events
        track_degradation: Whether to track degradation statistics
    """
    # Track degradation statistics
    _degradation_stats: Dict[str, Dict] = {}
    _stats_lock = threading.Lock()
    
    def decorator(func: Callable) -> Callable:
        func_name = func.__name__
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except exceptions as e:
                # Log degradation
                if log_degradation:
                    logger.warning(
                        "Graceful degradation for %s: %s. Using fallback.",
                        func_name, e
                    )
                
                # Track degradation
                if track_degradation:
                    with _stats_lock:
                        if func_name not in _degradation_stats:
                            _degradation_stats[func_name] = {
                                "count": 0,
                                "last_occurrence": None,
                                "exceptions": set(),
                            }
                        _degradation_stats[func_name]["count"] += 1
                        _degradation_stats[func_name]["last_occurrence"] = time.time()
                        _degradation_stats[func_name]["exceptions"].add(type(e).__name__)
                
                # Call degradation callback
                if on_degradation:
                    try:
                        on_degradation(e, DegradationLevel.FALLBACK)
                    except Exception as callback_err:
                        logger.error("Degradation callback failed: %s", callback_err)
                
                # Execute fallback
                if fallback:
                    try:
                        return fallback(*args, **kwargs)
                    except Exception as fallback_err:
                        logger.error("Fallback failed for %s: %s", func_name, fallback_err)
                
                # Return fallback value
                if fallback_value is not None:
                    return fallback_value
                
                # Re-raise if no fallback
                raise
        
        # Attach stats accessor
        wrapper._degradation_stats = lambda: dict(_degradation_stats.get(func_name, {}))
        return wrapper
    
    return decorator


# =============================================================================
# Timeout Handling
# =============================================================================


class TimeoutManager:
    """Manager for operation timeouts."""
    
    def __init__(self, default_timeout: float = 60.0):
        self.default_timeout = default_timeout
        self._active_timeouts: Dict[str, float] = {}
        self._lock = threading.Lock()
    
    def register(self, operation_id: str, timeout: float):
        """Register an operation with timeout."""
        with self._lock:
            self._active_timeouts[operation_id] = time.time() + timeout
    
    def unregister(self, operation_id: str):
        """Unregister an operation."""
        with self._lock:
            self._active_timeouts.pop(operation_id, None)
    
    def check_timeout(self, operation_id: str) -> bool:
        """Check if operation has timed out."""
        with self._lock:
            if operation_id not in self._active_timeouts:
                return False
            return time.time() > self._active_timeouts[operation_id]
    
    def get_remaining(self, operation_id: str) -> float:
        """Get remaining time for operation."""
        with self._lock:
            if operation_id not in self._active_timeouts:
                return 0.0
            return max(0, self._active_timeouts[operation_id] - time.time())


# Global timeout manager
_timeout_manager = TimeoutManager()


def timeout(seconds: float, operation_name: str = ""):
    """
    Decorator to add timeout to function.
    
    Args:
        seconds: Timeout in seconds
        operation_name: Name of operation for error messages
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            operation_id = f"{func.__name__}_{uuid.uuid4().hex[:8]}"
            _timeout_manager.register(operation_id, seconds)
            
            try:
                # Use threading for timeout enforcement
                import concurrent.futures
                
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(func, *args, **kwargs)
                    try:
                        return future.result(timeout=seconds)
                    except concurrent.futures.TimeoutError:
                        raise TimeoutError(
                            f"Operation '{operation_name or func.__name__}' timed out after {seconds}s",
                            operation=operation_name or func.__name__,
                            timeout_sec=seconds,
                        )
            finally:
                _timeout_manager.unregister(operation_id)
        
        return wrapper
    return decorator


@contextmanager
def timeout_context(seconds: float, operation_name: str = ""):
    """
    Context manager for timeout handling.
    
    Usage:
        with timeout_context(30, "API call"):
            result = make_api_call()
    """
    import signal
    
    def timeout_handler(signum, frame):
        raise TimeoutError(
            f"Operation '{operation_name}' timed out after {seconds}s",
            operation=operation_name,
            timeout_sec=seconds,
        )
    
    # Set up signal handler (Unix only)
    old_handler = signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(int(seconds))
    
    try:
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old_handler)


# =============================================================================
# Resource Cleanup Context Managers
# =============================================================================


@contextmanager
def resilient_context(
    cleanup_callback: Optional[Callable] = None,
    error_callback: Optional[Callable[[Exception], None]] = None,
    suppress_exceptions: bool = False,
):
    """
    Context manager for resilient resource handling.
    
    Args:
        cleanup_callback: Called on exit (success or failure)
        error_callback: Called when exception occurs
        suppress_exceptions: Whether to suppress exceptions after handling
    
    Usage:
        with resilient_context(cleanup_callback=cleanup, error_callback=on_error):
            do_work()
    """
    exception_occurred = False
    exception = None
    
    try:
        yield
    except Exception as e:
        exception_occurred = True
        exception = e
        
        if error_callback:
            try:
                error_callback(e)
            except Exception as callback_err:
                logger.error("Error callback failed: %s", callback_err)
        
        if not suppress_exceptions:
            raise
    finally:
        if cleanup_callback:
            try:
                cleanup_callback()
            except Exception as cleanup_err:
                logger.error("Cleanup callback failed: %s", cleanup_err)


@contextmanager
def managed_resource(
    acquire: Callable[[], Any],
    release: Callable[[Any], None],
    acquire_timeout: float = 30.0,
    release_timeout: float = 10.0,
):
    """
    Context manager for managed resource lifecycle.
    
    Args:
        acquire: Function to acquire resource
        release: Function to release resource
        acquire_timeout: Timeout for acquisition
        release_timeout: Timeout for release
    
    Usage:
        with managed_resource(acquire_db, release_db) as db:
            db.query(...)
    """
    resource = None
    
    try:
        # Acquire with timeout
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(acquire)
            try:
                resource = future.result(timeout=acquire_timeout)
            except concurrent.futures.TimeoutError:
                raise TimeoutError(
                    f"Resource acquisition timed out after {acquire_timeout}s",
                    operation="resource_acquire",
                    timeout_sec=acquire_timeout,
                )
        
        yield resource
        
    finally:
        if resource is not None:
            try:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(release, resource)
                    try:
                        future.result(timeout=release_timeout)
                    except concurrent.futures.TimeoutError:
                        logger.error("Resource release timed out after %ss", release_timeout)
            except Exception as e:
                logger.error("Resource release failed: %s", e)


# =============================================================================
# Combined Resilience Decorator
# =============================================================================


def resilient(
    max_retries: int = 3,
    retry_exceptions: tuple = (Exception,),
    retry_min_wait: float = 1.0,
    retry_max_wait: float = 60.0,
    circuit_breaker_name: Optional[str] = None,
    circuit_failure_threshold: int = 5,
    circuit_recovery_timeout: float = 60.0,
    fallback: Optional[Callable] = None,
    fallback_value: Any = None,
    timeout_seconds: Optional[float] = None,
):
    """
    Combined resilience decorator with retry, circuit breaker, and graceful degradation.
    
    Args:
        max_retries: Maximum retry attempts
        retry_exceptions: Exceptions to retry on
        retry_min_wait: Minimum wait between retries
        retry_max_wait: Maximum wait between retries
        circuit_breaker_name: Name for circuit breaker (None = no circuit breaker)
        circuit_failure_threshold: Circuit breaker failure threshold
        circuit_recovery_timeout: Circuit breaker recovery timeout
        fallback: Fallback function
        fallback_value: Fallback static value
        timeout_seconds: Optional timeout for operation
    """
    def decorator(func: Callable) -> Callable:
        # Apply timeout first (innermost)
        wrapped = func
        if timeout_seconds:
            wrapped = timeout(timeout_seconds)(wrapped)
        
        # Apply graceful degradation
        if fallback or fallback_value is not None:
            wrapped = graceful_degradation(
                fallback=fallback,
                fallback_value=fallback_value,
                exceptions=retry_exceptions,
            )(wrapped)
        
        # Apply circuit breaker
        if circuit_breaker_name:
            wrapped = circuit_breaker(
                name=circuit_breaker_name,
                failure_threshold=circuit_failure_threshold,
                recovery_timeout=circuit_recovery_timeout,
                expected_exception=retry_exceptions,
            )(wrapped)
        
        # Apply retry (outermost)
        wrapped = with_retry(
            max_attempts=max_retries,
            min_wait=retry_min_wait,
            max_wait=retry_max_wait,
            exceptions=retry_exceptions,
        )(wrapped)
        
        return wrapped
    
    return decorator


# =============================================================================
# Health Check Utilities
# =============================================================================


class HealthChecker:
    """Health checker for services."""
    
    def __init__(self):
        self._checks: Dict[str, Callable[[], Dict]] = {}
        self._results: Dict[str, Dict] = {}
        self._lock = threading.RLock()
    
    def register(self, name: str, check_func: Callable[[], Dict]):
        """Register a health check."""
        with self._lock:
            self._checks[name] = check_func
    
    def check(self, name: Optional[str] = None) -> Dict:
        """Run health check(s)."""
        with self._lock:
            if name:
                if name not in self._checks:
                    return {"status": "unknown", "error": f"No check registered for {name}"}
                try:
                    result = self._checks[name]()
                    self._results[name] = result
                    return result
                except Exception as e:
                    result = {"status": "unhealthy", "error": str(e)}
                    self._results[name] = result
                    return result
            else:
                results = {}
                for check_name, check_func in self._checks.items():
                    try:
                        result = check_func()
                        self._results[check_name] = result
                        results[check_name] = result
                    except Exception as e:
                        result = {"status": "unhealthy", "error": str(e)}
                        self._results[check_name] = result
                        results[check_name] = result
                return results
    
    def get_last_results(self) -> Dict:
        """Get last health check results."""
        with self._lock:
            return dict(self._results)


# Global health checker
health_checker = HealthChecker()


# =============================================================================
# Utility Functions
# =============================================================================


def safe_execute(
    func: Callable,
    *args,
    default: Any = None,
    log_errors: bool = True,
    **kwargs
) -> Any:
    """
    Safely execute a function, returning default on failure.
    
    Args:
        func: Function to execute
        *args: Positional arguments
        default: Default value to return on failure
        log_errors: Whether to log errors
        **kwargs: Keyword arguments
    
    Returns:
        Function result or default value
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        if log_errors:
            logger.error("safe_execute failed for %s: %s", func.__name__, e)
        return default


def retry_with_backoff(
    func: Callable,
    max_attempts: int = 3,
    min_wait: float = 1.0,
    max_wait: float = 60.0,
    exceptions: tuple = (Exception,),
) -> Any:
    """
    Execute function with retry and exponential backoff.
    
    Args:
        func: Function to execute
        max_attempts: Maximum retry attempts
        min_wait: Minimum wait between retries
        max_wait: Maximum wait between retries
        exceptions: Exceptions to retry on
    
    Returns:
        Function result
    
    Raises:
        Last exception if all retries fail
    """
    last_exception = None
    
    for attempt in range(1, max_attempts + 1):
        try:
            return func()
        except exceptions as e:
            last_exception = e
            if attempt < max_attempts:
                wait_time = min(min_wait * (2 ** (attempt - 1)), max_wait)
                logger.warning(
                    "Retry %d/%d: %s, waiting %.1fs",
                    attempt, max_attempts, e, wait_time
                )
                time.sleep(wait_time)
    
    raise last_exception


# =============================================================================
# Export public API
# =============================================================================

__all__ = [
    # Exceptions
    "DocumentaryError",
    "ExternalAPIError",
    "VastAIError",
    "B2StorageError",
    "LLMServiceError",
    "GPUWorkerError",
    "ResourceExhaustedError",
    "TimeoutError",
    "CircuitBreakerOpenError",
    
    # Retry
    "with_retry",
    "retry_with_backoff",
    
    # Circuit Breaker
    "CircuitBreaker",
    "circuit_breaker",
    "CircuitState",
    
    # Graceful Degradation
    "graceful_degradation",
    "DegradationLevel",
    "DegradationStrategy",
    
    # Timeout
    "timeout",
    "timeout_context",
    "TimeoutManager",
    
    # Context Managers
    "resilient_context",
    "managed_resource",
    
    # Combined
    "resilient",
    
    # Health Check
    "HealthChecker",
    "health_checker",
    
    # Utilities
    "safe_execute",
]
