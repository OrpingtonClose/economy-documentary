# Migration Guide: Legacy to Pydantic-Settings Configuration

This guide helps you migrate from the legacy `os.environ.get()` configuration system to the new pydantic-settings based system.

## Quick Migration Checklist

- [ ] Update `pyproject.toml` with new dependencies
- [ ] Copy new `config/` directory to your project
- [ ] Replace `from config import ...` statements
- [ ] Update server startup validation
- [ ] Create environment-specific `.env` files
- [ ] Test in development environment
- [ ] Deploy to staging
- [ ] Deploy to production

## Detailed Migration Steps

### Step 1: Update Dependencies

Add to your `pyproject.toml`:

```toml
[project]
dependencies = [
    # ... existing dependencies ...
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "python-dotenv>=1.0.0",
]
```

Then install:
```bash
pip install pydantic pydantic-settings python-dotenv
```

### Step 2: Copy New Configuration Files

Copy the new configuration package to your project:

```bash
# From the output directory
cp -r config/ /path/to/your/project/
cp .env.development /path/to/your/project/
cp .env.staging /path/to/your/project/
cp .env.production /path/to/your/project/
```

### Step 3: Update Import Statements

**Before (Legacy):**
```python
from config import (
    MAX_CONCURRENT_LLM,
    DOCUMENTARY_TEST_MODE,
    ADK_MODEL,
    GOOGLE_API_KEY,
)
```

**After (New System):**
```python
from config import get_settings

settings = get_settings()

# Access values through settings object
max_concurrent = settings.concurrency.max_concurrent_llm
test_mode = settings.documentary_test_mode
model = settings.adk_model
google_key = settings.llm_providers.google_api_key
```

### Step 4: Update API Key Access

**Before:**
```python
from config import GOOGLE_API_KEY

if GOOGLE_API_KEY:
    client = GeminiClient(api_key=GOOGLE_API_KEY)
```

**After:**
```python
from config import get_settings

settings = get_settings()
google_key = settings.llm_providers.google_api_key

if google_key:
    # SecretStr needs .get_secret_value()
    client = GeminiClient(api_key=google_key.get_secret_value())
```

### Step 5: Update Path Access

**Before:**
```python
from config import DATA_DIR, TIMELINE_DIR

output_path = TIMELINE_DIR / "timeline.json"
```

**After:**
```python
from config import get_settings

settings = get_settings()
output_path = settings.paths.timeline_dir / "timeline.json"
```

### Step 6: Update Server Startup

**Before (`server/server.py`):**
```python
def _validate_env() -> None:
    """Validate required environment variables at startup."""
    model = ADK_MODEL_NAME
    if not model:
        raise ValueError("ADK_MODEL environment variable is required")

    has_google = bool(os.environ.get("GOOGLE_API_KEY"))
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    
    if not (has_google or has_openai):
        logger.warning("No API keys configured...")
```

**After:**
```python
from config import validate_startup, get_settings

@app.on_event("startup")
async def on_startup():
    """Application startup: validate configuration."""
    # Comprehensive validation
    await validate_startup(exit_on_error=True)
    
    # Additional setup
    settings = get_settings()
    setup_otel()
    init_db()
```

### Step 7: Create Your Environment File

Choose the appropriate template for your environment:

```bash
# For local development
cp .env.development .env

# For staging server
cp .env.staging .env

# For production server
cp .env.production .env
```

Edit `.env` and fill in your actual API keys and configuration values.

### Step 8: Update Feature Flag Checks

**Before:**
```python
if os.environ.get("DOCUMENTARY_TEST_MODE", "false").lower() == "true":
    # Test mode logic
    pass
```

**After:**
```python
from config import get_settings, get_feature_flags

settings = get_settings()
if settings.documentary_test_mode:
    # Test mode logic
    pass

# Or use feature flags for more control
flags = get_feature_flags()
if flags.is_enabled("ENABLE_GPU_WORKERS"):
    provision_gpu()
```

## Common Migration Patterns

### Pattern 1: Simple Value Access

| Legacy | New |
|--------|-----|
| `from config import ADK_MODEL` | `settings.adk_model` |
| `from config import MAX_CONCURRENT_LLM` | `settings.concurrency.max_concurrent_llm` |
| `from config import DATA_DIR` | `settings.paths.data_dir` |

### Pattern 2: API Keys

| Legacy | New |
|--------|-----|
| `from config import GOOGLE_API_KEY` | `settings.llm_providers.google_api_key` |
| `from config import OPENAI_API_KEY` | `settings.llm_providers.openai_api_key` |
| `from config import VAST_API_KEY` | `settings.infrastructure.vast_api_key` |

### Pattern 3: Boolean Flags

| Legacy | New |
|--------|-----|
| `DOCUMENTARY_TEST_MODE = os.environ.get(...).lower() in ("true", "1")` | `settings.documentary_test_mode` (boolean) |
| `ADK_DEBUG = os.environ.get(...).lower() in ("true", "1")` | `settings.observability.adk_debug` (boolean) |

### Pattern 4: Integer Values

| Legacy | New |
|--------|-----|
| `int(os.environ.get("MAX_CONTEXT_TOKENS", "120000"))` | `settings.concurrency.max_context_tokens` (int) |
| `int(os.environ.get("GPU_CONCURRENCY", "2"))` | `settings.concurrency.gpu_concurrency` (int) |

### Pattern 5: Path Values

| Legacy | New |
|--------|-----|
| `Path(os.environ.get("DATA_DIR", "/tmp/..."))` | `settings.paths.data_dir` (Path) |
| `Path(os.environ.get("TIMELINE_DIR", ...))` | `settings.paths.timeline_dir` (Path) |

## Backward Compatibility

The new system provides backward compatibility through:

### Legacy `_read_key()` Function

```python
from config import _read_key

# Still works as before
api_key = _read_key("deepseek_api.txt")  # Returns DEEPSEEK_API env var
```

### Environment Variable Names

All environment variable names remain the same:
- `GOOGLE_API_KEY` → `settings.llm_providers.google_api_key`
- `ADK_MODEL` → `settings.adk_model`
- `MAX_CONCURRENT_LLM` → `settings.concurrency.max_concurrent_llm`

## Testing Your Migration

### 1. Configuration Validation Test

```python
from config import get_settings, validate_configuration

settings = get_settings()
warnings = validate_configuration()

if warnings:
    print("Warnings:")
    for w in warnings:
        print(f"  - {w}")
else:
    print("✅ Configuration is valid")
```

### 2. Startup Validation Test

```python
import asyncio
from config.startup import validate_startup

async def test_startup():
    result = await validate_startup(exit_on_error=False)
    print(f"Can start: {result.can_start()}")
    print(f"Warnings: {len(result.warnings)}")
    print(f"Errors: {len(result.errors)}")

asyncio.run(test_startup())
```

### 3. Feature Flags Test

```python
from config import get_feature_flags

flags = get_feature_flags()
flags.set_environment("development")

print("Enabled features:")
for flag_name in flags.get_enabled_flags():
    print(f"  - {flag_name}")
```

## Troubleshooting

### Issue: "ModuleNotFoundError: No module named 'config'"

**Solution**: Ensure the `config/` directory is in your Python path:

```python
import sys
sys.path.insert(0, '/path/to/your/project')
```

Or install your package in editable mode:
```bash
pip install -e .
```

### Issue: "ValidationError: HARD_CONTEXT_LIMIT must be greater than MAX_CONTEXT_TOKENS"

**Solution**: Update your `.env` file:
```bash
MAX_CONTEXT_TOKENS=120000
HARD_CONTEXT_LIMIT=180000  # Must be > MAX_CONTEXT_TOKENS
```

### Issue: "No LLM provider API key configured"

**Solution**: Add at least one API key to your `.env`:
```bash
GOOGLE_API_KEY=your-key-here
# or
OPENAI_API_KEY=your-key-here
```

### Issue: "SecretStr object has no attribute 'startswith'"

**Solution**: Use `.get_secret_value()` to access the actual string:

```python
# Wrong
api_key = settings.llm_providers.google_api_key
if api_key.startswith("sk-"):  # ❌ Error!

# Right
api_key = settings.llm_providers.google_api_key
if api_key and api_key.get_secret_value().startswith("sk-"):  # ✅
```

## Rollback Plan

If you need to rollback to the legacy system:

1. Keep the old `config.py` file as `config_legacy.py`
2. Update imports to use `config_legacy` instead of `config`
3. Remove pydantic-settings from dependencies

```python
# Emergency rollback
from config_legacy import (
    MAX_CONCURRENT_LLM,
    DOCUMENTARY_TEST_MODE,
    # ... etc
)
```

## Migration Timeline

| Phase | Duration | Activities |
|-------|----------|------------|
| 1. Preparation | 1 day | Review code, identify all config usage |
| 2. Development | 2-3 days | Update code, test locally |
| 3. Staging | 1-2 days | Deploy to staging, validate |
| 4. Production | 1 day | Deploy to production, monitor |

## Support

For issues during migration:

1. Check the `CONFIGURATION_IMPROVEMENTS.md` for detailed documentation
2. Review the examples in `config/__init__.py`
3. Run `print_configuration_status()` to debug configuration issues

## Summary

The migration provides:
- ✅ Type-safe configuration
- ✅ Automatic validation
- ✅ Better error messages
- ✅ Environment-specific configs
- ✅ Feature flags
- ✅ Secrets rotation
- ✅ Auto-generated documentation

The effort is worth the improved robustness and maintainability!
