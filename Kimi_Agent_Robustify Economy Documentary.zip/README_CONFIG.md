# Configuration Package - README

This directory contains the improved configuration management system for the Documentary Pipeline project.

## 📁 File Structure

```
output/
├── config/                          # Main configuration package
│   ├── __init__.py                  # Package exports and convenience functions
│   ├── settings.py                  # Pydantic settings with all configuration
│   ├── feature_flags.py             # Feature flag system
│   ├── secrets.py                   # Secrets rotation support
│   ├── validators.py                # Custom validators
│   ├── documentation.py             # Documentation generator
│   └── startup.py                   # Startup validation
│
├── .env.example                     # Generic environment template
├── .env.development                 # Development environment
├── .env.staging                     # Staging environment
├── .env.production                  # Production environment
│
├── pyproject.toml                   # Updated dependencies
├── server_config.py                 # Updated server configuration
│
├── CONFIGURATION_IMPROVEMENTS.md    # Summary of improvements
├── MIGRATION_GUIDE.md               # Step-by-step migration guide
└── README_CONFIG.md                 # This file
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install pydantic pydantic-settings python-dotenv
```

### 2. Copy Configuration Files

```bash
# Copy the config package
cp -r config/ /path/to/your/project/

# Copy environment template
cp .env.development /path/to/your/project/.env
```

### 3. Configure Your Environment

Edit `.env` and fill in your API keys:

```bash
# Required
GOOGLE_API_KEY=your-google-api-key

# Optional
OPENAI_API_KEY=your-openai-key
VAST_API_KEY=your-vast-key
```

### 4. Use in Your Code

```python
from config import get_settings, get_feature_flags

# Get settings
settings = get_settings()

# Access configuration
print(settings.adk_model)
print(settings.concurrency.max_concurrent_llm)

# Check feature flags
flags = get_feature_flags()
if flags.is_enabled("ENABLE_GPU_WORKERS"):
    provision_gpu()
```

## 📖 Key Features

### Type-Safe Configuration

All configuration values are validated at startup:

```python
from config import get_settings

settings = get_settings()

# Type-safe access
max_tokens: int = settings.concurrency.max_context_tokens
api_key: SecretStr = settings.llm_providers.google_api_key
```

### Environment-Specific Configs

Load different configurations per environment:

```python
from config import get_settings_for_environment, Environment

# Development
settings = get_settings_for_environment(Environment.DEVELOPMENT)

# Production
settings = get_settings_for_environment(Environment.PRODUCTION)
```

### Feature Flags

Enable gradual rollouts and A/B testing:

```python
from config.feature_flags import get_feature_flags

flags = get_feature_flags()

# Boolean flag
if flags.is_enabled("ENABLE_NEW_FEATURE"):
    use_new_feature()

# Percentage-based (10% of users)
if flags.is_enabled("EXPERIMENTAL_FEATURE", user_id="user123"):
    show_experimental_ui()
```

### Startup Validation

Validate configuration before starting:

```python
from config import validate_startup

@app.on_event("startup")
async def on_startup():
    await validate_startup()
```

### Secrets Rotation

Support for rotating secrets without downtime:

```python
from config.secrets import SecretsRotationManager, RotationStrategy

manager = SecretsRotationManager()
await manager.rotate_secret(
    "api_key",
    new_value=SecretStr("new-secret"),
    strategy=RotationStrategy.GRACEFUL,
)
```

## 📚 Documentation

- **CONFIGURATION_IMPROVEMENTS.md** - Detailed summary of all improvements
- **MIGRATION_GUIDE.md** - Step-by-step migration instructions
- **config/__init__.py** - Docstrings for all exported functions

## 🔧 Configuration Reference

### Core Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ENVIRONMENT` | string | `development` | Deployment environment |
| `DEBUG` | boolean | `false` | Enable debug mode |
| `LOG_LEVEL` | string | `INFO` | Logging level |
| `ADK_MODEL` | string | `gemini-2.5-flash` | Primary LLM model |

### API Keys

| Variable | Section | Description |
|----------|---------|-------------|
| `GOOGLE_API_KEY` | `llm_providers.google_api_key` | Google/Gemini API |
| `OPENAI_API_KEY` | `llm_providers.openai_api_key` | OpenAI API |
| `VAST_API_KEY` | `infrastructure.vast_api_key` | Vast.ai API |
| `B2_KEY_ID` | `storage.key_id` | Backblaze B2 key |

### Concurrency

| Variable | Section | Default | Description |
|----------|---------|---------|-------------|
| `MAX_CONCURRENT_LLM` | `concurrency.max_concurrent_llm` | 4 | Max concurrent LLM |
| `MAX_CONTEXT_TOKENS` | `concurrency.max_context_tokens` | 120000 | Max context |
| `GPU_CONCURRENCY` | `concurrency.gpu_concurrency` | 2 | Max GPU ops |

## 🧪 Testing

Run the configuration tests:

```python
from config import get_settings, validate_configuration

# Get settings
settings = get_settings()

# Validate
warnings = validate_configuration()
if warnings:
    print("Warnings:", warnings)
else:
    print("✅ Configuration valid")

# Print status
from config import print_configuration_status
print_configuration_status()
```

## 🔒 Security

### Secret Handling

All API keys use `SecretStr` for security:

```python
from config import get_settings

settings = get_settings()

# This is a SecretStr object (masked in logs)
secret = settings.llm_providers.google_api_key

# Get the actual value
api_key = secret.get_secret_value()
```

### Best Practices

1. **Never commit `.env` files** - Add to `.gitignore`
2. **Use environment-specific files** - Separate dev/staging/prod configs
3. **Rotate secrets regularly** - Use the secrets rotation manager
4. **Validate at startup** - Catch configuration errors early

## 🐛 Troubleshooting

### Common Issues

**Issue**: `ModuleNotFoundError: No module named 'config'`

**Solution**: Ensure the `config/` directory is in your Python path:
```python
import sys
sys.path.insert(0, '/path/to/project')
```

**Issue**: `ValidationError: HARD_CONTEXT_LIMIT must be greater than MAX_CONTEXT_TOKENS`

**Solution**: Update your `.env`:
```bash
MAX_CONTEXT_TOKENS=120000
HARD_CONTEXT_LIMIT=180000  # Must be greater
```

**Issue**: `No LLM provider API key configured`

**Solution**: Add an API key:
```bash
GOOGLE_API_KEY=your-key-here
```

## 📈 Performance

The configuration system is optimized for performance:

- **Cached Settings**: `get_settings()` uses `@lru_cache`
- **Lazy Loading**: Sub-configs loaded on demand
- **Validation at Startup**: Issues caught early
- **Type Safety**: Fewer runtime errors

## 🤝 Contributing

To add new configuration options:

1. Add the field to the appropriate settings class in `config/settings.py`
2. Add validation rules if needed
3. Update `.env.example` with the new variable
4. Regenerate documentation

Example:
```python
class MySettings(BaseSettings):
    my_new_field: str = Field(
        default="default_value",
        description="Description of the field",
    )
```

## 📄 License

This configuration package is part of the Documentary Pipeline project.

## 🔗 Links

- [Pydantic Settings Documentation](https://docs.pydantic.dev/latest/concepts/pydantic_settings/)
- [Pydantic Validation](https://docs.pydantic.dev/latest/concepts/validators/)
- [Feature Flags Pattern](https://martinfowler.com/articles/feature-toggles.html)
