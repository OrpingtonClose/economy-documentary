# Pull Request

## Description
<!-- Provide a brief description of the changes in this PR -->

Fixes # (issue number)

## Type of Change
<!-- Mark the relevant option with an [x] -->

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Code refactoring
- [ ] Test improvement
- [ ] CI/CD improvement
- [ ] Other (please describe):

## Changes Made
<!-- List the key changes made in this PR -->

1. 
2. 
3. 

## Testing
<!-- Describe the tests you ran and how to reproduce them -->

- [ ] Unit tests pass (`make test-server`)
- [ ] Integration tests pass
- [ ] Frontend tests pass (`make test-frontend`)
- [ ] Manual testing performed

### Test Configuration
* Python version:
* Node.js version:
* Operating System:

## Code Quality
<!-- Ensure all code quality checks pass -->

- [ ] Code follows the project style guidelines (`make lint`)
- [ ] Code is properly formatted (`make format`)
- [ ] Type checking passes (`make typecheck`)
- [ ] No new security vulnerabilities (`make security`)
- [ ] Pre-commit hooks pass (`make precommit`)

## Documentation
<!-- Mark the relevant option with an [x] -->

- [ ] Documentation updated (if applicable)
- [ ] Code comments added/updated
- [ ] README updated (if applicable)
- [ ] API documentation updated (if applicable)

## Checklist
<!-- Ensure all items are completed before submitting -->

- [ ] My code follows the project's style guidelines
- [ ] I have performed a self-review of my code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] Any dependent changes have been merged and published

## Screenshots (if applicable)
<!-- Add screenshots to help explain your changes -->

## Related Issues
<!-- Link any related issues -->

Closes #
Relates to #

## Deployment Notes
<!-- Any special notes for deployment -->

## Security Considerations
<!-- Describe any security implications -->

- [ ] No sensitive data exposed
- [ ] Secrets are properly handled
- [ ] Security best practices followed

## Performance Impact
<!-- Describe any performance implications -->

- [ ] No significant performance impact
- [ ] Performance improved
- [ ] Performance degraded (explain why):

## Additional Notes
<!-- Any additional information that reviewers should know -->

---

## Reviewer Checklist
<!-- For reviewers -->

- [ ] Code is clear and maintainable
- [ ] Tests cover the changes adequately
- [ ] Documentation is clear and complete
- [ ] Changes are appropriate for the scope of the PR
- [ ] Security implications have been considered
