"""
Central configuration — all settings from environment variables.

This is the single source of truth for runtime configuration.
Import from here rather than reading env vars directly.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


# ── Topic Configuration ──────────────────────────────────────
# The documentary topic — set dynamically per run
DOCUMENTARY_TOPIC: str = os.environ.get("DOCUMENTARY_TOPIC", "")

# ── Paths ────────────────────────────────────────────────────
PROJECT_ROOT: Path = Path(__file__).resolve().parent
DATA_DIR: Path = Path(os.environ.get("DATA_DIR", "/tmp/documentary-pipeline"))
CORPUS_DIR: Path = DATA_DIR / "corpus"
TRANSCRIPT_DIR: Path = CORPUS_DIR / "transcripts"
ENRICHMENT_DIR: Path = DATA_DIR / "enrichment"
TIMELINE_DIR: Path = Path(os.environ.get("TIMELINE_DIR", str(DATA_DIR / "timelines")))
TTS_OUTPUT_DIR: Path = Path(os.environ.get("TTS_OUTPUT_DIR", str(DATA_DIR / "tts")))
VIDEO_OUTPUT_DIR: Path = Path(os.environ.get("VIDEO_OUTPUT_DIR", str(DATA_DIR / "video")))
FINDINGS_DIR: Path = Path(os.environ.get("FINDINGS_DIR", str(DATA_DIR / "findings")))
DASHBOARD_DB_DIR: Path = Path(os.environ.get("DASHBOARD_DB_DIR", str(DATA_DIR / "dashboard")))

# ── API Keys (env vars only — no file-based keys) ───────────
# Env var names match what pipeline/_read_key() derives from legacy filenames.
# e.g. _read_key("minmax_api.txt") -> os.getenv("MINMAX_API")
#
# LLM Providers
MINMAX_API: str = os.environ.get("MINMAX_API", "")
DEEPSEEK_API: str = os.environ.get("DEEPSEEK_API", "")
PERPLEXITY_API_KEY: str = os.environ.get("PERPLEXITY_API_KEY", "")
GEMINI_API_KEY: str = os.environ.get("GEMINI_API_KEY", "")
GROK_API: str = os.environ.get("GROK_API", "")
OPENROUTER_API: str = os.environ.get("OPENROUTER_API", "")
GROQ_API: str = os.environ.get("GROQ_API", "")
MISTRAL_API_KEY: str = os.environ.get("MISTRAL_API_KEY", "")
OPENAI_API_KEY: str = os.environ.get("OPENAI_API_KEY", "")
ANTHROPIC_API: str = os.environ.get("ANTHROPIC_API", "")

# Search Providers
EXA_API_KEY: str = os.environ.get("EXA_API_KEY", "")
TAVILY_API_KEY: str = os.environ.get("TAVILY_API_KEY", "")
BRAVE_SEARCH_API_KEY: str = os.environ.get("BRAVE_SEARCH_API_KEY", "")
GOOGLE_SEARCH_API: str = os.environ.get("GOOGLE_SEARCH_API", "")
GOOGLE_SEARCH_ENGINE_ID: str = os.environ.get("GOOGLE_SEARCH_ENGINE_ID", "")

# Data APIs
FRED_API_KEY: str = os.environ.get("FRED_API_KEY", "")
WOLFRAM_ALPHA_API: str = os.environ.get("WOLFRAM_ALPHA_API", "")
JINA_API_KEY: str = os.environ.get("JINA_API_KEY", "")

# GPU / Infrastructure
VAST_API_KEY: str = os.environ.get("VAST_API_KEY", "")

# Proxy Services
BRIGHTDATA_KEY: str = os.environ.get("BRIGHTDATA_KEY", "")
BRIGHTDATA_CUSTOMER_ID: str = os.environ.get("BRIGHTDATA_CUSTOMER_ID", "hl_dc044bf4")
BRIGHTDATA_ZONE: str = os.environ.get("BRIGHTDATA_ZONE", "mcp_unlocker")
OXYLABS_USERNAME: str = os.environ.get("OXYLABS_USERNAME", "")
OXYLABS_PASSWORD: str = os.environ.get("OXYLABS_PASSWORD", "")

# Observability
AGENTOPS_API_KEY: str = os.environ.get("AGENTOPS_API_KEY", "")

# ── ADK Model Configuration ─────────────────────────────────
ADK_MODEL: str = os.environ.get("ADK_MODEL", "gemini-2.5-flash")
ADK_SYNTHESIS_MODEL: str = os.environ.get("ADK_SYNTHESIS_MODEL", "")
ADK_THINKER_MODEL: str = os.environ.get("ADK_THINKER_MODEL", "")
ADK_VISION_MODEL: str = os.environ.get("ADK_VISION_MODEL", "")
OPENAI_API_BASE: str = os.environ.get("OPENAI_API_BASE", "")

# ── Concurrency ──────────────────────────────────────────────
MAX_CONCURRENT_LLM: int = int(os.environ.get("MAX_CONCURRENT_LLM", "4"))
MAX_CONTEXT_TOKENS: int = int(os.environ.get("MAX_CONTEXT_TOKENS", "120000"))
HARD_CONTEXT_LIMIT: int = int(os.environ.get("HARD_CONTEXT_LIMIT", "180000"))
TOOL_RESULT_MAX_CHARS: int = int(os.environ.get("TOOL_RESULT_MAX_CHARS", "30000"))
GPU_CONCURRENCY: int = int(os.environ.get("GPU_CONCURRENCY", "2"))
TTS_CONCURRENCY: int = int(os.environ.get("TTS_CONCURRENCY", "3"))
VASTAI_CONCURRENCY: int = int(os.environ.get("VASTAI_CONCURRENCY", "2"))
TREE_MAX_CONCURRENT: int = int(os.environ.get("TREE_MAX_CONCURRENT", "4"))
MAX_SUBAGENT_TURNS: int = int(os.environ.get("MAX_SUBAGENT_TURNS", "12"))

# ── Feature Flags ────────────────────────────────────────────
DOCUMENTARY_TEST_MODE: bool = os.environ.get("DOCUMENTARY_TEST_MODE", "false").strip().lower() in ("true", "1")
ADK_DEBUG: bool = os.environ.get("ADK_DEBUG", "false").strip().lower() in ("true", "1")
PHOENIX_ENABLED: bool = os.environ.get("PHOENIX_ENABLED", "false").strip().lower() in ("true", "1")
PHOENIX_COLLECTOR_ENDPOINT: str = os.environ.get("PHOENIX_COLLECTOR_ENDPOINT", "")

# ── Plugin Configuration ─────────────────────────────────────
CONTEXT_INVOCATIONS_TO_KEEP: int = int(os.environ.get("CONTEXT_INVOCATIONS_TO_KEEP", "10"))
TOOL_MAX_RETRIES: int = int(os.environ.get("TOOL_MAX_RETRIES", "2"))


def _read_key(filename: str) -> str:
    """Read an API key from environment variable.

    This is a compatibility shim for existing code that used file-based keys.
    The filename is converted to an env var name by stripping the extension
    and uppercasing:

        'minmax_api.txt' -> MINMAX_API
        'deepseek_api.txt' -> DEEPSEEK_API
        'exa_api_key.json' -> EXA_API_KEY

    Args:
        filename: Original key filename (e.g., 'deepseek_api.txt').

    Returns:
        The API key string, or empty string if not set.
    """
    # Strip any common extension, not just .txt
    base: str = filename.rsplit(".", 1)[0] if "." in filename else filename
    env_name: str = base.upper()
    return os.environ.get(env_name, "")


def get_config_summary() -> dict[str, Optional[str] | int | bool]:
    """Return a summary of configuration values (for debugging/logging).
    
    Returns:
        Dictionary with configuration summary (API keys masked for security).
    """
    return {
        "documentary_topic": DOCUMENTARY_TOPIC if DOCUMENTARY_TOPIC else "(not set)",
        "data_dir": str(DATA_DIR),
        "timeline_dir": str(TIMELINE_DIR),
        "adk_model": ADK_MODEL,
        "max_concurrent_llm": MAX_CONCURRENT_LLM,
        "gpu_concurrency": GPU_CONCURRENCY,
        "tts_concurrency": TTS_CONCURRENCY,
        "test_mode": DOCUMENTARY_TEST_MODE,
        "adk_debug": ADK_DEBUG,
        "phoenix_enabled": PHOENIX_ENABLED,
        # API keys - only show if set (masked)
        "has_gemini_key": bool(GEMINI_API_KEY),
        "has_openai_key": bool(OPENAI_API_KEY),
        "has_perplexity_key": bool(PERPLEXITY_API_KEY),
    }
