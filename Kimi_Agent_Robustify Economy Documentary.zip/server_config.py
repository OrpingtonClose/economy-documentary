"""
Updated server configuration using pydantic-settings.

This module replaces the legacy os.environ.get() approach with type-safe,
validated configuration using pydantic-settings.
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

# Import the new configuration system
from config import (
    DocumentarySettings,
    Environment,
    get_settings,
    get_feature_flags,
    validate_startup,
    print_configuration_status,
)
from config.startup import StartupValidator, ValidationSeverity

logger = logging.getLogger(__name__)


class ConfigurationMiddleware(BaseHTTPMiddleware):
    """Middleware to inject configuration into request state."""

    async def dispatch(self, request: Request, call_next):
        request.state.settings = get_settings()
        request.state.feature_flags = get_feature_flags()
        return await call_next(request)


async def validate_server_configuration() -> None:
    """
    Validate server configuration at startup.

    This replaces the legacy _validate_env() function with comprehensive
    validation using the new pydantic-settings system.
    """
    settings = get_settings()
    flags = get_feature_flags()

    # Set environment for feature flags
    flags.set_environment(settings.environment.value)

    # Initialize flags from settings
    flags.initialize_from_settings(settings)

    # Run comprehensive validation
    validator = StartupValidator(settings)
    result = await validator.validate_all()

    # Log validation results
    if result.can_start():
        logger.info("✅ Configuration validation passed")

        if result.has_warnings():
            for warning in result.warnings:
                logger.warning("Config warning: %s", warning.message)
    else:
        logger.error("❌ Configuration validation failed")
        for error in result.critical_errors:
            logger.error("Critical: %s", error.message)
        raise RuntimeError("Server configuration validation failed")

    # Log configuration summary
    logger.info(
        "Server configured for environment: %s, model: %s",
        settings.environment.value,
        settings.adk_model,
    )

    # Log enabled features
    enabled_flags = flags.get_enabled_flags()
    if enabled_flags:
        logger.info("Enabled features: %s", ", ".join(enabled_flags))


async def on_startup():
    """Application startup handler."""
    # Print configuration status
    print_configuration_status()

    # Validate configuration
    await validate_server_configuration()

    logger.info("Documentary pipeline server started successfully")


async def on_shutdown():
    """Application shutdown handler."""
    logger.info("Documentary pipeline server shutting down")


def create_fastapi_app() -> FastAPI:
    """
    Create and configure the FastAPI application.

    This function creates a properly configured FastAPI application
    with the new configuration system integrated.
    """
    settings = get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Application lifespan handler."""
        await on_startup()
        yield
        await on_shutdown()

    app = FastAPI(
        title="Documentary Pipeline",
        description="ADHD-friendly AI documentary pipeline with Google ADK + AG-UI",
        version=settings.app_version,
        lifespan=lifespan,
    )

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Add configuration middleware
    app.add_middleware(ConfigurationMiddleware)

    return app


# =============================================================================
# Legacy Compatibility
# =============================================================================

def _validate_env_legacy() -> None:
    """
    Legacy environment validation for backward compatibility.

    This function provides a bridge for code that expects the old
    validation behavior.
    """
    settings = get_settings()

    model = settings.adk_model
    if not model:
        raise ValueError("ADK_MODEL environment variable is required")

    # Check for at least one API key
    has_google = settings.llm_providers.google_api_key is not None
    has_openai = settings.llm_providers.openai_api_key is not None
    has_api_base = settings.llm_providers.openai_api_base is not None

    if not (has_google or has_openai or has_api_base):
        logger.warning(
            "No API keys configured. Set GOOGLE_API_KEY for Gemini "
            "or OPENAI_API_KEY + OPENAI_API_BASE for LiteLLM routing."
        )

    logger.info(
        "Model configuration: ADK_MODEL=%s, Gemini=%s, LiteLLM=%s",
        model,
        "yes" if has_google else "no",
        "yes" if (has_openai or has_api_base) else "no",
    )


# =============================================================================
# Configuration Health Check Endpoint
# =============================================================================

from fastapi import APIRouter

config_router = APIRouter(prefix="/config", tags=["configuration"])


@config_router.get("/health")
async def config_health():
    """Get configuration health status."""
    settings = get_settings()
    flags = get_feature_flags()

    validator = StartupValidator(settings)
    result = await validator.validate_all()

    return {
        "status": "healthy" if result.can_start() else "unhealthy",
        "environment": settings.environment.value,
        "version": settings.app_version,
        "can_start": result.can_start(),
        "warnings_count": len(result.warnings),
        "errors_count": len(result.errors),
        "critical_errors_count": len(result.critical_errors),
        "services": {
            "gemini": settings.is_configured("gemini"),
            "openai": settings.is_configured("openai"),
            "vastai": settings.is_configured("vastai"),
            "b2": settings.is_configured("b2"),
            "phoenix": settings.is_configured("phoenix"),
            "agentops": settings.is_configured("agentops"),
        },
        "enabled_features": flags.get_enabled_flags(),
    }


@config_router.get("/settings")
async def config_settings():
    """Get current configuration (sensitive values masked)."""
    settings = get_settings()

    # Return safe configuration (no secrets)
    return {
        "environment": settings.environment.value,
        "app_name": settings.app_name,
        "app_version": settings.app_version,
        "debug": settings.debug,
        "log_level": settings.log_level.value,
        "adk_model": settings.adk_model,
        "adk_synthesis_model": settings.adk_synthesis_model,
        "adk_thinker_model": settings.adk_thinker_model,
        "adk_vision_model": settings.adk_vision_model,
        "paths": {
            "data_dir": str(settings.paths.data_dir),
            "timeline_dir": str(settings.paths.timeline_dir),
            "tts_output_dir": str(settings.paths.tts_output_dir),
            "video_output_dir": str(settings.paths.video_output_dir),
        },
        "concurrency": {
            "max_concurrent_llm": settings.concurrency.max_concurrent_llm,
            "max_context_tokens": settings.concurrency.max_context_tokens,
            "gpu_concurrency": settings.concurrency.gpu_concurrency,
            "tts_concurrency": settings.concurrency.tts_concurrency,
        },
        "documentary_test_mode": settings.documentary_test_mode,
        "documentary_quick_test": settings.documentary_quick_test,
    }


@config_router.get("/feature-flags")
async def config_feature_flags():
    """Get all feature flags and their current status."""
    flags = get_feature_flags()
    return flags.export_config()


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "validate_server_configuration",
    "create_fastapi_app",
    "ConfigurationMiddleware",
    "config_router",
    "on_startup",
    "on_shutdown",
    "_validate_env_legacy",
]
