"""Central configuration — all settings from environment variables.

This is the single source of truth for runtime configuration.
Import from here rather than reading env vars directly.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# =============================================================================
# Configuration Dataclasses
# =============================================================================

@dataclass(frozen=True, slots=True)
class ApiKeys:
    """Container for all API keys used by the pipeline."""

    # LLM Providers
    minmax: str = ""
    deepseek: str = ""
    perplexity: str = ""
    gemini: str = ""
    grok: str = ""
    openrouter: str = ""
    groq: str = ""
    mistral: str = ""
    openai: str = ""
    anthropic: str = ""

    # Search Providers
    exa: str = ""
    tavily: str = ""
    brave_search: str = ""
    google_search: str = ""
    google_search_engine_id: str = ""

    # Data APIs
    fred: str = ""
    wolfram_alpha: str = ""
    jina: str = ""

    # GPU / Infrastructure
    vast_ai: str = ""

    # Proxy Services
    brightdata: str = ""
    brightdata_customer_id: str = "hl_dc044bf4"
    brightdata_zone: str = "mcp_unlocker"
    oxylabs_username: str = ""
    oxylabs_password: str = ""

    # Observability
    agentops: str = ""

    @classmethod
    def from_env(cls) -> ApiKeys:
        """Create ApiKeys instance from environment variables."""
        return cls(
            # LLM Providers
            minmax=os.environ.get("MINMAX_API", ""),
            deepseek=os.environ.get("DEEPSEEK_API", ""),
            perplexity=os.environ.get("PERPLEXITY_API_KEY", ""),
            gemini=os.environ.get("GEMINI_API_KEY", ""),
            grok=os.environ.get("GROK_API", ""),
            openrouter=os.environ.get("OPENROUTER_API", ""),
            groq=os.environ.get("GROQ_API", ""),
            mistral=os.environ.get("MISTRAL_API_KEY", ""),
            openai=os.environ.get("OPENAI_API_KEY", ""),
            anthropic=os.environ.get("ANTHROPIC_API", ""),
            # Search Providers
            exa=os.environ.get("EXA_API_KEY", ""),
            tavily=os.environ.get("TAVILY_API_KEY", ""),
            brave_search=os.environ.get("BRAVE_SEARCH_API_KEY", ""),
            google_search=os.environ.get("GOOGLE_SEARCH_API", ""),
            google_search_engine_id=os.environ.get("GOOGLE_SEARCH_ENGINE_ID", ""),
            # Data APIs
            fred=os.environ.get("FRED_API_KEY", ""),
            wolfram_alpha=os.environ.get("WOLFRAM_ALPHA_API", ""),
            jina=os.environ.get("JINA_API_KEY", ""),
            # GPU / Infrastructure
            vast_ai=os.environ.get("VAST_API_KEY", ""),
            # Proxy Services
            brightdata=os.environ.get("BRIGHTDATA_KEY", ""),
            brightdata_customer_id=os.environ.get(
                "BRIGHTDATA_CUSTOMER_ID", "hl_dc044bf4"
            ),
            brightdata_zone=os.environ.get("BRIGHTDATA_ZONE", "mcp_unlocker"),
            oxylabs_username=os.environ.get("OXYLABS_USERNAME", ""),
            oxylabs_password=os.environ.get("OXYLABS_PASSWORD", ""),
            # Observability
            agentops=os.environ.get("AGENTOPS_API_KEY", ""),
        )


@dataclass(frozen=True, slots=True)
class ConcurrencySettings:
    """Concurrency limits for various pipeline operations."""

    max_concurrent_llm: int = 4
    max_context_tokens: int = 120_000
    hard_context_limit: int = 180_000
    tool_result_max_chars: int = 30_000
    gpu_concurrency: int = 2
    tts_concurrency: int = 3
    vastai_concurrency: int = 2
    tree_max_concurrent: int = 4
    max_subagent_turns: int = 12

    @classmethod
    def from_env(cls) -> ConcurrencySettings:
        """Create ConcurrencySettings instance from environment variables."""
        return cls(
            max_concurrent_llm=_parse_int("MAX_CONCURRENT_LLM", 4),
            max_context_tokens=_parse_int("MAX_CONTEXT_TOKENS", 120_000),
            hard_context_limit=_parse_int("HARD_CONTEXT_LIMIT", 180_000),
            tool_result_max_chars=_parse_int("TOOL_RESULT_MAX_CHARS", 30_000),
            gpu_concurrency=_parse_int("GPU_CONCURRENCY", 2),
            tts_concurrency=_parse_int("TTS_CONCURRENCY", 3),
            vastai_concurrency=_parse_int("VASTAI_CONCURRENCY", 2),
            tree_max_concurrent=_parse_int("TREE_MAX_CONCURRENT", 4),
            max_subagent_turns=_parse_int("MAX_SUBAGENT_TURNS", 12),
        )


@dataclass(frozen=True, slots=True)
class FeatureFlags:
    """Feature flags for enabling/disabling pipeline features."""

    test_mode: bool = False
    adk_debug: bool = False
    phoenix_enabled: bool = False
    phoenix_collector_endpoint: str = ""

    @classmethod
    def from_env(cls) -> FeatureFlags:
        """Create FeatureFlags instance from environment variables."""
        return cls(
            test_mode=_parse_bool("DOCUMENTARY_TEST_MODE", False),
            adk_debug=_parse_bool("ADK_DEBUG", False),
            phoenix_enabled=_parse_bool("PHOENIX_ENABLED", False),
            phoenix_collector_endpoint=os.environ.get(
                "PHOENIX_COLLECTOR_ENDPOINT", ""
            ),
        )


@dataclass(frozen=True, slots=True)
class AdkConfig:
    """ADK model configuration settings."""

    model: str = "gemini-2.5-flash"
    synthesis_model: str = ""
    thinker_model: str = ""
    vision_model: str = ""
    openai_api_base: str = ""

    @classmethod
    def from_env(cls) -> AdkConfig:
        """Create AdkConfig instance from environment variables."""
        return cls(
            model=os.environ.get("ADK_MODEL", "gemini-2.5-flash"),
            synthesis_model=os.environ.get("ADK_SYNTHESIS_MODEL", ""),
            thinker_model=os.environ.get("ADK_THINKER_MODEL", ""),
            vision_model=os.environ.get("ADK_VISION_MODEL", ""),
            openai_api_base=os.environ.get("OPENAI_API_BASE", ""),
        )


@dataclass(frozen=True, slots=True)
class PluginConfig:
    """Plugin configuration settings."""

    context_invocations_to_keep: int = 10
    tool_max_retries: int = 2

    @classmethod
    def from_env(cls) -> PluginConfig:
        """Create PluginConfig instance from environment variables."""
        return cls(
            context_invocations_to_keep=_parse_int(
                "CONTEXT_INVOCATIONS_TO_KEEP", 10
            ),
            tool_max_retries=_parse_int("TOOL_MAX_RETRIES", 2),
        )


@dataclass(frozen=True, slots=True)
class PathConfig:
    """Path configuration for pipeline directories."""

    project_root: Path = field(default_factory=lambda: Path(__file__).resolve().parent)
    data_dir: Path = field(default_factory=lambda: Path("/tmp/documentary-pipeline"))
    corpus_dir: Path = field(init=False)
    transcript_dir: Path = field(init=False)
    enrichment_dir: Path = field(init=False)
    timeline_dir: Path = field(init=False)
    tts_output_dir: Path = field(init=False)
    video_output_dir: Path = field(init=False)
    findings_dir: Path = field(init=False)
    dashboard_db_dir: Path = field(init=False)

    def __post_init__(self) -> None:
        """Initialize derived paths."""
        # Use object.__setattr__ since dataclass is frozen
        object.__setattr__(self, "corpus_dir", self.data_dir / "corpus")
        object.__setattr__(
            self, "transcript_dir", self.corpus_dir / "transcripts"
        )
        object.__setattr__(self, "enrichment_dir", self.data_dir / "enrichment")
        object.__setattr__(
            self,
            "timeline_dir",
            Path(os.environ.get("TIMELINE_DIR", str(self.data_dir / "timelines"))),
        )
        object.__setattr__(
            self,
            "tts_output_dir",
            Path(os.environ.get("TTS_OUTPUT_DIR", str(self.data_dir / "tts"))),
        )
        object.__setattr__(
            self,
            "video_output_dir",
            Path(os.environ.get("VIDEO_OUTPUT_DIR", str(self.data_dir / "video"))),
        )
        object.__setattr__(
            self,
            "findings_dir",
            Path(os.environ.get("FINDINGS_DIR", str(self.data_dir / "findings"))),
        )
        object.__setattr__(
            self,
            "dashboard_db_dir",
            Path(os.environ.get("DASHBOARD_DB_DIR", str(self.data_dir / "dashboard"))),
        )


# =============================================================================
# Helper Functions
# =============================================================================


def _parse_int(env_var: str, default: int) -> int:
    """Parse an integer from an environment variable.

    Args:
        env_var: Name of the environment variable.
        default: Default value if not set or invalid.

    Returns:
        Parsed integer value.
    """
    try:
        return int(os.environ.get(env_var, str(default)))
    except (ValueError, TypeError):
        return default


def _parse_bool(env_var: str, default: bool) -> bool:
    """Parse a boolean from an environment variable.

    Args:
        env_var: Name of the environment variable.
        default: Default value if not set.

    Returns:
        True if the value is 'true', '1', or 'yes' (case-insensitive).
    """
    value = os.environ.get(env_var, "").strip().lower()
    return value in ("true", "1", "yes") if value else default


def _read_key(filename: str) -> str:
    """Read an API key from environment variable.

    This is a compatibility shim for existing code that used file-based keys.
    The filename is converted to an env var name by stripping the extension
    and uppercasing:

        'minmax_api.txt' -> MINMAX_API
        'deepseek_api.txt' -> DEEPSEEK_API
        'exa_api_key.json' -> EXA_API_KEY

    Args:
        filename: Original key filename (e.g., 'deepseek_api.txt').

    Returns:
        The API key string, or empty string if not set.
    """
    # Strip any common extension, not just .txt
    base = filename.rsplit(".", 1)[0] if "." in filename else filename
    env_name = base.upper()
    return os.environ.get(env_name, "")


# =============================================================================
# Global Configuration Instance
# =============================================================================

# Topic configuration - set dynamically per run
DOCUMENTARY_TOPIC: str = os.environ.get("DOCUMENTARY_TOPIC", "")

# Path configuration
DATA_DIR = Path(os.environ.get("DATA_DIR", "/tmp/documentary-pipeline"))
PROJECT_ROOT = Path(__file__).resolve().parent
CORPUS_DIR = DATA_DIR / "corpus"
TRANSCRIPT_DIR = CORPUS_DIR / "transcripts"
ENRICHMENT_DIR = DATA_DIR / "enrichment"
TIMELINE_DIR = Path(os.environ.get("TIMELINE_DIR", str(DATA_DIR / "timelines")))
TTS_OUTPUT_DIR = Path(os.environ.get("TTS_OUTPUT_DIR", str(DATA_DIR / "tts")))
VIDEO_OUTPUT_DIR = Path(os.environ.get("VIDEO_OUTPUT_DIR", str(DATA_DIR / "video")))
FINDINGS_DIR = Path(os.environ.get("FINDINGS_DIR", str(DATA_DIR / "findings")))
DASHBOARD_DB_DIR = Path(os.environ.get("DASHBOARD_DB_DIR", str(DATA_DIR / "dashboard")))

# API Keys
API_KEYS = ApiKeys.from_env()

# LLM Providers
MINMAX_API = API_KEYS.minmax
DEEPSEEK_API = API_KEYS.deepseek
PERPLEXITY_API_KEY = API_KEYS.perplexity
GEMINI_API_KEY = API_KEYS.gemini
GROK_API = API_KEYS.grok
OPENROUTER_API = API_KEYS.openrouter
GROQ_API = API_KEYS.groq
MISTRAL_API_KEY = API_KEYS.mistral
OPENAI_API_KEY = API_KEYS.openai
ANTHROPIC_API = API_KEYS.anthropic

# Search Providers
EXA_API_KEY = API_KEYS.exa
TAVILY_API_KEY = API_KEYS.tavily
BRAVE_SEARCH_API_KEY = API_KEYS.brave_search
GOOGLE_SEARCH_API = API_KEYS.google_search
GOOGLE_SEARCH_ENGINE_ID = API_KEYS.google_search_engine_id

# Data APIs
FRED_API_KEY = API_KEYS.fred
WOLFRAM_ALPHA_API = API_KEYS.wolfram_alpha
JINA_API_KEY = API_KEYS.jina

# GPU / Infrastructure
VAST_API_KEY = API_KEYS.vast_ai

# Proxy Services
BRIGHTDATA_KEY = API_KEYS.brightdata
BRIGHTDATA_CUSTOMER_ID = API_KEYS.brightdata_customer_id
BRIGHTDATA_ZONE = API_KEYS.brightdata_zone
OXYLABS_USERNAME = API_KEYS.oxylabs_username
OXYLABS_PASSWORD = API_KEYS.oxylabs_password

# Observability
AGENTOPS_API_KEY = API_KEYS.agentops

# ADK Model Configuration
ADK_MODEL = os.environ.get("ADK_MODEL", "gemini-2.5-flash")
ADK_SYNTHESIS_MODEL = os.environ.get("ADK_SYNTHESIS_MODEL", "")
ADK_THINKER_MODEL = os.environ.get("ADK_THINKER_MODEL", "")
ADK_VISION_MODEL = os.environ.get("ADK_VISION_MODEL", "")
OPENAI_API_BASE = os.environ.get("OPENAI_API_BASE", "")

# Concurrency Settings
CONCURRENCY = ConcurrencySettings.from_env()
MAX_CONCURRENT_LLM = CONCURRENCY.max_concurrent_llm
MAX_CONTEXT_TOKENS = CONCURRENCY.max_context_tokens
HARD_CONTEXT_LIMIT = CONCURRENCY.hard_context_limit
TOOL_RESULT_MAX_CHARS = CONCURRENCY.tool_result_max_chars
GPU_CONCURRENCY = CONCURRENCY.gpu_concurrency
TTS_CONCURRENCY = CONCURRENCY.tts_concurrency
VASTAI_CONCURRENCY = CONCURRENCY.vastai_concurrency
TREE_MAX_CONCURRENT = CONCURRENCY.tree_max_concurrent
MAX_SUBAGENT_TURNS = CONCURRENCY.max_subagent_turns

# Feature Flags
FEATURES = FeatureFlags.from_env()
DOCUMENTARY_TEST_MODE = FEATURES.test_mode
ADK_DEBUG = FEATURES.adk_debug
PHOENIX_ENABLED = FEATURES.phoenix_enabled
PHOENIX_COLLECTOR_ENDPOINT = FEATURES.phoenix_collector_endpoint

# Plugin Configuration
PLUGINS = PluginConfig.from_env()
CONTEXT_INVOCATIONS_TO_KEEP = PLUGINS.context_invocations_to_keep
TOOL_MAX_RETRIES = PLUGINS.tool_max_retries


# =============================================================================
# Configuration Validation
# =============================================================================


def validate_config() -> dict[str, Any]:
    """Validate the current configuration and return a status report.

    Returns:
        Dictionary containing validation results.
    """
    issues: list[str] = []
    warnings_list: list[str] = []

    # Check for at least one LLM API key
    llm_keys = [
        API_KEYS.gemini,
        API_KEYS.openai,
        API_KEYS.anthropic,
        API_KEYS.openrouter,
        API_KEYS.groq,
        API_KEYS.mistral,
        API_KEYS.deepseek,
    ]
    if not any(llm_keys):
        issues.append("No LLM API key configured")

    # Check Vast.ai key if GPU features are used
    if not API_KEYS.vast_ai:
        warnings_list.append("VAST_API_KEY not set - GPU worker provisioning disabled")

    # Check data directories are writable
    for path_name, path in [
        ("DATA_DIR", DATA_DIR),
        ("TIMELINE_DIR", TIMELINE_DIR),
        ("TTS_OUTPUT_DIR", TTS_OUTPUT_DIR),
        ("VIDEO_OUTPUT_DIR", VIDEO_OUTPUT_DIR),
    ]:
        try:
            path.mkdir(parents=True, exist_ok=True)
            test_file = path / ".write_test"
            test_file.touch()
            test_file.unlink()
        except OSError as e:
            issues.append(f"{path_name} is not writable: {e}")

    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "warnings": warnings_list,
        "api_status": {
            "llm_configured": any(llm_keys),
            "vast_ai_configured": bool(API_KEYS.vast_ai),
            "search_configured": any(
                [API_KEYS.exa, API_KEYS.tavily, API_KEYS.brave_search]
            ),
        },
    }


# Run validation on import (can be disabled in production)
if os.environ.get("CONFIG_VALIDATE_ON_IMPORT", "false").lower() == "true":
    _validation_result = validate_config()
    if not _validation_result["valid"]:
        raise RuntimeError(
            f"Configuration validation failed: {_validation_result['issues']}"
        )
