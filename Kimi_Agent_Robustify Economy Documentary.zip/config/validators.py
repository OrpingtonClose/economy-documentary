"""
Custom Validators for Configuration Settings.

This module provides custom validators for pydantic settings that can be reused
across different configuration sections.
"""

from __future__ import annotations

import re
from typing import Any

from pydantic import field_validator


def validate_url(url: str | None) -> str | None:
    """
    Validate a URL format.

    Args:
        url: URL string to validate

    Returns:
        The URL if valid, None if input is None

    Raises:
        ValueError: If URL format is invalid
    """
    if url is None:
        return None

    url_pattern = re.compile(
        r"^https?://"  # http:// or https://
        r"(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+"
        r"[A-Z]{2,6}\.?|"  # domain
        r"localhost|"  # localhost
        r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"  # or ip
        r"(?::\d+)?"  # optional port
        r"(?:/?|[/?]\S+)$",
        re.IGNORECASE,
    )

    if not url_pattern.match(url):
        raise ValueError(f"Invalid URL format: {url}")

    return url


def validate_api_key(key: str | None, min_length: int = 10) -> str | None:
    """
    Validate an API key format.

    Args:
        key: API key to validate
        min_length: Minimum required length

    Returns:
        The key if valid, None if input is None

    Raises:
        ValueError: If key format is invalid
    """
    if key is None:
        return None

    if len(key) < min_length:
        raise ValueError(f"API key must be at least {min_length} characters")

    # Check for common placeholder patterns
    placeholders = ["your-api-key", "xxx", "placeholder", "test", "example"]
    if any(p in key.lower() for p in placeholders):
        raise ValueError(f"API key appears to be a placeholder: {key[:10]}...")

    return key


def validate_path_exists(path: str | None) -> str | None:
    """
    Validate that a path exists.

    Args:
        path: Path to validate

    Returns:
        The path if valid, None if input is None

    Raises:
        ValueError: If path does not exist
    """
    if path is None:
        return None

    from pathlib import Path

    p = Path(path)
    if not p.exists():
        raise ValueError(f"Path does not exist: {path}")

    return path


def validate_email(email: str | None) -> str | None:
    """
    Validate an email address format.

    Args:
        email: Email to validate

    Returns:
        The email if valid, None if input is None

    Raises:
        ValueError: If email format is invalid
    """
    if email is None:
        return None

    email_pattern = re.compile(
        r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    )

    if not email_pattern.match(email):
        raise ValueError(f"Invalid email format: {email}")

    return email


def validate_json_string(json_str: str | None) -> dict[str, Any] | None:
    """
    Validate and parse a JSON string.

    Args:
        json_str: JSON string to validate

    Returns:
        Parsed JSON dict if valid, None if input is None

    Raises:
        ValueError: If JSON is invalid
    """
    if json_str is None:
        return None

    import json

    try:
        result = json.loads(json_str)
        if not isinstance(result, dict):
            raise ValueError("JSON must be an object (dict)")
        return result
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}")


def validate_port(port: int | str | None) -> int | None:
    """
    Validate a port number.

    Args:
        port: Port number to validate

    Returns:
        The port number if valid, None if input is None

    Raises:
        ValueError: If port is invalid
    """
    if port is None:
        return None

    if isinstance(port, str):
        try:
            port = int(port)
        except ValueError:
            raise ValueError(f"Port must be a number: {port}")

    if not 1 <= port <= 65535:
        raise ValueError(f"Port must be between 1 and 65535: {port}")

    return port


def validate_model_name(model: str | None) -> str | None:
    """
    Validate an AI model name format.

    Args:
        model: Model name to validate

    Returns:
        The model name if valid, None if input is None

    Raises:
        ValueError: If model name format is invalid
    """
    if model is None:
        return None

    # Common model name patterns
    valid_patterns = [
        r"^gemini-[\w.-]+$",  # Google Gemini
        r"^gpt-[\w-]+$",  # OpenAI GPT
        r"^claude-[\w-]+$",  # Anthropic Claude
        r"^litellm/[\w/]+$",  # LiteLLM routing
        r"^openai/[\w/-]+$",  # OpenAI-compatible
        r"^[\w-]+/[\w/-]+$",  # Provider/model format
    ]

    for pattern in valid_patterns:
        if re.match(pattern, model, re.IGNORECASE):
            return model

    # If no pattern matches, just ensure it's not empty and has reasonable format
    if len(model) < 3:
        raise ValueError(f"Model name too short: {model}")

    return model


# =============================================================================
# Pydantic Field Validators
# =============================================================================


def create_url_validator(field_name: str):
    """Create a pydantic field validator for URL fields."""

    @field_validator(field_name, mode="before")
    @classmethod
    def validator(cls, v):
        return validate_url(v)

    return validator


def create_api_key_validator(field_name: str, min_length: int = 10):
    """Create a pydantic field validator for API key fields."""

    @field_validator(field_name, mode="before")
    @classmethod
    def validator(cls, v):
        return validate_api_key(v, min_length)

    return validator


def create_port_validator(field_name: str):
    """Create a pydantic field validator for port fields."""

    @field_validator(field_name, mode="before")
    @classmethod
    def validator(cls, v):
        return validate_port(v)

    return validator


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "validate_url",
    "validate_api_key",
    "validate_path_exists",
    "validate_email",
    "validate_json_string",
    "validate_port",
    "validate_model_name",
    "create_url_validator",
    "create_api_key_validator",
    "create_port_validator",
]
