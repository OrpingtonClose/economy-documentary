"""
Configuration Documentation Generator.

This module generates comprehensive documentation for all configuration options:
- Markdown documentation with tables
- JSON schema for validation
- Environment variable reference
- Configuration examples
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, get_args, get_origin

from pydantic import BaseModel
from pydantic.fields import FieldInfo


@dataclass
class ConfigFieldDoc:
    """Documentation for a single configuration field."""

    name: str
    env_var: str
    type_str: str
    default: Any
    description: str
    required: bool = False
    validation_rules: list[str] = field(default_factory=list)
    example: str | None = None
    deprecated: bool = False
    deprecated_reason: str | None = None


@dataclass
class ConfigSectionDoc:
    """Documentation for a configuration section."""

    name: str
    description: str
    fields: list[ConfigFieldDoc] = field(default_factory=list)
    prefix: str | None = None


class ConfigurationDocumenter:
    """Generate documentation for configuration settings."""

    def __init__(self, settings_class: type[BaseModel]) -> None:
        """
        Initialize the documenter with a settings class.

        Args:
            settings_class: The pydantic settings class to document
        """
        self._settings_class = settings_class
        self._sections: list[ConfigSectionDoc] = []

    def generate_documentation(self) -> list[ConfigSectionDoc]:
        """Generate documentation for all configuration sections."""
        self._sections = []

        # Document main settings
        main_section = ConfigSectionDoc(
            name="Core Application Settings",
            description="Primary application configuration options",
        )

        for field_name, field_info in self._settings_class.model_fields.items():
            # Skip nested models - they'll be documented separately
            if self._is_nested_model(field_info):
                continue

            doc = self._create_field_doc(field_name, field_info)
            main_section.fields.append(doc)

        self._sections.append(main_section)

        # Document nested models
        for field_name, field_info in self._settings_class.model_fields.items():
            if self._is_nested_model(field_info):
                nested_section = self._document_nested_model(field_name, field_info)
                if nested_section:
                    self._sections.append(nested_section)

        return self._sections

    def _is_nested_model(self, field_info: FieldInfo) -> bool:
        """Check if a field is a nested BaseModel."""
        annotation = field_info.annotation
        if annotation is None:
            return False

        # Handle Optional[Model]
        origin = get_origin(annotation)
        if origin is not None:
            args = get_args(annotation)
            if args:
                annotation = args[0]

        return isinstance(annotation, type) and issubclass(annotation, BaseModel)

    def _document_nested_model(
        self, field_name: str, field_info: FieldInfo
    ) -> ConfigSectionDoc | None:
        """Document a nested model section."""
        annotation = field_info.annotation
        if annotation is None:
            return None

        # Handle Optional[Model]
        origin = get_origin(annotation)
        if origin is not None:
            args = get_args(annotation)
            if args:
                annotation = args[0]

        if not (isinstance(annotation, type) and issubclass(annotation, BaseModel)):
            return None

        # Get model config for prefix
        prefix = ""
        if hasattr(annotation, "model_config"):
            config = annotation.model_config
            prefix = config.get("env_prefix", "")

        # Get description from field or model doc
        description = field_info.description or ""
        if not description and annotation.__doc__:
            description = annotation.__doc__.strip().split("\n")[0]

        section = ConfigSectionDoc(
            name=self._format_section_name(field_name),
            description=description,
            prefix=prefix,
        )

        for nested_field_name, nested_field_info in annotation.model_fields.items():
            doc = self._create_field_doc(
                nested_field_name, nested_field_info, prefix=prefix
            )
            section.fields.append(doc)

        return section

    def _create_field_doc(
        self, field_name: str, field_info: FieldInfo, prefix: str = ""
    ) -> ConfigFieldDoc:
        """Create documentation for a single field."""
        # Get environment variable name
        env_var = self._get_env_var_name(field_name, prefix)

        # Get type string
        type_str = self._format_type(field_info.annotation)

        # Get default value
        default = field_info.default
        if default is None and field_info.is_required() is False:
            default = "None"

        # Get description
        description = field_info.description or ""

        # Get validation rules from json_schema_extra
        validation_rules = []
        if field_info.json_schema_extra:
            if "ge" in field_info.json_schema_extra:
                validation_rules.append(f"minimum: {field_info.json_schema_extra['ge']}")
            if "le" in field_info.json_schema_extra:
                validation_rules.append(f"maximum: {field_info.json_schema_extra['le']}")
            if "min_length" in field_info.json_schema_extra:
                validation_rules.append(
                    f"min length: {field_info.json_schema_extra['min_length']}"
                )
            if "max_length" in field_info.json_schema_extra:
                validation_rules.append(
                    f"max length: {field_info.json_schema_extra['max_length']}"
                )

        # Get example
        example = None
        if field_info.json_schema_extra and "example" in field_info.json_schema_extra:
            example = str(field_info.json_schema_extra["example"])

        return ConfigFieldDoc(
            name=field_name,
            env_var=env_var,
            type_str=type_str,
            default=default,
            description=description,
            required=field_info.is_required(),
            validation_rules=validation_rules,
            example=example,
        )

    def _get_env_var_name(self, field_name: str, prefix: str = "") -> str:
        """Generate environment variable name for a field."""
        # Convert field_name to UPPER_SNAKE_CASE
        env_name = "".join(
            ["_" + c.upper() if c.isupper() else c.upper() for c in field_name]
        ).lstrip("_")

        if prefix:
            return f"{prefix}{env_name}"
        return env_name

    def _format_type(self, annotation: Any) -> str:
        """Format a type annotation as a string."""
        if annotation is None:
            return "Any"

        origin = get_origin(annotation)
        args = get_args(annotation)

        if origin is not None:
            if origin is list or origin is set:
                inner = self._format_type(args[0]) if args else "Any"
                return f"list[{inner}]"
            elif origin is dict:
                key = self._format_type(args[0]) if args else "Any"
                val = self._format_type(args[1]) if len(args) > 1 else "Any"
                return f"dict[{key}, {val}]"
            elif origin is type(None):
                return "None"
            elif len(args) == 2 and type(None) in args:
                # Optional[T]
                inner = [a for a in args if a is not type(None)][0]
                return f"Optional[{self._format_type(inner)}]"
            else:
                return str(origin.__name__ if hasattr(origin, "__name__") else origin)

        if hasattr(annotation, "__name__"):
            return annotation.__name__

        return str(annotation)

    def _format_section_name(self, field_name: str) -> str:
        """Format a field name as a section title."""
        return " ".join(word.capitalize() for word in field_name.split("_"))

    def generate_markdown(self) -> str:
        """Generate Markdown documentation."""
        sections = self.generate_documentation()

        lines = [
            "# Configuration Reference",
            "",
            "This document provides a comprehensive reference for all configuration options",
            "in the Documentary Pipeline application.",
            "",
            "## Table of Contents",
            "",
        ]

        # Add TOC
        for section in sections:
            anchor = section.name.lower().replace(" ", "-").replace(".", "")
            lines.append(f"- [{section.name}](#{anchor})")
        lines.append("")

        # Add sections
        for section in sections:
            anchor = section.name.lower().replace(" ", "-").replace(".", "")
            lines.extend([
                f"## {section.name}",
                "",
                section.description,
                "",
            ])

            if section.prefix:
                lines.append(f"**Environment Prefix:** `{section.prefix}`")
                lines.append("")

            # Add table
            lines.extend([
                "| Variable | Type | Default | Description |",
                "|----------|------|---------|-------------|",
            ])

            for field in section.fields:
                default_str = str(field.default) if field.default is not None else "-"
                if len(default_str) > 50:
                    default_str = default_str[:47] + "..."
                default_str = default_str.replace("|", "\\|")

                desc = field.description.replace("\n", " ").replace("|", "\\|")
                if field.validation_rules:
                    desc += f" (Rules: {', '.join(field.validation_rules)})"

                lines.append(
                    f"| `{field.env_var}` | {field.type_str} | {default_str} | {desc} |"
                )

            lines.append("")

        return "\n".join(lines)

    def generate_json_schema(self) -> dict[str, Any]:
        """Generate JSON schema for the configuration."""
        return self._settings_class.model_json_schema()

    def generate_env_example(self, environment: str = "development") -> str:
        """Generate an example .env file."""
        sections = self.generate_documentation()

        lines = [
            f"# Environment Configuration: {environment}",
            "#",
            f"# This is an example configuration file for the {environment} environment.",
            "# Copy this file to .env and fill in your values.",
            "",
        ]

        for section in sections:
            lines.extend([
                f"# {'=' * 60}",
                f"# {section.name}",
                f"# {'=' * 60}",
                "",
            ])

            for field in section.fields:
                # Add description as comment
                if field.description:
                    for desc_line in field.description.split("\n"):
                        lines.append(f"# {desc_line.strip()}")

                # Add example if available
                if field.example:
                    lines.append(f"# Example: {field.example}")

                # Add validation rules
                if field.validation_rules:
                    lines.append(f"# Rules: {', '.join(field.validation_rules)}")

                # Add the variable
                default = field.default
                if default is None:
                    default = ""
                elif isinstance(default, bool):
                    default = str(default).lower()
                elif isinstance(default, (list, dict)):
                    default = json.dumps(default)
                else:
                    default = str(default)

                lines.append(f"{field.env_var}={default}")
                lines.append("")

        return "\n".join(lines)

    def generate_feature_flags_doc(self) -> str:
        """Generate documentation for feature flags."""
        from .feature_flags import FeatureFlags

        lines = [
            "# Feature Flags",
            "",
            "This document describes all available feature flags in the application.",
            "",
            "## Available Feature Flags",
            "",
            "| Flag | Type | Default | Description |",
            "|------|------|---------|-------------|",
        ]

        flags = FeatureFlags.DEFAULT_FLAGS
        for name, config in flags.items():
            flag_type = config.get("flag_type", "boolean").value
            default = config.get("default_value", False)
            if isinstance(default, bool):
                default = str(default).lower()
            description = config.get("description", "").replace("\n", " ")
            lines.append(f"| `{name}` | {flag_type} | {default} | {description} |")

        lines.extend([
            "",
            "## Usage",
            "",
            "```python",
            "from config.feature_flags import get_feature_flags",
            "",
            "flags = get_feature_flags()",
            "",
            "# Check if a feature is enabled",
            "if flags.is_enabled('ENABLE_GPU_WORKERS'):",
            "    # Provision GPU workers",
            "    pass",
            "",
            "# Use decorator for conditional execution",
            "from config.feature_flags import feature_flag_required",
            "",
            "@feature_flag_required('EXPERIMENTAL_FEATURE')",
            "def experimental_function():",
            "    pass",
            "```",
            "",
        ])

        return "\n".join(lines)

    def save_documentation(self, output_dir: Path | str) -> dict[str, Path]:
        """Save all documentation files to a directory."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        saved_files = {}

        # Save Markdown reference
        md_path = output_path / "CONFIGURATION.md"
        md_path.write_text(self.generate_markdown())
        saved_files["markdown"] = md_path

        # Save JSON schema
        schema_path = output_path / "config-schema.json"
        schema_path.write_text(json.dumps(self.generate_json_schema(), indent=2))
        saved_files["schema"] = schema_path

        # Save environment examples
        for env in ["development", "staging", "production"]:
            env_path = output_path / f".env.{env}.example"
            env_path.write_text(self.generate_env_example(env))
            saved_files[f"env_{env}"] = env_path

        # Save feature flags documentation
        flags_path = output_path / "FEATURE_FLAGS.md"
        flags_path.write_text(self.generate_feature_flags_doc())
        saved_files["feature_flags"] = flags_path

        return saved_files


# =============================================================================
# Convenience Functions
# =============================================================================


def generate_all_documentation(
    settings_class: type[BaseModel],
    output_dir: Path | str = "docs/config",
) -> dict[str, Path]:
    """
    Generate all configuration documentation.

    Args:
        settings_class: The pydantic settings class to document
        output_dir: Directory to save documentation files

    Returns:
        Dictionary of documentation types to file paths
    """
    documenter = ConfigurationDocumenter(settings_class)
    return documenter.save_documentation(output_dir)


def print_configuration_help(settings_class: type[BaseModel]) -> None:
    """Print configuration help to stdout."""
    documenter = ConfigurationDocumenter(settings_class)
    print(documenter.generate_markdown())


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "ConfigFieldDoc",
    "ConfigSectionDoc",
    "ConfigurationDocumenter",
    "generate_all_documentation",
    "print_configuration_help",
]
