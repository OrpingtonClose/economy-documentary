"""
Configuration Management for Documentary Pipeline.

This package provides comprehensive configuration management with:
- Type-safe settings using pydantic-settings
- Environment-specific configurations
- Feature flags for gradual rollouts
- Secrets rotation support
- Configuration documentation generation
- Validation at startup

## Quick Start

```python
from config import get_settings, get_feature_flags

# Get application settings
settings = get_settings()

# Access configuration values
print(settings.adk_model)
print(settings.paths.data_dir)

# Check feature flags
flags = get_feature_flags()
if flags.is_enabled("ENABLE_GPU_WORKERS"):
    provision_gpu_workers()
```

## Environment-Specific Configuration

Create environment-specific `.env` files:
- `.env.development` - Development settings
- `.env.staging` - Staging settings
- `.env.production` - Production settings

Load specific environment:
```python
from config import get_settings_for_environment, Environment

settings = get_settings_for_environment(Environment.PRODUCTION)
```

## Feature Flags

Feature flags support boolean, percentage-based, time-based, and user-segment modes:

```python
from config.feature_flags import get_feature_flags, FeatureFlagType

flags = get_feature_flags()

# Boolean flag
if flags.is_enabled("ENABLE_NEW_FEATURE"):
    use_new_feature()

# Percentage-based rollout (10% of users)
if flags.is_enabled("EXPERIMENTAL_FEATURE", user_id="user123"):
    show_experimental_ui()
```

## Secrets Rotation

For production, use the secrets rotation manager:

```python
from config.secrets import (
    SecretsRotationManager,
    InMemorySecretManager,
    RotationStrategy,
)
from pydantic import SecretStr

# Initialize manager
manager = SecretsRotationManager()

# Register a secret
secret = manager.register_secret(
    name="api_key",
    initial_value=SecretStr("secret-value"),
    rotation_interval=86400,  # Rotate daily
)

# Rotate when needed
await manager.rotate_secret(
    "api_key",
    SecretStr("new-secret-value"),
    strategy=RotationStrategy.GRACEFUL,
)
```
"""

from __future__ import annotations

# Import main settings classes
from .settings import (
    # Enums
    Environment,
    LogLevel,
    # Settings classes
    DocumentarySettings,
    PathSettings,
    LLMProviderSettings,
    SearchProviderSettings,
    DataAPISettings,
    InfrastructureSettings,
    StorageSettings,
    ProxySettings,
    ObservabilitySettings,
    ConcurrencySettings,
    PluginSettings,
    VeniceSettings,
    # Functions
    get_settings,
    reload_settings,
    get_settings_for_environment,
    _read_key,  # Legacy compatibility
)

# Import feature flags
from .feature_flags import (
    FeatureFlagType,
    FeatureFlagScope,
    FeatureFlagConfig,
    FeatureFlagChangeEvent,
    FeatureFlags,
    get_feature_flags,
    reset_feature_flags,
    feature_flag_required,
    feature_flag_branch,
)

# Import secrets management
from .secrets import (
    SecretStatus,
    RotationStrategy,
    SecretVersion,
    SecretManager,
    InMemorySecretManager,
    RotatableSecret,
    SecretsRotationManager,
    SecretsAwareSettings,
    AWSSecretsManager,
    HashiCorpVaultManager,
)

# Import documentation generator
from .documentation import (
    ConfigFieldDoc,
    ConfigSectionDoc,
    ConfigurationDocumenter,
    generate_all_documentation,
    print_configuration_help,
)

# Import validators (if any custom validators are defined)
# from .validators import ...

__version__ = "0.1.0"

__all__ = [
    # Version
    "__version__",
    # Settings
    "DocumentarySettings",
    "Environment",
    "LogLevel",
    "PathSettings",
    "LLMProviderSettings",
    "SearchProviderSettings",
    "DataAPISettings",
    "InfrastructureSettings",
    "StorageSettings",
    "ProxySettings",
    "ObservabilitySettings",
    "ConcurrencySettings",
    "PluginSettings",
    "VeniceSettings",
    # Settings functions
    "get_settings",
    "reload_settings",
    "get_settings_for_environment",
    "_read_key",
    # Feature flags
    "FeatureFlagType",
    "FeatureFlagScope",
    "FeatureFlagConfig",
    "FeatureFlagChangeEvent",
    "FeatureFlags",
    "get_feature_flags",
    "reset_feature_flags",
    "feature_flag_required",
    "feature_flag_branch",
    # Secrets
    "SecretStatus",
    "RotationStrategy",
    "SecretVersion",
    "SecretManager",
    "InMemorySecretManager",
    "RotatableSecret",
    "SecretsRotationManager",
    "SecretsAwareSettings",
    "AWSSecretsManager",
    "HashiCorpVaultManager",
    # Documentation
    "ConfigFieldDoc",
    "ConfigSectionDoc",
    "ConfigurationDocumenter",
    "generate_all_documentation",
    "print_configuration_help",
]


def validate_configuration() -> list[str]:
    """
    Validate the current configuration and return any warnings.

    This function performs comprehensive validation of the configuration
    and returns a list of warning messages. It does not raise exceptions
    for non-critical issues.

    Returns:
        List of warning messages (empty if no warnings)
    """
    warnings = []
    settings = get_settings()

    # Check for required API keys in production
    if settings.environment == Environment.PRODUCTION:
        has_llm_key = any(
            [
                settings.llm_providers.google_api_key,
                settings.llm_providers.openai_api_key,
                settings.llm_providers.gemini_api_key,
            ]
        )
        if not has_llm_key:
            warnings.append(
                "PRODUCTION: No LLM API key configured. "
                "Set GOOGLE_API_KEY, OPENAI_API_KEY, or GEMINI_API_KEY."
            )

    # Check for GPU configuration
    if settings.infrastructure.vast_api_key is None:
        warnings.append(
            "VAST_API_KEY not set. GPU worker provisioning will be disabled."
        )

    # Check for storage configuration
    if settings.storage.key_id is None or settings.storage.application_key is None:
        warnings.append(
            "B2 storage not fully configured. Model caching will use local storage."
        )

    # Check for observability
    if settings.observability.agentops_api_key is None:
        warnings.append(
            "AGENTOPS_API_KEY not set. Agent monitoring will be disabled."
        )

    # Check context limits
    if settings.concurrency.hard_context_limit <= settings.concurrency.max_context_tokens:
        warnings.append(
            "HARD_CONTEXT_LIMIT should be greater than MAX_CONTEXT_TOKENS"
        )

    return warnings


def print_configuration_status() -> None:
    """Print a summary of the current configuration status."""
    settings = get_settings()

    print("=" * 60)
    print("Configuration Status")
    print("=" * 60)
    print(f"Environment: {settings.environment.value}")
    print(f"Application: {settings.app_name} v{settings.app_version}")
    print(f"Debug Mode: {'Enabled' if settings.debug else 'Disabled'}")
    print(f"Log Level: {settings.log_level.value}")
    print()

    print("Model Configuration:")
    print(f"  Primary Model: {settings.adk_model}")
    print(f"  Synthesis Model: {settings.adk_synthesis_model}")
    print(f"  Thinker Model: {settings.adk_thinker_model}")
    print(f"  Vision Model: {settings.adk_vision_model}")
    print()

    print("Service Status:")
    services = [
        ("Gemini", settings.is_configured("gemini")),
        ("OpenAI", settings.is_configured("openai")),
        ("Vast.ai", settings.is_configured("vastai")),
        ("Backblaze B2", settings.is_configured("b2")),
        ("Phoenix Tracing", settings.is_configured("phoenix")),
        ("AgentOps", settings.is_configured("agentops")),
    ]
    for name, configured in services:
        status = "✓ Configured" if configured else "✗ Not Configured"
        print(f"  {name}: {status}")
    print()

    warnings = validate_configuration()
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"  ⚠ {warning}")
    else:
        print("No configuration warnings.")

    print("=" * 60)


# Run validation on import in production
if get_settings().environment == Environment.PRODUCTION:
    warnings = validate_configuration()
    if warnings:
        import logging

        logger = logging.getLogger(__name__)
        for warning in warnings:
            logger.warning("Configuration warning: %s", warning)
