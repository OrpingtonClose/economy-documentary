"""
Feature Flags System for Documentary Pipeline.

This module provides a comprehensive feature flag system that supports:
- Environment-based feature toggles
- Runtime feature flag changes
- A/B testing support
- Gradual rollout (percentage-based)
- Feature flag dependencies
- Audit logging of flag changes
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from functools import wraps
from typing import Any, Callable, TypeVar

from pydantic import BaseModel, Field, field_validator

logger = logging.getLogger(__name__)

T = TypeVar("T")


class FeatureFlagType(str, Enum):
    """Types of feature flags."""

    BOOLEAN = "boolean"  # Simple on/off
    PERCENTAGE = "percentage"  # Gradual rollout (0-100%)
    USER_SEGMENT = "user_segment"  # Based on user attributes
    TIME_BASED = "time_based"  # Enabled during specific time windows
    DEPENDENCY = "dependency"  # Depends on other flags


class FeatureFlagScope(str, Enum):
    """Scope of feature flag application."""

    GLOBAL = "global"  # Applies to all users
    USER = "user"  # Per-user flag
    SESSION = "session"  # Per-session flag
    REQUEST = "request"  # Per-request flag


@dataclass
class FeatureFlagChangeEvent:
    """Event recorded when a feature flag is changed."""

    flag_name: str
    old_value: Any
    new_value: Any
    changed_by: str
    timestamp: float = field(default_factory=time.time)
    reason: str = ""


class FeatureFlagConfig(BaseModel):
    """Configuration for a single feature flag."""

    name: str = Field(description="Unique flag identifier")
    flag_type: FeatureFlagType = Field(default=FeatureFlagType.BOOLEAN)
    scope: FeatureFlagScope = Field(default=FeatureFlagScope.GLOBAL)
    description: str = Field(default="", description="Human-readable description")
    default_value: Any = Field(default=False)
    current_value: Any = Field(default=False)
    enabled_environments: list[str] = Field(default_factory=list)
    disabled_environments: list[str] = Field(default_factory=list)
    percentage: int = Field(default=100, ge=0, le=100)
    user_segments: list[str] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list)
    time_window: dict[str, str] | None = Field(default=None)
    created_at: float = Field(default_factory=time.time)
    updated_at: float = Field(default_factory=time.time)
    changed_by: str = Field(default="system")
    audit_log: list[FeatureFlagChangeEvent] = Field(default_factory=list)

    @field_validator("percentage")
    @classmethod
    def validate_percentage(cls, v: int) -> int:
        """Ensure percentage is between 0 and 100."""
        if not 0 <= v <= 100:
            raise ValueError("Percentage must be between 0 and 100")
        return v

    def is_enabled(
        self,
        environment: str = "development",
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> bool:
        """
        Check if the feature flag is enabled for the given context.

        Args:
            environment: Current deployment environment
            user_id: Optional user identifier for user-scoped flags
            session_id: Optional session identifier for session-scoped flags

        Returns:
            True if the feature is enabled, False otherwise
        """
        # Check environment restrictions
        if self.disabled_environments and environment in self.disabled_environments:
            return False
        if self.enabled_environments and environment not in self.enabled_environments:
            return False

        # Check dependencies
        if self.dependencies:
            # Dependencies must be checked externally
            pass

        # Handle different flag types
        if self.flag_type == FeatureFlagType.BOOLEAN:
            return bool(self.current_value)

        elif self.flag_type == FeatureFlagType.PERCENTAGE:
            return self._check_percentage(user_id, session_id)

        elif self.flag_type == FeatureFlagType.TIME_BASED:
            return self._check_time_window()

        elif self.flag_type == FeatureFlagType.USER_SEGMENT:
            return self._check_user_segment(user_id)

        return bool(self.current_value)

    def _check_percentage(
        self, user_id: str | None = None, session_id: str | None = None
    ) -> bool:
        """Check if user/session falls within the enabled percentage."""
        if self.percentage >= 100:
            return True
        if self.percentage <= 0:
            return False

        # Use user_id or session_id for consistent hashing
        identifier = user_id or session_id or str(time.time())
        hash_value = int(hashlib.md5(identifier.encode()).hexdigest(), 16)
        user_percentage = hash_value % 100

        return user_percentage < self.percentage

    def _check_time_window(self) -> bool:
        """Check if current time falls within the enabled window."""
        if not self.time_window:
            return True

        now = time.time()
        start = self.time_window.get("start")
        end = self.time_window.get("end")

        if start:
            start_ts = time.mktime(time.strptime(start, "%Y-%m-%d %H:%M:%S"))
            if now < start_ts:
                return False

        if end:
            end_ts = time.mktime(time.strptime(end, "%Y-%m-%d %H:%M:%S"))
            if now > end_ts:
                return False

        return True

    def _check_user_segment(self, user_id: str | None) -> bool:
        """Check if user belongs to an enabled segment."""
        if not user_id or not self.user_segments:
            return False

        # Simple hash-based segment assignment
        hash_value = int(hashlib.md5(user_id.encode()).hexdigest(), 16)
        segment_index = hash_value % len(self.user_segments)
        return self.user_segments[segment_index] in self.user_segments

    def update_value(
        self, new_value: Any, changed_by: str = "system", reason: str = ""
    ) -> None:
        """Update the flag value and record in audit log."""
        old_value = self.current_value
        self.current_value = new_value
        self.updated_at = time.time()
        self.changed_by = changed_by

        event = FeatureFlagChangeEvent(
            flag_name=self.name,
            old_value=old_value,
            new_value=new_value,
            changed_by=changed_by,
            reason=reason,
        )
        self.audit_log.append(event)
        logger.info(
            "Feature flag '%s' changed from %s to %s by %s: %s",
            self.name,
            old_value,
            new_value,
            changed_by,
            reason,
        )


class FeatureFlags:
    """
    Central feature flag registry and manager.

    This class provides a singleton-like interface for managing
    feature flags across the application.
    """

    # Predefined feature flags for the documentary pipeline
    DEFAULT_FLAGS: dict[str, dict[str, Any]] = {
        # Pipeline Features
        "ENABLE_GPU_WORKERS": {
            "description": "Enable GPU worker provisioning via Vast.ai",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_TTS_GENERATION": {
            "description": "Enable text-to-speech generation",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_VIDEO_GENERATION": {
            "description": "Enable LTX video generation",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_ENRICHMENT": {
            "description": "Enable data enrichment pipeline",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_VISUAL_QA": {
            "description": "Enable visual quality assurance",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },

        # LLM Features
        "USE_NATIVE_GEMINI": {
            "description": "Use native Gemini SDK instead of LiteLLM",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_MULTI_MODEL_SYNTHESIS": {
            "description": "Use different models for synthesis vs thinking",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_CITATION_TRACKING": {
            "description": "Enable source citation tracking in responses",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },

        # Observability Features
        "ENABLE_PHOENIX_TRACING": {
            "description": "Enable Phoenix OpenTelemetry tracing",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_AGENTOPS_MONITORING": {
            "description": "Enable AgentOps agent monitoring",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_DETAILED_SPANS": {
            "description": "Capture detailed message content in spans",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },

        # Dashboard Features
        "ENABLE_REALTIME_DASHBOARD": {
            "description": "Enable real-time pipeline dashboard",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_PIPELINE_REPLAY": {
            "description": "Enable pipeline run replay functionality",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },

        # Storage Features
        "ENABLE_B2_CACHING": {
            "description": "Enable Backblaze B2 model caching",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_ARTIFACT_PERSISTENCE": {
            "description": "Enable artifact persistence to B2",
            "default_value": False,
            "flag_type": FeatureFlagType.BOOLEAN,
        },

        # Experimental Features (gradual rollout)
        "EXPERIMENTAL_SCENE_SPLITTING": {
            "description": "Experimental AI scene splitting algorithm",
            "default_value": False,
            "flag_type": FeatureFlagType.PERCENTAGE,
            "percentage": 10,
        },
        "EXPERIMENTAL_VOICE_CLONING": {
            "description": "Experimental voice cloning for narration",
            "default_value": False,
            "flag_type": FeatureFlagType.PERCENTAGE,
            "percentage": 5,
        },

        # Safety Features
        "ENABLE_CONTENT_MODERATION": {
            "description": "Enable content moderation for generated scenes",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
        "ENABLE_CLAIM_VERIFICATION": {
            "description": "Enable automatic claim fact-checking",
            "default_value": True,
            "flag_type": FeatureFlagType.BOOLEAN,
        },
    }

    def __init__(self) -> None:
        """Initialize the feature flags registry."""
        self._flags: dict[str, FeatureFlagConfig] = {}
        self._environment: str = "development"
        self._load_default_flags()

    def _load_default_flags(self) -> None:
        """Load the default feature flag definitions."""
        for name, config in self.DEFAULT_FLAGS.items():
            self._flags[name] = FeatureFlagConfig(name=name, **config)

    def initialize_from_settings(self, settings: Any) -> None:
        """Initialize flags from application settings."""
        # Update flags based on settings
        if hasattr(settings, "observability"):
            obs = settings.observability
            self.set_flag(
                "ENABLE_PHOENIX_TRACING",
                obs.phoenix_enabled,
                changed_by="settings_loader",
            )
            self.set_flag(
                "ENABLE_AGENTOPS_MONITORING",
                obs.agentops_api_key is not None,
                changed_by="settings_loader",
            )
            self.set_flag(
                "ENABLE_DETAILED_SPANS",
                obs.adk_capture_message_content_in_spans,
                changed_by="settings_loader",
            )

        if hasattr(settings, "infrastructure"):
            infra = settings.infrastructure
            self.set_flag(
                "ENABLE_GPU_WORKERS",
                infra.vast_api_key is not None,
                changed_by="settings_loader",
            )

        if hasattr(settings, "storage"):
            storage = settings.storage
            has_b2 = storage.key_id is not None and storage.application_key is not None
            self.set_flag(
                "ENABLE_B2_CACHING", has_b2, changed_by="settings_loader"
            )

    def set_environment(self, environment: str) -> None:
        """Set the current environment for flag evaluation."""
        self._environment = environment
        logger.debug("Feature flags environment set to: %s", environment)

    def is_enabled(
        self,
        flag_name: str,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> bool:
        """
        Check if a feature flag is enabled.

        Args:
            flag_name: Name of the feature flag
            user_id: Optional user identifier
            session_id: Optional session identifier

        Returns:
            True if the feature is enabled
        """
        flag = self._flags.get(flag_name)
        if not flag:
            logger.warning("Unknown feature flag: %s", flag_name)
            return False

        return flag.is_enabled(self._environment, user_id, session_id)

    def get_flag(self, flag_name: str) -> FeatureFlagConfig | None:
        """Get the configuration for a feature flag."""
        return self._flags.get(flag_name)

    def set_flag(
        self, flag_name: str, value: Any, changed_by: str = "system", reason: str = ""
    ) -> None:
        """Set the value of a feature flag."""
        if flag_name not in self._flags:
            logger.warning("Creating new feature flag: %s", flag_name)
            self._flags[flag_name] = FeatureFlagConfig(name=flag_name)

        self._flags[flag_name].update_value(value, changed_by, reason)

    def register_flag(self, config: FeatureFlagConfig) -> None:
        """Register a new feature flag."""
        self._flags[config.name] = config
        logger.info("Registered feature flag: %s", config.name)

    def get_all_flags(self) -> dict[str, FeatureFlagConfig]:
        """Get all registered feature flags."""
        return self._flags.copy()

    def get_enabled_flags(
        self, user_id: str | None = None, session_id: str | None = None
    ) -> list[str]:
        """Get list of currently enabled flag names."""
        return [
            name
            for name, flag in self._flags.items()
            if flag.is_enabled(self._environment, user_id, session_id)
        ]

    def export_config(self) -> dict[str, Any]:
        """Export all flag configurations as a dictionary."""
        return {
            name: {
                "name": flag.name,
                "flag_type": flag.flag_type.value,
                "scope": flag.scope.value,
                "description": flag.description,
                "default_value": flag.default_value,
                "current_value": flag.current_value,
                "enabled_environments": flag.enabled_environments,
                "percentage": flag.percentage,
                "updated_at": flag.updated_at,
            }
            for name, flag in self._flags.items()
        }

    def import_config(self, config: dict[str, Any], changed_by: str = "import") -> None:
        """Import flag configurations from a dictionary."""
        for name, flag_config in config.items():
            if name in self._flags:
                flag = self._flags[name]
                if "current_value" in flag_config:
                    flag.update_value(
                        flag_config["current_value"],
                        changed_by,
                        reason="configuration_import",
                    )
                if "percentage" in flag_config:
                    flag.percentage = flag_config["percentage"]
                if "enabled_environments" in flag_config:
                    flag.enabled_environments = flag_config["enabled_environments"]

    def to_json(self) -> str:
        """Export flags to JSON string."""
        return json.dumps(self.export_config(), indent=2, default=str)

    def get_audit_log(self, flag_name: str | None = None) -> list[FeatureFlagChangeEvent]:
        """Get audit log for a specific flag or all flags."""
        if flag_name:
            flag = self._flags.get(flag_name)
            return flag.audit_log if flag else []

        all_logs = []
        for flag in self._flags.values():
            all_logs.extend(flag.audit_log)
        return sorted(all_logs, key=lambda e: e.timestamp, reverse=True)


# =============================================================================
# Global Feature Flags Instance
# =============================================================================

# Singleton instance
_feature_flags: FeatureFlags | None = None


def get_feature_flags() -> FeatureFlags:
    """Get the global feature flags instance."""
    global _feature_flags
    if _feature_flags is None:
        _feature_flags = FeatureFlags()
    return _feature_flags


def reset_feature_flags() -> None:
    """Reset the global feature flags instance (for testing)."""
    global _feature_flags
    _feature_flags = None


# =============================================================================
# Decorators
# =============================================================================


def feature_flag_required(
    flag_name: str,
    fallback: Callable[..., T] | None = None,
) -> Callable:
    """
    Decorator to conditionally execute a function based on a feature flag.

    Args:
        flag_name: Name of the feature flag to check
        fallback: Optional fallback function to call if flag is disabled

    Example:
        @feature_flag_required("ENABLE_GPU_WORKERS")
        async def provision_gpu():
            # Only runs if ENABLE_GPU_WORKERS is enabled
            pass

        @feature_flag_required("EXPERIMENTAL_FEATURE", fallback=legacy_function)
        async def new_feature():
            # Falls back to legacy_function if flag is disabled
            pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            flags = get_feature_flags()
            if flags.is_enabled(flag_name):
                return func(*args, **kwargs)
            elif fallback:
                return fallback(*args, **kwargs)
            else:
                logger.debug(
                    "Function '%s' skipped: feature flag '%s' is disabled",
                    func.__name__,
                    flag_name,
                )
                return None

        return wrapper

    return decorator


def feature_flag_branch(
    flag_name: str,
    enabled_func: Callable[..., T],
    disabled_func: Callable[..., T],
) -> Callable[..., T]:
    """
    Decorator to branch between two functions based on a feature flag.

    Args:
        flag_name: Name of the feature flag to check
        enabled_func: Function to call when flag is enabled
        disabled_func: Function to call when flag is disabled

    Example:
        @feature_flag_branch(
            "USE_NATIVE_GEMINI",
            enabled_func=native_gemini_call,
            disabled_func=litellm_gemini_call,
        )
        async def call_gemini():
            pass  # Will call the appropriate function based on flag
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            flags = get_feature_flags()
            if flags.is_enabled(flag_name):
                return enabled_func(*args, **kwargs)
            else:
                return disabled_func(*args, **kwargs)

        return wrapper

    return decorator


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "FeatureFlagType",
    "FeatureFlagScope",
    "FeatureFlagConfig",
    "FeatureFlagChangeEvent",
    "FeatureFlags",
    "get_feature_flags",
    "reset_feature_flags",
    "feature_flag_required",
    "feature_flag_branch",
]
