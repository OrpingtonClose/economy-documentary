"""
Pydantic-Settings based configuration for the documentary pipeline.

This module provides type-safe, validated configuration with:
- Environment-specific settings (dev, staging, prod)
- Secrets rotation support
- Feature flags
- Comprehensive validation
"""

from __future__ import annotations

import json
import logging
import os
from enum import Enum
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal, Self

from pydantic import (
    DirectoryPath,
    Field,
    SecretStr,
    field_validator,
    model_validator,
)
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class Environment(str, Enum):
    """Deployment environment types."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    TEST = "test"


class LogLevel(str, Enum):
    """Logging level options."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


# =============================================================================
# Base Configuration Settings
# =============================================================================


class PathSettings(BaseSettings):
    """Path and directory configuration."""

    model_config = SettingsConfigDict(
        env_prefix="PATH_",
        case_sensitive=False,
        extra="ignore",
    )

    data_dir: DirectoryPath = Field(
        default=Path("/tmp/documentary-pipeline"),
        description="Base directory for all pipeline data",
    )
    timeline_dir: Path | None = Field(
        default=None,
        description="Directory for timeline outputs (defaults to DATA_DIR/timelines)",
    )
    tts_output_dir: Path | None = Field(
        default=None,
        description="Directory for TTS audio outputs (defaults to DATA_DIR/audio)",
    )
    video_output_dir: Path | None = Field(
        default=None,
        description="Directory for video outputs (defaults to DATA_DIR/video)",
    )
    findings_dir: Path | None = Field(
        default=None,
        description="Directory for findings storage (defaults to DATA_DIR/findings)",
    )
    dashboard_db_dir: Path | None = Field(
        default=None,
        description="Directory for dashboard database (defaults to DATA_DIR/dashboard)",
    )
    corpus_dir: Path | None = Field(
        default=None,
        description="Directory for corpus data (defaults to DATA_DIR/corpus)",
    )
    enrichment_dir: Path | None = Field(
        default=None,
        description="Directory for enrichment data (defaults to DATA_DIR/enrichment)",
    )

    @model_validator(mode="after")
    def set_derived_paths(self) -> Self:
        """Set derived paths based on data_dir if not explicitly provided."""
        data_dir = self.data_dir

        if self.timeline_dir is None:
            self.timeline_dir = data_dir / "timelines"
        if self.tts_output_dir is None:
            self.tts_output_dir = data_dir / "audio"
        if self.video_output_dir is None:
            self.video_output_dir = data_dir / "video"
        if self.findings_dir is None:
            self.findings_dir = data_dir / "findings"
        if self.dashboard_db_dir is None:
            self.dashboard_db_dir = data_dir / "dashboard"
        if self.corpus_dir is None:
            self.corpus_dir = data_dir / "corpus"
        if self.enrichment_dir is None:
            self.enrichment_dir = data_dir / "enrichment"

        return self


class LLMProviderSettings(BaseSettings):
    """LLM provider API keys and configuration."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    # Google Gemini
    google_api_key: SecretStr | None = Field(
        default=None,
        description="Google API key for Gemini access",
    )
    gemini_api_key: SecretStr | None = Field(
        default=None,
        description="Gemini-specific API key (fallback to GOOGLE_API_KEY)",
    )

    # OpenAI-compatible
    openai_api_key: SecretStr | None = Field(
        default=None,
        description="OpenAI API key",
    )
    openai_api_base: str | None = Field(
        default=None,
        description="OpenAI-compatible API base URL (for vLLM, LiteLLM, etc.)",
    )

    # Other providers
    deepseek_api: SecretStr | None = Field(
        default=None,
        description="DeepSeek API key",
    )
    perplexity_api_key: SecretStr | None = Field(
        default=None,
        description="Perplexity API key",
    )
    grok_api: SecretStr | None = Field(
        default=None,
        description="Grok/xAI API key",
    )
    openrouter_api: SecretStr | None = Field(
        default=None,
        description="OpenRouter API key",
    )
    groq_api: SecretStr | None = Field(
        default=None,
        description="Groq API key",
    )
    mistral_api_key: SecretStr | None = Field(
        default=None,
        description="Mistral API key",
    )
    anthropic_api: SecretStr | None = Field(
        default=None,
        description="Anthropic API key",
    )
    minmax_api: SecretStr | None = Field(
        default=None,
        description="MiniMax API key",
    )

    # Provider-specific base URLs
    synthesis_api_key: SecretStr | None = Field(
        default=None,
        description="API key for synthesis model (if different from main)",
    )
    synthesis_api_base: str | None = Field(
        default=None,
        description="Base URL for synthesis model",
    )
    thinker_api_key: SecretStr | None = Field(
        default=None,
        description="API key for thinker model (if different)",
    )
    thinker_api_base: str | None = Field(
        default=None,
        description="Base URL for thinker model",
    )
    vision_api_key: SecretStr | None = Field(
        default=None,
        description="API key for vision model (if different)",
    )
    vision_api_base: str | None = Field(
        default=None,
        description="Base URL for vision model",
    )

    @model_validator(mode="after")
    def check_at_least_one_provider(self) -> Self:
        """Ensure at least one LLM provider is configured."""
        providers = [
            self.google_api_key,
            self.gemini_api_key,
            self.openai_api_key,
            self.deepseek_api,
            self.perplexity_api_key,
            self.grok_api,
            self.openrouter_api,
            self.groq_api,
            self.mistral_api_key,
            self.anthropic_api,
            self.minmax_api,
        ]
        if not any(p is not None and p.get_secret_value() for p in providers):
            logger.warning(
                "No LLM provider API keys configured. "
                "Set at least one of: GOOGLE_API_KEY, OPENAI_API_KEY, etc."
            )
        return self


class SearchProviderSettings(BaseSettings):
    """Search provider API keys."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    exa_api_key: SecretStr | None = Field(
        default=None,
        description="Exa search API key",
    )
    tavily_api_key: SecretStr | None = Field(
        default=None,
        description="Tavily search API key",
    )
    brave_search_api_key: SecretStr | None = Field(
        default=None,
        description="Brave Search API key",
    )
    google_search_api: SecretStr | None = Field(
        default=None,
        description="Google Custom Search API key",
    )
    google_search_engine_id: str | None = Field(
        default=None,
        description="Google Custom Search Engine ID",
    )


class DataAPISettings(BaseSettings):
    """Data provider API keys."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    fred_api_key: SecretStr | None = Field(
        default=None,
        description="FRED (Federal Reserve Economic Data) API key",
    )
    wolfram_alpha_api: SecretStr | None = Field(
        default=None,
        description="Wolfram Alpha API key",
    )
    jina_api_key: SecretStr | None = Field(
        default=None,
        description="Jina AI API key (for web scraping)",
    )


class InfrastructureSettings(BaseSettings):
    """Infrastructure and GPU configuration."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    vast_api_key: SecretStr | None = Field(
        default=None,
        description="Vast.ai API key for GPU provisioning",
    )
    gpu_worker_url: str | None = Field(
        default=None,
        description="URL of GPU worker (e.g., http://host:8880)",
    )
    tts_worker_url: str | None = Field(
        default=None,
        description="URL of TTS worker",
    )
    video_worker_urls: list[str] = Field(
        default_factory=list,
        description="List of video worker URLs (comma-separated in env)",
    )

    @field_validator("video_worker_urls", mode="before")
    @classmethod
    def parse_video_worker_urls(cls, v: Any) -> list[str]:
        """Parse comma-separated worker URLs."""
        if isinstance(v, str):
            return [url.strip() for url in v.split(",") if url.strip()]
        return v if v else []


class StorageSettings(BaseSettings):
    """Cloud storage configuration (Backblaze B2)."""

    model_config = SettingsConfigDict(
        env_prefix="B2_",
        case_sensitive=False,
        extra="ignore",
    )

    key_id: SecretStr | None = Field(
        default=None,
        description="Backblaze B2 key ID",
    )
    application_key: SecretStr | None = Field(
        default=None,
        description="Backblaze B2 application key",
    )
    models_bucket: str = Field(
        default="ltx2-models-orpington",
        description="B2 bucket for model caching",
    )
    artifacts_bucket: str = Field(
        default="economy-vid-assets",
        description="B2 bucket for artifact storage",
    )


class ProxySettings(BaseSettings):
    """Proxy service configuration."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    brightdata_key: SecretStr | None = Field(
        default=None,
        description="Brightdata proxy API key",
    )
    brightdata_customer_id: str = Field(
        default="hl_dc044bf4",
        description="Brightdata customer ID",
    )
    brightdata_zone: str = Field(
        default="mcp_unlocker",
        description="Brightdata proxy zone",
    )
    oxylabs_username: SecretStr | None = Field(
        default=None,
        description="Oxylabs proxy username",
    )
    oxylabs_password: SecretStr | None = Field(
        default=None,
        description="Oxylabs proxy password",
    )


class ObservabilitySettings(BaseSettings):
    """Observability and monitoring configuration."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    agentops_api_key: SecretStr | None = Field(
        default=None,
        description="AgentOps API key for agent monitoring",
    )
    phoenix_enabled: bool = Field(
        default=False,
        description="Enable Phoenix tracing",
    )
    phoenix_collector_endpoint: str | None = Field(
        default=None,
        description="Phoenix collector endpoint URL",
    )
    adk_debug: bool = Field(
        default=False,
        description="Enable ADK debug logging",
    )
    adk_capture_message_content_in_spans: bool = Field(
        default=False,
        description="Capture message content in OpenTelemetry spans",
    )


class ConcurrencySettings(BaseSettings):
    """Concurrency and rate limiting configuration."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    max_concurrent_llm: int = Field(
        default=4,
        ge=1,
        le=100,
        description="Maximum concurrent LLM requests",
    )
    max_context_tokens: int = Field(
        default=120_000,
        ge=1000,
        le=2_000_000,
        description="Maximum context tokens for LLM requests",
    )
    hard_context_limit: int = Field(
        default=180_000,
        ge=1000,
        le=2_000_000,
        description="Hard limit for context tokens (emergency cutoff)",
    )
    tool_result_max_chars: int = Field(
        default=30_000,
        ge=1000,
        le=1_000_000,
        description="Maximum characters in tool results",
    )
    gpu_concurrency: int = Field(
        default=2,
        ge=1,
        le=50,
        description="Maximum concurrent GPU operations",
    )
    tts_concurrency: int = Field(
        default=3,
        ge=1,
        le=50,
        description="Maximum concurrent TTS operations",
    )
    vastai_concurrency: int = Field(
        default=2,
        ge=1,
        le=20,
        description="Maximum concurrent Vast.ai operations",
    )
    tree_max_concurrent: int = Field(
        default=4,
        ge=1,
        le=50,
        description="Maximum concurrent tree operations",
    )
    max_subagent_turns: int = Field(
        default=12,
        ge=1,
        le=100,
        description="Maximum turns for subagent conversations",
    )
    litellm_request_timeout: int = Field(
        default=600,
        ge=10,
        le=3600,
        description="LiteLLM request timeout in seconds",
    )

    @model_validator(mode="after")
    def validate_context_limits(self) -> Self:
        """Ensure hard limit is greater than max context."""
        if self.hard_context_limit <= self.max_context_tokens:
            raise ValueError(
                f"HARD_CONTEXT_LIMIT ({self.hard_context_limit}) must be greater than "
                f"MAX_CONTEXT_TOKENS ({self.max_context_tokens})"
            )
        return self


class PluginSettings(BaseSettings):
    """Plugin configuration."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    context_invocations_to_keep: int = Field(
        default=10,
        ge=0,
        le=100,
        description="Number of context invocations to retain",
    )
    tool_max_retries: int = Field(
        default=2,
        ge=0,
        le=10,
        description="Maximum retries for tool calls",
    )


class VeniceSettings(BaseSettings):
    """Venice.ai-specific configuration."""

    model_config = SettingsConfigDict(
        env_prefix="VENICE_",
        case_sensitive=False,
        extra="ignore",
    )

    params: dict[str, Any] = Field(
        default_factory=lambda: {"include_venice_system_prompt": False},
        description="Venice-specific parameters as JSON dict",
    )

    @field_validator("params", mode="before")
    @classmethod
    def parse_params(cls, v: Any) -> dict[str, Any]:
        """Parse JSON string to dict."""
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON for VENICE_PARAMS: {e}")
        return v if v else {}


# =============================================================================
# Main Application Settings
# =============================================================================


class DocumentarySettings(BaseSettings):
    """
    Main application settings for the documentary pipeline.

    This class combines all configuration sections and provides:
    - Type-safe configuration with pydantic validation
    - Environment-specific settings loading
    - Secrets management with SecretStr
    - Comprehensive validation at startup
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        validate_default=True,
    )

    # ── Core Application ─────────────────────────────────────────
    environment: Environment = Field(
        default=Environment.DEVELOPMENT,
        description="Deployment environment",
    )
    app_name: str = Field(
        default="documentary-pipeline",
        description="Application name",
    )
    app_version: str = Field(
        default="0.1.0",
        description="Application version",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug mode",
    )
    log_level: LogLevel = Field(
        default=LogLevel.INFO,
        description="Logging level",
    )

    # ── Documentary Topic ────────────────────────────────────────
    documentary_topic: str = Field(
        default="",
        description="The documentary topic (set dynamically per run)",
    )

    # ── Model Configuration ──────────────────────────────────────
    adk_model: str = Field(
        default="gemini-2.5-flash",
        description="Primary ADK model (used by tool-capable agents)",
    )
    adk_synthesis_model: str | None = Field(
        default=None,
        description="Synthesis model (defaults to ADK_MODEL)",
    )
    adk_thinker_model: str | None = Field(
        default=None,
        description="Thinker model (defaults to ADK_SYNTHESIS_MODEL)",
    )
    adk_vision_model: str | None = Field(
        default=None,
        description="Vision model (defaults to ADK_MODEL, needs vision capability)",
    )

    # ── Sub-configurations ───────────────────────────────────────
    paths: PathSettings = Field(default_factory=PathSettings)
    llm_providers: LLMProviderSettings = Field(default_factory=LLMProviderSettings)
    search: SearchProviderSettings = Field(default_factory=SearchProviderSettings)
    data_apis: DataAPISettings = Field(default_factory=DataAPISettings)
    infrastructure: InfrastructureSettings = Field(default_factory=InfrastructureSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    proxy: ProxySettings = Field(default_factory=ProxySettings)
    observability: ObservabilitySettings = Field(default_factory=ObservabilitySettings)
    concurrency: ConcurrencySettings = Field(default_factory=ConcurrencySettings)
    plugins: PluginSettings = Field(default_factory=PluginSettings)
    venice: VeniceSettings = Field(default_factory=VeniceSettings)

    # ── Legacy Feature Flags ─────────────────────────────────────
    documentary_test_mode: bool = Field(
        default=False,
        description="Test mode (no GPU needed)",
    )
    documentary_quick_test: bool = Field(
        default=False,
        description="Quick test mode (1-min test movie, 2 scenes)",
    )

    @field_validator("environment", mode="before")
    @classmethod
    def parse_environment(cls, v: Any) -> Environment:
        """Parse environment from string."""
        if isinstance(v, str):
            v = v.lower()
            mapping = {
                "dev": Environment.DEVELOPMENT,
                "development": Environment.DEVELOPMENT,
                "stag": Environment.STAGING,
                "staging": Environment.STAGING,
                "prod": Environment.PRODUCTION,
                "production": Environment.PRODUCTION,
                "test": Environment.TEST,
            }
            return mapping.get(v, Environment.DEVELOPMENT)
        return v

    @field_validator("log_level", mode="before")
    @classmethod
    def parse_log_level(cls, v: Any) -> LogLevel:
        """Parse log level from string."""
        if isinstance(v, str):
            try:
                return LogLevel(v.upper())
            except ValueError:
                return LogLevel.INFO
        return v

    @model_validator(mode="after")
    def set_derived_models(self) -> Self:
        """Set derived model defaults."""
        if self.adk_synthesis_model is None:
            self.adk_synthesis_model = self.adk_model
        if self.adk_thinker_model is None:
            self.adk_thinker_model = self.adk_synthesis_model
        if self.adk_vision_model is None:
            self.adk_vision_model = self.adk_model
        return self

    @model_validator(mode="after")
    def validate_production_settings(self) -> Self:
        """Validate production-specific requirements."""
        if self.environment == Environment.PRODUCTION:
            # In production, require at least one API key
            has_api_key = any(
                [
                    self.llm_providers.google_api_key,
                    self.llm_providers.openai_api_key,
                    self.llm_providers.deepseek_api,
                    self.llm_providers.gemini_api_key,
                ]
            )
            if not has_api_key:
                raise ValueError(
                    "Production environment requires at least one LLM API key"
                )
        return self

    def get_effective_gemini_key(self) -> SecretStr | None:
        """Get the effective Gemini API key (with fallback)."""
        return self.llm_providers.gemini_api_key or self.llm_providers.google_api_key

    def get_model_config(self, model_type: Literal["primary", "synthesis", "thinker", "vision"]) -> dict[str, Any]:
        """Get configuration for a specific model type."""
        configs = {
            "primary": {
                "model": self.adk_model,
                "api_key": self.llm_providers.openai_api_key,
                "api_base": self.llm_providers.openai_api_base,
            },
            "synthesis": {
                "model": self.adk_synthesis_model,
                "api_key": self.llm_providers.synthesis_api_key or self.llm_providers.openai_api_key,
                "api_base": self.llm_providers.synthesis_api_base or self.llm_providers.openai_api_base,
            },
            "thinker": {
                "model": self.adk_thinker_model,
                "api_key": self.llm_providers.thinker_api_key or self.llm_providers.openai_api_key,
                "api_base": self.llm_providers.thinker_api_base or self.llm_providers.openai_api_base,
            },
            "vision": {
                "model": self.adk_vision_model,
                "api_key": self.llm_providers.vision_api_key or self.llm_providers.openai_api_key,
                "api_base": self.llm_providers.vision_api_base or self.llm_providers.openai_api_base,
            },
        }
        return configs.get(model_type, configs["primary"])

    def is_configured(self, service: str) -> bool:
        """Check if a service is properly configured."""
        checks = {
            "gemini": self.get_effective_gemini_key() is not None,
            "openai": self.llm_providers.openai_api_key is not None,
            "vastai": self.infrastructure.vast_api_key is not None,
            "b2": (
                self.storage.key_id is not None
                and self.storage.application_key is not None
            ),
            "phoenix": (
                self.observability.phoenix_enabled
                and self.observability.phoenix_collector_endpoint is not None
            ),
            "agentops": self.observability.agentops_api_key is not None,
        }
        return checks.get(service, False)


# =============================================================================
# Settings Factory with Caching
# =============================================================================


@lru_cache(maxsize=1)
def get_settings() -> DocumentarySettings:
    """
    Get cached settings instance.

    This function caches the settings to avoid re-reading environment
    variables on every call. Use this in application code.
    """
    return DocumentarySettings()


def reload_settings() -> DocumentarySettings:
    """
    Reload settings from environment.

    Call this function after changing environment variables to get
    fresh settings. Useful for testing and hot-reloading scenarios.
    """
    get_settings.cache_clear()
    return get_settings()


def get_settings_for_environment(env: Environment) -> DocumentarySettings:
    """
    Get settings for a specific environment.

    This loads environment-specific .env files:
    - .env.development
    - .env.staging
    - .env.production
    """
    env_file = f".env.{env.value}"
    if os.path.exists(env_file):
        return DocumentarySettings(_env_file=env_file)
    return DocumentarySettings(environment=env)


# =============================================================================
# Legacy Compatibility
# =============================================================================

def _read_key(filename: str) -> str:
    """
    Read an API key from environment variable (legacy compatibility).

    This is a compatibility shim for existing code that used file-based keys.
    The filename is converted to an env var name by stripping the extension
    and uppercasing:

        'minmax_api.txt' -> MINMAX_API
        'deepseek_api.txt' -> DEEPSEEK_API
        'exa_api_key.json' -> EXA_API_KEY

    Args:
        filename: Original key filename (e.g., 'deepseek_api.txt').

    Returns:
        The API key string, or empty string if not set.
    """
    settings = get_settings()

    # Strip any common extension, not just .txt
    base = filename.rsplit(".", 1)[0] if "." in filename else filename
    env_name = base.upper()

    # Map common filename patterns to settings
    mapping = {
        "MINMAX_API": settings.llm_providers.minmax_api,
        "DEEPSEEK_API": settings.llm_providers.deepseek_api,
        "PERPLEXITY_API_KEY": settings.llm_providers.perplexity_api_key,
        "GEMINI_API_KEY": settings.llm_providers.gemini_api_key,
        "GROK_API": settings.llm_providers.grok_api,
        "OPENROUTER_API": settings.llm_providers.openrouter_api,
        "GROQ_API": settings.llm_providers.groq_api,
        "MISTRAL_API_KEY": settings.llm_providers.mistral_api_key,
        "OPENAI_API_KEY": settings.llm_providers.openai_api_key,
        "ANTHROPIC_API": settings.llm_providers.anthropic_api,
        "EXA_API_KEY": settings.search.exa_api_key,
        "TAVILY_API_KEY": settings.search.tavily_api_key,
        "BRAVE_SEARCH_API_KEY": settings.search.brave_search_api_key,
        "GOOGLE_SEARCH_API": settings.search.google_search_api,
        "FRED_API_KEY": settings.data_apis.fred_api_key,
        "WOLFRAM_ALPHA_API": settings.data_apis.wolfram_alpha_api,
        "JINA_API_KEY": settings.data_apis.jina_api_key,
        "VAST_API_KEY": settings.infrastructure.vast_api_key,
        "BRIGHTDATA_KEY": settings.proxy.brightdata_key,
        "AGENTOPS_API_KEY": settings.observability.agentops_api_key,
    }

    secret = mapping.get(env_name)
    if secret:
        return secret.get_secret_value()
    return os.environ.get(env_name, "")


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "DocumentarySettings",
    "Environment",
    "LogLevel",
    "PathSettings",
    "LLMProviderSettings",
    "SearchProviderSettings",
    "DataAPISettings",
    "InfrastructureSettings",
    "StorageSettings",
    "ProxySettings",
    "ObservabilitySettings",
    "ConcurrencySettings",
    "PluginSettings",
    "VeniceSettings",
    "get_settings",
    "reload_settings",
    "get_settings_for_environment",
    "_read_key",
]
