"""
Secrets Management and Rotation Support.

This module provides patterns for:
- Secure secrets handling with rotation support
- Multiple secret versions (active, pending, previous)
- Automatic failover to backup secrets
- Secrets health checking
- Integration with external secret managers (AWS Secrets Manager, HashiCorp Vault)
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

from pydantic import BaseModel, Field, SecretStr

logger = logging.getLogger(__name__)


class SecretStatus(str, Enum):
    """Status of a secret version."""

    ACTIVE = "active"  # Currently in use
    PENDING = "pending"  # Will become active soon (rotation in progress)
    PREVIOUS = "previous"  # Previous version (for rollback)
    EXPIRED = "expired"  # No longer valid
    COMPROMISED = "compromised"  # Known to be compromised


class RotationStrategy(str, Enum):
    """Strategy for secret rotation."""

    IMMEDIATE = "immediate"  # Rotate immediately
    GRACEFUL = "graceful"  # Keep old secret valid during transition
    SCHEDULED = "scheduled"  # Rotate at scheduled time
    ON_DEMAND = "on_demand"  # Only rotate when manually triggered


@dataclass
class SecretVersion:
    """A version of a secret with metadata."""

    value: SecretStr
    version_id: str
    status: SecretStatus
    created_at: float = field(default_factory=time.time)
    expires_at: float | None = None
    last_used_at: float | None = None
    use_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def mark_used(self) -> None:
        """Mark this secret version as used."""
        self.last_used_at = time.time()
        self.use_count += 1

    def is_expired(self) -> bool:
        """Check if this secret version has expired."""
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at

    def get_masked_value(self) -> str:
        """Get a masked representation of the secret value."""
        secret = self.value.get_secret_value()
        if len(secret) <= 8:
            return "***"
        return f"{secret[:4]}...{secret[-4:]}"

    def get_fingerprint(self) -> str:
        """Get a hash fingerprint of the secret (for comparison without revealing value)."""
        return hashlib.sha256(
            self.value.get_secret_value().encode()
        ).hexdigest()[:16]


class SecretManager(ABC):
    """Abstract base class for secret managers."""

    @abstractmethod
    async def get_secret(self, secret_name: str) -> SecretVersion | None:
        """Get the active version of a secret."""
        pass

    @abstractmethod
    async def get_secret_versions(
        self, secret_name: str
    ) -> list[SecretVersion]:
        """Get all versions of a secret."""
        pass

    @abstractmethod
    async def rotate_secret(
        self,
        secret_name: str,
        new_value: SecretStr,
        strategy: RotationStrategy = RotationStrategy.GRACEFUL,
    ) -> SecretVersion:
        """Rotate a secret to a new value."""
        pass

    @abstractmethod
    async def revoke_secret(
        self, secret_name: str, version_id: str | None = None
    ) -> None:
        """Revoke a secret or a specific version."""
        pass

    @abstractmethod
    async def health_check(self, secret_name: str) -> bool:
        """Check if a secret is valid and accessible."""
        pass


class InMemorySecretManager(SecretManager):
    """
    In-memory secret manager for development and testing.

    NOTE: This is NOT suitable for production use as secrets are stored
    in memory only and will be lost on restart.
    """

    def __init__(self) -> None:
        """Initialize the in-memory secret store."""
        self._secrets: dict[str, list[SecretVersion]] = {}
        self._lock = asyncio.Lock()

    async def get_secret(self, secret_name: str) -> SecretVersion | None:
        """Get the active version of a secret."""
        async with self._lock:
            versions = self._secrets.get(secret_name, [])
            for version in versions:
                if version.status == SecretStatus.ACTIVE and not version.is_expired():
                    version.mark_used()
                    return version
            return None

    async def get_secret_with_fallback(
        self, secret_name: str
    ) -> SecretVersion | None:
        """Get a secret, falling back to previous version if active is unavailable."""
        async with self._lock:
            versions = self._secrets.get(secret_name, [])

            # Try active first
            for version in versions:
                if version.status == SecretStatus.ACTIVE and not version.is_expired():
                    version.mark_used()
                    return version

            # Fall back to previous
            for version in versions:
                if version.status == SecretStatus.PREVIOUS and not version.is_expired():
                    logger.warning(
                        "Using previous version of secret '%s' (active unavailable)",
                        secret_name,
                    )
                    version.mark_used()
                    return version

            return None

    async def get_secret_versions(
        self, secret_name: str
    ) -> list[SecretVersion]:
        """Get all versions of a secret."""
        async with self._lock:
            return list(self._secrets.get(secret_name, []))

    async def store_secret(
        self,
        secret_name: str,
        value: SecretStr,
        version_id: str | None = None,
        expires_at: float | None = None,
    ) -> SecretVersion:
        """Store a new secret (convenience method for in-memory manager)."""
        async with self._lock:
            if secret_name not in self._secrets:
                self._secrets[secret_name] = []

            version = SecretVersion(
                value=value,
                version_id=version_id or f"v{len(self._secrets[secret_name])}",
                status=SecretStatus.ACTIVE,
                expires_at=expires_at,
            )
            self._secrets[secret_name].append(version)
            return version

    async def rotate_secret(
        self,
        secret_name: str,
        new_value: SecretStr,
        strategy: RotationStrategy = RotationStrategy.GRACEFUL,
    ) -> SecretVersion:
        """Rotate a secret to a new value."""
        async with self._lock:
            versions = self._secrets.get(secret_name, [])

            # Mark current active as previous
            for version in versions:
                if version.status == SecretStatus.ACTIVE:
                    if strategy == RotationStrategy.GRACEFUL:
                        version.status = SecretStatus.PREVIOUS
                        # Set expiration for graceful transition (e.g., 24 hours)
                        version.expires_at = time.time() + 86400
                    else:
                        version.status = SecretStatus.EXPIRED

            # Create new active version
            new_version = SecretVersion(
                value=new_value,
                version_id=f"v{len(versions)}",
                status=SecretStatus.ACTIVE,
            )
            versions.append(new_version)
            self._secrets[secret_name] = versions

            logger.info(
                "Rotated secret '%s' with strategy '%s', new version: %s",
                secret_name,
                strategy.value,
                new_version.version_id,
            )
            return new_version

    async def revoke_secret(
        self, secret_name: str, version_id: str | None = None
    ) -> None:
        """Revoke a secret or a specific version."""
        async with self._lock:
            if version_id:
                versions = self._secrets.get(secret_name, [])
                for version in versions:
                    if version.version_id == version_id:
                        version.status = SecretStatus.EXPIRED
                        logger.info(
                            "Revoked secret '%s' version '%s'", secret_name, version_id
                        )
                        return
                raise ValueError(
                    f"Version '{version_id}' not found for secret '{secret_name}'"
                )
            else:
                # Revoke all versions
                if secret_name in self._secrets:
                    for version in self._secrets[secret_name]:
                        version.status = SecretStatus.EXPIRED
                    logger.info("Revoked all versions of secret '%s'", secret_name)

    async def health_check(self, secret_name: str) -> bool:
        """Check if a secret is valid and accessible."""
        secret = await self.get_secret(secret_name)
        return secret is not None and not secret.is_expired()


class RotatableSecret:
    """
    A secret that supports rotation with automatic failover.

    This class wraps a secret and provides:
    - Automatic rotation support
    - Health checking
    - Fallback to backup secrets
    - Usage tracking
    """

    def __init__(
        self,
        name: str,
        manager: SecretManager,
        rotation_interval: float | None = None,  # seconds
        health_check_interval: float = 300,  # 5 minutes
    ):
        """
        Initialize a rotatable secret.

        Args:
            name: Unique name for this secret
            manager: Secret manager instance
            rotation_interval: Optional automatic rotation interval
            health_check_interval: Health check interval in seconds
        """
        self.name = name
        self._manager = manager
        self._rotation_interval = rotation_interval
        self._health_check_interval = health_check_interval
        self._last_rotation: float | None = None
        self._last_health_check: float | None = None
        _health_status: bool = True

    async def get_value(self) -> str | None:
        """Get the current secret value."""
        version = await self._manager.get_secret_with_fallback(self.name)
        if version:
            return version.value.get_secret_value()
        return None

    async def get_secret_str(self) -> SecretStr | None:
        """Get the current secret as SecretStr."""
        version = await self._manager.get_secret_with_fallback(self.name)
        if version:
            return version.value
        return None

    async def rotate(
        self, new_value: SecretStr, strategy: RotationStrategy = RotationStrategy.GRACEFUL
    ) -> SecretVersion:
        """Rotate the secret to a new value."""
        version = await self._manager.rotate_secret(self.name, new_value, strategy)
        self._last_rotation = time.time()
        return version

    async def is_healthy(self) -> bool:
        """Check if the secret is healthy."""
        # Cache health check results
        if (
            self._last_health_check
            and time.time() - self._last_health_check < self._health_check_interval
        ):
            return self._health_status

        self._health_status = await self._manager.health_check(self.name)
        self._last_health_check = time.time()
        return self._health_status

    async def needs_rotation(self) -> bool:
        """Check if the secret needs rotation."""
        if self._rotation_interval is None:
            return False
        if self._last_rotation is None:
            return True
        return time.time() - self._last_rotation > self._rotation_interval

    def get_masked_value(self) -> str:
        """Get a masked representation for logging."""
        return f"<secret:{self.name}>"


class SecretsRotationManager:
    """
    Central manager for all rotatable secrets.

    This class provides:
    - Registration of multiple secrets
    - Scheduled rotation
    - Health monitoring
    - Audit logging
    """

    def __init__(self, manager: SecretManager | None = None) -> None:
        """
        Initialize the secrets rotation manager.

        Args:
            manager: Secret manager to use (defaults to InMemorySecretManager)
        """
        self._manager = manager or InMemorySecretManager()
        self._secrets: dict[str, RotatableSecret] = {}
        self._rotation_tasks: dict[str, asyncio.Task] = {}
        self._running = False

    def register_secret(
        self,
        name: str,
        initial_value: SecretStr | None = None,
        rotation_interval: float | None = None,
    ) -> RotatableSecret:
        """
        Register a secret for rotation management.

        Args:
            name: Unique secret name
            initial_value: Optional initial secret value
            rotation_interval: Optional rotation interval in seconds

        Returns:
            RotatableSecret instance
        """
        secret = RotatableSecret(
            name=name,
            manager=self._manager,
            rotation_interval=rotation_interval,
        )
        self._secrets[name] = secret

        if initial_value:
            asyncio.create_task(
                self._manager.store_secret(name, initial_value)
            )

        logger.info("Registered secret '%s' for rotation management", name)
        return secret

    def get_secret(self, name: str) -> RotatableSecret | None:
        """Get a registered secret by name."""
        return self._secrets.get(name)

    async def rotate_secret(
        self,
        name: str,
        new_value: SecretStr,
        strategy: RotationStrategy = RotationStrategy.GRACEFUL,
    ) -> SecretVersion:
        """Rotate a specific secret."""
        secret = self._secrets.get(name)
        if not secret:
            raise ValueError(f"Secret '{name}' not registered")
        return await secret.rotate(new_value, strategy)

    async def check_all_health(self) -> dict[str, bool]:
        """Check health of all registered secrets."""
        results = {}
        for name, secret in self._secrets.items():
            results[name] = await secret.is_healthy()
        return results

    async def get_unhealthy_secrets(self) -> list[str]:
        """Get list of unhealthy secret names."""
        health = await self.check_all_health()
        return [name for name, is_healthy in health.items() if not is_healthy]

    async def start_monitoring(self) -> None:
        """Start background monitoring for all secrets."""
        self._running = True
        for name, secret in self._secrets.items():
            task = asyncio.create_task(
                self._monitor_secret(name, secret),
                name=f"secret_monitor_{name}",
            )
            self._rotation_tasks[name] = task
        logger.info("Started secrets rotation monitoring")

    async def stop_monitoring(self) -> None:
        """Stop background monitoring."""
        self._running = False
        for task in self._rotation_tasks.values():
            task.cancel()
        await asyncio.gather(*self._rotation_tasks.values(), return_exceptions=True)
        self._rotation_tasks.clear()
        logger.info("Stopped secrets rotation monitoring")

    async def _monitor_secret(self, name: str, secret: RotatableSecret) -> None:
        """Background task to monitor a secret."""
        while self._running:
            try:
                # Check health
                if not await secret.is_healthy():
                    logger.error("Secret '%s' is unhealthy", name)

                # Check if rotation needed
                if await secret.needs_rotation():
                    logger.warning("Secret '%s' needs rotation", name)

                await asyncio.sleep(secret._health_check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Error monitoring secret '%s': %s", name, e)
                await asyncio.sleep(60)  # Wait before retrying


# =============================================================================
# Integration with Settings
# =============================================================================


class SecretsAwareSettings(BaseModel):
    """Mixin for settings classes that need secrets rotation support."""

    secrets_manager: SecretManager | None = Field(
        default=None,
        exclude=True,  # Don't serialize
    )

    class Config:
        arbitrary_types_allowed = True

    async def get_secret(self, name: str) -> SecretStr | None:
        """Get a secret value through the secrets manager."""
        if self.secrets_manager:
            version = await self.secrets_manager.get_secret(name)
            return version.value if version else None
        return None

    def with_secrets_manager(self, manager: SecretManager) -> Self:
        """Return a copy with secrets manager set."""
        data = self.model_dump()
        data["secrets_manager"] = manager
        return self.model_validate(data)


# =============================================================================
# Production Secret Manager Implementations (Stubs)
# =============================================================================


class AWSSecretsManager(SecretManager):
    """
    AWS Secrets Manager integration.

    This is a stub implementation. For production use, install boto3
    and implement full AWS Secrets Manager integration.
    """

    def __init__(self, region_name: str = "us-east-1") -> None:
        """Initialize AWS Secrets Manager client."""
        self._region = region_name
        # Import boto3 here to avoid dependency if not used
        try:
            import boto3

            self._client = boto3.client("secretsmanager", region_name=region_name)
        except ImportError:
            raise ImportError(
                "boto3 is required for AWS Secrets Manager. "
                "Install with: pip install boto3"
            )

    async def get_secret(self, secret_name: str) -> SecretVersion | None:
        """Get secret from AWS Secrets Manager."""
        # Implementation would use boto3 to fetch from AWS
        raise NotImplementedError("AWS Secrets Manager integration not implemented")

    async def get_secret_versions(
        self, secret_name: str
    ) -> list[SecretVersion]:
        """Get all versions from AWS."""
        raise NotImplementedError()

    async def rotate_secret(
        self,
        secret_name: str,
        new_value: SecretStr,
        strategy: RotationStrategy = RotationStrategy.GRACEFUL,
    ) -> SecretVersion:
        """Rotate secret in AWS."""
        raise NotImplementedError()

    async def revoke_secret(
        self, secret_name: str, version_id: str | None = None
    ) -> None:
        """Revoke secret in AWS."""
        raise NotImplementedError()

    async def health_check(self, secret_name: str) -> bool:
        """Check secret health in AWS."""
        raise NotImplementedError()


class HashiCorpVaultManager(SecretManager):
    """
    HashiCorp Vault integration.

    This is a stub implementation. For production use, install hvac
    and implement full Vault integration.
    """

    def __init__(self, vault_addr: str, token: str | None = None) -> None:
        """Initialize Vault client."""
        self._addr = vault_addr
        try:
            import hvac

            self._client = hvac.Client(url=vault_addr, token=token)
        except ImportError:
            raise ImportError(
                "hvac is required for HashiCorp Vault. "
                "Install with: pip install hvac"
            )

    async def get_secret(self, secret_name: str) -> SecretVersion | None:
        """Get secret from Vault."""
        raise NotImplementedError("Vault integration not implemented")

    async def get_secret_versions(
        self, secret_name: str
    ) -> list[SecretVersion]:
        """Get all versions from Vault."""
        raise NotImplementedError()

    async def rotate_secret(
        self,
        secret_name: str,
        new_value: SecretStr,
        strategy: RotationStrategy = RotationStrategy.GRACEFUL,
    ) -> SecretVersion:
        """Rotate secret in Vault."""
        raise NotImplementedError()

    async def revoke_secret(
        self, secret_name: str, version_id: str | None = None
    ) -> None:
        """Revoke secret in Vault."""
        raise NotImplementedError()

    async def health_check(self, secret_name: str) -> bool:
        """Check secret health in Vault."""
        raise NotImplementedError()


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "SecretStatus",
    "RotationStrategy",
    "SecretVersion",
    "SecretManager",
    "InMemorySecretManager",
    "RotatableSecret",
    "SecretsRotationManager",
    "SecretsAwareSettings",
    "AWSSecretsManager",
    "HashiCorpVaultManager",
]
