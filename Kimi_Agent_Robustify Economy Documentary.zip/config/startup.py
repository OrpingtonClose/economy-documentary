"""
Startup Validation for Documentary Pipeline.

This module provides comprehensive validation that runs at application startup
to ensure all configuration is correct and required services are accessible.
"""

from __future__ import annotations

import asyncio
import logging
import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from pydantic import ValidationError

from .settings import DocumentarySettings, Environment, get_settings

logger = logging.getLogger(__name__)


class ValidationSeverity(str, Enum):
    """Severity level for validation issues."""

    INFO = "info"  # Informational only
    WARNING = "warning"  # Warning but can continue
    ERROR = "error"  # Error but can attempt recovery
    CRITICAL = "critical"  # Fatal, cannot start


@dataclass
class ValidationIssue:
    """A single validation issue."""

    message: str
    severity: ValidationSeverity
    field: str | None = None
    suggestion: str | None = None
    documentation_link: str | None = None


@dataclass
class ValidationResult:
    """Result of startup validation."""

    success: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    warnings: list[ValidationIssue] = field(default_factory=list)
    errors: list[ValidationIssue] = field(default_factory=list)
    critical_errors: list[ValidationIssue] = field(default_factory=list)

    def add_issue(self, issue: ValidationIssue) -> None:
        """Add an issue to the appropriate list."""
        self.issues.append(issue)
        if issue.severity == ValidationSeverity.WARNING:
            self.warnings.append(issue)
        elif issue.severity == ValidationSeverity.ERROR:
            self.errors.append(issue)
        elif issue.severity == ValidationSeverity.CRITICAL:
            self.critical_errors.append(issue)

    def can_start(self) -> bool:
        """Check if the application can start despite issues."""
        return len(self.critical_errors) == 0

    def has_warnings(self) -> bool:
        """Check if there are any warnings."""
        return len(self.warnings) > 0

    def has_errors(self) -> bool:
        """Check if there are any errors."""
        return len(self.errors) > 0


class StartupValidator:
    """
    Validates application configuration at startup.

    This class performs comprehensive validation including:
    - Configuration schema validation
    - Required environment variables
    - API key format validation
    - Service connectivity checks
    - Resource availability
    """

    def __init__(self, settings: DocumentarySettings | None = None) -> None:
        """
        Initialize the validator.

        Args:
            settings: Settings to validate (uses get_settings() if None)
        """
        self._settings = settings or get_settings()
        self._result = ValidationResult(success=True)
        self._custom_validators: list[Callable[[DocumentarySettings], list[ValidationIssue]]] = []

    def add_custom_validator(
        self, validator: Callable[[DocumentarySettings], list[ValidationIssue]]
    ) -> None:
        """Add a custom validation function."""
        self._custom_validators.append(validator)

    async def validate_all(self) -> ValidationResult:
        """
        Run all validations.

        Returns:
            ValidationResult with all issues found
        """
        self._result = ValidationResult(success=True)

        # Run validations
        await self._validate_configuration()
        await self._validate_api_keys()
        await self._validate_paths()
        await self._validate_services()
        await self._validate_concurrency_settings()
        await self._run_custom_validators()

        # Determine overall success
        self._result.success = self._result.can_start()

        return self._result

    async def _validate_configuration(self) -> None:
        """Validate the basic configuration."""
        try:
            # Re-validate settings (catches any runtime issues)
            self._settings.model_validate(self._settings.model_dump())
        except ValidationError as e:
            for error in e.errors():
                self._result.add_issue(
                    ValidationIssue(
                        message=f"Configuration validation error: {error['msg']}",
                        severity=ValidationSeverity.CRITICAL,
                        field=".".join(str(x) for x in error["loc"]),
                        suggestion="Check your environment variables and .env file",
                    )
                )

    async def _validate_api_keys(self) -> None:
        """Validate API keys are present and properly formatted."""
        llm = self._settings.llm_providers

        # Check for at least one LLM provider
        has_llm = any(
            [
                llm.google_api_key,
                llm.openai_api_key,
                llm.gemini_api_key,
                llm.deepseek_api,
                llm.groq_api,
            ]
        )

        if not has_llm:
            self._result.add_issue(
                ValidationIssue(
                    message="No LLM provider API key configured",
                    severity=ValidationSeverity.CRITICAL,
                    field="llm_providers",
                    suggestion="Set GOOGLE_API_KEY, OPENAI_API_KEY, or another provider key",
                    documentation_link="https://github.com/OrpingtonClose/economy-documentary#configuration",
                )
            )

        # Production-specific checks
        if self._settings.environment == Environment.PRODUCTION:
            # Require at least two providers for redundancy
            provider_count = sum(
                [
                    1 if llm.google_api_key else 0,
                    1 if llm.openai_api_key else 0,
                    1 if llm.gemini_api_key else 0,
                    1 if llm.deepseek_api else 0,
                ]
            )
            if provider_count < 2:
                self._result.add_issue(
                    ValidationIssue(
                        message="Production requires at least 2 LLM providers for redundancy",
                        severity=ValidationSeverity.ERROR,
                        field="llm_providers",
                        suggestion="Configure multiple LLM providers for failover",
                    )
                )

    async def _validate_paths(self) -> None:
        """Validate that configured paths are accessible."""
        import os

        paths_to_check = [
            ("data_dir", self._settings.paths.data_dir),
            ("timeline_dir", self._settings.paths.timeline_dir),
            ("tts_output_dir", self._settings.paths.tts_output_dir),
            ("video_output_dir", self._settings.paths.video_output_dir),
        ]

        for name, path in paths_to_check:
            if path is None:
                continue

            # Check if parent directory exists and is writable
            parent = path.parent
            if not parent.exists():
                self._result.add_issue(
                    ValidationIssue(
                        message=f"Parent directory for {name} does not exist: {parent}",
                        severity=ValidationSeverity.ERROR,
                        field=f"paths.{name}",
                        suggestion=f"Create the directory: mkdir -p {parent}",
                    )
                )
            elif not os.access(parent, os.W_OK):
                self._result.add_issue(
                    ValidationIssue(
                        message=f"Parent directory for {name} is not writable: {parent}",
                        severity=ValidationSeverity.ERROR,
                        field=f"paths.{name}",
                        suggestion=f"Fix permissions: chmod 755 {parent}",
                    )
                )

    async def _validate_services(self) -> None:
        """Validate that required external services are accessible."""
        # Check Vast.ai if GPU workers are needed
        if not self._settings.documentary_test_mode:
            if self._settings.infrastructure.vast_api_key is None:
                self._result.add_issue(
                    ValidationIssue(
                        message="VAST_API_KEY not set but GPU workers may be needed",
                        severity=ValidationSeverity.WARNING,
                        field="infrastructure.vast_api_key",
                        suggestion="Set VAST_API_KEY or enable DOCUMENTARY_TEST_MODE",
                    )
                )

        # Check B2 configuration if caching is expected
        storage = self._settings.storage
        if storage.key_id is None or storage.application_key is None:
            self._result.add_issue(
                ValidationIssue(
                    message="Backblaze B2 not fully configured",
                    severity=ValidationSeverity.INFO,
                    field="storage",
                    suggestion="Configure B2 for model caching and artifact storage",
                )
            )

    async def _validate_concurrency_settings(self) -> None:
        """Validate concurrency settings are reasonable."""
        concurrency = self._settings.concurrency

        # Check context limits
        if concurrency.hard_context_limit <= concurrency.max_context_tokens:
            self._result.add_issue(
                ValidationIssue(
                    message="HARD_CONTEXT_LIMIT must be greater than MAX_CONTEXT_TOKENS",
                    severity=ValidationSeverity.ERROR,
                    field="concurrency.hard_context_limit",
                    suggestion=f"Set HARD_CONTEXT_LIMIT > {concurrency.max_context_tokens}",
                )
            )

        # Warn about very high concurrency in development
        if (
            self._settings.environment == Environment.DEVELOPMENT
            and concurrency.max_concurrent_llm > 4
        ):
            self._result.add_issue(
                ValidationIssue(
                    message="High LLM concurrency in development may cause rate limiting",
                    severity=ValidationSeverity.WARNING,
                    field="concurrency.max_concurrent_llm",
                    suggestion="Consider reducing MAX_CONCURRENT_LLM for development",
                )
            )

    async def _run_custom_validators(self) -> None:
        """Run any custom validation functions."""
        for validator in self._custom_validators:
            try:
                issues = validator(self._settings)
                for issue in issues:
                    self._result.add_issue(issue)
            except Exception as e:
                self._result.add_issue(
                    ValidationIssue(
                        message=f"Custom validator failed: {e}",
                        severity=ValidationSeverity.ERROR,
                    )
                )

    def print_report(self) -> None:
        """Print a validation report to the console."""
        print("\n" + "=" * 70)
        print("STARTUP VALIDATION REPORT")
        print("=" * 70)

        if self._result.success and not self._result.issues:
            print("✅ All validations passed!")
            print("=" * 70)
            return

        # Print critical errors
        if self._result.critical_errors:
            print("\n❌ CRITICAL ERRORS (Application cannot start):")
            for issue in self._result.critical_errors:
                print(f"  • {issue.message}")
                if issue.suggestion:
                    print(f"    Suggestion: {issue.suggestion}")

        # Print errors
        if self._result.errors:
            print("\n⚠️  ERRORS (Application may have issues):")
            for issue in self._result.errors:
                print(f"  • {issue.message}")
                if issue.suggestion:
                    print(f"    Suggestion: {issue.suggestion}")

        # Print warnings
        if self._result.warnings:
            print("\n⚡ WARNINGS:")
            for issue in self._result.warnings:
                print(f"  • {issue.message}")
                if issue.suggestion:
                    print(f"    Suggestion: {issue.suggestion}")

        print("\n" + "=" * 70)
        print(f"Result: {'✅ Can start' if self._result.can_start() else '❌ Cannot start'}")
        print("=" * 70 + "\n")


async def validate_startup(
    exit_on_error: bool = True,
    settings: DocumentarySettings | None = None,
) -> ValidationResult:
    """
    Convenience function to run startup validation.

    Args:
        exit_on_error: Whether to exit the process if validation fails
        settings: Optional settings instance to validate

    Returns:
        ValidationResult with all issues found
    """
    validator = StartupValidator(settings)
    result = await validator.validate_all()
    validator.print_report()

    if exit_on_error and not result.can_start():
        sys.exit(1)

    return result


def validate_startup_sync(
    exit_on_error: bool = True,
    settings: DocumentarySettings | None = None,
) -> ValidationResult:
    """Synchronous version of validate_startup."""
    return asyncio.run(validate_startup(exit_on_error, settings))


# =============================================================================
# FastAPI Integration
# =============================================================================


async def startup_validation_hook() -> None:
    """
    FastAPI startup hook for validation.

    Usage:
        @app.on_event("startup")
        async def on_startup():
            await startup_validation_hook()
    """
    result = await validate_startup(exit_on_error=True)
    if result.has_warnings():
        logger.warning("Startup validation completed with warnings")


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "ValidationSeverity",
    "ValidationIssue",
    "ValidationResult",
    "StartupValidator",
    "validate_startup",
    "validate_startup_sync",
    "startup_validation_hook",
]
