"""Refactored production orchestrator with reduced complexity.

This module provides a cleaner implementation of the production orchestrator
with better separation of concerns and reduced cyclomatic complexity.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

from google.genai import types as genai_types

if TYPE_CHECKING:
    from orchestrator.production_models import (
        BatchResult,
        ClipBatch,
        ClipResult,
        ClipTask,
        PlanEvaluation,
        ProductionPlan,
        ProductionPlanResult,
    )

logger = logging.getLogger(__name__)


# =============================================================================
# Constants and Enums
# =============================================================================


class QualityRating(Enum):
    """Quality rating for plan evaluation."""

    POOR = 0
    FAIR = 1
    GOOD = 2
    EXCELLENT = 3


class StageStatus(Enum):
    """Status of a production stage."""

    PENDING = auto()
    RUNNING = auto()
    COMPLETED = auto()
    FAILED = auto()
    SKIPPED = auto()


# =============================================================================
# Configuration Dataclass
# =============================================================================


@dataclass(frozen=True, slots=True)
class OrchestratorConfig:
    """Configuration for the production orchestrator."""

    max_refinements: int = 3
    default_lora_id: str = "documentary-realism"
    default_lora_weight: float = 0.75
    max_clip_duration: float = 10.0
    video_dir: str = field(
        default_factory=lambda: os.environ.get(
            "VIDEO_OUTPUT_DIR", "/tmp/documentary-pipeline/video"
        )
    )

    @classmethod
    def from_env(cls) -> OrchestratorConfig:
        """Create configuration from environment variables."""
        return cls(
            max_refinements=int(os.environ.get("MAX_REFINEMENTS", "3")),
            default_lora_id=os.environ.get("DEFAULT_LORA_ID", "documentary-realism"),
            default_lora_weight=float(os.environ.get("DEFAULT_LORA_WEIGHT", "0.75")),
            max_clip_duration=float(os.environ.get("MAX_CLIP_DURATION", "10.0")),
        )


# =============================================================================
# State Parser
# =============================================================================


class StateParser:
    """Parse and validate pipeline state."""

    def __init__(self, state: dict[str, Any]) -> None:
        self.state = state

    def parse_concepts(self) -> list[dict]:
        """Extract visual concepts from state.

        Returns:
            List of visual concept dictionaries.
        """
        from callbacks.deterministic_steps import extract_json_array, extract_json_object

        raw_concepts = self.state.get("visual_concepts", "")
        concepts = extract_json_array(str(raw_concepts))

        if not concepts:
            obj = extract_json_object(str(raw_concepts))
            if obj and "visual_concepts" in obj:
                concepts = obj["visual_concepts"]

        return concepts or []

    def parse_visual_style(self) -> tuple[str, list[str]]:
        """Extract visual style from state.

        Returns:
            Tuple of (style_string, avoid_list).
        """
        raw_visual_style = self.state.get("visual_style", "")
        if not raw_visual_style:
            return "", []

        try:
            vs = (
                json.loads(str(raw_visual_style))
                if isinstance(raw_visual_style, str)
                else raw_visual_style
            )
            if isinstance(vs, dict):
                return json.dumps(vs), vs.get("avoid", [])
        except (json.JSONDecodeError, TypeError):
            pass

        return str(raw_visual_style), []

    def parse_scenes(self) -> list[dict]:
        """Extract scenes from state for fallback concept generation.

        Returns:
            List of scene dictionaries.
        """
        from callbacks.deterministic_steps import extract_json_array

        raw_scenes = self.state.get("scenes", "[]")
        return extract_json_array(str(raw_scenes)) or []

    def generate_fallback_concepts(self, scenes: list[dict]) -> list[dict]:
        """Generate simple concepts from scenes when visual_concepts is empty.

        Args:
            scenes: List of scene dictionaries.

        Returns:
            List of generated concept dictionaries.
        """
        concepts = []
        for scene in scenes:
            sn = scene.get("scene_num", 0)
            duration = min(scene.get("duration_sec", 5), 10.0)
            concepts.append({
                "scene_num": sn,
                "phrase_idx": 0,
                "duration": duration,
                "prompt": (
                    f"Documentary footage: {scene.get('title', 'scene')}. "
                    f"{scene.get('visual_notes', '')}"
                ),
                "start_time": 0.0,
                "end_time": duration,
                "lora_id": "documentary-realism",
                "lora_weight": 0.75,
            })
        return concepts


# =============================================================================
# Worker Manager
# =============================================================================


class WorkerManager:
    """Manage GPU worker configuration and status."""

    def __init__(self) -> None:
        self.worker_urls: list[str] = []
        self.num_workers: int = 1
        self._load_from_env()

    def _load_from_env(self) -> None:
        """Load worker configuration from environment."""
        worker_urls_str = os.environ.get("VIDEO_WORKER_URLS", "")
        if worker_urls_str:
            self.worker_urls = [
                u.strip() for u in worker_urls_str.split(",") if u.strip()
            ]
            self.num_workers = max(1, len(self.worker_urls))

    def get_worker_info(self) -> dict[str, Any]:
        """Get worker configuration information.

        Returns:
            Dictionary with worker configuration.
        """
        return {
            "urls": self.worker_urls,
            "count": self.num_workers,
            "list": "\n".join(f"  - {url}" for url in self.worker_urls)
            if self.worker_urls
            else "  (single local worker)",
        }


# =============================================================================
# Clip Scanner
# =============================================================================


class ClipScanner:
    """Scan for existing clips with good QA status."""

    def __init__(self, video_dir: str) -> None:
        self.video_dir = video_dir
        self.existing_clips: dict[str, str] = {}

    def scan(self) -> dict[str, str]:
        """Scan video directory for existing clips.

        Returns:
            Dictionary mapping clip_id to mp4_path.
        """
        self.existing_clips = {}

        if not os.path.exists(self.video_dir):
            return self.existing_clips

        for filename in os.listdir(self.video_dir):
            if filename.endswith("_status.json"):
                self._process_status_file(filename)

        return self.existing_clips

    def _process_status_file(self, filename: str) -> None:
        """Process a single status file.

        Args:
            filename: Name of the status file.
        """
        status_path = os.path.join(self.video_dir, filename)

        try:
            with open(status_path) as f:
                status = json.load(f)

            if status.get("quality") not in ("good", "excellent"):
                return

            clip_id = self._extract_clip_id(filename)
            if not clip_id:
                return

            mp4_path = os.path.join(
                self.video_dir, filename.replace("_status.json", ".mp4")
            )
            if os.path.exists(mp4_path):
                self.existing_clips[clip_id] = mp4_path

        except (json.JSONDecodeError, OSError, IndexError):
            pass

    def _extract_clip_id(self, filename: str) -> str | None:
        """Extract clip_id from status filename.

        Args:
            filename: Status filename like "scene_001_phrase_002_status.json".

        Returns:
            Clip ID like "s001_p002" or None if parsing fails.
        """
        # e.g. "scene_001_phrase_002_status.json" -> "s001_p002"
        base = filename.replace("_status.json", "")
        parts = base.split("_")

        if len(parts) >= 4 and parts[0] == "scene" and parts[2] == "phrase":
            return f"s{parts[1]}_p{parts[3]}"

        return None


# =============================================================================
# Plan Builder
# =============================================================================


class PlanBuilder:
    """Build production plans from concepts and configuration."""

    def __init__(
        self,
        config: OrchestratorConfig,
        worker_manager: WorkerManager,
        existing_clips: dict[str, str],
    ) -> None:
        self.config = config
        self.worker_manager = worker_manager
        self.existing_clips = existing_clips

    def create_fallback_plan(self, concepts: list[dict]) -> "ProductionPlan":
        """Create a deterministic fallback plan.

        Args:
            concepts: List of visual concepts.

        Returns:
            ProductionPlan with round-robin batch assignment.
        """
        from orchestrator.production_models import ClipBatch, ClipTask, ProductionPlan

        logger.info("Creating fallback deterministic plan")

        batches: list[ClipBatch] = []
        current_tasks: list[ClipTask] = []

        for concept in concepts:
            task = self._create_task_from_concept(concept)
            current_tasks.append(task)

            if len(current_tasks) >= self.worker_manager.num_workers:
                batches.append(
                    ClipBatch(
                        description=f"Batch {len(batches) + 1}",
                        tasks=current_tasks,
                        rationale="Round-robin assignment (fallback plan)",
                    )
                )
                current_tasks = []

        # Add remaining tasks
        if current_tasks:
            batches.append(
                ClipBatch(
                    description=f"Batch {len(batches) + 1}",
                    tasks=current_tasks,
                    rationale="Round-robin assignment (fallback plan)",
                )
            )

        return ProductionPlan(
            batches=batches,
            is_complete=True,
            strategy="Fallback deterministic plan — round-robin batches",
            estimated_gpu_minutes=len(concepts) * 2.0,
            risk_assessment="Fallback plan — no LLM optimization applied",
        )

    def _create_task_from_concept(self, concept: dict) -> "ClipTask":
        """Create a ClipTask from a concept dictionary.

        Args:
            concept: Visual concept dictionary.

        Returns:
            ClipTask instance.
        """
        from orchestrator.production_models import ClipTask

        sn = concept.get("scene_num", 0)
        pi = concept.get("phrase_idx", 0)
        clip_id = f"s{sn:03d}_p{pi:03d}"

        return ClipTask(
            clip_id=clip_id,
            scene_num=sn,
            phrase_idx=pi,
            prompt=concept.get("prompt", ""),
            negative_prompt=concept.get("negative_prompt", ""),
            duration=min(concept.get("duration", 5.0), self.config.max_clip_duration),
            lora_id=concept.get("lora_id", self.config.default_lora_id),
            lora_weight=concept.get("lora_weight", self.config.default_lora_weight),
            assigned_worker="auto",
            priority=0,
            style_group=concept.get("lora_id", "default"),
            skip=clip_id in self.existing_clips,
        )


# =============================================================================
# Batch Executor
# =============================================================================


class BatchExecutor:
    """Execute batches of clip generation tasks."""

    def __init__(
        self,
        video_dir: str,
        default_negative: str,
        visual_style: str,
        feedback_store: Any,
        num_workers: int,
    ) -> None:
        self.video_dir = video_dir
        self.default_negative = default_negative
        self.visual_style = visual_style
        self.feedback_store = feedback_store
        self.num_workers = num_workers

    def execute_batch(
        self, batch: "ClipBatch", batch_idx: int
    ) -> tuple["BatchResult", list[dict]]:
        """Execute a single batch of clips.

        Args:
            batch: The batch to execute.
            batch_idx: Index of the batch.

        Returns:
            Tuple of (BatchResult, generation results).
        """
        from orchestrator.clip_helpers import generate_one_clip
        from orchestrator.production_models import BatchResult, ClipResult

        clip_results: list[ClipResult] = []
        gen_results: list[dict] = []
        task_concepts = []

        # Separate skipped and active tasks
        for task in batch.tasks:
            if task.skip:
                result = self._handle_skipped_task(task)
                gen_results.append(result)
                clip_results.append(self._result_to_clip_result(task.clip_id, result))
            else:
                task_concepts.append(self._task_to_concept(task))

        # Generate active clips
        if task_concepts:
            batch_results = self._generate_clips_parallel(task_concepts)
            gen_results.extend(batch_results)
            clip_results.extend(
                self._result_to_clip_result(
                    tc["_clip_id"], result
                )
                for tc, result in zip(task_concepts, batch_results)
            )

        batch_result = BatchResult(batch_idx=batch_idx, clip_results=clip_results)
        batch_result.compute_stats()

        return batch_result, gen_results

    def _handle_skipped_task(self, task: "ClipTask") -> dict:
        """Handle a task that should be skipped (already generated).

        Args:
            task: The task to skip.

        Returns:
            Result dictionary for skipped task.
        """
        output_path = os.path.join(
            self.video_dir,
            f"scene_{task.scene_num:03d}_phrase_{task.phrase_idx:03d}.mp4",
        )

        return {
            "skipped": True,
            "output_path": output_path,
            "scene_num": task.scene_num,
            "phrase_idx": task.phrase_idx,
            "duration": task.duration,
            "lora_id": task.lora_id,
        }

    def _task_to_concept(self, task: "ClipTask") -> dict:
        """Convert a ClipTask to a concept dictionary.

        Args:
            task: The task to convert.

        Returns:
            Concept dictionary for generation.
        """
        return {
            "scene_num": task.scene_num,
            "phrase_idx": task.phrase_idx,
            "duration": task.duration,
            "prompt": task.prompt,
            "negative_prompt": task.negative_prompt or self.default_negative,
            "lora_id": task.lora_id,
            "lora_weight": task.lora_weight,
            "_clip_id": task.clip_id,
        }

    def _generate_clips_parallel(self, task_concepts: list[dict]) -> list[dict]:
        """Generate clips in parallel using thread pool.

        Args:
            task_concepts: List of concept dictionaries.

        Returns:
            List of generation results.
        """
        from orchestrator.clip_helpers import generate_one_clip

        results = []

        if len(task_concepts) <= 1 or self.num_workers <= 1:
            # Sequential execution
            for concept in task_concepts:
                try:
                    result = generate_one_clip(
                        concept,
                        self.video_dir,
                        self.default_negative,
                        self.visual_style,
                        self.feedback_store,
                    )
                    results.append(result)
                except RuntimeError:
                    raise
                except Exception as e:
                    logger.error("Error generating clip: %s", e)
                    results.append(self._error_result(concept, e))
            return results

        # Parallel execution
        with ThreadPoolExecutor(max_workers=self.num_workers) as executor:
            future_to_concept = {
                executor.submit(
                    generate_one_clip,
                    c,
                    self.video_dir,
                    self.default_negative,
                    self.visual_style,
                    self.feedback_store,
                ): c
                for c in task_concepts
            }

            for future in as_completed(future_to_concept):
                concept = future_to_concept[future]
                try:
                    results.append(future.result())
                except RuntimeError:
                    raise
                except Exception as e:
                    logger.error("Error generating clip %s: %s", concept["_clip_id"], e)
                    results.append(self._error_result(concept, e))

        return results

    def _error_result(self, concept: dict, error: Exception) -> dict:
        """Create an error result dictionary.

        Args:
            concept: The concept that failed.
            error: The exception that occurred.

        Returns:
            Error result dictionary.
        """
        return {
            "status": "error",
            "error": str(error),
            "scene_num": concept["scene_num"],
            "phrase_idx": concept["phrase_idx"],
            "duration": concept["duration"],
            "lora_id": concept["lora_id"],
        }

    def _result_to_clip_result(self, clip_id: str, result: dict) -> "ClipResult":
        """Convert generation result to ClipResult.

        Args:
            clip_id: The clip ID.
            result: Generation result dictionary.

        Returns:
            ClipResult instance.
        """
        from orchestrator.production_models import ClipResult

        if result.get("skipped"):
            return ClipResult(
                clip_id=clip_id,
                status="skipped",
                output_path=result.get("output_path", ""),
                scene_num=result.get("scene_num", 0),
                phrase_idx=result.get("phrase_idx", 0),
                lora_id=result.get("lora_id", ""),
            )

        if result.get("status") == "error":
            return ClipResult(
                clip_id=clip_id,
                status="failed",
                error=result.get("error", ""),
                scene_num=result.get("scene_num", 0),
                phrase_idx=result.get("phrase_idx", 0),
                lora_id=result.get("lora_id", ""),
            )

        return ClipResult(
            clip_id=clip_id,
            status="generated",
            qa_quality=result.get("qa_quality", "unknown"),
            qa_reason=result.get("qa_reason", ""),
            output_path=result.get("_output_path", result.get("output_path", "")),
            actual_duration=result.get("actual_duration", 0.0),
            gen_time=result.get("gen_time", 0.0),
            scene_num=result.get("scene_num", 0),
            phrase_idx=result.get("phrase_idx", 0),
            lora_id=result.get("lora_id", ""),
        )


# =============================================================================
# Refactored ProductionOrchestrator
# =============================================================================


class ProductionOrchestratorRefactored:
    """Refactored production orchestrator with reduced complexity.

    This version separates concerns into dedicated classes:
    - StateParser: Handles state extraction
    - WorkerManager: Manages worker configuration
    - ClipScanner: Scans for existing clips
    - PlanBuilder: Creates production plans
    - BatchExecutor: Executes clip generation batches
    """

    MAX_REFINEMENTS = 3

    def __init__(self, state: dict[str, Any], callback_context: Any) -> None:
        self.state = state
        self.callback_context = callback_context
        self.config = OrchestratorConfig.from_env()

        # Components
        self.state_parser = StateParser(state)
        self.worker_manager = WorkerManager()
        self.clip_scanner = ClipScanner(self.config.video_dir)

        # Parsed data
        self.concepts: list[dict] = []
        self.visual_style_str = ""
        self.visual_style_avoid: list[str] = []
        self.existing_clips: dict[str, str] = {}
        self._feedback_store: Any = None
        self._narr_durations: dict = {}

    async def run(self) -> str:
        """Main entry point for production orchestration.

        Returns:
            Summary string for the pipeline.
        """
        # Phase 0: Preconditions
        self._check_preconditions()

        # Phase 1: Parse state
        self._parse_state()

        if not self.concepts:
            return self._handle_no_concepts()

        # Phase 2: Generate and execute plan
        plan = await self._generate_verified_plan()
        result = await self._execute_plan(plan)

        # Phase 3: Post-processing
        return self._post_process(result)

    def _check_preconditions(self) -> None:
        """Check all preconditions before starting production."""
        from contracts import PRODUCTION_CONTRACT, validate_preconditions
        from infra_agent import check_infra_pause, get_infra_agent

        # B2 stage skip check
        stages_complete = self.state.get("_b2_stages_complete", [])
        if "production" in stages_complete:
            raise _StageSkipped(
                "Production stage restored from B2 checkpoint — skipped."
            )

        # OTIO gate check
        if self.state.get("otio_violation"):
            raise RuntimeError(
                f"OTIO VIOLATION (from previous stage): {self.state['otio_violation']}"
            )

        # Contract validation
        validate_preconditions(PRODUCTION_CONTRACT, dict(self.state))

        # Infra notification
        _infra = get_infra_agent()
        if _infra:
            _infra.notify_stage_start("production")
        check_infra_pause()

        self.state["pipeline_phase"] = "production"

    def _parse_state(self) -> None:
        """Parse all required state information."""
        from tools.otio_tools import get_narration_durations_by_scene

        # Parse concepts
        self.concepts = self.state_parser.parse_concepts()
        self.visual_style_str, self.visual_style_avoid = (
            self.state_parser.parse_visual_style()
        )

        # Generate fallback concepts if needed
        if not self.concepts:
            scenes = self.state_parser.parse_scenes()
            if scenes:
                self.concepts = self.state_parser.generate_fallback_concepts(scenes)

        # Scan for existing clips
        self.existing_clips = self.clip_scanner.scan()

        # Get feedback store
        from agui import get_feedback_store

        self._feedback_store = get_feedback_store()

        # Get narration durations
        self._narr_durations = get_narration_durations_by_scene(
            tool_context=_MockToolContext(self.state),
        )

    def _handle_no_concepts(self) -> str:
        """Handle case when no visual concepts are found.

        Returns:
            Error message string.
        """
        from infra_agent import get_infra_agent

        _infra = get_infra_agent()
        if _infra:
            _infra.notify_stage_complete("production")
        return "ERROR: No visual concepts found"

    async def _generate_verified_plan(self) -> "ProductionPlan":
        """Generate and verify production plan.

        Returns:
            ProductionPlan instance.
        """
        from orchestrator.production_models import ProductionPlan

        # For now, use fallback plan (LLM planning can be added later)
        plan_builder = PlanBuilder(
            self.config, self.worker_manager, self.existing_clips
        )
        return plan_builder.create_fallback_plan(self.concepts)

    async def _execute_plan(self, plan: "ProductionPlan") -> "ProductionPlanResult":
        """Execute the production plan.

        Args:
            plan: The production plan to execute.

        Returns:
            ProductionPlanResult with execution results.
        """
        from orchestrator.clip_helpers import (
            process_results_to_otio,
            run_gatekeeper_and_upload,
        )
        from orchestrator.production_models import BatchResult, ProductionPlanResult

        all_results: list[dict] = []
        batch_results: list[BatchResult] = []
        completed_clip_ids: set[str] = set()

        executor = BatchExecutor(
            self.config.video_dir,
            ", ".join(self.visual_style_avoid) if self.visual_style_avoid else "",
            self.visual_style_str,
            self._feedback_store,
            self.worker_manager.num_workers,
        )

        for batch_idx, batch in enumerate(plan.batches):
            batch_result, gen_results = executor.execute_batch(batch, batch_idx)
            batch_results.append(batch_result)
            all_results.extend(gen_results)

            for cr in batch_result.clip_results:
                if cr.status in ("generated", "skipped"):
                    completed_clip_ids.add(cr.clip_id)

        # Process results through OTIO
        total_clips, skipped_clips, errors, deferred_gk_clips = (
            process_results_to_otio(
                results=all_results,
                state=self.state,
                narr_durations=self._narr_durations,
            )
        )

        # Run gatekeeper and upload
        run_gatekeeper_and_upload(self.state, deferred_gk_clips)

        return ProductionPlanResult(
            plan=plan,
            batch_results=batch_results,
            total_clips=total_clips,
            failed_clips=sum(len(br.failed_clips) for br in batch_results),
            skipped_clips=skipped_clips,
            replan_count=0,
        )

    def _post_process(self, result: "ProductionPlanResult") -> str:
        """Run post-production steps.

        Args:
            result: The production plan result.

        Returns:
            Summary string.
        """
        from orchestrator.clip_helpers import run_post_production

        return run_post_production(
            callback_context=self.callback_context,
            num_workers=self.worker_manager.num_workers,
            total_clips=result.total_clips,
            skipped_clips=result.skipped_clips,
            errors=[],
        )


# =============================================================================
# Exceptions
# =============================================================================


class _StageSkipped(Exception):
    """Raised when a stage is skipped due to B2 checkpoint."""

    pass


class _MockToolContext:
    """Mock tool context for state access."""

    def __init__(self, state: dict[str, Any]) -> None:
        self.state = state
