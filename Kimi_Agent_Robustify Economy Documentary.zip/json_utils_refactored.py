"""JSON extraction utilities with improved code quality.

This module provides robust JSON extraction from LLM responses,
handling common errors like markdown fences, preamble text, and
malformed JSON structures.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


# =============================================================================
# JSON Repair Functions
# =============================================================================


def _repair_json_text(text: str) -> str | None:
    """Attempt to repair common LLM JSON generation errors.

    Common error: LLM drops the opening ``{`` and ``"voice": "V3",`` for a
    voice block inside a ``voices`` array, leaving a bare ``"text":`` key
    after a ``},`` that closed the previous object.

    Args:
        text: The potentially malformed JSON text.

    Returns:
        Repaired JSON text if successful, None otherwise.
    """
    # Fix: bare key-value after closing brace in an array context
    repaired = re.sub(
        r'(},\s*\n)(\s*)("(?:text|tone|voice)"\s*:)',
        r'\1\2{\n\2  \3',
        text,
    )

    if repaired == text:
        return None

    # Try parsing the repaired text directly first
    try:
        json.loads(repaired)
        return repaired
    except json.JSONDecodeError:
        pass

    # More aggressive repair with closing braces
    return _insert_closing_braces(repaired, text)


def _insert_closing_braces(repaired: str, original: str) -> str | None:
    """Insert closing braces for repaired JSON.

    Args:
        repaired: The partially repaired JSON text.
        original: The original text for reference.

    Returns:
        Fully repaired JSON text if successful, None otherwise.
    """
    repair_lines = _find_repair_lines(repaired, original)
    lines = repaired.split("\n")
    fixed_lines = []
    seeking_close = False

    for i, line in enumerate(lines):
        stripped = line.strip()
        if i in repair_lines:
            seeking_close = True
            fixed_lines.append(line)
            continue

        # Insert closing } before a scope-closing line
        if seeking_close and stripped and stripped[0] in ("}", "]"):
            indent = len(line) - len(line.lstrip())
            fixed_lines.append(" " * (indent + 2) + "}")
            seeking_close = False
        fixed_lines.append(line)

    result = "\n".join(fixed_lines)
    try:
        json.loads(result)
        return result
    except json.JSONDecodeError:
        return None


def _find_repair_lines(repaired: str, original: str) -> set[int]:
    """Find line numbers where repairs were made.

    Args:
        repaired: The repaired text.
        original: The original text.

    Returns:
        Set of line numbers where opening braces were inserted.
    """
    repair_lines: set[int] = set()
    orig_lines = original.split("\n")
    offset = 0

    for i, line in enumerate(repaired.split("\n")):
        if line.strip() == "{":
            orig_idx = i - offset
            if orig_idx < 0 or orig_idx >= len(orig_lines):
                repair_lines.add(i)
                offset += 1
            elif orig_lines[orig_idx].strip() != "{":
                repair_lines.add(i)
                offset += 1

    return repair_lines


def _repair_unescaped_quotes(text: str) -> str | None:
    """Fix unescaped double-quotes inside JSON string values.

    LLMs sometimes produce JSON with unescaped inner quotes.

    Args:
        text: The potentially malformed JSON text.

    Returns:
        Repaired JSON text if changes were made, None otherwise.
    """
    result_lines = []
    changed = False

    for line in text.split("\n"):
        repaired_line = _repair_line_quotes(line)
        if repaired_line is not None:
            result_lines.append(repaired_line)
            changed = True
        else:
            result_lines.append(line)

    return "\n".join(result_lines) if changed else None


def _repair_line_quotes(line: str) -> str | None:
    """Repair unescaped quotes in a single line.

    Args:
        line: The line to repair.

    Returns:
        Repaired line if changes were made, None otherwise.
    """
    # Match:  <indent>"<key>" : "<value>",?
    pattern = r'^(\s*"\w+"\s*:\s*)"(.*)"(,?)\s*$'
    match = re.match(pattern, line)

    if not match:
        return None

    value = match.group(2)
    if '"' not in value:
        return None

    # Fix unescaped quotes
    fixed = (
        value.replace('\\"', "\x00")
        .replace('"', '\\"')
        .replace("\x00", '\\"')
    )
    return f'{match.group(1)}"{fixed}"{match.group(3)}'


# =============================================================================
# JSON Extraction Functions
# =============================================================================


def extract_json_array(text: str) -> list | None:
    """Extract a JSON array from text with various formats.

    Handles:
    - Pure JSON arrays
    - JSON wrapped in ```json ... ``` fences
    - JSON preceded by preamble text
    - Multiple JSON blocks (returns first valid array)
    - Common LLM JSON errors via repair

    Args:
        text: The text to extract JSON array from.

    Returns:
        Extracted JSON array or None if extraction fails.
    """
    if not text or not text.strip():
        return None

    text = text.strip()

    # Strategy 1: Try direct parsing
    if result := _try_parse_json_array(text):
        return result

    # Strategy 2: Extract from markdown code fences
    if result := _extract_from_fences(text, _try_parse_json_array):
        return result

    # Strategy 3: Find first [ ... ] block
    if result := _extract_bracket_block(text):
        return result

    return None


def extract_json_object(text: str) -> dict | None:
    """Extract a JSON object from text with various formats.

    Args:
        text: The text to extract JSON object from.

    Returns:
        Extracted JSON object or None if extraction fails.
    """
    if not text or not text.strip():
        return None

    text = text.strip()

    # Strategy 1: Try direct parsing
    if result := _try_parse_json_object(text):
        return result

    # Strategy 2: Extract from markdown code fences
    if result := _extract_from_fences(text, _try_parse_json_object):
        return result

    # Strategy 3: Find first { ... } block
    if result := _extract_brace_block(text):
        return result

    return None


# =============================================================================
# Internal Helper Functions
# =============================================================================


def _try_parse_json_array(text: str) -> list | None:
    """Try to parse text as a JSON array.

    Args:
        text: The text to parse.

    Returns:
        Parsed list or None if parsing fails.
    """
    try:
        result = json.loads(text)
        return result if isinstance(result, list) else None
    except (json.JSONDecodeError, ValueError):
        return None


def _try_parse_json_object(text: str) -> dict | None:
    """Try to parse text as a JSON object.

    Args:
        text: The text to parse.

    Returns:
        Parsed dict or None if parsing fails.
    """
    try:
        result = json.loads(text)
        return result if isinstance(result, dict) else None
    except (json.JSONDecodeError, ValueError):
        return None


def _extract_from_fences(
    text: str, parser: callable
) -> list | dict | None:
    """Extract JSON from markdown code fences.

    Args:
        text: The text containing markdown fences.
        parser: Function to parse the extracted content.

    Returns:
        Parsed JSON or None if extraction fails.
    """
    fence_pattern = re.compile(r"```(?:json)?\s*\n?(.*?)```", re.DOTALL)

    for match in fence_pattern.finditer(text):
        inner = match.group(1).strip()

        # Try direct parsing
        if result := parser(inner):
            return result

        # Try extracting from dict with known keys
        if parser == _try_parse_json_array:
            if obj_result := _extract_from_object_keys(inner):
                return obj_result

        # Try repair for arrays
        if parser == _try_parse_json_array:
            if repaired := _repair_json_text(inner):
                if result := parser(repaired):
                    logger.info("Extracted JSON array after repair")
                    return result

        # Try quote repair for objects
        if parser == _try_parse_json_object:
            if repaired := _repair_unescaped_quotes(inner):
                if result := parser(repaired):
                    logger.info("Extracted JSON object after quote repair")
                    return result

    return None


def _extract_from_object_keys(text: str) -> list | None:
    """Extract array from object with known keys.

    Args:
        text: The text to parse as object.

    Returns:
        Extracted array or None.
    """
    try:
        obj = json.loads(text)
        if not isinstance(obj, dict):
            return None

        # Prefer known keys first
        for key in ("scenes", "visual_concepts", "content_analysis"):
            if key in obj and isinstance(obj[key], list):
                return obj[key]

        # Return first list value
        for value in obj.values():
            if isinstance(value, list):
                return value
    except (json.JSONDecodeError, ValueError):
        pass

    return None


def _extract_bracket_block(text: str) -> list | None:
    """Extract JSON array from first [ ... ] block.

    Args:
        text: The text to search for bracket blocks.

    Returns:
        Extracted array or None.
    """
    bracket_depth = 0
    start_idx: int | None = None

    for i, char in enumerate(text):
        if char == "[" and bracket_depth == 0:
            start_idx = i
            bracket_depth = 1
        elif char == "[":
            bracket_depth += 1
        elif char == "]":
            bracket_depth -= 1
            if bracket_depth == 0 and start_idx is not None:
                candidate = text[start_idx : i + 1]
                if result := _try_parse_with_repair(candidate, _try_parse_json_array):
                    return result
                start_idx = None

    return None


def _extract_brace_block(text: str) -> dict | None:
    """Extract JSON object from first { ... } block.

    Args:
        text: The text to search for brace blocks.

    Returns:
        Extracted object or None.
    """
    brace_depth = 0
    start_idx: int | None = None

    for i, char in enumerate(text):
        if char == "{" and brace_depth == 0:
            start_idx = i
            brace_depth = 1
        elif char == "{":
            brace_depth += 1
        elif char == "}":
            brace_depth -= 1
            if brace_depth == 0 and start_idx is not None:
                candidate = text[start_idx : i + 1]
                if result := _try_parse_with_repair(candidate, _try_parse_json_object):
                    return result
                start_idx = None

    return None


def _try_parse_with_repair(
    text: str, parser: callable
) -> list | dict | None:
    """Try to parse text, with quote repair fallback.

    Args:
        text: The text to parse.
        parser: Parsing function to use.

    Returns:
        Parsed result or None.
    """
    # Try direct parsing
    if result := parser(text):
        return result

    # Try quote repair for objects
    if parser == _try_parse_json_object:
        if repaired := _repair_unescaped_quotes(text):
            if result := parser(repaired):
                logger.info(
                    "Extracted JSON object after quote repair (strategy 3)"
                )
                return result

    return None


# =============================================================================
# Legacy Compatibility
# =============================================================================

# Keep original function names for backward compatibility
def extract_json_array_legacy(text: str) -> list | None:
    """Legacy wrapper for extract_json_array."""
    return extract_json_array(text)


def extract_json_object_legacy(text: str) -> dict | None:
    """Legacy wrapper for extract_json_object."""
    return extract_json_object(text)
