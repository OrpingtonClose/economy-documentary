"""
Integration tests for the FastAPI server.

Tests cover:
- Health check endpoint
- Middleware functionality
- Error handling
- Request/response validation

Note: These tests mock external dependencies to avoid requiring
actual services to be running.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, AsyncGenerator
from unittest.mock import AsyncMock, MagicMock, Mock, patch

import pytest

# Add server directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "server"))


# -----------------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def mock_adk_agent() -> Generator[MagicMock, None, None]:
    """Mock ADKAgent for testing."""
    with patch("server.ADKAgent") as mock:
        mock_agent = MagicMock()
        mock.from_app.return_value = mock_agent
        yield mock_agent


@pytest.fixture
def mock_app() -> Generator[MagicMock, None, None]:
    """Mock App for testing."""
    with patch("server.App") as mock:
        mock_app = MagicMock()
        mock.return_value = mock_app
        yield mock_app


@pytest.fixture
def mock_fastapi() -> Generator[MagicMock, None, None]:
    """Mock FastAPI for testing."""
    with patch("server.FastAPI") as mock:
        mock_app = MagicMock()
        mock.return_value = mock_app
        yield mock_app


@pytest.fixture
def mock_middleware() -> Generator[None, None, None]:
    """Mock middleware components."""
    with patch("server.RequestLoggingMiddleware"):
        with patch("server.AGUIRunCollectorMiddleware"):
            yield


# -----------------------------------------------------------------------------
# Health Check Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestHealthEndpoint:
    """Tests for the /health endpoint."""

    @pytest.mark.asyncio
    async def test_health_check_returns_ok(self) -> None:
        """Test that health check returns status ok."""
        # This test would normally use httpx.AsyncClient
        # For now, we test the function directly
        from server import health
        
        with patch("server.ADK_MODEL_NAME", "gemini-2.5-flash"):
            result = await health()
        
        assert result["status"] == "ok"
        assert result["version"] == "0.1.0"
        assert "model" in result

    @pytest.mark.asyncio
    async def test_health_check_includes_model(self) -> None:
        """Test that health check includes model name."""
        from server import health
        
        with patch("server.ADK_MODEL_NAME", "test-model"):
            result = await health()
        
        assert result["model"] == "test-model"


# -----------------------------------------------------------------------------
# Environment Validation Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestEnvironmentValidation:
    """Tests for environment variable validation."""

    @patch.dict("os.environ", {"ADK_MODEL": "gemini-2.5-flash"})
    @patch("server.ADK_MODEL_NAME", "gemini-2.5-flash")
    def test_validate_env_with_model(self) -> None:
        """Test validation with model configured."""
        from server import _validate_env
        
        # Should not raise
        _validate_env()

    @patch.dict("os.environ", {}, clear=True)
    @patch("server.ADK_MODEL_NAME", "")
    def test_validate_env_missing_model(self) -> None:
        """Test validation fails without model."""
        from server import _validate_env
        
        with pytest.raises(ValueError) as exc_info:
            _validate_env()
        
        assert "ADK_MODEL" in str(exc_info.value)

    @patch("server.ADK_MODEL_NAME", "gemini-2.5-flash")
    def test_validate_env_no_api_keys(self) -> None:
        """Test validation warns when no API keys configured."""
        from server import _validate_env, logger
        
        with patch.object(logger, "warning") as mock_warning:
            _validate_env()
            mock_warning.assert_called_once()
            assert "No API keys configured" in str(mock_warning.call_args)

    @patch.dict("os.environ", {"GOOGLE_API_KEY": "test_key"})
    @patch("server.ADK_MODEL_NAME", "gemini-2.5-flash")
    def test_validate_env_with_google_key(self) -> None:
        """Test validation with Google API key."""
        from server import _validate_env, logger
        
        with patch.object(logger, "info") as mock_info:
            _validate_env()
            # Check that Gemini=yes is logged
            log_calls = [call for call in mock_info.call_args_list if "Gemini=yes" in str(call)]
            assert len(log_calls) > 0


# -----------------------------------------------------------------------------
# Middleware Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestRequestLoggingMiddleware:
    """Tests for the RequestLoggingMiddleware."""

    @pytest.mark.asyncio
    async def test_middleware_logs_request(self) -> None:
        """Test that middleware logs requests."""
        from server import RequestLoggingMiddleware, logger
        
        mock_request = MagicMock()
        mock_request.method = "GET"
        mock_request.url.path = "/test"
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        
        mock_call_next = AsyncMock(return_value=mock_response)
        
        middleware = RequestLoggingMiddleware(app=MagicMock())
        
        with patch.object(logger, "info") as mock_info:
            await middleware.dispatch(mock_request, mock_call_next)
            
            # Check that request was logged
            log_calls = [call for call in mock_info.call_args_list if "GET /test" in str(call)]
            assert len(log_calls) > 0

    @pytest.mark.asyncio
    async def test_middleware_logs_duration(self) -> None:
        """Test that middleware logs request duration."""
        from server import RequestLoggingMiddleware, logger
        
        mock_request = MagicMock()
        mock_request.method = "POST"
        mock_request.url.path = "/api/test"
        
        mock_response = MagicMock()
        mock_response.status_code = 201
        
        mock_call_next = AsyncMock(return_value=mock_response)
        
        middleware = RequestLoggingMiddleware(app=MagicMock())
        
        with patch.object(logger, "info") as mock_info:
            await middleware.dispatch(mock_request, mock_call_next)
            
            # Check that duration is logged
            log_calls = [call for call in mock_info.call_args_list if "POST /api/test" in str(call)]
            assert len(log_calls) > 0


@pytest.mark.integration
class TestAGUIRunCollectorMiddleware:
    """Tests for the AGUIRunCollectorMiddleware."""

    @pytest.mark.asyncio
    async def test_middleware_skips_non_post_requests(self) -> None:
        """Test that middleware skips non-POST requests."""
        from server import AGUIRunCollectorMiddleware
        
        mock_request = MagicMock()
        mock_request.url.path = "/"
        mock_request.method = "GET"
        
        mock_response = MagicMock()
        mock_call_next = AsyncMock(return_value=mock_response)
        
        middleware = AGUIRunCollectorMiddleware(app=MagicMock())
        
        result = await middleware.dispatch(mock_request, mock_call_next)
        
        assert result == mock_response
        # Should call next directly without creating collector
        mock_call_next.assert_called_once()

    @pytest.mark.asyncio
    async def test_middleware_skips_non_root_path(self) -> None:
        """Test that middleware skips non-root paths."""
        from server import AGUIRunCollectorMiddleware
        
        mock_request = MagicMock()
        mock_request.url.path = "/health"
        mock_request.method = "POST"
        
        mock_response = MagicMock()
        mock_call_next = AsyncMock(return_value=mock_response)
        
        middleware = AGUIRunCollectorMiddleware(app=MagicMock())
        
        result = await middleware.dispatch(mock_request, mock_call_next)
        
        assert result == mock_response
        mock_call_next.assert_called_once()


# -----------------------------------------------------------------------------
# Lifespan Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestLifespan:
    """Tests for the application lifespan."""

    @pytest.mark.asyncio
    async def test_lifespan_setup(self) -> None:
        """Test lifespan setup phase."""
        from server import lifespan, logger
        
        mock_app = MagicMock()
        
        with patch("server._validate_env") as mock_validate:
            with patch("server.setup_otel") as mock_setup_otel:
                with patch("server.init_db") as mock_init_db:
                    with patch.object(logger, "info") as mock_info:
                        async with lifespan(mock_app):
                            pass
                        
                        mock_validate.assert_called_once()
                        mock_setup_otel.assert_called_once()
                        mock_init_db.assert_called_once()

    @pytest.mark.asyncio
    async def test_lifespan_logs_startup_shutdown(self) -> None:
        """Test that lifespan logs startup and shutdown."""
        from server import lifespan, logger
        
        mock_app = MagicMock()
        
        with patch("server._validate_env"):
            with patch("server.setup_otel"):
                with patch("server.init_db"):
                    with patch.object(logger, "info") as mock_info:
                        async with lifespan(mock_app):
                            pass
                        
                        # Check startup log
                        startup_calls = [call for call in mock_info.call_args_list 
                                       if "started" in str(call)]
                        assert len(startup_calls) > 0
                        
                        # Check shutdown log
                        shutdown_calls = [call for call in mock_info.call_args_list 
                                        if "shutting down" in str(call)]
                        assert len(shutdown_calls) > 0


# -----------------------------------------------------------------------------
# CORS Configuration Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestCORSConfiguration:
    """Tests for CORS middleware configuration."""

    def test_cors_allows_all_origins(self) -> None:
        """Test that CORS allows all origins."""
        from server import app
        
        # Check that CORS middleware was added
        # Note: This is a simplified check - in real tests we'd inspect the app
        assert app is not None


# -----------------------------------------------------------------------------
# Router Registration Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestRouterRegistration:
    """Tests for router registration."""

    def test_dashboard_router_registered(self) -> None:
        """Test that dashboard router is registered."""
        from server import app
        
        # The app should have routers included
        # In a real test, we'd check app.routes
        assert app is not None

    def test_agui_router_registered(self) -> None:
        """Test that AG-UI router is registered."""
        from server import app
        
        # The app should have routers included
        assert app is not None


# -----------------------------------------------------------------------------
# Error Handling Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestErrorHandling:
    """Tests for error handling."""

    @pytest.mark.asyncio
    async def test_middleware_handles_exception(self) -> None:
        """Test that middleware handles exceptions gracefully."""
        from server import AGUIRunCollectorMiddleware
        
        mock_request = MagicMock()
        mock_request.url.path = "/"
        mock_request.method = "POST"
        
        mock_call_next = AsyncMock(side_effect=Exception("Test error"))
        
        middleware = AGUIRunCollectorMiddleware(app=MagicMock())
        
        with patch("server.finalize_run"):
            with patch("server.remove_collector"):
                with pytest.raises(Exception) as exc_info:
                    await middleware.dispatch(mock_request, mock_call_next)
                
                assert "Test error" in str(exc_info.value)


# -----------------------------------------------------------------------------
# Type Import Tests
# -----------------------------------------------------------------------------

@pytest.mark.integration
class TestTypeImports:
    """Tests that type hints are properly imported."""

    def test_async_iterator_imported(self) -> None:
        """Test that AsyncIterator is imported for type hints."""
        from server import AsyncIterator
        assert AsyncIterator is not None

    def test_callable_imported(self) -> None:
        """Test that Callable is imported for type hints."""
        from server import Callable
        assert Callable is not None

    def test_optional_imported(self) -> None:
        """Test that Optional is imported for type hints."""
        from server import Optional
        assert Optional is not None

    def test_union_imported(self) -> None:
        """Test that Union is imported for type hints."""
        from server import Union
        assert Union is not None
