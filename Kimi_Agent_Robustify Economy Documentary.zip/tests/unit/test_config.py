"""
Unit tests for the config module.

Tests cover:
- Configuration value loading from environment
- Path configuration
- API key configuration
- Feature flags
- Helper functions
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))


# Need to reload config module for each test to pick up env changes
@pytest.fixture
def fresh_config() -> Any:
    """Import config module fresh for each test."""
    # Remove config from cache if present
    if "config" in sys.modules:
        del sys.modules["config"]
    
    import config
    return config


# -----------------------------------------------------------------------------
# Configuration Value Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestConfigValues:
    """Tests for configuration value loading."""

    @patch.dict(os.environ, {"DOCUMENTARY_TOPIC": "Test Topic"})
    def test_documentary_topic(self, fresh_config: Any) -> None:
        """Test DOCUMENTARY_TOPIC configuration."""
        assert fresh_config.DOCUMENTARY_TOPIC == "Test Topic"

    def test_documentary_topic_default(self, fresh_config: Any) -> None:
        """Test DOCUMENTARY_TOPIC default value."""
        with patch.dict(os.environ, {}, clear=True):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            assert config.DOCUMENTARY_TOPIC == ""

    @patch.dict(os.environ, {"DATA_DIR": "/custom/data"})
    def test_data_dir_override(self, fresh_config: Any) -> None:
        """Test DATA_DIR override."""
        assert str(fresh_config.DATA_DIR) == "/custom/data"

    def test_data_dir_default(self, fresh_config: Any) -> None:
        """Test DATA_DIR default value."""
        assert "/tmp/documentary-pipeline" in str(fresh_config.DATA_DIR)

    @patch.dict(os.environ, {"ADK_MODEL": "gemini-pro"})
    def test_adk_model_override(self, fresh_config: Any) -> None:
        """Test ADK_MODEL override."""
        assert fresh_config.ADK_MODEL == "gemini-pro"

    def test_adk_model_default(self, fresh_config: Any) -> None:
        """Test ADK_MODEL default value."""
        assert fresh_config.ADK_MODEL == "gemini-2.5-flash"


# -----------------------------------------------------------------------------
# Path Configuration Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestPathConfiguration:
    """Tests for path configuration."""

    def test_project_root_is_path(self, fresh_config: Any) -> None:
        """Test that PROJECT_ROOT is a Path object."""
        assert isinstance(fresh_config.PROJECT_ROOT, Path)

    def test_data_dir_is_path(self, fresh_config: Any) -> None:
        """Test that DATA_DIR is a Path object."""
        assert isinstance(fresh_config.DATA_DIR, Path)

    def test_corpus_dir_is_subpath(self, fresh_config: Any) -> None:
        """Test that CORPUS_DIR is a subdirectory of DATA_DIR."""
        assert "corpus" in str(fresh_config.CORPUS_DIR)
        assert fresh_config.DATA_DIR in fresh_config.CORPUS_DIR.parents

    def test_transcript_dir_is_subpath(self, fresh_config: Any) -> None:
        """Test that TRANSCRIPT_DIR is a subdirectory of CORPUS_DIR."""
        assert "transcripts" in str(fresh_config.TRANSCRIPT_DIR)
        assert fresh_config.CORPUS_DIR in fresh_config.TRANSCRIPT_DIR.parents

    def test_enrichment_dir_is_subpath(self, fresh_config: Any) -> None:
        """Test that ENRICHMENT_DIR is a subdirectory of DATA_DIR."""
        assert "enrichment" in str(fresh_config.ENRICHMENT_DIR)

    def test_timeline_dir_is_path(self, fresh_config: Any) -> None:
        """Test that TIMELINE_DIR is a Path object."""
        assert isinstance(fresh_config.TIMELINE_DIR, Path)

    def test_tts_output_dir_is_path(self, fresh_config: Any) -> None:
        """Test that TTS_OUTPUT_DIR is a Path object."""
        assert isinstance(fresh_config.TTS_OUTPUT_DIR, Path)

    def test_video_output_dir_is_path(self, fresh_config: Any) -> None:
        """Test that VIDEO_OUTPUT_DIR is a Path object."""
        assert isinstance(fresh_config.VIDEO_OUTPUT_DIR, Path)


# -----------------------------------------------------------------------------
# API Key Configuration Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestApiKeyConfiguration:
    """Tests for API key configuration."""

    @patch.dict(os.environ, {"GEMINI_API_KEY": "test_gemini_key"})
    def test_gemini_api_key(self, fresh_config: Any) -> None:
        """Test GEMINI_API_KEY configuration."""
        assert fresh_config.GEMINI_API_KEY == "test_gemini_key"

    @patch.dict(os.environ, {"OPENAI_API_KEY": "test_openai_key"})
    def test_openai_api_key(self, fresh_config: Any) -> None:
        """Test OPENAI_API_KEY configuration."""
        assert fresh_config.OPENAI_API_KEY == "test_openai_key"

    @patch.dict(os.environ, {"PERPLEXITY_API_KEY": "test_perplexity_key"})
    def test_perplexity_api_key(self, fresh_config: Any) -> None:
        """Test PERPLEXITY_API_KEY configuration."""
        assert fresh_config.PERPLEXITY_API_KEY == "test_perplexity_key"

    @patch.dict(os.environ, {"FRED_API_KEY": "test_fred_key"})
    def test_fred_api_key(self, fresh_config: Any) -> None:
        """Test FRED_API_KEY configuration."""
        assert fresh_config.FRED_API_KEY == "test_fred_key"

    def test_api_keys_default_empty(self, fresh_config: Any) -> None:
        """Test that API keys default to empty string."""
        with patch.dict(os.environ, {}, clear=True):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            assert config.GEMINI_API_KEY == ""
            assert config.OPENAI_API_KEY == ""


# -----------------------------------------------------------------------------
# Concurrency Configuration Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestConcurrencyConfiguration:
    """Tests for concurrency configuration."""

    @patch.dict(os.environ, {"MAX_CONCURRENT_LLM": "8"})
    def test_max_concurrent_llm_override(self, fresh_config: Any) -> None:
        """Test MAX_CONCURRENT_LLM override."""
        assert fresh_config.MAX_CONCURRENT_LLM == 8

    def test_max_concurrent_llm_default(self, fresh_config: Any) -> None:
        """Test MAX_CONCURRENT_LLM default value."""
        assert fresh_config.MAX_CONCURRENT_LLM == 4

    @patch.dict(os.environ, {"GPU_CONCURRENCY": "4"})
    def test_gpu_concurrency_override(self, fresh_config: Any) -> None:
        """Test GPU_CONCURRENCY override."""
        assert fresh_config.GPU_CONCURRENCY == 4

    def test_gpu_concurrency_default(self, fresh_config: Any) -> None:
        """Test GPU_CONCURRENCY default value."""
        assert fresh_config.GPU_CONCURRENCY == 2

    @patch.dict(os.environ, {"TTS_CONCURRENCY": "5"})
    def test_tts_concurrency_override(self, fresh_config: Any) -> None:
        """Test TTS_CONCURRENCY override."""
        assert fresh_config.TTS_CONCURRENCY == 5

    def test_tts_concurrency_default(self, fresh_config: Any) -> None:
        """Test TTS_CONCURRENCY default value."""
        assert fresh_config.TTS_CONCURRENCY == 3


# -----------------------------------------------------------------------------
# Feature Flag Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestFeatureFlags:
    """Tests for feature flag configuration."""

    @pytest.mark.parametrize("value", ["true", "True", "TRUE", "1"])
    def test_test_mode_enabled(self, value: str, fresh_config: Any) -> None:
        """Test DOCUMENTARY_TEST_MODE enabled values."""
        with patch.dict(os.environ, {"DOCUMENTARY_TEST_MODE": value}):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            assert config.DOCUMENTARY_TEST_MODE is True

    @pytest.mark.parametrize("value", ["false", "False", "FALSE", "0", ""])
    def test_test_mode_disabled(self, value: str, fresh_config: Any) -> None:
        """Test DOCUMENTARY_TEST_MODE disabled values."""
        with patch.dict(os.environ, {"DOCUMENTARY_TEST_MODE": value}):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            assert config.DOCUMENTARY_TEST_MODE is False

    @pytest.mark.parametrize("value", ["true", "1"])
    def test_adk_debug_enabled(self, value: str, fresh_config: Any) -> None:
        """Test ADK_DEBUG enabled values."""
        with patch.dict(os.environ, {"ADK_DEBUG": value}):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            assert config.ADK_DEBUG is True

    @pytest.mark.parametrize("value", ["false", "0", ""])
    def test_phoenix_enabled(self, value: str, fresh_config: Any) -> None:
        """Test PHOENIX_ENABLED values."""
        with patch.dict(os.environ, {"PHOENIX_ENABLED": value}):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            assert config.PHOENIX_ENABLED is (value.lower() in ("true", "1"))


# -----------------------------------------------------------------------------
# Helper Function Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestHelperFunctions:
    """Tests for config helper functions."""

    def test_read_key_txt_extension(self, fresh_config: Any) -> None:
        """Test _read_key with .txt extension."""
        with patch.dict(os.environ, {"DEEPSEEK_API": "test_key"}):
            result = fresh_config._read_key("deepseek_api.txt")
            assert result == "test_key"

    def test_read_key_json_extension(self, fresh_config: Any) -> None:
        """Test _read_key with .json extension."""
        with patch.dict(os.environ, {"EXA_API_KEY": "test_key"}):
            result = fresh_config._read_key("exa_api_key.json")
            assert result == "test_key"

    def test_read_key_no_extension(self, fresh_config: Any) -> None:
        """Test _read_key without extension."""
        with patch.dict(os.environ, {"MY_API": "test_key"}):
            result = fresh_config._read_key("my_api")
            assert result == "test_key"

    def test_read_key_missing(self, fresh_config: Any) -> None:
        """Test _read_key returns empty for missing key."""
        with patch.dict(os.environ, {}, clear=True):
            result = fresh_config._read_key("nonexistent_api.txt")
            assert result == ""

    def test_read_key_uppercase_conversion(self, fresh_config: Any) -> None:
        """Test _read_key converts filename to uppercase env var."""
        with patch.dict(os.environ, {"LOWERCASE_KEY": "test_value"}):
            result = fresh_config._read_key("lowercase_key.txt")
            assert result == "test_value"


# -----------------------------------------------------------------------------
# Config Summary Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestConfigSummary:
    """Tests for get_config_summary function."""

    def test_summary_returns_dict(self, fresh_config: Any) -> None:
        """Test that get_config_summary returns a dictionary."""
        summary = fresh_config.get_config_summary()
        assert isinstance(summary, dict)

    def test_summary_contains_key_fields(self, fresh_config: Any) -> None:
        """Test that summary contains expected fields."""
        summary = fresh_config.get_config_summary()
        assert "documentary_topic" in summary
        assert "data_dir" in summary
        assert "adk_model" in summary
        assert "max_concurrent_llm" in summary
        assert "test_mode" in summary

    def test_summary_masks_api_keys(self, fresh_config: Any) -> None:
        """Test that API keys are masked in summary."""
        with patch.dict(os.environ, {
            "GEMINI_API_KEY": "secret_key",
            "OPENAI_API_KEY": "another_secret",
        }):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            summary = config.get_config_summary()
            assert summary["has_gemini_key"] is True
            assert summary["has_openai_key"] is True
            # Actual keys should not be in summary
            assert "secret_key" not in str(summary)

    def test_summary_handles_missing_topic(self, fresh_config: Any) -> None:
        """Test summary handles missing topic gracefully."""
        with patch.dict(os.environ, {"DOCUMENTARY_TOPIC": ""}):
            if "config" in sys.modules:
                del sys.modules["config"]
            import config
            summary = config.get_config_summary()
            assert "(not set)" in summary["documentary_topic"]
