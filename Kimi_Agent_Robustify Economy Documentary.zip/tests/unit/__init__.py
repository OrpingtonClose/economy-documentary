"""
Unit tests for the economy-documentary project.
"""

from __future__ import annotations
