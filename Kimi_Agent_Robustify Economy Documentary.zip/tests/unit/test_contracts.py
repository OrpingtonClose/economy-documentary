"""
Unit tests for the contracts module.

Tests cover:
- ServiceRequirement dataclass
- StageContract dataclass
- ContractViolation exception
- Service health checking
- Precondition validation
- Postcondition validation
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, Mock, patch
from urllib.error import URLError

import pytest

# Add server directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "server"))

from contracts import (
    AUDIO_CONTRACT,
    ASSEMBLY_CONTRACT,
    PRODUCTION_CONTRACT,
    SCENARIO_CONTRACT,
    VISUAL_DIRECTION_CONTRACT,
    ContractViolation,
    ServiceRequirement,
    StageContract,
    _check_service_health,
    validate_postconditions,
    validate_preconditions,
)


# -----------------------------------------------------------------------------
# ServiceRequirement Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestServiceRequirement:
    """Tests for the ServiceRequirement dataclass."""

    def test_service_requirement_creation(self) -> None:
        """Test creating a ServiceRequirement instance."""
        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
            required=True,
        )
        assert req.name == "Test Worker"
        assert req.env_var == "TEST_WORKER_URL"
        assert req.capability == "test"
        assert req.required is True

    def test_service_requirement_defaults(self) -> None:
        """Test ServiceRequirement default values."""
        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
        )
        assert req.required is True

    def test_service_requirement_optional(self) -> None:
        """Test optional ServiceRequirement."""
        req = ServiceRequirement(
            name="Optional Worker",
            env_var="OPTIONAL_WORKER_URL",
            capability="optional",
            required=False,
        )
        assert req.required is False


# -----------------------------------------------------------------------------
# StageContract Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestStageContract:
    """Tests for the StageContract dataclass."""

    def test_stage_contract_creation(self) -> None:
        """Test creating a StageContract instance."""
        contract = StageContract(
            name="test_stage",
            required_services=[],
            required_state=["input1", "input2"],
            produced_state=["output1"],
            produced_artifacts=["*.mp4"],
        )
        assert contract.name == "test_stage"
        assert contract.required_state == ["input1", "input2"]
        assert contract.produced_state == ["output1"]
        assert contract.produced_artifacts == ["*.mp4"]

    def test_stage_contract_defaults(self) -> None:
        """Test StageContract default values."""
        contract = StageContract(name="test_stage")
        assert contract.required_services == []
        assert contract.required_state == []
        assert contract.produced_state == []
        assert contract.produced_artifacts == []


# -----------------------------------------------------------------------------
# ContractViolation Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestContractViolation:
    """Tests for the ContractViolation exception."""

    def test_exception_creation(self) -> None:
        """Test creating a ContractViolation exception."""
        exc = ContractViolation(
            stage="test_stage",
            message="Something went wrong",
        )
        assert exc.stage == "test_stage"
        assert exc.details == {}
        assert "test_stage" in str(exc)
        assert "Something went wrong" in str(exc)

    def test_exception_with_details(self) -> None:
        """Test ContractViolation with details."""
        exc = ContractViolation(
            stage="test_stage",
            message="Validation failed",
            details={"errors": ["error1", "error2"]},
        )
        assert exc.details == {"errors": ["error1", "error2"]}

    def test_exception_is_runtime_error(self) -> None:
        """Test that ContractViolation is a RuntimeError subclass."""
        exc = ContractViolation("stage", "message")
        assert isinstance(exc, RuntimeError)


# -----------------------------------------------------------------------------
# Predefined Contract Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestPredefinedContracts:
    """Tests for the predefined stage contracts."""

    def test_scenario_contract(self) -> None:
        """Test SCENARIO_CONTRACT configuration."""
        assert SCENARIO_CONTRACT.name == "scenario"
        assert SCENARIO_CONTRACT.required_services == []
        assert SCENARIO_CONTRACT.required_state == []
        assert SCENARIO_CONTRACT.produced_state == ["scenes"]

    def test_audio_contract(self) -> None:
        """Test AUDIO_CONTRACT configuration."""
        assert AUDIO_CONTRACT.name == "audio"
        assert len(AUDIO_CONTRACT.required_services) == 1
        assert AUDIO_CONTRACT.required_services[0].env_var == "TTS_WORKER_URL"
        assert AUDIO_CONTRACT.required_state == ["scenes"]
        assert AUDIO_CONTRACT.produced_state == ["whisperx_alignment"]

    def test_visual_direction_contract(self) -> None:
        """Test VISUAL_DIRECTION_CONTRACT configuration."""
        assert VISUAL_DIRECTION_CONTRACT.name == "visual_direction"
        assert VISUAL_DIRECTION_CONTRACT.required_services == []
        assert "scenes" in VISUAL_DIRECTION_CONTRACT.required_state
        assert "whisperx_alignment" in VISUAL_DIRECTION_CONTRACT.required_state

    def test_production_contract(self) -> None:
        """Test PRODUCTION_CONTRACT configuration."""
        assert PRODUCTION_CONTRACT.name == "production"
        assert len(PRODUCTION_CONTRACT.required_services) == 1
        assert PRODUCTION_CONTRACT.required_services[0].env_var == "VIDEO_WORKER_URLS"
        assert "video/*.mp4" in PRODUCTION_CONTRACT.produced_artifacts

    def test_assembly_contract(self) -> None:
        """Test ASSEMBLY_CONTRACT configuration."""
        assert ASSEMBLY_CONTRACT.name == "assembly"
        assert ASSEMBLY_CONTRACT.required_services == []
        assert "output/*.mp4" in ASSEMBLY_CONTRACT.produced_artifacts


# -----------------------------------------------------------------------------
# Service Health Check Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestCheckServiceHealth:
    """Tests for the _check_service_health function."""

    @patch.dict(os.environ, {"TEST_WORKER_URL": "http://localhost:8000"})
    @patch("urllib.request.urlopen")
    def test_healthy_service(self, mock_urlopen: Mock) -> None:
        """Test healthy service check."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "test_loaded": True,
            "worker_mode": "test"
        }).encode()
        mock_urlopen.return_value.__enter__.return_value = mock_response

        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is None

    @patch.dict(os.environ, {}, clear=True)
    def test_missing_env_var(self) -> None:
        """Test error when environment variable is missing."""
        req = ServiceRequirement(
            name="Test Worker",
            env_var="MISSING_WORKER_URL",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is not None
        assert "MISSING_WORKER_URL is not set" in result

    @patch.dict(os.environ, {"TEST_WORKER_URL": "http://localhost:8000"})
    @patch("urllib.request.urlopen")
    def test_unhealthy_status(self, mock_urlopen: Mock) -> None:
        """Test error when service reports unhealthy status."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "error",
        }).encode()
        mock_urlopen.return_value.__enter__.return_value = mock_response

        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is not None
        assert "unhealthy status" in result

    @patch.dict(os.environ, {"TEST_WORKER_URL": "http://localhost:8000"})
    @patch("urllib.request.urlopen")
    def test_capability_not_loaded(self, mock_urlopen: Mock) -> None:
        """Test error when capability is not loaded."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "test_loaded": False,
        }).encode()
        mock_urlopen.return_value.__enter__.return_value = mock_response

        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is not None
        assert "not loaded" in result

    @patch.dict(os.environ, {"TEST_WORKER_URL": "http://localhost:8000"})
    @patch("urllib.request.urlopen")
    def test_wrong_worker_mode(self, mock_urlopen: Mock) -> None:
        """Test error when worker mode doesn't match capability."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "test_loaded": True,
            "worker_mode": "wrong_mode"
        }).encode()
        mock_urlopen.return_value.__enter__.return_value = mock_response

        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is not None
        assert "worker_mode" in result

    @patch.dict(os.environ, {"TEST_WORKER_URL": "http://localhost:8000"})
    @patch("urllib.request.urlopen")
    def test_unreachable_service(self, mock_urlopen: Mock) -> None:
        """Test error when service is unreachable."""
        mock_urlopen.side_effect = URLError("Connection refused")

        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URL",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is not None
        assert "unreachable" in result

    @patch.dict(os.environ, {"TEST_WORKER_URLS": "http://localhost:8000,http://localhost:8001"})
    @patch("urllib.request.urlopen")
    def test_multiple_urls_one_healthy(self, mock_urlopen: Mock) -> None:
        """Test that one healthy URL is sufficient."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "test_loaded": True,
            "worker_mode": "test"
        }).encode()
        mock_urlopen.return_value.__enter__.return_value = mock_response

        req = ServiceRequirement(
            name="Test Worker",
            env_var="TEST_WORKER_URLS",
            capability="test",
        )
        result = _check_service_health(req)
        assert result is None


# -----------------------------------------------------------------------------
# Precondition Validation Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestValidatePreconditions:
    """Tests for the validate_preconditions function."""

    @patch("contracts._check_service_health")
    def test_valid_preconditions(self, mock_check: Mock) -> None:
        """Test validation with valid preconditions."""
        mock_check.return_value = None

        contract = StageContract(
            name="test_stage",
            required_services=[
                ServiceRequirement(
                    name="Test Worker",
                    env_var="TEST_URL",
                    capability="test",
                )
            ],
            required_state=["input_data"],
        )
        state = {"input_data": "valid data"}
        
        # Should not raise
        validate_preconditions(contract, state)

    @patch("contracts._check_service_health")
    def test_placeholder_state_value(self, mock_check: Mock) -> None:
        """Test validation fails with placeholder state value."""
        mock_check.return_value = None

        contract = StageContract(
            name="test_stage",
            required_state=["input_data"],
        )
        state = {"input_data": "(not yet generated)"}
        
        with pytest.raises(ContractViolation) as exc_info:
            validate_preconditions(contract, state)
        
        assert "placeholder" in str(exc_info.value).lower()

    @patch("contracts._check_service_health")
    def test_empty_state_value(self, mock_check: Mock) -> None:
        """Test validation fails with empty state value."""
        mock_check.return_value = None

        contract = StageContract(
            name="test_stage",
            required_state=["input_data"],
        )
        state = {"input_data": ""}
        
        with pytest.raises(ContractViolation) as exc_info:
            validate_preconditions(contract, state)
        
        assert "empty" in str(exc_info.value).lower()

    @patch.dict(os.environ, {"DOCUMENTARY_TEST_MODE": "true"})
    @patch("contracts._check_service_health")
    def test_test_mode_continues_on_error(self, mock_check: Mock) -> None:
        """Test that test mode logs warning but continues."""
        mock_check.return_value = None

        contract = StageContract(
            name="test_stage",
            required_state=["input_data"],
        )
        state = {"input_data": ""}
        
        # Should not raise in test mode
        validate_preconditions(contract, state)


# -----------------------------------------------------------------------------
# Postcondition Validation Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestValidatePostconditions:
    """Tests for the validate_postconditions function."""

    @patch("glob.glob")
    @patch("os.path.getsize")
    def test_valid_postconditions(self, mock_getsize: Mock, mock_glob: Mock) -> None:
        """Test validation with valid postconditions."""
        mock_glob.return_value = ["/tmp/test.mp4"]
        mock_getsize.return_value = 1000

        contract = StageContract(
            name="test_stage",
            produced_state=["output_data"],
            produced_artifacts=["*.mp4"],
        )
        state = {"output_data": "valid output"}
        
        # Should not raise
        validate_postconditions(contract, state)

    @patch("glob.glob")
    @patch("os.path.getsize")
    def test_missing_artifact(self, mock_getsize: Mock, mock_glob: Mock) -> None:
        """Test validation fails when artifact is missing."""
        mock_glob.return_value = []

        contract = StageContract(
            name="test_stage",
            produced_artifacts=["*.mp4"],
        )
        state = {}
        
        with pytest.raises(ContractViolation) as exc_info:
            validate_postconditions(contract, state)
        
        assert "none found" in str(exc_info.value).lower()

    @patch("glob.glob")
    @patch("os.path.getsize")
    def test_empty_artifact(self, mock_getsize: Mock, mock_glob: Mock) -> None:
        """Test validation fails when artifact is empty."""
        mock_glob.return_value = ["/tmp/empty.mp4"]
        mock_getsize.return_value = 0

        contract = StageContract(
            name="test_stage",
            produced_artifacts=["*.mp4"],
        )
        state = {}
        
        with pytest.raises(ContractViolation) as exc_info:
            validate_postconditions(contract, state)
        
        assert "empty files" in str(exc_info.value).lower()

    @patch("glob.glob")
    @patch("os.path.getsize")
    def test_placeholder_output(self, mock_getsize: Mock, mock_glob: Mock) -> None:
        """Test validation fails with placeholder output."""
        mock_glob.return_value = ["/tmp/test.mp4"]
        mock_getsize.return_value = 1000

        contract = StageContract(
            name="test_stage",
            produced_state=["output_data"],
        )
        state = {"output_data": "(not yet generated)"}
        
        with pytest.raises(ContractViolation) as exc_info:
            validate_postconditions(contract, state)


# -----------------------------------------------------------------------------
# Placeholder Values Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestPlaceholderValues:
    """Tests for placeholder value detection."""

    @pytest.mark.parametrize("value", [
        "",
        "[]",
        "{}",
        "(not yet analyzed)",
        "(not yet generated)",
        "(not yet evaluated)",
    ])
    def test_placeholder_values_detected(self, value: str) -> None:
        """Test that all placeholder values are detected."""
        from contracts import _PLACEHOLDER_VALUES
        assert value in _PLACEHOLDER_VALUES

    def test_non_placeholder_values_allowed(self) -> None:
        """Test that non-placeholder values are allowed."""
        from contracts import _PLACEHOLDER_VALUES
        assert "valid data" not in _PLACEHOLDER_VALUES
        assert "[1, 2, 3]" not in _PLACEHOLDER_VALUES
        assert '{"key": "value"}' not in _PLACEHOLDER_VALUES
