"""
Unit tests for the otio_timeline module.

Tests cover:
- Timeline creation
- Timeline loading and saving
- Clip addition with idempotency
- Timeline summary generation
- Timeline validation
- Utility functions
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, Mock, patch

import pytest

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

# Mock opentimelineio before importing the module
otio_mock = MagicMock()
otio_mock.schema = MagicMock()
otio_mock.schema.Timeline = MagicMock(return_value=MagicMock(
    name="test_timeline",
    metadata={},
    tracks=[],
))
otio_mock.schema.Track = MagicMock(return_value=MagicMock(
    name="test_track",
    kind="Video",
))
otio_mock.schema.TrackKind = MagicMock()
otio_mock.schema.TrackKind.Video = "Video"
otio_mock.schema.TrackKind.Audio = "Audio"
otio_mock.schema.Clip = MagicMock(return_value=MagicMock(
    name="test_clip",
    source_range=None,
    media_reference=None,
    metadata={},
))
otio_mock.schema.Gap = MagicMock(return_value=MagicMock(
    name="gap",
))
otio_mock.schema.ExternalReference = MagicMock(return_value=MagicMock(
    target_url="/path/to/media.mp4",
))
otio_mock.opentime = MagicMock()
otio_mock.opentime.TimeRange = MagicMock()
otio_mock.opentime.RationalTime = MagicMock()
otio_mock.adapters = MagicMock()
otio_mock.adapters.read_from_file = MagicMock(return_value=MagicMock(
    name="loaded_timeline",
    metadata={},
    tracks=[],
))
otio_mock.adapters.write_to_file = MagicMock()

sys.modules["opentimelineio"] = otio_mock

from pipeline.otio_timeline import (
    TIMELINE_DIR,
    add_clip,
    create_timeline,
    get_timeline_summary,
    get_track_duration,
    list_clips,
    load_timeline,
    remove_clip,
    save_timeline,
    validate_timeline,
)


# -----------------------------------------------------------------------------
# Timeline Creation Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestCreateTimeline:
    """Tests for the create_timeline function."""

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_create_timeline_basic(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test basic timeline creation."""
        mock_timeline = MagicMock()
        mock_timeline.metadata = {}
        mock_timeline.tracks = []
        mock_otio.schema.Timeline.return_value = mock_timeline
        
        result = create_timeline(
            topic="Test Documentary",
            num_scenes=5,
            output_dir="/tmp/test",
        )
        
        assert "Test_Documentary.otio" in result
        mock_makedirs.assert_called_once_with("/tmp/test", exist_ok=True)
        mock_otio.adapters.write_to_file.assert_called_once()

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_create_timeline_sanitizes_topic(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test that topic is sanitized for filename."""
        mock_timeline = MagicMock()
        mock_timeline.metadata = {}
        mock_timeline.tracks = []
        mock_otio.schema.Timeline.return_value = mock_timeline
        
        result = create_timeline(
            topic="Test/Topic With Spaces",
            num_scenes=3,
            output_dir="/tmp/test",
        )
        
        assert "Test_Topic_With_Spaces.otio" in result

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_create_timeline_uses_default_dir(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test that default timeline directory is used."""
        mock_timeline = MagicMock()
        mock_timeline.metadata = {}
        mock_timeline.tracks = []
        mock_otio.schema.Timeline.return_value = mock_timeline
        
        with patch("pipeline.otio_timeline.TIMELINE_DIR", "/default/timeline/dir"):
            result = create_timeline(
                topic="Test",
                num_scenes=3,
            )
        
        assert "/default/timeline/dir" in result

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_create_timeline_sets_metadata(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test that timeline metadata is set correctly."""
        mock_timeline = MagicMock()
        mock_timeline.metadata = {}
        mock_timeline.tracks = []
        mock_otio.schema.Timeline.return_value = mock_timeline
        
        create_timeline(topic="Test", num_scenes=5)
        
        assert mock_timeline.metadata["topic"] == "Test"
        assert mock_timeline.metadata["num_scenes"] == 5

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_create_timeline_creates_tracks(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test that timeline creates expected tracks."""
        mock_timeline = MagicMock()
        mock_timeline.metadata = {}
        mock_timeline.tracks = []
        mock_otio.schema.Timeline.return_value = mock_timeline
        
        create_timeline(topic="Test", num_scenes=3)
        
        # Should create 3 tracks
        assert mock_otio.schema.Track.call_count == 3
        # Tracks should be appended
        assert mock_timeline.tracks.append.call_count == 3


# -----------------------------------------------------------------------------
# Timeline Load/Save Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestLoadSaveTimeline:
    """Tests for load_timeline and save_timeline functions."""

    @patch("pipeline.otio_timeline.otio")
    def test_load_timeline(self, mock_otio: Mock) -> None:
        """Test loading a timeline from file."""
        mock_timeline = MagicMock()
        mock_otio.adapters.read_from_file.return_value = mock_timeline
        
        result = load_timeline("/path/to/timeline.otio")
        
        assert result == mock_timeline
        mock_otio.adapters.read_from_file.assert_called_once_with("/path/to/timeline.otio")

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_save_timeline(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test saving a timeline to file."""
        mock_timeline = MagicMock()
        
        save_timeline(mock_timeline, "/path/to/timeline.otio")
        
        mock_makedirs.assert_called_once_with("/path/to", exist_ok=True)
        mock_otio.adapters.write_to_file.assert_called_once_with(mock_timeline, "/path/to/timeline.otio")

    @patch("os.makedirs")
    @patch("pipeline.otio_timeline.otio")
    def test_save_timeline_creates_parent_dir(self, mock_otio: Mock, mock_makedirs: Mock) -> None:
        """Test that save_timeline creates parent directory."""
        mock_timeline = MagicMock()
        
        save_timeline(mock_timeline, "timeline.otio")
        
        mock_makedirs.assert_called_once_with(".", exist_ok=True)


# -----------------------------------------------------------------------------
# Add Clip Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestAddClip:
    """Tests for the add_clip function."""

    @patch("pipeline.otio_timeline.load_timeline")
    @patch("pipeline.otio_timeline.save_timeline")
    @patch("pipeline.otio_timeline.otio")
    def test_add_clip_success(
        self, 
        mock_otio: Mock, 
        mock_save: Mock, 
        mock_load: Mock
    ) -> None:
        """Test successful clip addition."""
        mock_timeline = MagicMock()
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.__iter__ = Mock(return_value=iter([]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = add_clip(
            filepath="/path/to/timeline.otio",
            track_name="V1_Video",
            clip_name="test_clip",
            media_path="/path/to/media.mp4",
            duration=5.0,
        )
        
        assert result is True
        mock_save.assert_called_once()

    @patch("pipeline.otio_timeline.load_timeline")
    @patch("pipeline.otio_timeline.otio")
    def test_add_clip_idempotency(
        self, 
        mock_otio: Mock, 
        mock_load: Mock
    ) -> None:
        """Test that duplicate clips are not added."""
        mock_timeline = MagicMock()
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        
        # Create existing clip with same name
        mock_existing_clip = MagicMock()
        mock_existing_clip.name = "existing_clip"
        mock_track.__iter__ = Mock(return_value=iter([mock_existing_clip]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = add_clip(
            filepath="/path/to/timeline.otio",
            track_name="V1_Video",
            clip_name="existing_clip",
            media_path="/path/to/media.mp4",
            duration=5.0,
        )
        
        assert result is False

    @patch("pipeline.otio_timeline.load_timeline")
    def test_add_clip_missing_track(self, mock_load: Mock) -> None:
        """Test error when track doesn't exist."""
        mock_timeline = MagicMock()
        mock_track = MagicMock()
        mock_track.name = "Other_Track"
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        with pytest.raises(ValueError) as exc_info:
            add_clip(
                filepath="/path/to/timeline.otio",
                track_name="V1_Video",
                clip_name="test_clip",
                media_path="/path/to/media.mp4",
                duration=5.0,
            )
        
        assert "Track 'V1_Video' not found" in str(exc_info.value)

    @patch("pipeline.otio_timeline.load_timeline")
    @patch("pipeline.otio_timeline.save_timeline")
    @patch("pipeline.otio_timeline.otio")
    def test_add_clip_with_metadata(
        self, 
        mock_otio: Mock, 
        mock_save: Mock, 
        mock_load: Mock
    ) -> None:
        """Test clip addition with metadata."""
        mock_timeline = MagicMock()
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.__iter__ = Mock(return_value=iter([]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        mock_clip = MagicMock()
        mock_clip.metadata = {}
        mock_otio.schema.Clip.return_value = mock_clip
        
        add_clip(
            filepath="/path/to/timeline.otio",
            track_name="V1_Video",
            clip_name="test_clip",
            media_path="/path/to/media.mp4",
            duration=5.0,
            metadata={"scene": 1, "phrase": 2},
        )
        
        assert mock_clip.metadata["scene"] == 1
        assert mock_clip.metadata["phrase"] == 2


# -----------------------------------------------------------------------------
# Timeline Summary Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestGetTimelineSummary:
    """Tests for the get_timeline_summary function."""

    @patch("pipeline.otio_timeline.load_timeline")
    def test_summary_structure(self, mock_load: Mock) -> None:
        """Test summary dictionary structure."""
        mock_timeline = MagicMock()
        mock_timeline.name = "test_timeline"
        mock_timeline.tracks = []
        mock_load.return_value = mock_timeline
        
        result = get_timeline_summary("/path/to/timeline.otio")
        
        assert "timeline_name" in result
        assert "tracks" in result
        assert result["timeline_name"] == "test_timeline"
        assert isinstance(result["tracks"], list)

    @patch("pipeline.otio_timeline.load_timeline")
    def test_summary_with_clips(self, mock_load: Mock) -> None:
        """Test summary with clips."""
        mock_timeline = MagicMock()
        mock_timeline.name = "test_timeline"
        
        mock_clip = MagicMock()
        mock_clip.name = "test_clip"
        mock_clip.source_range.duration.to_seconds.return_value = 5.0
        
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.kind = "Video"
        mock_track.__iter__ = Mock(return_value=iter([mock_clip]))
        
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = get_timeline_summary("/path/to/timeline.otio")
        
        assert len(result["tracks"]) == 1
        assert result["tracks"][0]["total_clips"] == 1
        assert result["tracks"][0]["clips"][0]["name"] == "test_clip"

    @patch("pipeline.otio_timeline.load_timeline")
    def test_summary_with_gaps(self, mock_load: Mock) -> None:
        """Test summary with gaps."""
        mock_timeline = MagicMock()
        mock_timeline.name = "test_timeline"
        
        mock_gap = MagicMock()
        mock_gap.name = "gap"
        
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.kind = "Video"
        mock_track.__iter__ = Mock(return_value=iter([mock_gap]))
        
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = get_timeline_summary("/path/to/timeline.otio")
        
        assert result["tracks"][0]["total_gaps"] == 1


# -----------------------------------------------------------------------------
# Timeline Validation Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestValidateTimeline:
    """Tests for the validate_timeline function."""

    @patch("pipeline.otio_timeline.load_timeline")
    def test_scenario_phase_valid(self, mock_load: Mock) -> None:
        """Test scenario phase validation with valid timeline."""
        mock_timeline = MagicMock()
        mock_track1 = MagicMock()
        mock_track1.name = "V1_Video"
        mock_track2 = MagicMock()
        mock_track2.name = "A1_Narration"
        mock_track3 = MagicMock()
        mock_track3.name = "A2_Music"
        mock_timeline.tracks = [mock_track1, mock_track2, mock_track3]
        mock_load.return_value = mock_timeline
        
        result = validate_timeline("/path/to/timeline.otio", "scenario")
        
        assert result["valid"] is True
        assert result["phase"] == "scenario"
        assert result["errors"] is None

    @patch("pipeline.otio_timeline.load_timeline")
    def test_scenario_phase_missing_track(self, mock_load: Mock) -> None:
        """Test scenario phase validation with missing track."""
        mock_timeline = MagicMock()
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_timeline.tracks = [mock_track]  # Missing A1_Narration and A2_Music
        mock_load.return_value = mock_timeline
        
        result = validate_timeline("/path/to/timeline.otio", "scenario")
        
        assert result["valid"] is False
        assert "Missing required track" in result["errors"]

    @patch("pipeline.otio_timeline.load_timeline")
    @patch("os.path.exists")
    def test_audio_phase_missing_wav(self, mock_exists: Mock, mock_load: Mock) -> None:
        """Test audio phase validation with missing WAV file."""
        mock_exists.return_value = False
        
        mock_timeline = MagicMock()
        mock_clip = MagicMock()
        mock_clip.name = "narration_clip"
        mock_media_ref = MagicMock()
        mock_media_ref.target_url = "/path/to/missing.wav"
        mock_clip.media_reference = mock_media_ref
        
        mock_track = MagicMock()
        mock_track.name = "A1_Narration"
        mock_track.__iter__ = Mock(return_value=iter([mock_clip]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = validate_timeline("/path/to/timeline.otio", "audio")
        
        assert result["valid"] is False
        assert "WAV not found" in result["errors"]

    @patch("pipeline.otio_timeline.load_timeline")
    def test_assembly_phase_no_clips(self, mock_load: Mock) -> None:
        """Test assembly phase validation with no clips."""
        mock_timeline = MagicMock()
        mock_video_track = MagicMock()
        mock_video_track.name = "V1_Video"
        mock_video_track.__iter__ = Mock(return_value=iter([]))
        mock_narration_track = MagicMock()
        mock_narration_track.name = "A1_Narration"
        mock_narration_track.__iter__ = Mock(return_value=iter([]))
        mock_timeline.tracks = [mock_video_track, mock_narration_track]
        mock_load.return_value = mock_timeline
        
        result = validate_timeline("/path/to/timeline.otio", "assembly")
        
        assert result["valid"] is False
        assert "No video clips" in result["errors"]


# -----------------------------------------------------------------------------
# Utility Function Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestUtilityFunctions:
    """Tests for utility functions."""

    @patch("pipeline.otio_timeline.load_timeline")
    def test_get_track_duration(self, mock_load: Mock) -> None:
        """Test getting track duration."""
        mock_timeline = MagicMock()
        mock_clip = MagicMock()
        mock_clip.source_range.duration.to_seconds.return_value = 5.0
        
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.__iter__ = Mock(return_value=iter([mock_clip]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = get_track_duration("/path/to/timeline.otio", "V1_Video")
        
        assert result == 5.0

    @patch("pipeline.otio_timeline.load_timeline")
    def test_get_track_duration_missing_track(self, mock_load: Mock) -> None:
        """Test getting duration for missing track."""
        mock_timeline = MagicMock()
        mock_timeline.tracks = []
        mock_load.return_value = mock_timeline
        
        result = get_track_duration("/path/to/timeline.otio", "V1_Video")
        
        assert result == 0.0

    @patch("pipeline.otio_timeline.load_timeline")
    def test_list_clips(self, mock_load: Mock) -> None:
        """Test listing clips."""
        mock_timeline = MagicMock()
        mock_clip = MagicMock()
        mock_clip.name = "test_clip"
        mock_clip.source_range.duration.to_seconds.return_value = 5.0
        mock_media_ref = MagicMock()
        mock_media_ref.target_url = "/path/to/media.mp4"
        mock_clip.media_reference = mock_media_ref
        
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.__iter__ = Mock(return_value=iter([mock_clip]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = list_clips("/path/to/timeline.otio")
        
        assert len(result) == 1
        assert result[0]["name"] == "test_clip"
        assert result[0]["track"] == "V1_Video"

    @patch("pipeline.otio_timeline.load_timeline")
    def test_list_clips_filtered_by_track(self, mock_load: Mock) -> None:
        """Test listing clips filtered by track name."""
        mock_timeline = MagicMock()
        
        mock_video_clip = MagicMock()
        mock_video_clip.name = "video_clip"
        mock_video_clip.source_range = None
        mock_video_clip.media_reference = None
        
        mock_audio_clip = MagicMock()
        mock_audio_clip.name = "audio_clip"
        mock_audio_clip.source_range = None
        mock_audio_clip.media_reference = None
        
        mock_video_track = MagicMock()
        mock_video_track.name = "V1_Video"
        mock_video_track.__iter__ = Mock(return_value=iter([mock_video_clip]))
        
        mock_audio_track = MagicMock()
        mock_audio_track.name = "A1_Narration"
        mock_audio_track.__iter__ = Mock(return_value=iter([mock_audio_clip]))
        
        mock_timeline.tracks = [mock_video_track, mock_audio_track]
        mock_load.return_value = mock_timeline
        
        result = list_clips("/path/to/timeline.otio", track_name="V1_Video")
        
        assert len(result) == 1
        assert result[0]["name"] == "video_clip"

    @patch("pipeline.otio_timeline.load_timeline")
    @patch("pipeline.otio_timeline.save_timeline")
    def test_remove_clip_success(self, mock_save: Mock, mock_load: Mock) -> None:
        """Test successful clip removal."""
        mock_timeline = MagicMock()
        mock_clip = MagicMock()
        mock_clip.name = "test_clip"
        
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.__iter__ = Mock(return_value=iter([mock_clip]))
        mock_track.__delitem__ = Mock()
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = remove_clip("/path/to/timeline.otio", "V1_Video", "test_clip")
        
        assert result is True
        mock_save.assert_called_once()

    @patch("pipeline.otio_timeline.load_timeline")
    def test_remove_clip_not_found(self, mock_load: Mock) -> None:
        """Test clip removal when clip doesn't exist."""
        mock_timeline = MagicMock()
        mock_clip = MagicMock()
        mock_clip.name = "other_clip"
        
        mock_track = MagicMock()
        mock_track.name = "V1_Video"
        mock_track.__iter__ = Mock(return_value=iter([mock_clip]))
        mock_timeline.tracks = [mock_track]
        mock_load.return_value = mock_timeline
        
        result = remove_clip("/path/to/timeline.otio", "V1_Video", "test_clip")
        
        assert result is False


# -----------------------------------------------------------------------------
# TIMELINE_DIR Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestTimelineDir:
    """Tests for TIMELINE_DIR constant."""

    def test_default_timeline_dir(self) -> None:
        """Test default TIMELINE_DIR value."""
        assert "timelines" in TIMELINE_DIR

    @patch.dict(os.environ, {"TIMELINE_DIR": "/custom/timeline/dir"})
    def test_timeline_dir_from_env(self) -> None:
        """Test TIMELINE_DIR from environment variable."""
        # Need to reload module to pick up env change
        import importlib
        import pipeline.otio_timeline as otio_module
        importlib.reload(otio_module)
        assert otio_module.TIMELINE_DIR == "/custom/timeline/dir"
