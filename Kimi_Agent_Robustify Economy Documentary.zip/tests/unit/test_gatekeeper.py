"""
Unit tests for the gatekeeper module.

Tests cover:
- GatekeeperVerdict enum
- GatekeeperCheck dataclass
- GatekeeperStore operations
- Video and narration clip validation
- Stage handoff checks
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, Mock, patch

import pytest

# Add server directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "server"))

from gatekeeper import (
    GatekeeperCheck,
    GatekeeperStore,
    GatekeeperVerdict,
    check_narration_clip,
    check_stage_handoff,
    check_video_clip,
    get_gatekeeper_store,
    intervention_window,
)


# -----------------------------------------------------------------------------
# GatekeeperVerdict Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestGatekeeperVerdict:
    """Tests for the GatekeeperVerdict enum."""

    def test_verdict_values(self) -> None:
        """Test that verdict enum has expected values."""
        assert GatekeeperVerdict.PASS.value == "pass"
        assert GatekeeperVerdict.WARN.value == "warn"
        assert GatekeeperVerdict.REJECT.value == "reject"

    def test_verdict_is_str_subclass(self) -> None:
        """Test that GatekeeperVerdict is a string subclass."""
        assert isinstance(GatekeeperVerdict.PASS, str)
        assert GatekeeperVerdict.PASS == "pass"


# -----------------------------------------------------------------------------
# GatekeeperCheck Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestGatekeeperCheck:
    """Tests for the GatekeeperCheck dataclass."""

    def test_check_creation(self) -> None:
        """Test creating a GatekeeperCheck instance."""
        check = GatekeeperCheck(
            name="test_check",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
            message="Test message",
            stage="production",
            scene_num=1,
            phrase_idx=2,
        )
        assert check.name == "test_check"
        assert check.category == "structural"
        assert check.verdict == GatekeeperVerdict.PASS
        assert check.message == "Test message"
        assert check.stage == "production"
        assert check.scene_num == 1
        assert check.phrase_idx == 2

    def test_check_default_values(self) -> None:
        """Test GatekeeperCheck default values."""
        check = GatekeeperCheck(
            name="test_check",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
        )
        assert check.message == ""
        assert check.stage == ""
        assert check.scene_num == 0
        assert check.phrase_idx == 0
        assert check.metadata == {}
        assert check.timestamp == 0.0

    def test_check_to_dict(self) -> None:
        """Test converting GatekeeperCheck to dictionary."""
        check = GatekeeperCheck(
            name="test_check",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
            message="Test message",
            stage="production",
            scene_num=1,
            phrase_idx=2,
            metadata={"key": "value"},
            timestamp=1234567890.0,
        )
        result = check.to_dict()
        assert result["name"] == "test_check"
        assert result["category"] == "structural"
        assert result["verdict"] == "pass"
        assert result["message"] == "Test message"
        assert result["stage"] == "production"
        assert result["scene_num"] == 1
        assert result["phrase_idx"] == 2
        assert result["metadata"] == {"key": "value"}
        assert result["timestamp"] == 1234567890.0

    def test_check_to_dict_auto_timestamp(self) -> None:
        """Test that to_dict auto-generates timestamp if not set."""
        before = time.time()
        check = GatekeeperCheck(
            name="test_check",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
        )
        result = check.to_dict()
        after = time.time()
        assert before <= result["timestamp"] <= after


# -----------------------------------------------------------------------------
# GatekeeperStore Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestGatekeeperStore:
    """Tests for the GatekeeperStore class."""

    def test_store_initialization(self) -> None:
        """Test GatekeeperStore initialization."""
        store = GatekeeperStore()
        assert store.get_all_checks() == []

    def test_record_check(self) -> None:
        """Test recording a check in the store."""
        store = GatekeeperStore()
        check = GatekeeperCheck(
            name="test_check",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
        )
        store.record_check(check)
        assert len(store.get_all_checks()) == 1
        assert store.get_all_checks()[0]["name"] == "test_check"

    def test_record_multiple_checks(self) -> None:
        """Test recording multiple checks."""
        store = GatekeeperStore()
        for i in range(3):
            check = GatekeeperCheck(
                name=f"check_{i}",
                category="structural",
                verdict=GatekeeperVerdict.PASS,
            )
            store.record_check(check)
        assert len(store.get_all_checks()) == 3

    def test_get_checks_for_stage(self) -> None:
        """Test filtering checks by stage."""
        store = GatekeeperStore()
        store.record_check(GatekeeperCheck(
            name="check1",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
            stage="audio",
        ))
        store.record_check(GatekeeperCheck(
            name="check2",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
            stage="production",
        ))
        audio_checks = store.get_checks_for_stage("audio")
        assert len(audio_checks) == 1
        assert audio_checks[0]["name"] == "check1"

    def test_get_rejects(self) -> None:
        """Test getting only rejected checks."""
        store = GatekeeperStore()
        store.record_check(GatekeeperCheck(
            name="pass_check",
            category="structural",
            verdict=GatekeeperVerdict.PASS,
        ))
        store.record_check(GatekeeperCheck(
            name="reject_check",
            category="structural",
            verdict=GatekeeperVerdict.REJECT,
        ))
        store.record_check(GatekeeperCheck(
            name="warn_check",
            category="structural",
            verdict=GatekeeperVerdict.WARN,
        ))
        rejects = store.get_rejects()
        assert len(rejects) == 1
        assert rejects[0]["name"] == "reject_check"

    def test_thread_safety(self) -> None:
        """Test that GatekeeperStore is thread-safe."""
        store = GatekeeperStore()
        errors: list[Exception] = []

        def record_checks() -> None:
            try:
                for i in range(100):
                    check = GatekeeperCheck(
                        name=f"thread_check_{threading.current_thread().ident}_{i}",
                        category="structural",
                        verdict=GatekeeperVerdict.PASS,
                    )
                    store.record_check(check)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=record_checks) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(store.get_all_checks()) == 500

    def test_record_intervention_window(self) -> None:
        """Test recording intervention window."""
        store = GatekeeperStore()
        summary = [{"name": "check1", "verdict": "pass"}]
        store.record_intervention_window("test_stage", 30.0, summary)
        # Should not raise and intervention_events should be stored
        assert len(store._intervention_events) == 1
        assert store._intervention_events[0]["stage"] == "test_stage"


# -----------------------------------------------------------------------------
# Video Clip Check Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestCheckVideoClip:
    """Tests for the check_video_clip function."""

    @patch("os.path.exists")
    def test_file_not_found(self, mock_exists: Mock) -> None:
        """Test rejection when video file doesn't exist."""
        mock_exists.return_value = False
        checks = check_video_clip(
            mp4_path="/nonexistent/video.mp4",
            scene_num=1,
            phrase_idx=0,
            source_range=5.0,
            expected_duration=5.0,
        )
        assert len(checks) == 1
        assert checks[0].name == "file_exists"
        assert checks[0].verdict == GatekeeperVerdict.REJECT

    @patch("os.path.exists")
    def test_source_range_zero(self, mock_exists: Mock) -> None:
        """Test rejection when source_range is zero."""
        mock_exists.return_value = True
        checks = check_video_clip(
            mp4_path="/path/video.mp4",
            scene_num=1,
            phrase_idx=0,
            source_range=0.0,
            expected_duration=5.0,
        )
        file_exists_check = next(c for c in checks if c.name == "file_exists")
        source_range_check = next(c for c in checks if c.name == "source_range_positive")
        assert file_exists_check.verdict == GatekeeperVerdict.PASS
        assert source_range_check.verdict == GatekeeperVerdict.REJECT

    @patch("os.path.exists")
    @patch("gatekeeper._probe_video_stats")
    def test_successful_probe(self, mock_probe: Mock, mock_exists: Mock) -> None:
        """Test successful video probe."""
        mock_exists.return_value = True
        mock_probe.return_value = {
            "duration": 10.0,
            "nb_frames": 240,
            "width": 1920,
            "height": 1080,
            "codec": "h264",
            "fps": 24.0,
        }
        checks = check_video_clip(
            mp4_path="/path/video.mp4",
            scene_num=1,
            phrase_idx=0,
            source_range=10.0,
            expected_duration=10.0,
        )
        probe_check = next(c for c in checks if c.name == "probe_video")
        assert probe_check.verdict == GatekeeperVerdict.PASS
        assert probe_check.metadata["codec"] == "h264"

    @patch("os.path.exists")
    @patch("gatekeeper._probe_video_stats")
    def test_non_h264_codec_warning(self, mock_probe: Mock, mock_exists: Mock) -> None:
        """Test warning for non-H.264 codec."""
        mock_exists.return_value = True
        mock_probe.return_value = {
            "duration": 10.0,
            "nb_frames": 240,
            "width": 1920,
            "height": 1080,
            "codec": "mpeg4",
            "fps": 24.0,
        }
        checks = check_video_clip(
            mp4_path="/path/video.mp4",
            scene_num=1,
            phrase_idx=0,
            source_range=10.0,
            expected_duration=10.0,
        )
        codec_check = next(c for c in checks if c.name == "codec_h264")
        assert codec_check.verdict == GatekeeperVerdict.WARN


# -----------------------------------------------------------------------------
# Narration Clip Check Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestCheckNarrationClip:
    """Tests for the check_narration_clip function."""

    @patch("os.path.exists")
    def test_wav_file_not_found(self, mock_exists: Mock) -> None:
        """Test rejection when WAV file doesn't exist."""
        mock_exists.return_value = False
        checks = check_narration_clip(
            wav_path="/nonexistent/audio.wav",
            scene_num=1,
            voice="test_voice",
            duration=5.0,
        )
        assert len(checks) == 1
        assert checks[0].name == "file_exists"
        assert checks[0].verdict == GatekeeperVerdict.REJECT

    @patch("os.path.exists")
    @patch("os.path.getsize")
    def test_successful_check(self, mock_getsize: Mock, mock_exists: Mock) -> None:
        """Test successful narration check."""
        mock_exists.return_value = True
        mock_getsize.return_value = 50000  # 50KB
        checks = check_narration_clip(
            wav_path="/path/audio.wav",
            scene_num=1,
            voice="test_voice",
            duration=5.0,
        )
        file_check = next(c for c in checks if c.name == "file_exists")
        duration_check = next(c for c in checks if c.name == "duration_positive")
        size_check = next(c for c in checks if c.name == "file_size_sanity")
        assert file_check.verdict == GatekeeperVerdict.PASS
        assert duration_check.verdict == GatekeeperVerdict.PASS
        assert size_check.verdict == GatekeeperVerdict.PASS

    @patch("os.path.exists")
    def test_zero_duration(self, mock_exists: Mock) -> None:
        """Test rejection for zero duration."""
        mock_exists.return_value = True
        checks = check_narration_clip(
            wav_path="/path/audio.wav",
            scene_num=1,
            voice="test_voice",
            duration=0.0,
        )
        duration_check = next(c for c in checks if c.name == "duration_positive")
        assert duration_check.verdict == GatekeeperVerdict.REJECT

    @patch("os.path.exists")
    @patch("os.path.getsize")
    def test_small_file_rejection(self, mock_getsize: Mock, mock_exists: Mock) -> None:
        """Test rejection for suspiciously small file."""
        mock_exists.return_value = True
        mock_getsize.return_value = 500  # 500 bytes - too small
        checks = check_narration_clip(
            wav_path="/path/audio.wav",
            scene_num=1,
            voice="test_voice",
            duration=5.0,
        )
        size_check = next(c for c in checks if c.name == "file_size_sanity")
        assert size_check.verdict == GatekeeperVerdict.REJECT


# -----------------------------------------------------------------------------
# Intervention Window Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestInterventionWindow:
    """Tests for the intervention_window function."""

    @patch.dict(os.environ, {"DOCUMENTARY_TEST_MODE": "true"})
    def test_test_mode_auto_approve(self) -> None:
        """Test that test mode auto-approves."""
        checks = [
            GatekeeperCheck(
                name="test",
                category="structural",
                verdict=GatekeeperVerdict.PASS,
            )
        ]
        result = intervention_window("test_stage", checks)
        assert result is True

    @patch.dict(os.environ, {"DOCUMENTARY_AUTO_APPROVE": "true"})
    def test_auto_approve_mode(self) -> None:
        """Test auto-approve mode."""
        checks = [
            GatekeeperCheck(
                name="test",
                category="structural",
                verdict=GatekeeperVerdict.PASS,
            )
        ]
        result = intervention_window("test_stage", checks)
        assert result is True

    @patch.dict(os.environ, {"DOCUMENTARY_TEST_MODE": "false", "DOCUMENTARY_AUTO_APPROVE": "false"})
    def test_reject_blocks_immediately(self) -> None:
        """Test that rejects block without intervention window."""
        checks = [
            GatekeeperCheck(
                name="reject_check",
                category="structural",
                verdict=GatekeeperVerdict.REJECT,
            )
        ]
        result = intervention_window("test_stage", checks)
        assert result is False


# -----------------------------------------------------------------------------
# Singleton Tests
# -----------------------------------------------------------------------------

@pytest.mark.unit
class TestSingleton:
    """Tests for the gatekeeper singleton."""

    def test_get_gatekeeper_store_returns_same_instance(self) -> None:
        """Test that get_gatekeeper_store returns the same instance."""
        store1 = get_gatekeeper_store()
        store2 = get_gatekeeper_store()
        assert store1 is store2

    def test_store_is_gatekeeper_store(self) -> None:
        """Test that the store is a GatekeeperStore instance."""
        store = get_gatekeeper_store()
        assert isinstance(store, GatekeeperStore)
