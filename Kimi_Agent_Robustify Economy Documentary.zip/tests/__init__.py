"""
Test suite for the economy-documentary project.

This package contains unit and integration tests for the documentary pipeline.
"""

from __future__ import annotations
