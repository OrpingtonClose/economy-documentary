"""
Pytest configuration and shared fixtures for the documentary pipeline tests.

This module provides:
- Test configuration and markers
- Shared fixtures for test data and mocks
- Helper utilities for testing
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Callable, Generator, Iterator
from unittest.mock import MagicMock, Mock, patch

import pytest


# -----------------------------------------------------------------------------
# Pytest Configuration
# -----------------------------------------------------------------------------

def pytest_configure(config: pytest.Config) -> None:
    """Configure pytest with custom markers."""
    config.addinivalue_line("markers", "unit: Unit tests (fast, isolated)")
    config.addinivalue_line("markers", "integration: Integration tests")
    config.addinivalue_line("markers", "slow: Slow tests (skip in quick runs)")
    config.addinivalue_line("markers", "api: API endpoint tests")
    config.addinivalue_line("markers", "pipeline: Pipeline component tests")


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Modify test collection to add markers based on test location."""
    for item in items:
        # Auto-mark tests based on their file location
        if "unit" in str(item.fspath):
            item.add_marker(pytest.mark.unit)
        if "integration" in str(item.fspath):
            item.add_marker(pytest.mark.integration)
        if "test_server" in str(item.fspath):
            item.add_marker(pytest.mark.api)
        if "test_otio" in str(item.fspath):
            item.add_marker(pytest.mark.pipeline)


# -----------------------------------------------------------------------------
# Environment Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def setup_test_environment() -> Generator[None, None, None]:
    """Set up the test environment for the entire test session."""
    # Set test mode environment variable
    os.environ["DOCUMENTARY_TEST_MODE"] = "true"
    os.environ["GATEKEEPER_TIMEOUT"] = "1"  # Short timeout for tests
    
    yield
    
    # Cleanup
    os.environ.pop("DOCUMENTARY_TEST_MODE", None)
    os.environ.pop("GATEKEEPER_TIMEOUT", None)


@pytest.fixture
def temp_dir() -> Generator[str, None, None]:
    """Provide a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def temp_file(temp_dir: str) -> Callable[[str, str], str]:
    """Factory fixture to create temporary files."""
    def _create_file(filename: str, content: str = "") -> str:
        filepath = os.path.join(temp_dir, filename)
        os.makedirs(os.path.dirname(filepath) or tmpdir, exist_ok=True)
        with open(filepath, "w") as f:
            f.write(content)
        return filepath
    return _create_file


# -----------------------------------------------------------------------------
# Mock Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def mock_subprocess_run() -> Generator[Mock, None, None]:
    """Mock subprocess.run for testing external commands."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout='{"streams": [{"codec_type": "video", "nb_frames": "100", "width": "1920", "height": "1080", "codec_name": "h264", "r_frame_rate": "24/1"}], "format": {"duration": "10.0"}}',
            stderr="",
        )
        yield mock_run


@pytest.fixture
def mock_urlopen() -> Generator[Mock, None, None]:
    """Mock urllib.request.urlopen for testing HTTP requests."""
    with patch("urllib.request.urlopen") as mock:
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "status": "ok",
            "tts_loaded": True,
            "ltx_loaded": True,
            "worker_mode": "tts"
        }).encode()
        mock.return_value.__enter__.return_value = mock_response
        yield mock


@pytest.fixture
def mock_os_path_exists() -> Generator[Mock, None, None]:
    """Mock os.path.exists for testing file existence checks."""
    with patch("os.path.exists") as mock:
        mock.return_value = True
        yield mock


@pytest.fixture
def mock_os_path_getsize() -> Generator[Mock, None, None]:
    """Mock os.path.getsize for testing file size checks."""
    with patch("os.path.getsize") as mock:
        mock.return_value = 10000  # 10KB
        yield mock


@pytest.fixture
def mock_otio() -> Generator[Mock, None, None]:
    """Mock opentimelineio for testing timeline operations."""
    with patch.dict("sys.modules", {"opentimelineio": MagicMock()}):
        import opentimelineio as otio
        yield otio


# -----------------------------------------------------------------------------
# Gatekeeper Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def gatekeeper_store() -> Generator[Any, None, None]:
    """Provide a fresh GatekeeperStore instance."""
    # Import here to avoid circular imports
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent / "server"))
    from gatekeeper import GatekeeperStore, GatekeeperCheck, GatekeeperVerdict
    
    store = GatekeeperStore()
    yield store


@pytest.fixture
def sample_gatekeeper_check() -> Callable[..., Any]:
    """Factory fixture to create sample GatekeeperCheck instances."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent / "server"))
    from gatekeeper import GatekeeperCheck, GatekeeperVerdict
    
    def _create_check(
        name: str = "test_check",
        verdict: str = "pass",
        category: str = "structural",
        message: str = "",
        stage: str = "test",
        scene_num: int = 1,
        phrase_idx: int = 0,
    ) -> Any:
        return GatekeeperCheck(
            name=name,
            category=category,
            verdict=GatekeeperVerdict(verdict),
            message=message,
            stage=stage,
            scene_num=scene_num,
            phrase_idx=phrase_idx,
        )
    return _create_check


# -----------------------------------------------------------------------------
# Contract Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def sample_stage_contract() -> Callable[..., Any]:
    """Factory fixture to create sample StageContract instances."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent / "server"))
    from contracts import StageContract, ServiceRequirement
    
    def _create_contract(
        name: str = "test_stage",
        required_services: list | None = None,
        required_state: list[str] | None = None,
        produced_state: list[str] | None = None,
        produced_artifacts: list[str] | None = None,
    ) -> Any:
        return StageContract(
            name=name,
            required_services=required_services or [],
            required_state=required_state or [],
            produced_state=produced_state or [],
            produced_artifacts=produced_artifacts or [],
        )
    return _create_contract


@pytest.fixture
def sample_service_requirement() -> Callable[..., Any]:
    """Factory fixture to create sample ServiceRequirement instances."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent / "server"))
    from contracts import ServiceRequirement
    
    def _create_requirement(
        name: str = "Test Worker",
        env_var: str = "TEST_WORKER_URL",
        capability: str = "test",
        required: bool = True,
    ) -> Any:
        return ServiceRequirement(
            name=name,
            env_var=env_var,
            capability=capability,
            required=required,
        )
    return _create_requirement


# -----------------------------------------------------------------------------
# Timeline Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def sample_timeline_path(temp_dir: str) -> str:
    """Create a sample timeline file for testing."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from pipeline.otio_timeline import create_timeline
    
    timeline_path = create_timeline(
        topic="test_documentary",
        num_scenes=3,
        output_dir=temp_dir,
    )
    return timeline_path


@pytest.fixture
def mock_otio_timeline() -> MagicMock:
    """Provide a mock OTIO timeline for testing."""
    timeline = MagicMock()
    timeline.name = "test_timeline"
    timeline.metadata = {"topic": "test", "num_scenes": 3}
    
    # Mock tracks
    video_track = MagicMock()
    video_track.name = "V1_Video"
    video_track.kind = "Video"
    
    audio_track = MagicMock()
    audio_track.name = "A1_Narration"
    audio_track.kind = "Audio"
    
    timeline.tracks = [video_track, audio_track]
    
    return timeline


# -----------------------------------------------------------------------------
# FastAPI Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def mock_fastapi_app() -> MagicMock:
    """Provide a mock FastAPI application for testing."""
    app = MagicMock()
    app.routes = []
    app.middleware_stack = None
    return app


@pytest.fixture
def mock_request() -> Callable[..., MagicMock]:
    """Factory fixture to create mock Request objects."""
    def _create_request(
        method: str = "GET",
        path: str = "/",
        headers: dict[str, str] | None = None,
        body: bytes = b"",
    ) -> MagicMock:
        request = MagicMock()
        request.method = method
        request.url.path = path
        request.headers = headers or {}
        request.body = MagicMock(return_value=body)
        return request
    return _create_request


# -----------------------------------------------------------------------------
# Config Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def clean_env() -> Generator[None, None, None]:
    """Clean environment variables for config testing."""
    # Store original values
    original_env = {
        key: os.environ.get(key)
        for key in [
            "DOCUMENTARY_TOPIC",
            "ADK_MODEL",
            "GOOGLE_API_KEY",
            "OPENAI_API_KEY",
            "DOCUMENTARY_TEST_MODE",
        ]
    }
    
    # Clear test-related env vars
    for key in original_env:
        os.environ.pop(key, None)
    
    yield
    
    # Restore original values
    for key, value in original_env.items():
        if value is not None:
            os.environ[key] = value
        else:
            os.environ.pop(key, None)


# -----------------------------------------------------------------------------
# Utility Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def capture_logs() -> Callable[[], list[dict[str, Any]]]:
    """Fixture to capture log records during tests."""
    import logging
    
    class LogCapture(logging.Handler):
        def __init__(self) -> None:
            super().__init__()
            self.records: list[logging.LogRecord] = []
        
        def emit(self, record: logging.LogRecord) -> None:
            self.records.append(record)
    
    capture = LogCapture()
    logger = logging.getLogger()
    logger.addHandler(capture)
    
    def _get_logs() -> list[dict[str, Any]]:
        return [
            {
                "level": record.levelname,
                "message": record.getMessage(),
                "name": record.name,
            }
            for record in capture.records
        ]
    
    yield _get_logs
    
    logger.removeHandler(capture)


@pytest.fixture
def freeze_time() -> Callable[[float], Generator[None, None, None]]:
    """Fixture to freeze time for deterministic tests."""
    @pytest.fixture
    def _freeze_time(frozen_time: float) -> Generator[None, None, None]:
        with patch("time.time", return_value=frozen_time):
            yield
    return _freeze_time


# -----------------------------------------------------------------------------
# Async Fixtures
# -----------------------------------------------------------------------------

@pytest.fixture
def async_mock() -> Callable[..., MagicMock]:
    """Factory fixture to create async mock functions."""
    def _create_async_mock(return_value: Any = None) -> MagicMock:
        async def _async_mock(*args: Any, **kwargs: Any) -> Any:
            return return_value
        return MagicMock(side_effect=_async_mock)
    return _create_async_mock
