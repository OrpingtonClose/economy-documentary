"""
FastAPI middleware for observability.

Features:
- Correlation ID propagation
- Request/response metrics collection
- Distributed tracing integration
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from .logging_config import set_correlation_id, clear_correlation_id, get_correlation_id, LogContext
from .metrics import get_metrics_collector, API_CALL_LATENCY, ERROR_COUNTER
from .tracing import get_tracing_manager, start_span


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """Middleware to extract/generate and propagate correlation IDs.
    
    Extracts correlation ID from:
    - X-Correlation-ID header
    - X-Request-ID header
    - Generates new UUID if not present
    
    Propagates correlation ID to:
    - Response headers
    - Logging context
    """

    def __init__(
        self,
        app: Any,
        header_name: str = "X-Correlation-ID",
        response_header: str = "X-Correlation-ID",
    ):
        super().__init__(app)
        self.header_name = header_name
        self.response_header = response_header

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Extract or generate correlation ID
        correlation_id = (
            request.headers.get(self.header_name)
            or request.headers.get("X-Request-ID")
        )
        correlation_id = set_correlation_id(correlation_id)
        
        # Add to request state for access in route handlers
        request.state.correlation_id = correlation_id
        
        try:
            response = await call_next(request)
            # Add correlation ID to response headers
            response.headers[self.response_header] = correlation_id
            return response
        finally:
            clear_correlation_id()


class MetricsMiddleware(BaseHTTPMiddleware):
    """Middleware to collect request/response metrics.
    
    Collects:
    - Request latency
    - Response status codes
    - Request counts by endpoint
    """

    def __init__(
        self,
        app: Any,
        exclude_paths: Optional[list] = None,
    ):
        super().__init__(app)
        self.exclude_paths = exclude_paths or ["/health", "/metrics", "/dashboard/stream"]
        self.metrics = get_metrics_collector()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip excluded paths
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)
        
        start_time = time.time()
        
        try:
            response = await call_next(request)
            
            # Record metrics
            duration = time.time() - start_time
            status = "success" if response.status_code < 400 else "error"
            
            self.metrics.record_api_call(
                api=request.url.path,
                method=request.method,
                latency=duration,
                status=status,
            )
            
            # Record errors for 5xx status codes
            if response.status_code >= 500:
                ERROR_COUNTER.inc(
                    type="http_error",
                    component="api",
                    stage=f"{request.method}_{request.url.path}",
                )
            
            return response
            
        except Exception as e:
            # Record error metric
            duration = time.time() - start_time
            self.metrics.record_api_call(
                api=request.url.path,
                method=request.method,
                latency=duration,
                status="error",
            )
            ERROR_COUNTER.inc(
                type="exception",
                component="api",
                stage=f"{request.method}_{request.url.path}",
            )
            raise


class TracingMiddleware(BaseHTTPMiddleware):
    """Middleware to create spans for HTTP requests.
    
    Creates a span for each request with:
    - HTTP method and path
    - Status code
    - Error information (if any)
    """

    def __init__(
        self,
        app: Any,
        exclude_paths: Optional[list] = None,
    ):
        super().__init__(app)
        self.exclude_paths = exclude_paths or ["/health", "/metrics"]

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip excluded paths
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)
        
        # Get tracer
        tracer_manager = get_tracing_manager()
        if tracer_manager is None:
            return await call_next(request)
        
        tracer = tracer_manager.get_tracer()
        if tracer is None:
            return await call_next(request)
        
        # Extract trace context from headers if present
        carrier = dict(request.headers)
        parent_context = tracer_manager.extract_context(carrier)
        
        # Create span for the request
        span_name = f"{request.method} {request.url.path}"
        
        from opentelemetry import trace as otel_trace
        
        context = parent_context or otel_trace.get_current_span().get_span_context()
        
        with tracer.start_as_current_span(span_name, context=context) as span:
            # Add request attributes
            span.set_attribute("http.method", request.method)
            span.set_attribute("http.url", str(request.url))
            span.set_attribute("http.target", request.url.path)
            span.set_attribute("http.host", request.url.hostname)
            span.set_attribute("http.scheme", request.url.scheme)
            span.set_attribute("http.client_ip", request.client.host if request.client else "unknown")
            
            # Add correlation ID
            correlation_id = get_correlation_id()
            if correlation_id and correlation_id != "-":
                span.set_attribute("correlation_id", correlation_id)
            
            try:
                response = await call_next(request)
                
                # Add response attributes
                span.set_attribute("http.status_code", response.status_code)
                
                # Set status based on response code
                from opentelemetry.trace import Status, StatusCode
                if response.status_code < 400:
                    span.set_status(Status(StatusCode.OK))
                elif response.status_code < 500:
                    span.set_status(Status(StatusCode.UNSET))
                else:
                    span.set_status(Status(StatusCode.ERROR, f"HTTP {response.status_code}"))
                
                return response
                
            except Exception as e:
                # Record exception
                span.record_exception(e)
                span.set_status(Status(StatusCode.ERROR, str(e)))
                raise


class LoggingMiddleware(BaseHTTPMiddleware):
    """Middleware for request/response logging.
    
    Logs:
    - Request details (method, path, query params)
    - Response details (status, duration)
    - Error details (if any)
    """

    def __init__(
        self,
        app: Any,
        exclude_paths: Optional[list] = None,
        log_level: str = "INFO",
    ):
        super().__init__(app)
        self.exclude_paths = exclude_paths or ["/health", "/metrics", "/dashboard/stream"]
        self.log_level = log_level
        from .logging_config import get_logger
        self.logger = get_logger("http")

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip excluded paths
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)
        
        start_time = time.time()
        
        # Log request
        self.logger.info(
            "HTTP request",
            http_method=request.method,
            http_path=request.url.path,
            http_query=str(request.query_params),
            http_user_agent=request.headers.get("user-agent", "unknown"),
        )
        
        try:
            response = await call_next(request)
            
            duration = time.time() - start_time
            
            # Log response
            self.logger.info(
                "HTTP response",
                http_method=request.method,
                http_path=request.url.path,
                http_status_code=response.status_code,
                http_duration_ms=round(duration * 1000, 2),
            )
            
            return response
            
        except Exception as e:
            duration = time.time() - start_time
            
            # Log error
            self.logger.error(
                "HTTP error",
                http_method=request.method,
                http_path=request.url.path,
                http_duration_ms=round(duration * 1000, 2),
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise


class ObservabilityMiddleware(BaseHTTPMiddleware):
    """Combined observability middleware.
    
    Combines correlation ID, metrics, tracing, and logging in a single middleware.
    More efficient than using multiple separate middlewares.
    """

    def __init__(
        self,
        app: Any,
        exclude_paths: Optional[list] = None,
        service_name: str = "documentary-pipeline",
    ):
        super().__init__(app)
        self.exclude_paths = exclude_paths or ["/health", "/metrics", "/dashboard/stream"]
        self.service_name = service_name
        self.metrics = get_metrics_collector()
        from .logging_config import get_logger
        self.logger = get_logger("observability")

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Check if path should be excluded
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)
        
        # Set up correlation ID
        correlation_id = (
            request.headers.get("X-Correlation-ID")
            or request.headers.get("X-Request-ID")
        )
        correlation_id = set_correlation_id(correlation_id)
        request.state.correlation_id = correlation_id
        
        start_time = time.time()
        
        # Log request
        self.logger.info(
            "Request started",
            http_method=request.method,
            http_path=request.url.path,
            correlation_id=correlation_id,
        )
        
        try:
            with LogContext(
                http_method=request.method,
                http_path=request.url.path,
            ):
                response = await call_next(request)
                
                duration = time.time() - start_time
                status = "success" if response.status_code < 400 else "error"
                
                # Record metrics
                self.metrics.record_api_call(
                    api=request.url.path,
                    method=request.method,
                    latency=duration,
                    status=status,
                )
                
                # Log response
                self.logger.info(
                    "Request completed",
                    http_method=request.method,
                    http_path=request.url.path,
                    http_status_code=response.status_code,
                    http_duration_ms=round(duration * 1000, 2),
                    correlation_id=correlation_id,
                )
                
                # Add correlation ID to response
                response.headers["X-Correlation-ID"] = correlation_id
                
                return response
                
        except Exception as e:
            duration = time.time() - start_time
            
            # Record error metrics
            self.metrics.record_api_call(
                api=request.url.path,
                method=request.method,
                latency=duration,
                status="error",
            )
            ERROR_COUNTER.inc(
                type="exception",
                component="api",
                stage=f"{request.method}_{request.url.path}",
            )
            
            # Log error
            self.logger.error(
                "Request failed",
                http_method=request.method,
                http_path=request.url.path,
                http_duration_ms=round(duration * 1000, 2),
                error_type=type(e).__name__,
                error_message=str(e),
                correlation_id=correlation_id,
            )
            raise
        finally:
            clear_correlation_id()
