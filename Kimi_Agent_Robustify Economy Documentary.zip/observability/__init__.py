"""
Observability module for the documentary pipeline.

Provides structured logging, metrics, tracing, and health checks.
"""

from __future__ import annotations

from .logging_config import configure_logging, get_logger, LogContext
from .metrics import (
    MetricsCollector,
    PIPELINE_STAGE_DURATION,
    API_CALL_LATENCY,
    ERROR_COUNTER,
    VM_PROVISIONING_TIME,
    LLM_TOKEN_USAGE,
    TOOL_CALL_COUNTER,
    WORKER_HEALTH_STATUS,
    ACTIVE_PIPELINES,
)
from .tracing import TracingManager, get_tracer
from .health import HealthChecker, HealthStatus
from .middleware import CorrelationIdMiddleware, MetricsMiddleware, TracingMiddleware

__all__ = [
    # Logging
    "configure_logging",
    "get_logger",
    "LogContext",
    # Metrics
    "MetricsCollector",
    "PIPELINE_STAGE_DURATION",
    "API_CALL_LATENCY",
    "ERROR_COUNTER",
    "VM_PROVISIONING_TIME",
    "LLM_TOKEN_USAGE",
    "TOOL_CALL_COUNTER",
    "WORKER_HEALTH_STATUS",
    "ACTIVE_PIPELINES",
    # Tracing
    "TracingManager",
    "get_tracer",
    # Health
    "HealthChecker",
    "HealthStatus",
    # Middleware
    "CorrelationIdMiddleware",
    "MetricsMiddleware",
    "TracingMiddleware",
]
