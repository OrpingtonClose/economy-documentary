"""
OpenTelemetry distributed tracing for the documentary pipeline.

Features:
- Automatic span creation for pipeline stages
- Context propagation across async boundaries
- Integration with external trace collectors
- Custom span attributes for pipeline context
"""

from __future__ import annotations

import functools
import os
from contextlib import contextmanager
from typing import Any, Callable, Dict, Optional, TypeVar

# Try to import OpenTelemetry
try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
    from opentelemetry.trace import Status, StatusCode
    from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False

F = TypeVar("F", bound=Callable[..., Any])


class TracingManager:
    """Manages OpenTelemetry tracing configuration."""

    def __init__(
        self,
        service_name: str = "documentary-pipeline",
        service_version: str = "0.1.0",
        exporter_type: str = "console",
        endpoint: Optional[str] = None,
    ):
        self.service_name = service_name
        self.service_version = service_version
        self.exporter_type = exporter_type
        self.endpoint = endpoint
        self._tracer: Optional[Any] = None
        self._provider: Optional[Any] = None
        self._propagator: Optional[Any] = None

    def setup(self) -> None:
        """Set up the tracer provider and exporters."""
        if not OTEL_AVAILABLE:
            print("OpenTelemetry not available, tracing disabled")
            return

        # Create tracer provider
        self._provider = TracerProvider()
        trace.set_tracer_provider(self._provider)

        # Configure exporter
        if self.exporter_type == "console":
            exporter = ConsoleSpanExporter()
        elif self.exporter_type == "otlp":
            try:
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                    OTLPSpanExporter,
                )
                exporter = OTLPSpanExporter(endpoint=self.endpoint or "http://localhost:4318/v1/traces")
            except ImportError:
                print("OTLP exporter not available, falling back to console")
                exporter = ConsoleSpanExporter()
        elif self.exporter_type == "sqlite":
            # Use ADK's SQLite exporter if available
            try:
                from google.adk.telemetry.sqlite_span_exporter import SqliteSpanExporter
                findings_dir = os.environ.get(
                    "FINDINGS_DIR",
                    os.path.join(os.path.expanduser("~"), ".documentary-pipeline"),
                )
                os.makedirs(findings_dir, exist_ok=True)
                exporter = SqliteSpanExporter(db_path=os.path.join(findings_dir, "traces.db"))
            except ImportError:
                print("SQLite exporter not available, falling back to console")
                exporter = ConsoleSpanExporter()
        else:
            exporter = ConsoleSpanExporter()

        # Add span processor
        processor = BatchSpanProcessor(exporter)
        self._provider.add_span_processor(processor)

        # Create propagator for distributed tracing
        self._propagator = TraceContextTextMapPropagator()

        # Get tracer
        self._tracer = trace.get_tracer(self.service_name, self.service_version)

        print(f"Tracing configured: {self.exporter_type} exporter")

    def get_tracer(self) -> Any:
        """Get the tracer instance."""
        if self._tracer is None:
            if OTEL_AVAILABLE:
                return trace.get_tracer(self.service_name, self.service_version)
            return None
        return self._tracer

    def get_propagator(self) -> Any:
        """Get the propagator for distributed context."""
        return self._propagator

    def inject_context(self, carrier: Dict[str, str]) -> None:
        """Inject trace context into a carrier dict."""
        if self._propagator and OTEL_AVAILABLE:
            self._propagator.inject(carrier)

    def extract_context(self, carrier: Dict[str, str]) -> Any:
        """Extract trace context from a carrier dict."""
        if self._propagator and OTEL_AVAILABLE:
            return self._propagator.extract(carrier)
        return None

    def shutdown(self) -> None:
        """Shutdown the tracer provider."""
        if self._provider and OTEL_AVAILABLE:
            self._provider.shutdown()


# Global tracing manager instance
_tracing_manager: Optional[TracingManager] = None


def setup_tracing(
    service_name: str = "documentary-pipeline",
    service_version: str = "0.1.0",
    exporter_type: Optional[str] = None,
    endpoint: Optional[str] = None,
) -> TracingManager:
    """Set up global tracing.
    
    Args:
        service_name: Name of the service
        service_version: Version of the service
        exporter_type: Type of exporter (console, otlp, sqlite)
        endpoint: Optional endpoint URL for OTLP exporter
        
    Returns:
        The configured TracingManager
    """
    global _tracing_manager
    
    # Determine exporter from environment if not specified
    if exporter_type is None:
        if os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT"):
            exporter_type = "otlp"
        elif os.environ.get("TRACING_SQLITE", "0") == "1":
            exporter_type = "sqlite"
        else:
            exporter_type = "console"
    
    _tracing_manager = TracingManager(
        service_name=service_name,
        service_version=service_version,
        exporter_type=exporter_type,
        endpoint=endpoint or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT"),
    )
    _tracing_manager.setup()
    return _tracing_manager


def get_tracer() -> Any:
    """Get the global tracer."""
    global _tracing_manager
    if _tracing_manager is None:
        _tracing_manager = TracingManager()
        _tracing_manager.setup()
    return _tracing_manager.get_tracer()


def get_tracing_manager() -> Optional[TracingManager]:
    """Get the global tracing manager."""
    return _tracing_manager


# Decorators and context managers

def traced(
    span_name: Optional[str] = None,
    attributes: Optional[Dict[str, Any]] = None,
):
    """Decorator to trace a function.
    
    Usage:
        @traced(span_name="process_scenario", attributes={"stage": "scenario"})
        def process_scenario():
            pass
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if not OTEL_AVAILABLE:
                return func(*args, **kwargs)
            
            tracer = get_tracer()
            if tracer is None:
                return func(*args, **kwargs)
            
            name = span_name or func.__name__
            with tracer.start_as_current_span(name) as span:
                # Add attributes
                if attributes:
                    for key, value in attributes.items():
                        span.set_attribute(key, value)
                
                # Add function info
                span.set_attribute("function.name", func.__name__)
                span.set_attribute("function.module", func.__module__)
                
                try:
                    result = func(*args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise
        return wrapper  # type: ignore
    return decorator


@contextmanager
def start_span(
    name: str,
    attributes: Optional[Dict[str, Any]] = None,
    parent_context: Optional[Any] = None,
):
    """Context manager to start a span.
    
    Usage:
        with start_span("process_scenario", attributes={"stage": "scenario"}):
            process_scenario()
    """
    if not OTEL_AVAILABLE:
        yield None
        return
    
    tracer = get_tracer()
    if tracer is None:
        yield None
        return
    
    ctx = parent_context or trace.get_current_span().get_span_context()
    with tracer.start_as_current_span(name) as span:
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)
        try:
            yield span
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise


def set_span_attribute(key: str, value: Any) -> None:
    """Set an attribute on the current span."""
    if not OTEL_AVAILABLE:
        return
    
    current_span = trace.get_current_span()
    if current_span:
        current_span.set_attribute(key, value)


def add_span_event(name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
    """Add an event to the current span."""
    if not OTEL_AVAILABLE:
        return
    
    current_span = trace.get_current_span()
    if current_span:
        current_span.add_event(name, attributes or {})


def record_span_exception(exception: Exception) -> None:
    """Record an exception on the current span."""
    if not OTEL_AVAILABLE:
        return
    
    current_span = trace.get_current_span()
    if current_span:
        current_span.record_exception(exception)
        current_span.set_status(Status(StatusCode.ERROR, str(exception)))


# Pipeline-specific tracing helpers

def trace_pipeline_start(run_id: str, topic: str) -> Any:
    """Start a trace span for a pipeline run.
    
    Args:
        run_id: The pipeline run ID
        topic: The documentary topic
        
    Returns:
        The span context
    """
    if not OTEL_AVAILABLE:
        return None
    
    tracer = get_tracer()
    if tracer is None:
        return None
    
    span = tracer.start_span("pipeline_run")
    span.set_attribute("pipeline.run_id", run_id)
    span.set_attribute("pipeline.topic", topic)
    span.set_attribute("pipeline.type", "documentary")
    
    return span


def trace_pipeline_stage(stage_name: str, run_id: str):
    """Context manager for tracing a pipeline stage.
    
    Usage:
        with trace_pipeline_stage("scenario", run_id="abc"):
            process_scenario()
    """
    return start_span(
        f"pipeline_stage.{stage_name}",
        attributes={"pipeline.stage": stage_name, "pipeline.run_id": run_id},
    )


def trace_tool_call(tool_name: str, agent: str):
    """Context manager for tracing a tool call.
    
    Usage:
        with trace_tool_call("tts_generate", agent="audio_agent"):
            generate_tts()
    """
    return start_span(
        f"tool_call.{tool_name}",
        attributes={"tool.name": tool_name, "tool.agent": agent},
    )


def trace_llm_call(model: str, estimated_tokens: int):
    """Context manager for tracing an LLM call.
    
    Usage:
        with trace_llm_call("gemini-1.5-pro", estimated_tokens=1000):
            call_llm()
    """
    return start_span(
        "llm_call",
        attributes={
            "llm.model": model,
            "llm.estimated_tokens": estimated_tokens,
        },
    )


def trace_vm_operation(operation: str, role: str):
    """Context manager for tracing VM operations.
    
    Usage:
        with trace_vm_operation("provision", role="tts"):
            provision_vm()
    """
    return start_span(
        f"vm_operation.{operation}",
        attributes={"vm.operation": operation, "vm.role": role},
    )
