"""
Prometheus-style metrics collection for the documentary pipeline.

Features:
- Pipeline stage duration histograms
- API call latency tracking
- Error rate counters
- VM provisioning time tracking
- LLM token usage metrics
- Tool call counters
- Worker health status gauges
- Active pipeline gauges
"""

from __future__ import annotations

import functools
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TypeVar

# Metric types
F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class MetricValue:
    """A single metric value with labels."""
    value: float
    labels: Dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class Counter:
    """Prometheus-style counter metric (monotonically increasing)."""

    def __init__(self, name: str, description: str, label_names: Optional[List[str]] = None):
        self.name = name
        self.description = description
        self.label_names = label_names or []
        self._values: Dict[str, float] = {}
        self._lock = False  # Simple lock simulation

    def _key(self, labels: Dict[str, str]) -> str:
        """Generate a key from labels."""
        if not labels:
            return "__default__"
        return ",".join(f"{k}={v}" for k, v in sorted(labels.items()))

    def inc(self, amount: float = 1.0, **labels: str) -> None:
        """Increment the counter."""
        key = self._key(labels)
        self._values[key] = self._values.get(key, 0.0) + amount

    def get(self, **labels: str) -> float:
        """Get the current counter value."""
        key = self._key(labels)
        return self._values.get(key, 0.0)

    def collect(self) -> List[MetricValue]:
        """Collect all counter values."""
        return [
            MetricValue(value=v, labels=self._parse_key(k))
            for k, v in self._values.items()
        ]

    def _parse_key(self, key: str) -> Dict[str, str]:
        """Parse a key back into labels."""
        if key == "__default__":
            return {}
        return dict(part.split("=", 1) for part in key.split(","))

    def to_prometheus(self) -> str:
        """Export counter in Prometheus text format."""
        lines = [f"# HELP {self.name} {self.description}", f"# TYPE {self.name} counter"]
        for key, value in self._values.items():
            labels = self._parse_key(key)
            if labels:
                label_str = ",".join(f'{k}="{v}"' for k, v in labels.items())
                lines.append(f'{self.name}{{{label_str}}} {value}')
            else:
                lines.append(f'{self.name} {value}')
        return "\n".join(lines)


class Histogram:
    """Prometheus-style histogram metric."""

    DEFAULT_BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0, 120.0, 300.0, 600.0]

    def __init__(
        self,
        name: str,
        description: str,
        label_names: Optional[List[str]] = None,
        buckets: Optional[List[float]] = None,
    ):
        self.name = name
        self.description = description
        self.label_names = label_names or []
        self.buckets = sorted(buckets or self.DEFAULT_BUCKETS)
        self._values: Dict[str, Dict[str, Any]] = {}

    def _key(self, labels: Dict[str, str]) -> str:
        """Generate a key from labels."""
        if not labels:
            return "__default__"
        return ",".join(f"{k}={v}" for k, v in sorted(labels.items()))

    def observe(self, value: float, **labels: str) -> None:
        """Observe a value."""
        key = self._key(labels)
        if key not in self._values:
            self._values[key] = {
                "sum": 0.0,
                "count": 0,
                "buckets": {b: 0 for b in self.buckets},
            }
        self._values[key]["sum"] += value
        self._values[key]["count"] += 1
        for bucket in self.buckets:
            if value <= bucket:
                self._values[key]["buckets"][bucket] += 1

    def get(self, **labels: str) -> Dict[str, Any]:
        """Get histogram statistics."""
        key = self._key(labels)
        return self._values.get(key, {"sum": 0.0, "count": 0, "buckets": {}})

    def to_prometheus(self) -> str:
        """Export histogram in Prometheus text format."""
        lines = [f"# HELP {self.name} {self.description}", f"# TYPE {self.name} histogram"]
        
        for key, data in self._values.items():
            labels = self._parse_key(key)
            label_str = ",".join(f'{k}="{v}"' for k, v in labels.items()) if labels else ""
            
            # Bucket counts
            for bucket, count in data["buckets"].items():
                bucket_labels = labels.copy()
                bucket_labels["le"] = str(bucket)
                bucket_label_str = ",".join(f'{k}="{v}"' for k, v in bucket_labels.items())
                lines.append(f'{self.name}_bucket{{{bucket_label_str}}} {count}')
            
            # +Inf bucket
            inf_labels = labels.copy()
            inf_labels["le"] = "+Inf"
            inf_label_str = ",".join(f'{k}="{v}"' for k, v in inf_labels.items())
            lines.append(f'{self.name}_bucket{{{inf_label_str}}} {data["count"]}')
            
            # Sum and count
            if label_str:
                lines.append(f'{self.name}_sum{{{label_str}}} {data["sum"]}')
                lines.append(f'{self.name}_count{{{label_str}}} {data["count"]}')
            else:
                lines.append(f'{self.name}_sum {data["sum"]}')
                lines.append(f'{self.name}_count {data["count"]}')
        
        return "\n".join(lines)

    def _parse_key(self, key: str) -> Dict[str, str]:
        """Parse a key back into labels."""
        if key == "__default__":
            return {}
        return dict(part.split("=", 1) for part in key.split(","))


class Gauge:
    """Prometheus-style gauge metric (can go up and down)."""

    def __init__(self, name: str, description: str, label_names: Optional[List[str]] = None):
        self.name = name
        self.description = description
        self.label_names = label_names or []
        self._values: Dict[str, float] = {}

    def _key(self, labels: Dict[str, str]) -> str:
        """Generate a key from labels."""
        if not labels:
            return "__default__"
        return ",".join(f"{k}={v}" for k, v in sorted(labels.items()))

    def set(self, value: float, **labels: str) -> None:
        """Set the gauge value."""
        key = self._key(labels)
        self._values[key] = value

    def inc(self, amount: float = 1.0, **labels: str) -> None:
        """Increment the gauge."""
        key = self._key(labels)
        self._values[key] = self._values.get(key, 0.0) + amount

    def dec(self, amount: float = 1.0, **labels: str) -> None:
        """Decrement the gauge."""
        key = self._key(labels)
        self._values[key] = self._values.get(key, 0.0) - amount

    def get(self, **labels: str) -> float:
        """Get the current gauge value."""
        key = self._key(labels)
        return self._values.get(key, 0.0)

    def to_prometheus(self) -> str:
        """Export gauge in Prometheus text format."""
        lines = [f"# HELP {self.name} {self.description}", f"# TYPE {self.name} gauge"]
        for key, value in self._values.items():
            labels = self._parse_key(key)
            if labels:
                label_str = ",".join(f'{k}="{v}"' for k, v in labels.items())
                lines.append(f'{self.name}{{{label_str}}} {value}')
            else:
                lines.append(f'{self.name} {value}')
        return "\n".join(lines)

    def _parse_key(self, key: str) -> Dict[str, str]:
        """Parse a key back into labels."""
        if key == "__default__":
            return {}
        return dict(part.split("=", 1) for part in key.split(","))


# Define metrics for the documentary pipeline

# Pipeline stage duration histogram
PIPELINE_STAGE_DURATION = Histogram(
    name="documentary_pipeline_stage_duration_seconds",
    description="Duration of pipeline stages in seconds",
    label_names=["stage", "status"],
    buckets=[1.0, 5.0, 10.0, 30.0, 60.0, 120.0, 300.0, 600.0, 1200.0, 1800.0, 3600.0],
)

# API call latency histogram
API_CALL_LATENCY = Histogram(
    name="documentary_api_call_latency_seconds",
    description="Latency of API calls in seconds",
    label_names=["api", "method", "status"],
    buckets=[0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0],
)

# Error counter
ERROR_COUNTER = Counter(
    name="documentary_errors_total",
    description="Total number of errors",
    label_names=["type", "stage", "component"],
)

# VM provisioning time histogram
VM_PROVISIONING_TIME = Histogram(
    name="documentary_vm_provisioning_duration_seconds",
    description="Time to provision a VM in seconds",
    label_names=["role", "status"],
    buckets=[30.0, 60.0, 120.0, 300.0, 600.0, 900.0, 1200.0, 1800.0, 2700.0, 3600.0],
)

# LLM token usage counter
LLM_TOKEN_USAGE = Counter(
    name="documentary_llm_tokens_total",
    description="Total LLM token usage",
    label_names=["model", "type"],  # type: input/output
)

# Tool call counter
TOOL_CALL_COUNTER = Counter(
    name="documentary_tool_calls_total",
    description="Total tool calls",
    label_names=["tool", "agent", "status"],
)

# Worker health status gauge
WORKER_HEALTH_STATUS = Gauge(
    name="documentary_worker_health",
    description="Worker health status (1=healthy, 0=unhealthy)",
    label_names=["role", "capability"],
)

# Active pipelines gauge
ACTIVE_PIPELINES = Gauge(
    name="documentary_active_pipelines",
    description="Number of active pipelines",
    label_names=["status"],
)

# Pipeline run counter
PIPELINE_RUN_COUNTER = Counter(
    name="documentary_pipeline_runs_total",
    description="Total number of pipeline runs",
    label_names=["status"],
)

# Approval gate wait time histogram
APPROVAL_WAIT_TIME = Histogram(
    name="documentary_approval_wait_seconds",
    description="Time waiting for human approval",
    label_names=["stage"],
    buckets=[1.0, 5.0, 10.0, 30.0, 60.0, 120.0, 300.0, 600.0, 1800.0, 3600.0],
)

# Document generation counter
DOCUMENT_GENERATION_COUNTER = Counter(
    name="documentary_documents_generated_total",
    description="Total documents generated",
    label_names=["type", "status"],
)


class MetricsCollector:
    """Central collector for all metrics."""

    def __init__(self):
        self._metrics: Dict[str, Any] = {
            "pipeline_stage_duration": PIPELINE_STAGE_DURATION,
            "api_call_latency": API_CALL_LATENCY,
            "errors": ERROR_COUNTER,
            "vm_provisioning_time": VM_PROVISIONING_TIME,
            "llm_token_usage": LLM_TOKEN_USAGE,
            "tool_calls": TOOL_CALL_COUNTER,
            "worker_health": WORKER_HEALTH_STATUS,
            "active_pipelines": ACTIVE_PIPELINES,
            "pipeline_runs": PIPELINE_RUN_COUNTER,
            "approval_wait_time": APPROVAL_WAIT_TIME,
            "documents_generated": DOCUMENT_GENERATION_COUNTER,
        }

    def get_all_metrics(self) -> str:
        """Get all metrics in Prometheus text format."""
        lines = []
        for metric in self._metrics.values():
            lines.append(metric.to_prometheus())
        return "\n\n".join(lines)

    def record_pipeline_stage(
        self, stage: str, duration: float, status: str = "success"
    ) -> None:
        """Record a pipeline stage duration."""
        PIPELINE_STAGE_DURATION.observe(duration, stage=stage, status=status)

    def record_api_call(
        self, api: str, method: str, latency: float, status: str = "success"
    ) -> None:
        """Record an API call latency."""
        API_CALL_LATENCY.observe(latency, api=api, method=method, status=status)

    def record_error(self, error_type: str, stage: str = "", component: str = "") -> None:
        """Record an error."""
        ERROR_COUNTER.inc(type=error_type, stage=stage, component=component)

    def record_vm_provisioning(
        self, role: str, duration: float, status: str = "success"
    ) -> None:
        """Record VM provisioning time."""
        VM_PROVISIONING_TIME.observe(duration, role=role, status=status)

    def record_llm_tokens(self, model: str, input_tokens: int, output_tokens: int) -> None:
        """Record LLM token usage."""
        LLM_TOKEN_USAGE.inc(input_tokens, model=model, type="input")
        LLM_TOKEN_USAGE.inc(output_tokens, model=model, type="output")

    def record_tool_call(self, tool: str, agent: str, status: str = "success") -> None:
        """Record a tool call."""
        TOOL_CALL_COUNTER.inc(tool=tool, agent=agent, status=status)

    def set_worker_health(self, role: str, capability: str, healthy: bool) -> None:
        """Set worker health status."""
        WORKER_HEALTH_STATUS.set(1.0 if healthy else 0.0, role=role, capability=capability)

    def set_active_pipelines(self, count: int, status: str = "running") -> None:
        """Set active pipeline count."""
        ACTIVE_PIPELINES.set(count, status=status)

    def record_pipeline_run(self, status: str = "success") -> None:
        """Record a pipeline run."""
        PIPELINE_RUN_COUNTER.inc(status=status)

    def record_approval_wait(self, stage: str, duration: float) -> None:
        """Record approval wait time."""
        APPROVAL_WAIT_TIME.observe(duration, stage=stage)

    def record_document_generated(self, doc_type: str, status: str = "success") -> None:
        """Record document generation."""
        DOCUMENT_GENERATION_COUNTER.inc(type=doc_type, status=status)


# Global metrics collector instance
_metrics_collector: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    """Get the global metrics collector instance."""
    global _metrics_collector
    if _metrics_collector is None:
        _metrics_collector = MetricsCollector()
    return _metrics_collector


# Decorators for easy metric collection

def timed(metric: Histogram, **labels: str):
    """Decorator to time a function and record to a histogram.
    
    Usage:
        @timed(PIPELINE_STAGE_DURATION, stage="scenario")
        def process_scenario():
            pass
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.time()
            try:
                result = func(*args, **kwargs)
                metric.observe(time.time() - start, **labels, status="success")
                return result
            except Exception:
                metric.observe(time.time() - start, **labels, status="error")
                raise
        return wrapper  # type: ignore
    return decorator


def counted(metric: Counter, **labels: str):
    """Decorator to count function calls.
    
    Usage:
        @counted(TOOL_CALL_COUNTER, tool="tts_generate")
        def generate_tts():
            pass
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            metric.inc(**labels)
            return func(*args, **kwargs)
        return wrapper  # type: ignore
    return decorator


@contextmanager
def timed_context(metric: Histogram, **labels: str):
    """Context manager for timing code blocks.
    
    Usage:
        with timed_context(PIPELINE_STAGE_DURATION, stage="scenario"):
            process_scenario()
    """
    start = time.time()
    try:
        yield
        metric.observe(time.time() - start, **labels, status="success")
    except Exception:
        metric.observe(time.time() - start, **labels, status="error")
        raise
