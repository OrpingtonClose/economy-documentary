"""
Structured logging configuration using structlog with correlation IDs.

Features:
- JSON-formatted logs for easy parsing
- Correlation ID propagation across async boundaries
- Context-aware logging with bound fields
- Integration with standard library logging
"""

from __future__ import annotations

import contextvars
import logging
import os
import sys
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Optional

import structlog

# Context variable for correlation ID - works across async boundaries
_correlation_id: contextvars.ContextVar[str] = contextvars.ContextVar(
    "correlation_id", default=""
)

# Context variable for additional log context
_log_context: contextvars.ContextVar[Dict[str, Any]] = contextvars.ContextVar(
    "log_context", default_factory=dict
)


class CorrelationIdFilter(logging.Filter):
    """Add correlation ID to all log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.correlation_id = _correlation_id.get() or "-"
        return True


def get_correlation_id() -> str:
    """Get the current correlation ID."""
    return _correlation_id.get() or "-"


def set_correlation_id(correlation_id: Optional[str] = None) -> str:
    """Set the correlation ID for the current context.
    
    Args:
        correlation_id: The correlation ID to set. If None, generates a new UUID.
        
    Returns:
        The correlation ID that was set.
    """
    cid = correlation_id or str(uuid.uuid4())
    _correlation_id.set(cid)
    return cid


def clear_correlation_id() -> None:
    """Clear the correlation ID from the current context."""
    _correlation_id.set("")


@contextmanager
def LogContext(**kwargs: Any):
    """Context manager for adding fields to log context.
    
    Usage:
        with LogContext(pipeline_id="abc", stage="scenario"):
            logger.info("Processing started")
            # Logs will include pipeline_id and stage fields
    """
    token = None
    try:
        current = _log_context.get().copy()
        current.update(kwargs)
        token = _log_context.set(current)
        yield
    finally:
        if token:
            _log_context.reset(token)


def get_log_context() -> Dict[str, Any]:
    """Get the current log context."""
    return _log_context.get().copy()


def _add_correlation_id(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Add correlation ID to structlog event dict."""
    event_dict["correlation_id"] = _correlation_id.get() or "-"
    return event_dict


def _add_log_context(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Add custom context fields to structlog event dict."""
    context = _log_context.get()
    for key, value in context.items():
        if key not in event_dict:
            event_dict[key] = value
    return event_dict


def _add_timestamp(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Add ISO format timestamp."""
    import datetime
    event_dict["timestamp"] = datetime.datetime.utcnow().isoformat() + "Z"
    return event_dict


def _add_service_info(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Add service information."""
    event_dict.setdefault("service", "documentary-pipeline")
    event_dict.setdefault("version", os.environ.get("SERVICE_VERSION", "0.1.0"))
    event_dict.setdefault("environment", os.environ.get("ENVIRONMENT", "development"))
    return event_dict


def configure_logging(
    log_level: str = "INFO",
    json_format: bool = True,
    enable_console: bool = True,
    log_file: Optional[str] = None,
) -> None:
    """Configure structured logging for the application.
    
    Args:
        log_level: The log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        json_format: Whether to output JSON formatted logs
        enable_console: Whether to log to console
        log_file: Optional file path for logging to file
    """
    # Configure standard library logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, log_level.upper()),
    )

    # Add correlation ID filter to root logger
    root_logger = logging.getLogger()
    root_logger.addFilter(CorrelationIdFilter())

    # Shared processors for all configurations
    shared_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        _add_correlation_id,
        _add_log_context,
        _add_service_info,
    ]

    if json_format:
        # JSON output for production
        structlog.configure(
            processors=shared_processors + [
                structlog.processors.dict_tracebacks,
                structlog.processors.JSONRenderer(),
            ],
            wrapper_class=structlog.make_filtering_bound_logger(
                getattr(logging, log_level.upper())
            ),
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(),
            cache_logger_on_first_use=True,
        )
    else:
        # Console output for development
        structlog.configure(
            processors=shared_processors + [
                structlog.dev.ConsoleRenderer(
                    colors=True,
                    exception_formatter=structlog.dev.plain_traceback,
                ),
            ],
            wrapper_class=structlog.make_filtering_bound_logger(
                getattr(logging, log_level.upper())
            ),
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(),
            cache_logger_on_first_use=True,
        )

    # Configure file logging if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        )
        root_logger.addHandler(file_handler)

    # Get logger and log configuration
    logger = structlog.get_logger()
    logger.info(
        "Logging configured",
        log_level=log_level,
        json_format=json_format,
        log_file=log_file,
    )


def get_logger(name: Optional[str] = None) -> structlog.BoundLogger:
    """Get a structured logger instance.
    
    Args:
        name: Optional logger name
        
    Returns:
        A configured structlog logger
    """
    return structlog.get_logger(name)


# Convenience function for pipeline runs
def start_pipeline_logging(run_id: str, topic: str) -> str:
    """Set up logging context for a new pipeline run.
    
    Args:
        run_id: The pipeline run ID
        topic: The documentary topic
        
    Returns:
        The correlation ID for this pipeline run
    """
    correlation_id = set_correlation_id()
    token = _log_context.set({
        "run_id": run_id,
        "topic": topic,
        "pipeline": "documentary",
    })
    logger = get_logger()
    logger.info(
        "Pipeline logging started",
        run_id=run_id,
        topic=topic,
        correlation_id=correlation_id,
    )
    return correlation_id


def end_pipeline_logging() -> None:
    """Clear logging context after pipeline run."""
    logger = get_logger()
    logger.info("Pipeline logging ended")
    clear_correlation_id()
    _log_context.set({})
