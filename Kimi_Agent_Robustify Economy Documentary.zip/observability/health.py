"""
Health check system for the documentary pipeline.

Features:
- Liveness probe (/health/live) - is the process running
- Readiness probe (/health/ready) - is the service ready to accept traffic
- Comprehensive health check (/health) - full system status
- Custom health checkers for components
"""

from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class HealthStatus(Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class ComponentHealth:
    """Health status for a single component."""
    name: str
    status: HealthStatus
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    last_check: float = field(default_factory=time.time)
    response_time_ms: float = 0.0


@dataclass
class SystemHealth:
    """Overall system health."""
    status: HealthStatus
    version: str
    timestamp: str
    uptime_seconds: float
    components: List[ComponentHealth]
    message: str = ""


class HealthChecker:
    """Manages health checks for all system components."""

    def __init__(self, version: str = "0.1.0"):
        self.version = version
        self._start_time = time.time()
        self._checks: Dict[str, Callable[[], ComponentHealth]] = {}
        self._async_checks: Dict[str, Callable[[], Any]] = {}
        self._component_status: Dict[str, ComponentHealth] = {}

    def register_check(
        self,
        name: str,
        check_func: Callable[[], ComponentHealth],
    ) -> None:
        """Register a synchronous health check.
        
        Args:
            name: Component name
            check_func: Function that returns ComponentHealth
        """
        self._checks[name] = check_func

    def register_async_check(
        self,
        name: str,
        check_func: Callable[[], Any],
    ) -> None:
        """Register an async health check.
        
        Args:
            name: Component name
            check_func: Async function that returns ComponentHealth
        """
        self._async_checks[name] = check_func

    def _check_basic_liveness(self) -> ComponentHealth:
        """Basic liveness check - is the process running."""
        return ComponentHealth(
            name="process",
            status=HealthStatus.HEALTHY,
            message="Process is running",
            details={"pid": os.getpid()},
        )

    def check_liveness(self) -> SystemHealth:
        """Check if the process is alive.
        
        Returns:
            SystemHealth with basic liveness info
        """
        component = self._check_basic_liveness()
        return SystemHealth(
            status=component.status,
            version=self.version,
            timestamp=self._iso_timestamp(),
            uptime_seconds=time.time() - self._start_time,
            components=[component],
            message="Liveness check passed" if component.status == HealthStatus.HEALTHY else "Liveness check failed",
        )

    async def check_readiness(self) -> SystemHealth:
        """Check if the service is ready to accept traffic.
        
        Returns:
            SystemHealth with readiness info
        """
        components = []
        
        # Run all async checks
        for name, check_func in self._async_checks.items():
            start = time.time()
            try:
                component = await check_func()
                component.response_time_ms = (time.time() - start) * 1000
                components.append(component)
            except Exception as e:
                components.append(ComponentHealth(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Health check failed: {str(e)}",
                    response_time_ms=(time.time() - start) * 1000,
                ))
        
        # Run all sync checks
        for name, check_func in self._checks.items():
            start = time.time()
            try:
                component = check_func()
                component.response_time_ms = (time.time() - start) * 1000
                components.append(component)
            except Exception as e:
                components.append(ComponentHealth(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Health check failed: {str(e)}",
                    response_time_ms=(time.time() - start) * 1000,
                ))
        
        # Determine overall status
        status = self._aggregate_status(components)
        
        return SystemHealth(
            status=status,
            version=self.version,
            timestamp=self._iso_timestamp(),
            uptime_seconds=time.time() - self._start_time,
            components=components,
            message="Service is ready" if status == HealthStatus.HEALTHY else "Service not ready",
        )

    async def check_full_health(self) -> SystemHealth:
        """Run all health checks and return comprehensive status.
        
        Returns:
            SystemHealth with full system status
        """
        components = []
        
        # Add basic liveness
        components.append(self._check_basic_liveness())
        
        # Run all async checks
        for name, check_func in self._async_checks.items():
            start = time.time()
            try:
                component = await check_func()
                component.response_time_ms = (time.time() - start) * 1000
                components.append(component)
            except Exception as e:
                components.append(ComponentHealth(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Health check failed: {str(e)}",
                    response_time_ms=(time.time() - start) * 1000,
                ))
        
        # Run all sync checks
        for name, check_func in self._checks.items():
            start = time.time()
            try:
                component = check_func()
                component.response_time_ms = (time.time() - start) * 1000
                components.append(component)
            except Exception as e:
                components.append(ComponentHealth(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Health check failed: {str(e)}",
                    response_time_ms=(time.time() - start) * 1000,
                ))
        
        # Determine overall status
        status = self._aggregate_status(components)
        
        # Generate summary message
        unhealthy = [c for c in components if c.status == HealthStatus.UNHEALTHY]
        degraded = [c for c in components if c.status == HealthStatus.DEGRADED]
        
        if unhealthy:
            message = f"{len(unhealthy)} component(s) unhealthy: {', '.join(c.name for c in unhealthy)}"
        elif degraded:
            message = f"{len(degraded)} component(s) degraded: {', '.join(c.name for c in degraded)}"
        else:
            message = "All components healthy"
        
        return SystemHealth(
            status=status,
            version=self.version,
            timestamp=self._iso_timestamp(),
            uptime_seconds=time.time() - self._start_time,
            components=components,
            message=message,
        )

    def _aggregate_status(self, components: List[ComponentHealth]) -> HealthStatus:
        """Aggregate component statuses into overall status."""
        if not components:
            return HealthStatus.UNKNOWN
        
        statuses = [c.status for c in components]
        
        if any(s == HealthStatus.UNHEALTHY for s in statuses):
            return HealthStatus.UNHEALTHY
        elif any(s == HealthStatus.DEGRADED for s in statuses):
            return HealthStatus.DEGRADED
        elif all(s == HealthStatus.HEALTHY for s in statuses):
            return HealthStatus.HEALTHY
        else:
            return HealthStatus.UNKNOWN

    def _iso_timestamp(self) -> str:
        """Get current timestamp in ISO format."""
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).isoformat()


# Pre-built health check functions

def check_environment_variables(required_vars: List[str]) -> ComponentHealth:
    """Check if required environment variables are set.
    
    Args:
        required_vars: List of required environment variable names
        
    Returns:
        ComponentHealth with check results
    """
    missing = [var for var in required_vars if not os.environ.get(var)]
    
    if missing:
        return ComponentHealth(
            name="environment",
            status=HealthStatus.UNHEALTHY,
            message=f"Missing required environment variables: {', '.join(missing)}",
            details={"missing_vars": missing},
        )
    
    return ComponentHealth(
        name="environment",
        status=HealthStatus.HEALTHY,
        message="All required environment variables are set",
        details={"checked_vars": required_vars},
    )


def check_api_key(api_key_var: str, service_name: str) -> ComponentHealth:
    """Check if an API key is configured.
    
    Args:
        api_key_var: Environment variable name for the API key
        service_name: Name of the service
        
    Returns:
        ComponentHealth with check results
    """
    api_key = os.environ.get(api_key_var)
    
    if not api_key:
        return ComponentHealth(
            name=f"{service_name}_api",
            status=HealthStatus.UNHEALTHY,
            message=f"{service_name} API key not configured ({api_key_var})",
        )
    
    # Mask the key for display
    masked_key = api_key[:4] + "..." + api_key[-4:] if len(api_key) > 8 else "****"
    
    return ComponentHealth(
        name=f"{service_name}_api",
        status=HealthStatus.HEALTHY,
        message=f"{service_name} API key is configured",
        details={"key_preview": masked_key},
    )


async def check_worker_health(url: str, capability: str, role: str) -> ComponentHealth:
    """Check if a worker is healthy.
    
    Args:
        url: Worker URL
        capability: Worker capability (e.g., "tts", "ltx")
        role: Worker role (e.g., "tts", "video")
        
    Returns:
        ComponentHealth with check results
    """
    import aiohttp
    
    health_url = f"{url.rstrip('/')}/health"
    
    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(health_url) as response:
                if response.status != 200:
                    return ComponentHealth(
                        name=f"worker_{role}",
                        status=HealthStatus.UNHEALTHY,
                        message=f"Worker returned status {response.status}",
                        details={"url": url, "status_code": response.status},
                    )
                
                data = await response.json()
                
                if data.get("status") != "ok":
                    return ComponentHealth(
                        name=f"worker_{role}",
                        status=HealthStatus.UNHEALTHY,
                        message=f"Worker status is {data.get('status')}",
                        details={"url": url, "worker_status": data.get("status")},
                    )
                
                loaded_key = f"{capability}_loaded"
                if not data.get(loaded_key, False):
                    return ComponentHealth(
                        name=f"worker_{role}",
                        status=HealthStatus.DEGRADED,
                        message=f"Worker healthy but {capability} model not loaded",
                        details={"url": url, "bootstrap": data.get("bootstrap", {})},
                    )
                
                return ComponentHealth(
                    name=f"worker_{role}",
                    status=HealthStatus.HEALTHY,
                    message=f"{role} worker is healthy and {capability} model is loaded",
                    details={
                        "url": url,
                        "model": data.get("model", "unknown"),
                        "bootstrap_phase": data.get("bootstrap", {}).get("phase"),
                    },
                )
    except asyncio.TimeoutError:
        return ComponentHealth(
            name=f"worker_{role}",
            status=HealthStatus.UNHEALTHY,
            message=f"Worker health check timed out",
            details={"url": url, "timeout": 10},
        )
    except Exception as e:
        return ComponentHealth(
            name=f"worker_{role}",
            status=HealthStatus.UNHEALTHY,
            message=f"Worker health check failed: {str(e)}",
            details={"url": url, "error": str(e)},
        )


def check_database_connection(db_path: str) -> ComponentHealth:
    """Check if the database is accessible.
    
    Args:
        db_path: Path to the SQLite database
        
    Returns:
        ComponentHealth with check results
    """
    import sqlite3
    
    try:
        conn = sqlite3.connect(db_path, timeout=5)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        conn.close()
        
        return ComponentHealth(
            name="database",
            status=HealthStatus.HEALTHY,
            message="Database connection successful",
            details={"db_path": db_path},
        )
    except Exception as e:
        return ComponentHealth(
            name="database",
            status=HealthStatus.UNHEALTHY,
            message=f"Database connection failed: {str(e)}",
            details={"db_path": db_path, "error": str(e)},
        )


def check_disk_space(min_free_gb: float = 1.0) -> ComponentHealth:
    """Check if there's enough disk space.
    
    Args:
        min_free_gb: Minimum free space in GB
        
    Returns:
        ComponentHealth with check results
    """
    import shutil
    
    try:
        stat = shutil.disk_usage("/")
        free_gb = stat.free / (1024 ** 3)
        total_gb = stat.total / (1024 ** 3)
        used_percent = (stat.used / stat.total) * 100
        
        if free_gb < min_free_gb:
            return ComponentHealth(
                name="disk_space",
                status=HealthStatus.UNHEALTHY,
                message=f"Low disk space: {free_gb:.1f}GB free (minimum {min_free_gb}GB)",
                details={
                    "free_gb": free_gb,
                    "total_gb": total_gb,
                    "used_percent": used_percent,
                },
            )
        
        status = HealthStatus.HEALTHY
        if used_percent > 90:
            status = HealthStatus.DEGRADED
        
        return ComponentHealth(
            name="disk_space",
            status=status,
            message=f"Disk space OK: {free_gb:.1f}GB free ({used_percent:.1f}% used)",
            details={
                "free_gb": free_gb,
                "total_gb": total_gb,
                "used_percent": used_percent,
            },
        )
    except Exception as e:
        return ComponentHealth(
            name="disk_space",
            status=HealthStatus.UNHEALTHY,
            message=f"Disk space check failed: {str(e)}",
            details={"error": str(e)},
        )


# Global health checker instance
_health_checker: Optional[HealthChecker] = None


def get_health_checker(version: str = "0.1.0") -> HealthChecker:
    """Get the global health checker instance."""
    global _health_checker
    if _health_checker is None:
        _health_checker = HealthChecker(version=version)
    return _health_checker
