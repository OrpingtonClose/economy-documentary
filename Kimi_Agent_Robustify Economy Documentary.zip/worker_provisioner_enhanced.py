"""
Worker provisioner with observability — automatic GPU worker lifecycle management.

Enhanced with:
- Metrics collection for VM provisioning time
- Distributed tracing for VM operations
- Structured logging with correlation IDs
- Health status reporting

Architecture: **parallel lazy provisioning**

Instead of blocking the entire pipeline until all workers are ready,
provisioning runs in background threads. The pipeline starts immediately
(scenario generation needs no GPU) and each stage waits only for the
specific worker it needs.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shlex
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import Optional
from urllib.error import URLError
from urllib.request import Request, urlopen

# Try to import observability
try:
    from observability import (
        get_logger,
        LogContext,
        get_metrics_collector,
        VM_PROVISIONING_TIME,
        WORKER_HEALTH_STATUS,
        ERROR_COUNTER,
        trace_vm_operation,
        set_span_attribute,
        add_span_event,
        record_span_exception,
    )
    OBSERVABILITY_AVAILABLE = True
except ImportError:
    OBSERVABILITY_AVAILABLE = False

logger = get_logger(__name__) if OBSERVABILITY_AVAILABLE else logging.getLogger(__name__)

_TEST_MODE = os.environ.get("DOCUMENTARY_TEST_MODE", "").strip().lower() in (
    "1",
    "true",
)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class WorkerSpec:
    """Specification for a GPU worker to provision."""

    role: str  # "tts" or "video"
    env_var: str  # e.g. "TTS_WORKER_URL"
    local_port: int  # localhost port for SSH tunnel
    remote_port: int  # port on the GPU VM
    capability: str  # health check key (e.g. "tts", "ltx")
    gpu_type: str = "A100_SXM4"
    min_vram_gb: int = 48
    max_price: float = 2.00
    min_disk_gb: int = 50
    disk_gb: int = 64
    worker_mode: str = "tts"
    vm_id: str = ""
    ssh_host: str = ""
    ssh_port: int = 0
    tunnel_proc: Optional[subprocess.Popen] = field(default=None, repr=False)
    # Parallel provisioning status
    status: str = "pending"  # "pending", "provisioning", "healthy", "failed"
    error: str = ""  # error message if status == "failed"
    ready_event: threading.Event = field(default_factory=threading.Event)
    # Bootstrap error detail
    bootstrap_error: str = ""
    bootstrap_error_category: str = ""  # "auth", "network", "disk", "missing_file", "runtime"
    # Observability
    provisioning_start_time: float = 0.0
    provisioning_end_time: float = 0.0


# ---------------------------------------------------------------------------
# Model manifest
# ---------------------------------------------------------------------------

def _load_model_manifest() -> dict:
    """Load config/model_manifest.json if available."""
    manifest_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "config", "model_manifest.json",
    )
    try:
        with open(manifest_path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning("Could not load model manifest from %s: %s", manifest_path, e)
        return {}


_FULL_MANIFEST = _load_model_manifest()
_MODEL_MANIFEST = _FULL_MANIFEST.get("models", {})


def _parse_version(v: str) -> tuple:
    """Parse a version string into a comparable tuple."""
    v = v.split("+")[0]
    parts = []
    for p in v.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            break
    return tuple(parts)


def resolve_docker_image(worker_mode: str) -> tuple[str, str]:
    """Pick the best Docker image for a worker mode from the model manifest."""
    model_spec = None
    for _key, spec in _MODEL_MANIFEST.items():
        if spec.get("worker_mode") == worker_mode:
            model_spec = spec
            break

    default_image = "pytorch/pytorch:2.10.0-cuda12.6-cudnn9-devel"
    default_index = "https://download.pytorch.org/whl/cu126"

    if not model_spec:
        logger.warning(
            "No model manifest entry for worker_mode=%s, using default image %s",
            worker_mode, default_image,
        )
        return default_image, default_index

    min_torch = _parse_version(model_spec.get("min_torch", "2.6.0"))
    min_cuda = _parse_version(model_spec.get("min_cuda", "12.4"))
    wheel_suffix = model_spec.get("torch_wheel_suffix", "cu126")
    torch_index = f"https://download.pytorch.org/whl/{wheel_suffix}"

    images = _FULL_MANIFEST.get("docker_images", {}).get("images", [])
    for img in images:
        img_torch = _parse_version(img.get("torch_version", "0.0.0"))
        img_cuda = _parse_version(img.get("cuda_version", "0.0"))
        if img_torch >= min_torch and img_cuda >= min_cuda:
            tag = img["tag"]
            logger.info(
                "Resolved Docker image for %s: %s (torch %s >= %s, cuda %s >= %s)",
                worker_mode, tag,
                img.get("torch_version"), model_spec.get("min_torch"),
                img.get("cuda_version"), model_spec.get("min_cuda"),
            )
            return tag, torch_index

    if images:
        fallback = images[0]["tag"]
        logger.warning(
            "No image satisfies min_torch=%s min_cuda=%s for %s, falling back to %s",
            model_spec.get("min_torch"), model_spec.get("min_cuda"),
            worker_mode, fallback,
        )
        return fallback, torch_index

    logger.warning("No docker_images in manifest, using default %s", default_image)
    return default_image, default_index


# ---------------------------------------------------------------------------
# Default worker specs
# ---------------------------------------------------------------------------

TTS_SPEC = WorkerSpec(
    role="tts",
    env_var="TTS_WORKER_URL",
    local_port=8880,
    remote_port=8880,
    capability="tts",
    gpu_type="RTX_4000",
    min_vram_gb=8,
    max_price=1.00,
    min_disk_gb=50,
    disk_gb=64,
    worker_mode="tts",
)

VIDEO_SPEC = WorkerSpec(
    role="video",
    env_var="GPU_WORKER_URL",
    local_port=8881,
    remote_port=8880,
    capability="ltx",
    gpu_type="A100_SXM4",
    min_vram_gb=80,
    max_price=5.00,
    min_disk_gb=200,
    disk_gb=224,
    worker_mode="ltx",
)


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

def check_worker_health(url: str, capability: str, timeout: int = 10) -> bool:
    """Check if a worker at the given URL is healthy and has the capability loaded."""
    health_url = f"{url.rstrip('/')}/health"
    try:
        req = Request(health_url)
        with urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode())
        if data.get("status") != "ok":
            return False
        loaded_key = f"{capability}_loaded"
        return bool(data.get(loaded_key, False))
    except (URLError, OSError, json.JSONDecodeError, TimeoutError, Exception):
        return False


def check_worker_reachable(url: str, timeout: int = 5) -> bool:
    """Check if a worker URL is reachable."""
    health_url = f"{url.rstrip('/')}/health"
    try:
        req = Request(health_url)
        with urlopen(req, timeout=timeout) as resp:
            resp.read()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Vast.ai account & budget
# ---------------------------------------------------------------------------

_CREDIT_RESERVE = 5.0
_ESTIMATED_RUN_HOURS = 2.0
_TTS_PRICE_CEILING = 1.00
_VIDEO_PRICE_CEILING = 10.00
_TTS_BUDGET_WEIGHT = 0.10
_VIDEO_BUDGET_WEIGHT = 0.90


def get_account_credits() -> float:
    """Query Vast.ai account and return available credit balance in USD."""
    result = _vast_cmd(["show", "user", "--raw"])
    if isinstance(result, dict):
        credit = float(result.get("credit", 0.0))
        balance = float(result.get("balance", 0.0))
        total = credit + balance
        logger.info(
            "Vast.ai account: credit=$%.2f, balance=$%.2f, total=$%.2f",
            credit, balance, total,
        )
        return total
    raise RuntimeError(f"Could not read Vast.ai account info: {result}")


def calculate_weighted_budgets(
    estimated_hours: float = _ESTIMATED_RUN_HOURS,
) -> tuple[float, float]:
    """Calculate per-worker $/hr budgets weighted by GPU tier."""
    credits = get_account_credits()
    usable = credits - _CREDIT_RESERVE
    if usable <= 0:
        raise RuntimeError(
            f"Insufficient Vast.ai credits: ${credits:.2f} "
            f"(reserve=${_CREDIT_RESERVE:.2f}). "
            f"Top up at https://cloud.vast.ai/billing/"
        )

    total_hourly = usable / max(estimated_hours, 0.5)

    tts_budget = min(total_hourly * _TTS_BUDGET_WEIGHT, _TTS_PRICE_CEILING)
    video_budget = min(total_hourly * _VIDEO_BUDGET_WEIGHT, _VIDEO_PRICE_CEILING)

    combined = tts_budget + video_budget
    if combined > total_hourly:
        scale = total_hourly / combined
        tts_budget *= scale
        video_budget *= scale

    logger.info(
        "Weighted budget: $%.2f usable / %.1fh = $%.2f/hr total. "
        "TTS: $%.2f/hr (weight %.0f%%, ceiling $%.2f). "
        "Video: $%.2f/hr (weight %.0f%%, ceiling $%.2f).",
        usable, estimated_hours, total_hourly,
        tts_budget, _TTS_BUDGET_WEIGHT * 100, _TTS_PRICE_CEILING,
        video_budget, _VIDEO_BUDGET_WEIGHT * 100, _VIDEO_PRICE_CEILING,
    )
    return tts_budget, video_budget


def calculate_budget_per_worker(
    num_workers: int,
    estimated_hours: float = _ESTIMATED_RUN_HOURS,
) -> float:
    """Legacy equal-split budget."""
    credits = get_account_credits()
    usable = credits - _CREDIT_RESERVE
    if usable <= 0:
        raise RuntimeError(
            f"Insufficient Vast.ai credits: ${credits:.2f} "
            f"(reserve=${_CREDIT_RESERVE:.2f}). "
            f"Top up at https://cloud.vast.ai/billing/"
        )
    budget = usable / max(num_workers, 1) / max(estimated_hours, 0.5)
    capped = min(budget, _VIDEO_PRICE_CEILING)
    return capped


# ---------------------------------------------------------------------------
# Vast.ai provisioning
# ---------------------------------------------------------------------------

def _vast_cmd(args: list[str]) -> dict | list | str:
    """Run a vastai CLI command and return parsed output."""
    api_key = os.environ.get("VAST_API_KEY", "")
    if not api_key:
        raise RuntimeError("VAST_API_KEY not set — cannot provision GPU workers")

    cmd = ["vastai", "--api-key", api_key] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            raise RuntimeError(
                f"vastai command failed (rc={result.returncode}): "
                f"{result.stderr[:500]}"
            )
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return result.stdout.strip()
    except FileNotFoundError:
        raise RuntimeError("vastai CLI not installed")
    except subprocess.TimeoutExpired:
        raise RuntimeError("vastai command timed out")


def provision_vm(spec: WorkerSpec, excluded_offer_ids: set[int] | None = None) -> int:
    """Provision a Vast.ai GPU VM for the given worker spec with observability."""
    start_time = time.time()
    spec.provisioning_start_time = start_time
    
    # Start tracing span if available
    trace_ctx = None
    if OBSERVABILITY_AVAILABLE:
        trace_ctx = trace_vm_operation("provision", spec.role)
        trace_ctx.__enter__()
    
    try:
        logger.info(
            "Provisioning %s worker: gpu=%s, vram>=%dGB, max $%.2f/hr, "
            "disk>=%dGB (--disk %d)",
            spec.role, spec.gpu_type, spec.min_vram_gb, spec.max_price,
            spec.min_disk_gb, spec.disk_gb,
        )
        
        if OBSERVABILITY_AVAILABLE:
            set_span_attribute("vm.gpu_type", spec.gpu_type)
            set_span_attribute("vm.min_vram_gb", spec.min_vram_gb)
            set_span_attribute("vm.max_price", spec.max_price)
            add_span_event("provisioning_started", {
                "role": spec.role,
                "gpu_type": spec.gpu_type,
            })

        # Search for offers
        vram_gb = spec.min_vram_gb
        vram_mb = spec.min_vram_gb * 1024
        query = (
            f"gpu_name={spec.gpu_type} "
            f"gpu_ram>={vram_gb} "
            f"dph_total<={spec.max_price} "
            f"rentable=true "
            f"reliability>0.95 "
            f"inet_down>200 "
            f"disk_space>={spec.min_disk_gb}"
        )

        search_result = _vast_cmd([
            "search", "offers",
            "--type", "on-demand",
            "--order", "inet_down-",
            "--raw",
            query,
        ])

        offers = search_result if isinstance(search_result, list) else []

        # Broaden search if no offers
        if not offers:
            logger.warning(
                "No %s offers found, broadening search to any GPU with >=%dGB VRAM",
                spec.gpu_type, spec.min_vram_gb,
            )
            query = (
                f"gpu_ram>={vram_gb} "
                f"dph_total<={spec.max_price} "
                f"rentable=true "
                f"reliability>0.90 "
                f"inet_down>100 "
                f"disk_space>={spec.min_disk_gb}"
            )
            search_result = _vast_cmd([
                "search", "offers",
                "--type", "on-demand",
                "--order", "inet_down-",
                "--raw",
                query,
            ])
            offers = search_result if isinstance(search_result, list) else []

        # Python-side filtering
        if offers:
            filtered = []
            for o in offers:
                o_vram = float(o.get("gpu_ram", 0))
                o_price = float(o.get("dph_total", 999))
                o_disk = float(o.get("disk_space", 0))
                if (
                    o_vram >= vram_mb
                    and o_price <= spec.max_price
                    and o_disk >= spec.min_disk_gb
                ):
                    filtered.append(o)
            offers = filtered

        # Exclude previously-tried offers
        if excluded_offer_ids and offers:
            offers = [o for o in offers if int(o.get("id", 0)) not in excluded_offer_ids]

        if not offers:
            raise RuntimeError(
                f"No GPU offers found for {spec.role} worker "
                f"(min {spec.min_vram_gb}GB VRAM, max ${spec.max_price:.2f}/hr, "
                f"min disk {spec.min_disk_gb}GB). "
                f"VRAM floor is non-negotiable (no quantisation). "
                f"Current account budget allows up to ${spec.max_price:.2f}/hr."
            )

        # Sort and select best offer
        sorted_offers = sorted(
            offers,
            key=lambda o: (-float(o.get("inet_down", 0)), float(o.get("dph_total", 999))),
        )
        best = sorted_offers[0]
        offer_id = int(best.get("id", 0))

        logger.info(
            "Selected offer %s: %s %dx, %.1fGB VRAM, $%.3f/hr, %.0fGB disk",
            offer_id,
            best.get("gpu_name", "unknown"),
            best.get("num_gpus", 1),
            float(best.get("gpu_ram", 0)) / 1024,
            float(best.get("dph_total", 0)),
            float(best.get("disk_space", 0)),
        )
        
        if OBSERVABILITY_AVAILABLE:
            set_span_attribute("vm.offer_id", offer_id)
            set_span_attribute("vm.gpu_name", best.get("gpu_name", "unknown"))
            add_span_event("offer_selected", {
                "offer_id": offer_id,
                "gpu_name": best.get("gpu_name"),
            })

        # Create instance
        b2_key_id = os.environ.get("B2_KEY_ID", "")
        b2_app_key = os.environ.get("B2_APPLICATION_KEY", "")
        dashscope_key = os.environ.get("DASHSCOPE_API_KEY", "")
        openrouter_key = os.environ.get("OPENROUTER_API_KEY", "")

        # Auto-detect git branch
        try:
            _branch = subprocess.check_output(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=os.path.dirname(os.path.abspath(__file__)),
                text=True,
            ).strip()
            if not _branch or _branch == "HEAD":
                _branch = "main"
        except Exception:
            _branch = "main"
        logger.info("VMs will clone branch: %s", _branch)

        # Resolve Docker image
        _docker_image, _torch_index = resolve_docker_image(spec.worker_mode)
        logger.info("Docker image for %s worker: %s", spec.role, _docker_image)
        
        if OBSERVABILITY_AVAILABLE:
            set_span_attribute("vm.docker_image", _docker_image)

        # Look up min_torch
        _min_torch = "2.7.0"
        for _key, _mspec in _MODEL_MANIFEST.items():
            if _mspec.get("worker_mode") == spec.worker_mode:
                _min_torch = _mspec.get("min_torch", "2.7.0")
                break

        # Build onstart command
        onstart = (
            f"export B2_KEY_ID={shlex.quote(b2_key_id)} && "
            f"export B2_APPLICATION_KEY={shlex.quote(b2_app_key)} && "
            f"export WORKER_MODE={shlex.quote(spec.worker_mode)} && "
            f"export DASHSCOPE_API_KEY={shlex.quote(dashscope_key)} && "
            f"export OPENROUTER_API_KEY={shlex.quote(openrouter_key)} && "
            f"export TORCH_INDEX={shlex.quote(_torch_index)} && "
            f"export MIN_TORCH_VERSION={shlex.quote(_min_torch)} && "
            "export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True && "
            "apt-get update && apt-get install -y git curl ffmpeg libsndfile1 sox libsox-dev && "
            f"git clone -b {shlex.quote(_branch)} --single-branch "
            "https://github.com/OrpingtonClose/economy-documentary.git "
            "/workspace/economy-documentary 2>/dev/null || "
            f"(cd /workspace/economy-documentary && git fetch origin {shlex.quote(_branch)} && "
            f"git checkout {shlex.quote(_branch)} && git pull origin {shlex.quote(_branch)}) && "
            "python3 -c 'import torch; print(f\"torch {torch.__version__} from {torch.__file__}\")' && "
            "pip install --break-system-packages --no-cache-dir "
            "'fastapi>=0.100.0' 'uvicorn>=0.20.0' 'pydantic>=2.0.0' "
            "'numpy>=1.26.0,<2.0.0' 'soundfile>=0.12.0' && "
            "python3 -c \""
            "import os,site,pathlib;"
            "nv_dirs=[str(p) for sp in site.getsitepackages() "
            "for p in pathlib.Path(sp,'nvidia').glob('*/lib') if p.is_dir()];"
            "open('/etc/ld.so.conf.d/nvidia-pip.conf','w').write(chr(10).join(nv_dirs)+chr(10)) if nv_dirs else None;"
            "print(f'Registered {len(nv_dirs)} nvidia lib dirs')\" && "
            "ldconfig && "
            "python3 /workspace/economy-documentary/scripts/gpu_worker.py "
            f"--mode {shlex.quote(spec.worker_mode)} --port {spec.remote_port}"
        )

        # Generate label
        import uuid as _uuid
        _run_id = os.environ.get("DOCUMENTARY_RUN_ID", _uuid.uuid4().hex[:8])
        _label = f"documentary-{spec.role}-{_run_id}"

        # Create instance
        create_result = _vast_cmd([
            "create", "instance",
            str(offer_id),
            "--image", _docker_image,
            "--disk", str(spec.disk_gb),
            "--ssh",
            "--direct",
            "--label", _label,
            "--onstart-cmd", onstart,
        ])
        logger.info("VM label: %s", _label)
        
        if OBSERVABILITY_AVAILABLE:
            set_span_attribute("vm.label", _label)
            add_span_event("instance_created", {"label": _label})

        # Parse response
        if isinstance(create_result, dict):
            instance_id = create_result.get("new_contract")
            if instance_id:
                spec.vm_id = str(instance_id)
                try:
                    from tools.vastai_tools import register_owned_vm
                    register_owned_vm(spec.vm_id)
                except ImportError:
                    pass
                
                duration = time.time() - start_time
                spec.provisioning_end_time = time.time()
                
                logger.info("VM provisioned: instance_id=%s", spec.vm_id)
                
                if OBSERVABILITY_AVAILABLE:
                    set_span_attribute("vm.instance_id", spec.vm_id)
                    add_span_event("provisioning_complete", {
                        "instance_id": spec.vm_id,
                        "duration_seconds": duration,
                    })
                
                return offer_id

        if isinstance(create_result, str) and "new_contract" in create_result:
            match = re.search(r"'new_contract'\s*:\s*(\d+)", create_result)
            if match:
                spec.vm_id = match.group(1)
                try:
                    from tools.vastai_tools import register_owned_vm
                    register_owned_vm(spec.vm_id)
                except ImportError:
                    pass
                
                duration = time.time() - start_time
                spec.provisioning_end_time = time.time()
                
                logger.info("VM provisioned: instance_id=%s (parsed from text)", spec.vm_id)
                
                if OBSERVABILITY_AVAILABLE:
                    set_span_attribute("vm.instance_id", spec.vm_id)
                    add_span_event("provisioning_complete", {
                        "instance_id": spec.vm_id,
                        "duration_seconds": duration,
                    })
                
                return offer_id

        raise RuntimeError(
            f"Failed to provision {spec.role} VM: unexpected response: {create_result}"
        )
        
    except Exception as e:
        duration = time.time() - start_time
        
        if OBSERVABILITY_AVAILABLE:
            ERROR_COUNTER.inc(type="vm_error", stage="provision", component=spec.role)
            record_span_exception(e)
            add_span_event("provisioning_failed", {
                "error": str(e),
                "duration_seconds": duration,
            })
        
        logger.error("VM provisioning failed: %s", e)
        raise
    finally:
        if trace_ctx:
            trace_ctx.__exit__(None, None, None)


def wait_for_vm_running(spec: WorkerSpec, timeout: int = 600) -> dict:
    """Wait for a provisioned VM to reach 'running' status."""
    logger.info(
        "Waiting for %s VM %s to start (timeout %ds)...",
        spec.role, spec.vm_id, timeout,
    )
    start = time.time()
    while time.time() - start < timeout:
        try:
            result = _vast_cmd(["show", "instance", spec.vm_id, "--raw"])
            if isinstance(result, dict):
                status = result.get(
                    "actual_status", result.get("status_msg", "unknown")
                )
                elapsed = int(time.time() - start)
                logger.info(
                    "  %s VM %s: status=%s (%ds)",
                    spec.role, spec.vm_id, status, elapsed,
                )
                if status == "running":
                    spec.ssh_host = result.get("ssh_host", "")
                    spec.ssh_port = int(result.get("ssh_port", 0))
                    return result
        except Exception as exc:
            logger.warning("  Error checking VM status: %s", exc)

        time.sleep(15)

    raise RuntimeError(
        f"{spec.role} VM {spec.vm_id} did not reach 'running' "
        f"within {timeout}s"
    )


# ---------------------------------------------------------------------------
# SSH tunnel management
# ---------------------------------------------------------------------------

def setup_ssh_tunnel(
    spec: WorkerSpec, max_retries: int = 12, retry_delay: int = 15,
) -> subprocess.Popen:
    """Set up an SSH tunnel from localhost:local_port to the GPU VM."""
    if not spec.ssh_host or not spec.ssh_port:
        raise RuntimeError(
            f"Cannot set up SSH tunnel for {spec.role}: "
            f"no SSH connection details (host={spec.ssh_host}, port={spec.ssh_port})"
        )

    # Collect SSH identity files
    _ssh_keys: list[str] = []
    for _name in ("id_rsa", "id_ed25519"):
        _path = os.path.expanduser(f"~/.ssh/{_name}")
        if os.path.exists(_path):
            _ssh_keys.append(_path)
    if not _ssh_keys:
        raise RuntimeError(
            f"Cannot set up SSH tunnel for {spec.role}: "
            f"no SSH identity file found at ~/.ssh/id_rsa or ~/.ssh/id_ed25519"
        )

    def _build_tunnel_cmd(key_path: str) -> list[str]:
        return [
            "ssh",
            "-i", key_path,
            "-o", "IdentitiesOnly=yes",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "ServerAliveInterval=30",
            "-o", "ServerAliveCountMax=3",
            "-N",
            "-L", f"{spec.local_port}:localhost:{spec.remote_port}",
            "-p", str(spec.ssh_port),
            f"root@{spec.ssh_host}",
        ]

    last_err = ""
    for attempt in range(1, max_retries + 1):
        _ssh_key = _ssh_keys[(attempt - 1) % len(_ssh_keys)]
        tunnel_cmd = _build_tunnel_cmd(_ssh_key)

        logger.info(
            "Setting up SSH tunnel (attempt %d/%d, key=%s): "
            "localhost:%d -> %s:%d (via %s:%d)",
            attempt, max_retries, os.path.basename(_ssh_key),
            spec.local_port, spec.ssh_host, spec.remote_port,
            spec.ssh_host, spec.ssh_port,
        )

        proc = subprocess.Popen(
            tunnel_cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

        time.sleep(3)

        if proc.poll() is not None:
            last_err = proc.stderr.read().decode() if proc.stderr else ""
            logger.warning(
                "SSH tunnel attempt %d/%d for %s failed: %s",
                attempt, max_retries, spec.role, last_err.strip(),
            )
            if attempt < max_retries:
                time.sleep(retry_delay)
                continue
            raise RuntimeError(
                f"SSH tunnel for {spec.role} failed after {max_retries} attempts: {last_err}"
            )

        if proc.stderr:
            proc.stderr.close()

        spec.tunnel_proc = proc
        logger.info(
            "SSH tunnel established: localhost:%d -> %s VM %s",
            spec.local_port, spec.role, spec.vm_id,
        )
        return proc

    raise RuntimeError(
        f"SSH tunnel for {spec.role} failed after {max_retries} attempts: {last_err}"
    )


# ---------------------------------------------------------------------------
# Wait for worker health
# ---------------------------------------------------------------------------

def _get_worker_health_detail(url: str, timeout: int = 10) -> dict | None:
    """Fetch full health JSON from a worker."""
    health_url = f"{url.rstrip('/')}/health"
    try:
        req = Request(health_url)
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return None


def wait_for_worker_healthy(
    spec: WorkerSpec,
    timeout: int = 900,
    poll_interval: int = 15,
) -> bool:
    """Wait for a worker to become healthy after provisioning with observability."""
    url = f"http://localhost:{spec.local_port}"
    logger.info(
        "Waiting for %s worker at %s to become healthy (timeout %ds)...",
        spec.role, url, timeout,
    )
    
    start = time.time()
    last_status = "unknown"
    last_bootstrap_phase = ""
    
    while time.time() - start < timeout:
        elapsed = int(time.time() - start)

        # Check if tunnel is still alive
        if spec.tunnel_proc and spec.tunnel_proc.poll() is not None:
            logger.warning("SSH tunnel for %s died — restarting...", spec.role)
            try:
                setup_ssh_tunnel(spec)
            except Exception as exc:
                logger.error("Failed to restart tunnel: %s", exc)

        # Fetch health detail
        health_data = _get_worker_health_detail(url, timeout=10)

        if health_data is not None:
            # Bootstrap error escalation
            bootstrap = health_data.get("bootstrap") or {}
            bootstrap_phase = bootstrap.get("phase", "")
            bootstrap_error = bootstrap.get("error", "")
            bootstrap_category = bootstrap.get("error_category", "")

            if bootstrap_phase == "error":
                logger.error(
                    "BOOTSTRAP FAILED on %s worker (category=%s): %s",
                    spec.role, bootstrap_category, bootstrap_error,
                )
                spec.bootstrap_error = bootstrap_error
                spec.bootstrap_error_category = bootstrap_category
                
                if OBSERVABILITY_AVAILABLE:
                    ERROR_COUNTER.inc(
                        type="bootstrap_error",
                        stage="worker_health",
                        component=spec.role,
                    )
                    WORKER_HEALTH_STATUS.set(0.0, role=spec.role, capability=spec.capability)
                
                return False

            # Log phase transitions
            if bootstrap_phase and bootstrap_phase != last_bootstrap_phase:
                logger.info(
                    "  %s worker bootstrap phase: %s — %s (%ds)",
                    spec.role, bootstrap_phase,
                    bootstrap.get("detail", ""), elapsed,
                )
                last_bootstrap_phase = bootstrap_phase

            # Check if model is loaded
            if health_data.get("status") == "ok":
                loaded_key = f"{spec.capability}_loaded"
                if health_data.get(loaded_key, False):
                    duration = time.time() - start
                    logger.info(
                        "%s worker at %s is HEALTHY after %ds",
                        spec.role, url, elapsed,
                    )
                    
                    if OBSERVABILITY_AVAILABLE:
                        # Record metrics
                        metrics = get_metrics_collector()
                        metrics.record_vm_provisioning(
                            role=spec.role,
                            duration=duration + (spec.provisioning_end_time - spec.provisioning_start_time),
                            status="success",
                        )
                        WORKER_HEALTH_STATUS.set(1.0, role=spec.role, capability=spec.capability)
                    
                    return True
                if last_status != "reachable_not_loaded":
                    logger.info(
                        "  %s worker reachable but model not loaded yet (%ds)",
                        spec.role, elapsed,
                    )
                    last_status = "reachable_not_loaded"
        else:
            if last_status != "unreachable":
                logger.info(
                    "  %s worker not yet reachable (%ds) — "
                    "VM still bootstrapping...",
                    spec.role, elapsed,
                )
                last_status = "unreachable"

        time.sleep(poll_interval)

    logger.error(
        "%s worker at %s did not become healthy within %ds",
        spec.role, url, timeout,
    )
    
    if OBSERVABILITY_AVAILABLE:
        ERROR_COUNTER.inc(type="health_timeout", stage="worker_health", component=spec.role)
        WORKER_HEALTH_STATUS.set(0.0, role=spec.role, capability=spec.capability)
    
    return False


# ---------------------------------------------------------------------------
# High-level orchestrator — parallel lazy provisioning
# ---------------------------------------------------------------------------


class WorkerProvisioner:
    """Manages the full lifecycle of GPU workers for the pipeline with observability."""

    def __init__(self) -> None:
        self._specs: list[WorkerSpec] = []
        self._lock = threading.Lock()
        self._provisioned = False
        self._threads: dict[str, threading.Thread] = {}
        self._provision_start_error: str = ""
        self._specs_ready = threading.Event()
        
        # Observability
        if OBSERVABILITY_AVAILABLE:
            self.metrics = get_metrics_collector()
        else:
            self.metrics = None

    def start_provisioning(
        self,
        require_tts: bool = True,
        require_video: bool = True,
    ) -> None:
        """Start provisioning workers in parallel background threads."""
        self._provision_start_error = ""
        self._specs_ready.clear()

        try:
            # Calculate budgets
            tts_budget, video_budget = calculate_weighted_budgets()
            TTS_SPEC.max_price = tts_budget
            VIDEO_SPEC.max_price = video_budget

            # Determine which workers to provision
            specs_to_provision: list[WorkerSpec] = []
            if require_tts:
                specs_to_provision.append(TTS_SPEC)
            if require_video:
                specs_to_provision.append(VIDEO_SPEC)

            with self._lock:
                self._specs = specs_to_provision
                for spec in self._specs:
                    spec.status = "provisioning"

            # Start provisioning threads
            for spec in specs_to_provision:
                t = threading.Thread(
                    target=self._provision_worker_thread,
                    args=(spec,),
                    name=f"provision-{spec.role}",
                    daemon=True,
                )
                self._threads[spec.role] = t
                t.start()
                logger.info("Started provisioning thread for %s worker", spec.role)

            self._provisioned = True

        except Exception as exc:
            logger.error("Failed to start worker provisioning: %s", exc)
            self._provision_start_error = str(exc)
            for spec in self._specs:
                spec.status = "failed"
                spec.error = str(exc)
                spec.ready_event.set()
        finally:
            self._specs_ready.set()

    def _provision_worker_thread(self, spec: WorkerSpec) -> None:
        """Background thread to provision a single worker."""
        logger.info("Provisioning thread started for %s worker", spec.role)
        
        # Start tracing span if available
        trace_ctx = None
        if OBSERVABILITY_AVAILABLE:
            trace_ctx = trace_vm_operation("full_provisioning", spec.role)
            trace_ctx.__enter__()
        
        try:
            # Provision VM
            provision_vm(spec)
            
            # Wait for VM to be running
            wait_for_vm_running(spec)
            
            # Setup SSH tunnel
            setup_ssh_tunnel(spec)
            
            # Wait for worker to be healthy
            healthy = wait_for_worker_healthy(spec)
            
            if healthy:
                spec.status = "healthy"
                logger.info("%s worker is ready", spec.role)
            else:
                spec.status = "failed"
                spec.error = spec.bootstrap_error or "Worker did not become healthy"
                logger.error("%s worker failed to become healthy", spec.role)
                
                if OBSERVABILITY_AVAILABLE:
                    ERROR_COUNTER.inc(type="worker_unhealthy", stage="provisioning", component=spec.role)
            
            spec.ready_event.set()
            
        except Exception as exc:
            logger.error("Provisioning failed for %s worker: %s", spec.role, exc)
            spec.status = "failed"
            spec.error = str(exc)
            spec.ready_event.set()
            
            if OBSERVABILITY_AVAILABLE:
                ERROR_COUNTER.inc(type="provisioning_error", stage="provisioning", component=spec.role)
                if trace_ctx:
                    record_span_exception(exc)
        finally:
            if trace_ctx:
                trace_ctx.__exit__(None, None, None)

    def wait_for_worker(self, role: str, timeout: int = 2700) -> None:
        """Wait for a specific worker to be ready."""
        logger.info("Waiting for %s worker to be ready...", role)
        
        # Wait for specs to be populated
        specs_ready = self._specs_ready.wait(timeout=120)
        if not specs_ready:
            raise RuntimeError("Timeout waiting for provisioning to start")

        if self._provision_start_error:
            raise RuntimeError(f"Provisioning failed to start: {self._provision_start_error}")

        # Find the spec
        spec = None
        with self._lock:
            for s in self._specs:
                if s.role == role:
                    spec = s
                    break

        if spec is None:
            raise RuntimeError(f"No worker spec found for role: {role}")

        # Wait for the worker to be ready
        ready = spec.ready_event.wait(timeout=timeout)
        if not ready:
            raise RuntimeError(f"Timeout waiting for {role} worker to be ready")

        if spec.status != "healthy":
            raise RuntimeError(f"{role} worker failed: {spec.error}")

        logger.info("%s worker is ready", role)

    def get_worker_status(self) -> dict:
        """Get the status of all workers."""
        with self._lock:
            return {
                spec.role: {
                    "status": spec.status,
                    "error": spec.error,
                    "vm_id": spec.vm_id,
                    "healthy": spec.status == "healthy",
                }
                for spec in self._specs
            }

    def cleanup(self) -> None:
        """Cleanup all workers and resources."""
        logger.info("Cleaning up worker provisioner...")
        
        for spec in self._specs:
            # Kill SSH tunnel
            if spec.tunnel_proc and spec.tunnel_proc.poll() is None:
                logger.info("Terminating SSH tunnel for %s worker", spec.role)
                spec.tunnel_proc.terminate()
                try:
                    spec.tunnel_proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    spec.tunnel_proc.kill()
            
            # Terminate VM if owned
            if spec.vm_id:
                logger.info("Terminating VM %s for %s worker", spec.vm_id, spec.role)
                try:
                    from tools.vastai_tools import terminate_vm
                    terminate_vm(spec.vm_id)
                except ImportError:
                    logger.warning("Could not import terminate_vm, VM may not be terminated")
                except Exception as e:
                    logger.error("Error terminating VM %s: %s", spec.vm_id, e)
        
        logger.info("Worker provisioner cleanup complete")


# Singleton instance
_provisioner: Optional[WorkerProvisioner] = None


def get_provisioner() -> WorkerProvisioner:
    """Get the global WorkerProvisioner singleton."""
    global _provisioner
    if _provisioner is None:
        _provisioner = WorkerProvisioner()
    return _provisioner


def reset_provisioner() -> None:
    """Reset the global provisioner (for testing)."""
    global _provisioner
    _provisioner = None
