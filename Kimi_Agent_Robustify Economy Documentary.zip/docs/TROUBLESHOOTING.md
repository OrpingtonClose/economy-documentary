# Troubleshooting Guide

Common issues and solutions for the Documentary Pipeline.

## Table of Contents

1. [Installation Issues](#installation-issues)
2. [Configuration Issues](#configuration-issues)
3. [Pipeline Execution Issues](#pipeline-execution-issues)
4. [GPU/Production Issues](#gpuproduction-issues)
5. [Audio Generation Issues](#audio-generation-issues)
6. [Visual Generation Issues](#visual-generation-issues)
7. [Assembly Issues](#assembly-issues)
8. [Dashboard Issues](#dashboard-issues)
9. [Performance Issues](#performance-issues)
10. [Error Codes Reference](#error-codes-reference)

---

## Installation Issues

### Poetry Installation Fails

**Symptom:**
```
Command 'poetry' not found
```

**Solution:**
```bash
# Install Poetry
curl -sSL https://install.python-poetry.org | python3 -

# Add to PATH
export PATH="$HOME/.local/bin:$PATH"

# Verify installation
poetry --version
```

---

### Dependency Resolution Fails

**Symptom:**
```
SolverProblemError: The current project's Python requirement (>=3.9) is not compatible
```

**Solution:**
```bash
# Check Python version
python3 --version  # Must be >= 3.10

# Use pyenv to install correct version
pyenv install 3.11.0
pyenv local 3.11.0

# Clear Poetry cache and retry
poetry cache clear --all pypi
poetry install
```

---

### Package Conflicts

**Symptom:**
```
Because documentary-pipeline depends on both package-a (>=2.0) and package-b (<2.0), version solving failed.
```

**Solution:**
```bash
# Update lock file
poetry lock --no-update

# If still failing, force update
poetry update

# As last resort, remove and recreate virtual environment
poetry env remove python
poetry install
```

---

## Configuration Issues

### Missing Environment Variables

**Symptom:**
```
ValueError: ADK_MODEL environment variable is required
```

**Solution:**
```bash
# Copy example environment file
cd server
cp .env.example .env

# Edit with your API keys
nano .env

# Required variables:
# - ADK_MODEL (default: gemini-2.5-flash)
# - GOOGLE_API_KEY or OPENAI_API_KEY
# - VAST_API_KEY (for GPU production)

# Verify configuration
python -c "import config; print(config.ADK_MODEL)"
```

---

### API Key Not Recognized

**Symptom:**
```
AuthenticationError: Invalid API key provided
```

**Solution:**
```bash
# Check if key is loaded
echo $GOOGLE_API_KEY

# If empty, source the environment file
source server/.env

# Verify in Python
python -c "import os; print('Key present:', bool(os.getenv('GOOGLE_API_KEY')))"

# Check for whitespace in .env file
cat -A server/.env | grep GOOGLE
```

---

### Model Not Available

**Symptom:**
```
NotFoundError: Model 'gemini-2.5-flash' not found or not accessible
```

**Solution:**
```bash
# Check available models
curl "https://generativelanguage.googleapis.com/v1beta/models?key=$GOOGLE_API_KEY"

# Use a supported model
export ADK_MODEL="gemini-1.5-flash"

# Or configure fallback
export ADK_MODEL="gemini-1.5-pro"
```

---

## Pipeline Execution Issues

### Pipeline Hangs on Startup

**Symptom:**
Server starts but first request never completes.

**Solution:**
```bash
# Check if model is responsive
python -c "
from google import genai
client = genai.Client(api_key='$GOOGLE_API_KEY')
response = client.models.generate_content(model='gemini-1.5-flash', contents='Hello')
print(response.text)
"

# Check database initialization
ls -la /tmp/documentary-pipeline/dashboard/

# Reset dashboard database
rm /tmp/documentary-pipeline/dashboard/*.db
python -c "from dashboard.event_store import init_db; init_db()"

# Enable debug logging
export ADK_DEBUG=true
poetry run uvicorn server:app --reload --port 8000
```

---

### Scenario Generation Fails

**Symptom:**
```
Scenario generation failed: Evaluator rated content as POOR after 3 attempts
```

**Solution:**
```bash
# Check topic is valid
topic="Your topic here"
if [ ${#topic} -lt 3 ]; then
    echo "Topic too short"
fi

# Increase max attempts
export MAX_EVALUATOR_ATTEMPTS=5

# Check evaluator criteria in logs
grep -i "evaluator" /tmp/documentary-pipeline/logs/*.log

# Try with simpler topic
# Topics with special characters may cause issues
```

---

### Context Length Exceeded

**Symptom:**
```
ContextWindowExceeded: Input tokens (145000) exceed maximum (128000)
```

**Solution:**
```bash
# Increase context limit (if model supports it)
export MAX_CONTEXT_TOKENS=180000

# Reduce tool result size
export TOOL_RESULT_MAX_CHARS=15000

# Reduce context invocations kept
export CONTEXT_INVOCATIONS_TO_KEEP=5

# Enable context filtering
# Already enabled by default via ContextFilterPlugin
```

---

### Agent Loop Detection

**Symptom:**
```
Loop detected: Agent has exceeded maximum turns (12)
```

**Solution:**
```bash
# Increase max turns
export MAX_SUBAGENT_TURNS=20

# Check for infinite loops in agent logic
# Review agent callbacks in logs

# Enable detailed tracing
export ADK_DEBUG=true
```

---

## GPU/Production Issues

### Vast.ai API Errors

**Symptom:**
```
VastAIError: Failed to create instance: Insufficient capacity
```

**Solution:**
```bash
# Check Vast.ai API key
curl -H "Authorization: Bearer $VAST_API_KEY" https://console.vast.ai/api/v0/instances

# List available GPUs
curl -s "https://console.vast.ai/api/v0/bundles?q={\"gpu_name\":\"RTX_4090\"}" | jq '.offers[0:3]'

# Try different GPU type
export VASTAI_GPU_TYPE="RTX_3090"

# Reduce concurrency
export VASTAI_CONCURRENCY=1
```

---

### GPU Instance Timeout

**Symptom:**
```
GPUInstanceTimeout: Instance did not become ready within 300 seconds
```

**Solution:**
```bash
# Increase timeout
export VASTAI_STARTUP_TIMEOUT=600

# Check instance status manually
instance_id="your-instance-id"
curl -H "Authorization: Bearer $VAST_API_KEY" \
  "https://console.vast.ai/api/v0/instances/$instance_id"

# Destroy stuck instances
curl -X DELETE -H "Authorization: Bearer $VAST_API_KEY" \
  "https://console.vast.ai/api/v0/instances/$instance_id"
```

---

### CUDA Out of Memory

**Symptom:**
```
RuntimeError: CUDA out of memory. Tried to allocate 4.00 GiB
```

**Solution:**
```bash
# Reduce batch size
export LTX_BATCH_SIZE=1

# Use smaller resolution
export VIDEO_RESOLUTION="512x320"

# Enable gradient checkpointing (if supported)
export LTX_GRADIENT_CHECKPOINTING=true

# Request GPU with more VRAM
export VASTAI_MIN_VRAM_GB=24
```

---

### Video Generation Fails

**Symptom:**
```
VideoGenerationError: LTX-2.3 returned empty output
```

**Solution:**
```bash
# Check prompt length (should be < 500 tokens)
# Verify LoRA weights are loaded
# Check disk space on GPU instance

# Enable test mode to skip GPU
export DOCUMENTARY_TEST_MODE=true

# Regenerate with modified prompt
# Add more specific visual details
```

---

## Audio Generation Issues

### TTS Generation Fails

**Symptom:**
```
TTSError: Failed to generate audio for scene 1, voice V1
```

**Solution:**
```bash
# Check TTS service availability
# For Qwen3-TTS, verify API endpoint

# Reduce text length per clip
# Max recommended: 500 characters per voice block

# Try alternative TTS provider
export TTS_PROVIDER="openai"
export OPENAI_TTS_MODEL="tts-1"

# Check output directory permissions
ls -la /tmp/documentary-pipeline/tts/
chmod 755 /tmp/documentary-pipeline/tts/
```

---

### WhisperX Alignment Fails

**Symptom:**
```
WhisperXError: Failed to align audio: No speech detected
```

**Solution:**
```bash
# Check audio file is valid
ffprobe -i /tmp/documentary-pipeline/tts/scene_001_V1.wav

# Adjust WhisperX parameters
export WHISPERX_MODEL="base"
export WHISPERX_LANGUAGE="en"

# For non-English content
export WHISPERX_LANGUAGE="auto"

# Increase minimum speech duration
export WHISPERX_MIN_SPEECH_DURATION=0.5
```

---

### Audio Quality Issues

**Symptom:**
Generated audio is garbled, has artifacts, or wrong speed.

**Solution:**
```bash
# Check sample rate
ffprobe -show_streams /tmp/documentary-pipeline/tts/scene_001_V1.wav | grep sample_rate

# Convert to standard format if needed
ffmpeg -i input.wav -ar 22050 -ac 1 output.wav

# For speed issues, check WhisperX alignment
# May need to regenerate with different voice parameters
```

---

## Visual Generation Issues

### Coherence Check Fails

**Symptom:**
```
CoherenceError: Visual variety check failed after 5 iterations
```

**Solution:**
```bash
# Increase max iterations
export MAX_COHERENCE_ITERATIONS=10

# Relax variety requirements (not recommended)
# Or manually review and approve

# Check visual concepts have sufficient variety
# Ensure camera angles, environments differ between scenes
```

---

### LoRA Loading Fails

**Symptom:**
```
LoRAError: Failed to load LoRA weights from /path/to/lora.safetensors
```

**Solution:**
```bash
# Verify LoRA file exists
ls -la /path/to/lora.safetensors

# Check file is valid
python -c "
import torch
weights = torch.load('lora.safetensors')
print('Keys:', list(weights.keys())[:5])
"

# Download correct LoRA version
# Ensure compatibility with base model (LTX-2.3)
```

---

### Visual Concept Rejection

**Symptom:**
Visual concepts are repeatedly rejected by evaluator.

**Solution:**
```bash
# Review rejection reasons in logs
grep -A 5 "visual_concept_rejected" /tmp/documentary-pipeline/logs/*.log

# Common issues:
# - Too generic prompts
# - Missing specific camera angles
# - Inconsistent lighting descriptions

# Add more specific details to prompts
# Include: camera type, lens, lighting setup, film stock
```

---

## Assembly Issues

### OTIO Timeline Errors

**Symptom:**
```
OTIOError: Invalid timeline: Overlapping clips on track V1_Video
```

**Solution:**
```bash
# Check timeline file
python -c "
import opentimelineio as otio
timeline = otio.adapters.read_from_file('/tmp/documentary-pipeline/timelines/run_abc.otio')
for track in timeline.tracks:
    print(f'Track {track.name}: {len(track)} clips')
"

# Enable timeline guardian debug
export TIMELINE_GUARDIAN_DEBUG=true

# Regenerate timeline from scratch
rm /tmp/documentary-pipeline/timelines/run_*.otio
```

---

### FFmpeg Assembly Fails

**Symptom:**
```
FFmpegError: Error initializing output stream 0:0
```

**Solution:**
```bash
# Check FFmpeg version
ffmpeg -version | head -1

# Update FFmpeg (requires 4.4+)
# Check input files exist
ls -la /tmp/documentary-pipeline/video/

# Check file formats
ffprobe -show_format /tmp/documentary-pipeline/video/scene_001.mp4

# Debug assembly command
export FFMPEG_DEBUG=true
```

---

### Final Output Corrupted

**Symptom:**
Generated MP4 is unplayable or has artifacts.

**Solution:**
```bash
# Check output file
ffprobe -show_streams /tmp/documentary-pipeline/output/final.mp4

# Validate with FFmpeg
ffmpeg -v error -i final.mp4 -f null - 2>errors.log

# Re-encode if needed
ffmpeg -i final.mp4 -c:v libx264 -preset medium -crf 23 final_fixed.mp4

# Check for truncated files (disk space issue)
df -h /tmp/documentary-pipeline/
```

---

## Dashboard Issues

### Dashboard Not Updating

**Symptom:**
Dashboard shows stale data or doesn't update.

**Solution:**
```bash
# Check SSE connection
curl -N http://localhost:8000/dashboard/runs/run_abc123/sse

# Verify database is writable
ls -la /tmp/documentary-pipeline/dashboard/events.db

# Check for locks
lsof /tmp/documentary-pipeline/dashboard/events.db

# Reset dashboard
rm /tmp/documentary-pipeline/dashboard/*.db
python -c "from dashboard.event_store import init_db; init_db()"
```

---

### HTML Report Generation Fails

**Symptom:**
```
ReportError: Failed to generate HTML report: Template not found
```

**Solution:**
```bash
# Check template directory exists
ls -la server/dashboard/templates/

# Reinstall templates
poetry install

# Or manually copy templates
cp -r server/dashboard/templates /tmp/documentary-pipeline/
```

---

## Performance Issues

### Slow Pipeline Execution

**Symptom:**
Pipeline takes significantly longer than expected.

**Solution:**
```bash
# Profile pipeline execution
export ADK_DEBUG=true
export TIMING_LOG=true

# Check resource usage
htop
nvidia-smi

# Optimize concurrency settings
export MAX_CONCURRENT_LLM=8      # Increase if CPU/memory allows
export GPU_CONCURRENCY=4         # More parallel GPU jobs
export TTS_CONCURRENCY=6         # More parallel TTS

# Use faster models for drafts
export ADK_MODEL="gemini-1.5-flash"  # Instead of pro
```

---

### High Memory Usage

**Symptom:**
Process uses excessive RAM, may be killed by OOM.

**Solution:**
```bash
# Monitor memory usage
watch -n 1 'ps aux | grep python | grep -v grep'

# Reduce context window
export MAX_CONTEXT_TOKENS=80000
export HARD_CONTEXT_LIMIT=120000

# Limit concurrent operations
export MAX_CONCURRENT_LLM=2
export TREE_MAX_CONCURRENT=2

# Enable garbage collection between phases
export FORCE_GC_BETWEEN_PHASES=true
```

---

### Database Performance

**Symptom:**
Dashboard queries are slow, UI is unresponsive.

**Solution:**
```bash
# Vacuum database
sqlite3 /tmp/documentary-pipeline/dashboard/events.db "VACUUM;"

# Check database size
ls -lh /tmp/documentary-pipeline/dashboard/events.db

# Archive old runs
python -c "
from dashboard.event_store import archive_old_runs
archive_old_runs(keep_days=7)
"

# Enable WAL mode (already default)
sqlite3 events.db "PRAGMA journal_mode=WAL;"
```

---

## Error Codes Reference

### Pipeline Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| `PIPELINE_001` | Scenario generation timeout | Increase timeout, check topic validity |
| `PIPELINE_002` | Audio generation failed | Check TTS service, verify text length |
| `PIPELINE_003` | Visual generation failed | Check GPU availability, reduce batch size |
| `PIPELINE_004` | Production timeout | Increase GPU timeout, check Vast.ai status |
| `PIPELINE_005` | Assembly failed | Check FFmpeg, verify timeline integrity |
| `PIPELINE_006` | Context exceeded | Reduce context tokens, filter invocations |
| `PIPELINE_007` | Agent loop detected | Increase max turns, check agent logic |
| `PIPELINE_008` | Quality gate rejection | Review at gate, regenerate with feedback |

### API Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| `API_001` | Invalid request format | Check JSON syntax, required fields |
| `API_002` | Topic validation failed | Ensure 3-200 characters, valid characters |
| `API_003` | Rate limit exceeded | Wait and retry, implement backoff |
| `API_004` | Run not found | Verify run_id, check if expired |
| `API_005` | Authentication failed | Check API key, verify permissions |

### Infrastructure Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| `INF_001` | GPU unavailable | Check Vast.ai, try different region |
| `INF_002` | Disk space full | Clean up old runs, expand storage |
| `INF_003` | Network timeout | Check connectivity, retry with backoff |
| `INF_004` | Service dependency failed | Check dependent services (TTS, LLM) |

---

## Getting Help

If issues persist:

1. **Check logs:**
   ```bash
   tail -f /tmp/documentary-pipeline/logs/*.log
   ```

2. **Enable debug mode:**
   ```bash
   export ADK_DEBUG=true
   export LOG_LEVEL=DEBUG
   ```

3. **Collect diagnostic info:**
   ```bash
   python scripts/diagnostics.py --output diagnostics.zip
   ```

4. **File an issue:**
   - Include error messages
   - Attach logs (sanitized)
   - Describe reproduction steps
   - Include environment info (`python --version`, OS, etc.)
