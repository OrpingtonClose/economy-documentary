# Environment Setup Guide

Complete guide for setting up the Documentary Pipeline development and production environments.

## Table of Contents

1. [Quick Start](#quick-start)
2. [Prerequisites](#prerequisites)
3. [Development Environment](#development-environment)
4. [Production Environment](#production-environment)
5. [Configuration Reference](#configuration-reference)
6. [API Keys Setup](#api-keys-setup)
7. [GPU Setup](#gpu-setup)
8. [Verification](#verification)
9. [Troubleshooting Setup](#troubleshooting-setup)

---

## Quick Start

For experienced users who want to get started immediately:

```bash
# 1. Clone and setup
git clone https://github.com/OrpingtonClose/economy-documentary.git
cd economy-documentary
poetry install

# 2. Configure
cd server && cp .env.example .env
# Edit .env with your API keys

# 3. Run
poetry run uvicorn server:app --reload --port 8000
```

---

## Prerequisites

### Operating System

**Supported Platforms:**
- Ubuntu 22.04 LTS (recommended)
- macOS 13+ (Apple Silicon or Intel)
- Windows 11 with WSL2

**Check OS Version:**
```bash
# Linux
cat /etc/os-release

# macOS
sw_vers

# Windows (in WSL)
uname -a
```

### Python Environment

**Required:** Python 3.10 or higher

```bash
# Check Python version
python3 --version

# If needed, install pyenv for version management
curl https://pyenv.run | bash

# Add to ~/.bashrc or ~/.zshrc
export PATH="$HOME/.pyenv/bin:$PATH"
eval "$(pyenv init -)"
eval "$(pyenv virtualenv-init -)"

# Install Python 3.11
pyenv install 3.11.0
pyenv global 3.11.0

# Verify
python --version  # Should show 3.11.0
```

### Poetry Installation

```bash
# Install Poetry
curl -sSL https://install.python-poetry.org | python3 -

# Add to PATH
export PATH="$HOME/.local/bin:$PATH"

# Verify
poetry --version  # Should show 1.7.0 or higher

# Configure Poetry
poetry config virtualenvs.in-project true  # Create venv in project directory
poetry config virtualenvs.prefer-active-python true
```

### System Dependencies

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install -y \
    python3-dev \
    python3-pip \
    ffmpeg \
    git \
    curl \
    build-essential \
    libsqlite3-dev \
    pkg-config

# Verify FFmpeg
ffmpeg -version | head -1
```

**macOS:**
```bash
# Install Homebrew if not present
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install dependencies
brew install \
    python@3.11 \
    ffmpeg \
    git \
    sqlite3

# Verify
ffmpeg -version | head -1
```

**Windows (WSL2):**
```bash
# In WSL2 Ubuntu
sudo apt-get update
sudo apt-get install -y python3-dev ffmpeg git build-essential

# Windows-side: Install Docker Desktop with WSL2 backend
# https://docs.docker.com/desktop/windows/wsl/
```

---

## Development Environment

### 1. Clone Repository

```bash
# Clone the repository
git clone https://github.com/OrpingtonClose/economy-documentary.git
cd economy-documentary

# Verify structure
ls -la
# Should show: server/, frontend/, pipeline/, docs/, config.py, etc.
```

### 2. Install Dependencies

```bash
# Install all dependencies
poetry install

# Install with development dependencies
poetry install --with dev

# Verify installation
poetry run python -c "import fastapi; print('FastAPI:', fastapi.__version__)"
```

### 3. Environment Configuration

```bash
cd server

# Copy example environment file
cp .env.example .env

# Edit the file
nano .env  # or use your preferred editor
```

**Minimum Required Variables:**
```bash
# .env - Minimum Configuration
ADK_MODEL=gemini-2.5-flash
GOOGLE_API_KEY=your_google_api_key_here

# Optional but recommended
DOCUMENTARY_TEST_MODE=true  # For testing without GPU
```

### 4. Directory Structure Setup

```bash
# Create required directories
mkdir -p /tmp/documentary-pipeline/{data,timelines,tts,video,output,logs,dashboard}

# Set permissions
chmod 755 /tmp/documentary-pipeline

# Or use custom data directory
export DATA_DIR=/path/to/your/data
mkdir -p $DATA_DIR/{corpus,enrichment,timelines,tts,video,findings,dashboard}
```

### 5. Start Development Server

```bash
# Start with hot reload
poetry run uvicorn server:app --reload --port 8000

# Or with specific host
poetry run uvicorn server:app --reload --host 0.0.0.0 --port 8000

# With debug logging
ADK_DEBUG=true poetry run uvicorn server:app --reload --port 8000
```

### 6. Verify Setup

```bash
# In another terminal, test health endpoint
curl http://localhost:8000/health

# Expected response:
# {"status": "ok", "model": "gemini-2.5-flash", "version": "0.1.0"}

# Test API documentation
curl http://localhost:8000/openapi.json | head -20

# Open interactive docs in browser
# http://localhost:8000/docs
```

---

## Production Environment

### 1. Server Preparation

```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Create dedicated user
sudo useradd -m -s /bin/bash documentary
sudo usermod -aG sudo documentary

# Switch to user
su - documentary
```

### 2. Install Production Dependencies

```bash
# Install all prerequisites (see Development Environment)
# Then install without dev dependencies
poetry install --no-dev

# Or install from requirements.txt (if generated)
poetry export -f requirements.txt --output requirements.txt
pip install -r requirements.txt
```

### 3. Production Configuration

```bash
# Create production .env
cat > /opt/documentary-pipeline/server/.env << 'EOF'
# Production Environment
ENVIRONMENT=production
ADK_MODEL=gemini-2.5-flash
ADK_DEBUG=false
LOG_LEVEL=INFO

# API Keys (use secrets manager in production)
GOOGLE_API_KEY=${GOOGLE_API_KEY}
VAST_API_KEY=${VAST_API_KEY}

# Paths
DATA_DIR=/var/lib/documentary-pipeline/data
TIMELINE_DIR=/var/lib/documentary-pipeline/timelines
LOG_DIR=/var/log/documentary-pipeline

# Concurrency
MAX_CONCURRENT_LLM=8
GPU_CONCURRENCY=4
TTS_CONCURRENCY=6

# Timeouts
PIPELINE_TIMEOUT=3600
GPU_STARTUP_TIMEOUT=600
EOF
```

### 4. Systemd Service

```bash
# Create systemd service file
sudo tee /etc/systemd/system/documentary-pipeline.service << 'EOF'
[Unit]
Description=Documentary Pipeline API
After=network.target

[Service]
Type=simple
User=documentary
Group=documentary
WorkingDirectory=/opt/documentary-pipeline/server
Environment=PATH=/opt/documentary-pipeline/.venv/bin
EnvironmentFile=/opt/documentary-pipeline/server/.env
ExecStart=/opt/documentary-pipeline/.venv/bin/uvicorn server:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable documentary-pipeline
sudo systemctl start documentary-pipeline

# Check status
sudo systemctl status documentary-pipeline
sudo journalctl -u documentary-pipeline -f
```

### 5. Nginx Reverse Proxy

```bash
# Install Nginx
sudo apt-get install -y nginx

# Create site configuration
sudo tee /etc/nginx/sites-available/documentary-pipeline << 'EOF'
upstream documentary_backend {
    server 127.0.0.1:8000;
    keepalive 32;
}

server {
    listen 80;
    server_name api.yourdomain.com;
    
    location / {
        proxy_pass http://documentary_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts for SSE
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 3600s;
    }
}
EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/documentary-pipeline /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. SSL with Let's Encrypt

```bash
# Install Certbot
sudo apt-get install -y certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d api.yourdomain.com

# Auto-renewal is configured automatically
# Test renewal
sudo certbot renew --dry-run
```

---

## Configuration Reference

### Environment Variables

#### Core Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `ADK_MODEL` | `gemini-2.5-flash` | Primary LLM model for ADK |
| `ADK_SYNTHESIS_MODEL` | - | Model for synthesis tasks |
| `ADK_THINKER_MODEL` | - | Model for reasoning tasks |
| `ADK_VISION_MODEL` | - | Model for vision tasks |
| `ADK_DEBUG` | `false` | Enable debug logging |
| `LOG_LEVEL` | `INFO` | Logging level |

#### API Keys

| Variable | Required For | Description |
|----------|--------------|-------------|
| `GOOGLE_API_KEY` | All | Google AI (Gemini) API key |
| `OPENAI_API_KEY` | Optional | OpenAI API key |
| `OPENAI_API_BASE` | Optional | Custom OpenAI-compatible endpoint |
| `VAST_API_KEY` | Production | Vast.ai API key for GPU |
| `PERPLEXITY_API_KEY` | Research | Perplexity search API |
| `FRED_API_KEY` | Economy | FRED economic data |

#### Paths

| Variable | Default | Description |
|----------|---------|-------------|
| `DATA_DIR` | `/tmp/documentary-pipeline` | Base data directory |
| `TIMELINE_DIR` | `$DATA_DIR/timelines` | OTIO timeline storage |
| `TTS_OUTPUT_DIR` | `$DATA_DIR/tts` | TTS audio output |
| `VIDEO_OUTPUT_DIR` | `$DATA_DIR/video` | Generated video clips |
| `DASHBOARD_DB_DIR` | `$DATA_DIR/dashboard` | Dashboard database |
| `FINDINGS_DIR` | `$DATA_DIR/findings` | Research findings |

#### Concurrency

| Variable | Default | Description |
|----------|---------|-------------|
| `MAX_CONCURRENT_LLM` | `4` | Max concurrent LLM calls |
| `MAX_CONTEXT_TOKENS` | `120000` | Max context window tokens |
| `HARD_CONTEXT_LIMIT` | `180000` | Hard limit for context |
| `GPU_CONCURRENCY` | `2` | Max concurrent GPU jobs |
| `TTS_CONCURRENCY` | `3` | Max concurrent TTS jobs |
| `VASTAI_CONCURRENCY` | `2` | Max concurrent Vast.ai ops |

#### Feature Flags

| Variable | Default | Description |
|----------|---------|-------------|
| `DOCUMENTARY_TEST_MODE` | `false` | Test mode (no GPU) |
| `PHOENIX_ENABLED` | `false` | Enable Phoenix tracing |
| `PHOENIX_COLLECTOR_ENDPOINT` | - | Phoenix endpoint URL |

#### Plugin Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `CONTEXT_INVOCATIONS_TO_KEEP` | `10` | Context items to retain |
| `TOOL_MAX_RETRIES` | `2` | Max tool call retries |
| `TOOL_RESULT_MAX_CHARS` | `30000` | Max tool result size |

---

## API Keys Setup

### Google AI (Gemini)

```bash
# 1. Visit https://aistudio.google.com/app/apikey
# 2. Click "Create API Key"
# 3. Copy the key

# 4. Add to .env
echo "GOOGLE_API_KEY=your_key_here" >> server/.env

# 5. Verify
curl "https://generativelanguage.googleapis.com/v1beta/models?key=$GOOGLE_API_KEY"
```

### Vast.ai (GPU)

```bash
# 1. Create account at https://vast.ai/
# 2. Go to Account → API Keys
# 3. Generate new API key

# 4. Add to .env
echo "VAST_API_KEY=your_key_here" >> server/.env

# 5. Verify
pip install vastai
vastai set api-key $VAST_API_KEY
vastai search offers 'gpu_name=RTX_4090'
```

### Perplexity (Search)

```bash
# 1. Sign up at https://www.perplexity.ai/
# 2. Go to Settings → API
# 3. Generate API key

# 4. Add to .env
echo "PERPLEXITY_API_KEY=your_key_here" >> server/.env
```

### FRED (Economic Data)

```bash
# 1. Register at https://fred.stlouisfed.org/
# 2. Go to My Account → API Keys
# 3. Request API key

# 4. Add to .env
echo "FRED_API_KEY=your_key_here" >> server/.env

# 5. Verify
curl "https://api.stlouisfed.org/fred/series?series_id=GDP&api_key=$FRED_API_KEY&file_type=json"
```

### AgentOps (Observability)

```bash
# 1. Sign up at https://agentops.ai/
# 2. Create new project
# 3. Copy API key

# 4. Add to .env
echo "AGENTOPS_API_KEY=your_key_here" >> server/.env
```

---

## GPU Setup

### Local GPU (Optional)

```bash
# Check CUDA availability
nvidia-smi

# Install CUDA toolkit (if needed)
# https://developer.nvidia.com/cuda-downloads

# Verify PyTorch CUDA
poetry run python -c "import torch; print('CUDA available:', torch.cuda.is_available())"
```

### Vast.ai Configuration

```bash
# Install CLI
pip install vastai

# Set API key
vastai set api-key $VAST_API_KEY

# Search for instances
vastai search offers 'gpu_name=RTX_4090 num_gpus=1'

# Test provisioning
vastai create instance <offer_id> --image nvidia/cuda:12.0-devel-ubuntu22.04

# List instances
vastai show instances

# Destroy when done
vastai destroy instance <instance_id>
```

---

## Verification

### Full Setup Verification Script

```bash
#!/bin/bash
# verify-setup.sh

echo "=== Documentary Pipeline Setup Verification ==="
echo ""

# Python version
echo -n "Python version >= 3.10... "
PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
REQUIRED_VERSION="3.10.0"
if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" = "$REQUIRED_VERSION" ]; then
    echo "OK ($PYTHON_VERSION)"
else
    echo "FAIL ($PYTHON_VERSION)"
    exit 1
fi

# Poetry
echo -n "Poetry installed... "
if command -v poetry &> /dev/null; then
    echo "OK ($(poetry --version))"
else
    echo "FAIL"
    exit 1
fi

# FFmpeg
echo -n "FFmpeg installed... "
if command -v ffmpeg &> /dev/null; then
    echo "OK ($(ffmpeg -version | head -1 | cut -d' ' -f3))"
else
    echo "FAIL"
    exit 1
fi

# Dependencies
echo -n "Dependencies installed... "
if poetry run python -c "import fastapi" 2>/dev/null; then
    echo "OK"
else
    echo "FAIL"
    exit 1
fi

# Environment file
echo -n "Environment file exists... "
if [ -f "server/.env" ]; then
    echo "OK"
else
    echo "FAIL (copy server/.env.example to server/.env)"
    exit 1
fi

# API key
echo -n "GOOGLE_API_KEY set... "
if grep -q "GOOGLE_API_KEY=" server/.env && ! grep -q "GOOGLE_API_KEY=your_" server/.env; then
    echo "OK"
else
    echo "FAIL (set your Google API key in server/.env)"
    exit 1
fi

# Data directories
echo -n "Data directories... "
if [ -d "/tmp/documentary-pipeline" ]; then
    echo "OK"
else
    echo "Creating..."
    mkdir -p /tmp/documentary-pipeline/{data,timelines,tts,video,output,logs,dashboard}
    echo "OK"
fi

echo ""
echo "=== All checks passed! ==="
echo ""
echo "Start the server with:"
echo "  cd server && poetry run uvicorn server:app --reload --port 8000"
```

Run the verification:
```bash
chmod +x verify-setup.sh
./verify-setup.sh
```

---

## Troubleshooting Setup

### Common Issues

**Issue: Poetry not found**
```bash
# Add to PATH
export PATH="$HOME/.local/bin:$PATH"

# Or reinstall
curl -sSL https://install.python-poetry.org | python3 -
```

**Issue: Permission denied on data directory**
```bash
# Fix permissions
sudo chown -R $USER:$USER /tmp/documentary-pipeline
chmod -R 755 /tmp/documentary-pipeline
```

**Issue: Port 8000 already in use**
```bash
# Find and kill process
lsof -ti:8000 | xargs kill -9

# Or use different port
poetry run uvicorn server:app --reload --port 8001
```

**Issue: Module not found errors**
```bash
# Reinstall dependencies
poetry install

# Or update lock file
poetry lock --no-update
poetry install
```

**Issue: FFmpeg not found**
```bash
# Ubuntu/Debian
sudo apt-get install ffmpeg

# macOS
brew install ffmpeg

# Verify
which ffmpeg
ffmpeg -version
```

---

## Next Steps

After successful setup:

1. **Read the documentation:**
   - [API Documentation](API_DOCUMENTATION.md)
   - [Architecture](ARCHITECTURE.md)
   - [Troubleshooting](TROUBLESHOOTING.md)

2. **Run a test:**
   ```bash
   export DOCUMENTARY_TEST_MODE=true
   python test_run.py --topic "Your test topic"
   ```

3. **Explore the API:**
   - Open http://localhost:8000/docs
   - Try the interactive endpoints

4. **Set up the frontend:**
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
