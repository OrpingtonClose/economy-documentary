# Code Documentation

Comprehensive inline documentation and docstrings for the Documentary Pipeline codebase.

## Table of Contents

1. [Configuration Module](#configuration-module)
2. [Server Module](#server-module)
3. [Agent Modules](#agent-modules)
4. [Dashboard Module](#dashboard-module)
5. [Plugin Modules](#plugin-modules)
6. [Tool Modules](#tool-modules)
7. [Callback Modules](#callback-modules)
8. [Vault Builder Module](#vault-builder-module)

---

## Configuration Module

### config.py

```python
"""
Central configuration module for the Documentary Pipeline.

This module serves as the single source of truth for all runtime configuration,
reading values from environment variables. All components should import from
here rather than reading environment variables directly.

Example:
    >>> from config import ADK_MODEL, MAX_CONCURRENT_LLM
    >>> print(f"Using model: {ADK_MODEL}")
    Using model: gemini-2.5-flash

Attributes:
    All configuration values are exposed as module-level constants.
    See the full list in the Configuration Reference section.

Note:
    Environment variable names are derived from legacy file-based key names
    by stripping extensions and uppercasing (e.g., 'deepseek_api.txt' -> 'DEEPSEEK_API').
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


# ═════════════════════════════════════════════════════════════════════════════
# Topic Configuration
# ═════════════════════════════════════════════════════════════════════════════

DOCUMENTARY_TOPIC: str = os.environ.get("DOCUMENTARY_TOPIC", "")
"""The documentary topic — set dynamically per run via environment variable.

This value is typically set by the frontend or API request to specify
the subject matter for the documentary being generated.

Example:
    >>> os.environ["DOCUMENTARY_TOPIC"] = "The Federal Reserve"
    >>> from config import DOCUMENTARY_TOPIC
    >>> print(DOCUMENTARY_TOPIC)
    The Federal Reserve
"""


# ═════════════════════════════════════════════════════════════════════════════
# Path Configuration
# ═════════════════════════════════════════════════════════════════════════════

PROJECT_ROOT: Path = Path(__file__).resolve().parent
"""Absolute path to the project root directory.

Used as the base for resolving relative paths throughout the application.
"""

DATA_DIR: Path = Path(os.environ.get("DATA_DIR", "/tmp/documentary-pipeline"))
"""Base directory for all pipeline data.

Default: /tmp/documentary-pipeline

Subdirectories:
    - corpus/: Raw text corpus and transcripts
    - enrichment/: Research enrichment data
    - timelines/: OTIO timeline files
    - tts/: Text-to-speech audio output
    - video/: Generated video clips
    - findings/: Research findings and claims
    - dashboard/: Dashboard event database
"""

CORPUS_DIR: Path = DATA_DIR / "corpus"
"""Directory for text corpus and transcript storage."""

TRANSCRIPT_DIR: Path = CORPUS_DIR / "transcripts"
"""Directory for audio transcript files."""

ENRICHMENT_DIR: Path = DATA_DIR / "enrichment"
"""Directory for research enrichment data."""

TIMELINE_DIR: Path = Path(os.environ.get("TIMELINE_DIR", str(DATA_DIR / "timelines")))
"""Directory for OTIO timeline files.

These files represent the assembled documentary timeline before final
ffmpeg rendering.
"""

TTS_OUTPUT_DIR: Path = Path(os.environ.get("TTS_OUTPUT_DIR", str(DATA_DIR / "tts")))
"""Directory for TTS-generated audio files."""

VIDEO_OUTPUT_DIR: Path = Path(os.environ.get("VIDEO_OUTPUT_DIR", str(DATA_DIR / "video")))
"""Directory for GPU-generated video clips."""

FINDINGS_DIR: Path = Path(os.environ.get("FINDINGS_DIR", str(DATA_DIR / "findings")))
"""Directory for research findings and verified claims."""

DASHBOARD_DB_DIR: Path = Path(os.environ.get("DASHBOARD_DB_DIR", str(DATA_DIR / "dashboard")))
"""Directory for dashboard SQLite database."""


# ═════════════════════════════════════════════════════════════════════════════
# API Keys - LLM Providers
# ═════════════════════════════════════════════════════════════════════════════

# Google AI (Gemini)
GEMINI_API_KEY: str = os.environ.get("GEMINI_API_KEY", "")
"""Google AI API key for Gemini models."""

# OpenAI
OPENAI_API_KEY: str = os.environ.get("OPENAI_API_KEY", "")
"""OpenAI API key for GPT models and TTS."""

OPENAI_API_BASE: str = os.environ.get("OPENAI_API_BASE", "")
"""Custom OpenAI-compatible API base URL.

Used for LiteLLM proxy or other OpenAI-compatible endpoints.
"""

# Alternative LLM providers
MINMAX_API: str = os.environ.get("MINMAX_API", "")
"""Minimax API key."""

DEEPSEEK_API: str = os.environ.get("DEEPSEEK_API", "")
"""DeepSeek API key."""

GROK_API: str = os.environ.get("GROK_API", "")
"""Grok API key."""

OPENROUTER_API: str = os.environ.get("OPENROUTER_API", "")
"""OpenRouter API key for model routing."""

GROQ_API: str = os.environ.get("GROQ_API", "")
"""Groq API key for fast inference."""

MISTRAL_API_KEY: str = os.environ.get("MISTRAL_API_KEY", "")
"""Mistral AI API key."""

ANTHROPIC_API: str = os.environ.get("ANTHROPIC_API", "")
"""Anthropic API key for Claude models."""


# ═════════════════════════════════════════════════════════════════════════════
# API Keys - Search Providers
# ═════════════════════════════════════════════════════════════════════════════

EXA_API_KEY: str = os.environ.get("EXA_API_KEY", "")
"""Exa (Metaphor) API key for neural search."""

TAVILY_API_KEY: str = os.environ.get("TAVILY_API_KEY", "")
"""Tavily API key for AI search."""

BRAVE_SEARCH_API_KEY: str = os.environ.get("BRAVE_SEARCH_API_KEY", "")
"""Brave Search API key."""

GOOGLE_SEARCH_API: str = os.environ.get("GOOGLE_SEARCH_API", "")
"""Google Custom Search API key."""

GOOGLE_SEARCH_ENGINE_ID: str = os.environ.get("GOOGLE_SEARCH_ENGINE_ID", "")
"""Google Custom Search Engine ID."""


# ═════════════════════════════════════════════════════════════════════════════
# API Keys - Data APIs
# ═════════════════════════════════════════════════════════════════════════════

PERPLEXITY_API_KEY: str = os.environ.get("PERPLEXITY_API_KEY", "")
"""Perplexity API key for web search and answers."""

FRED_API_KEY: str = os.environ.get("FRED_API_KEY", "")
"""FRED (Federal Reserve Economic Data) API key."""

WOLFRAM_ALPHA_API: str = os.environ.get("WOLFRAM_ALPHA_API", "")
"""Wolfram Alpha API key for computations."""

JINA_API_KEY: str = os.environ.get("JINA_API_KEY", "")
"""Jina AI API key for embeddings and reranking."""


# ═════════════════════════════════════════════════════════════════════════════
# API Keys - Infrastructure
# ═════════════════════════════════════════════════════════════════════════════

VAST_API_KEY: str = os.environ.get("VAST_API_KEY", "")
"""Vast.ai API key for GPU instance provisioning."""


# ═════════════════════════════════════════════════════════════════════════════
# API Keys - Proxy Services
# ═════════════════════════════════════════════════════════════════════════════

BRIGHTDATA_KEY: str = os.environ.get("BRIGHTDATA_KEY", "")
"""Bright Data proxy API key."""

BRIGHTDATA_CUSTOMER_ID: str = os.environ.get("BRIGHTDATA_CUSTOMER_ID", "hl_dc044bf4")
"""Bright Data customer ID."""

BRIGHTDATA_ZONE: str = os.environ.get("BRIGHTDATA_ZONE", "mcp_unlocker")
"""Bright Data proxy zone."""

OXYLABS_USERNAME: str = os.environ.get("OXYLABS_USERNAME", "")
"""Oxylabs proxy username."""

OXYLABS_PASSWORD: str = os.environ.get("OXYLABS_PASSWORD", "")
"""Oxylabs proxy password."""


# ═════════════════════════════════════════════════════════════════════════════
# API Keys - Observability
# ═════════════════════════════════════════════════════════════════════════════

AGENTOPS_API_KEY: str = os.environ.get("AGENTOPS_API_KEY", "")
"""AgentOps API key for agent observability."""


# ═════════════════════════════════════════════════════════════════════════════
# ADK Model Configuration
# ═════════════════════════════════════════════════════════════════════════════

ADK_MODEL: str = os.environ.get("ADK_MODEL", "gemini-2.5-flash")
"""Primary LLM model for ADK agent execution.

Default: gemini-2.5-flash

This model is used for most agent operations including scenario generation,
visual conception, and content analysis.
"""

ADK_SYNTHESIS_MODEL: str = os.environ.get("ADK_SYNTHESIS_MODEL", "")
"""Model specifically for synthesis tasks.

If not set, falls back to ADK_MODEL.
"""

ADK_THINKER_MODEL: str = os.environ.get("ADK_THINKER_MODEL", "")
"""Model specifically for reasoning tasks.

If not set, falls back to ADK_MODEL.
"""

ADK_VISION_MODEL: str = os.environ.get("ADK_VISION_MODEL", "")
"""Model specifically for vision tasks.

If not set, falls back to ADK_MODEL.
"""


# ═════════════════════════════════════════════════════════════════════════════
# Concurrency Configuration
# ═════════════════════════════════════════════════════════════════════════════

MAX_CONCURRENT_LLM: int = int(os.environ.get("MAX_CONCURRENT_LLM", "4"))
"""Maximum concurrent LLM API calls.

Default: 4

This limits the number of simultaneous LLM requests to prevent
rate limiting and manage costs.
"""

MAX_CONTEXT_TOKENS: int = int(os.environ.get("MAX_CONTEXT_TOKENS", "120000"))
"""Maximum context window tokens before truncation.

Default: 120000

When context exceeds this, older messages are summarized or removed.
"""

HARD_CONTEXT_LIMIT: int = int(os.environ.get("HARD_CONTEXT_LIMIT", "180000"))
"""Hard limit for context tokens (absolute maximum).

Default: 180000

Requests exceeding this will be rejected.
"""

TOOL_RESULT_MAX_CHARS: int = int(os.environ.get("TOOL_RESULT_MAX_CHARS", "30000"))
"""Maximum characters for tool results before truncation.

Default: 30000
"""

GPU_CONCURRENCY: int = int(os.environ.get("GPU_CONCURRENCY", "2"))
"""Maximum concurrent GPU video generation jobs.

Default: 2

Limited by GPU memory and Vast.ai instance capacity.
"""

TTS_CONCURRENCY: int = int(os.environ.get("TTS_CONCURRENCY", "3"))
"""Maximum concurrent TTS generation jobs.

Default: 3
"""

VASTAI_CONCURRENCY: int = int(os.environ.get("VASTAI_CONCURRENCY", "2"))
"""Maximum concurrent Vast.ai operations.

Default: 2

Includes instance creation, destruction, and status checks.
"""

TREE_MAX_CONCURRENT: int = int(os.environ.get("TREE_MAX_CONCURRENT", "4"))
"""Maximum concurrent subagent executions in tree patterns.

Default: 4
"""

MAX_SUBAGENT_TURNS: int = int(os.environ.get("MAX_SUBAGENT_TURNS", "12"))
"""Maximum turns for subagent loops.

Default: 12

Prevents infinite loops in EvaluatorOptimizer and LoopAgent patterns.
"""


# ═════════════════════════════════════════════════════════════════════════════
# Feature Flags
# ═════════════════════════════════════════════════════════════════════════════

DOCUMENTARY_TEST_MODE: bool = os.environ.get("DOCUMENTARY_TEST_MODE", "false").strip().lower() in ("true", "1")
"""Enable test mode (no GPU required).

Default: False

When enabled:
- Skips actual GPU video generation
- Uses placeholder/mock video files
- Useful for testing pipeline logic without GPU costs
"""

ADK_DEBUG: bool = os.environ.get("ADK_DEBUG", "false").strip().lower() in ("true", "1")
"""Enable ADK debug logging.

Default: False

When enabled, outputs detailed debug information about agent execution,
tool calls, and state changes.
"""

PHOENIX_ENABLED: bool = os.environ.get("PHOENIX_ENABLED", "false").strip().lower() in ("true", "1")
"""Enable Phoenix tracing.

Default: False

Phoenix provides distributed tracing and observability for LLM applications.
"""

PHOENIX_COLLECTOR_ENDPOINT: str = os.environ.get("PHOENIX_COLLECTOR_ENDPOINT", "")
"""Phoenix collector endpoint URL."""


# ═════════════════════════════════════════════════════════════════════════════
# Plugin Configuration
# ═════════════════════════════════════════════════════════════════════════════

CONTEXT_INVOCATIONS_TO_KEEP: int = int(os.environ.get("CONTEXT_INVOCATIONS_TO_KEEP", "10"))
"""Number of recent context invocations to retain.

Default: 10

Older invocations are filtered out by ContextFilterPlugin.
"""

TOOL_MAX_RETRIES: int = int(os.environ.get("TOOL_MAX_RETRIES", "2"))
"""Maximum retries for failed tool calls.

Default: 2

Used by ReflectAndRetryToolPlugin.
"""


# ═════════════════════════════════════════════════════════════════════════════
# Compatibility Functions
# ═════════════════════════════════════════════════════════════════════════════

def _read_key(filename: str) -> str:
    """Read an API key from environment variable.

    This is a compatibility shim for existing code that used file-based keys.
    The filename is converted to an env var name by stripping the extension
    and uppercasing.

    Args:
        filename: Original key filename (e.g., 'deepseek_api.txt').

    Returns:
        The API key string, or empty string if not set.

    Examples:
        >>> _read_key('deepseek_api.txt')
        'sk-...'
        >>> _read_key('exa_api_key.json')
        '...'
        >>> _read_key('nonexistent.txt')
        ''

    Note:
        This function is deprecated. New code should read environment
        variables directly from the module-level constants.
    """
    # Strip any common extension, not just .txt
    base = filename.rsplit(".", 1)[0] if "." in filename else filename
    env_name = base.upper()
    return os.environ.get(env_name, "")


def get_config_summary() -> dict:
    """Get a summary of current configuration.

    Returns:
        Dictionary with configuration summary (no sensitive values).

    Example:
        >>> summary = get_config_summary()
        >>> print(summary['model'])
        gemini-2.5-flash
    """
    return {
        "model": ADK_MODEL,
        "test_mode": DOCUMENTARY_TEST_MODE,
        "debug": ADK_DEBUG,
        "max_concurrent_llm": MAX_CONCURRENT_LLM,
        "gpu_concurrency": GPU_CONCURRENCY,
        "data_dir": str(DATA_DIR),
        "has_google_key": bool(GEMINI_API_KEY or os.environ.get("GOOGLE_API_KEY")),
        "has_openai_key": bool(OPENAI_API_KEY),
        "has_vast_key": bool(VAST_API_KEY),
    }
```

---

## Server Module

### server.py

```python
"""
FastAPI + AG-UI server for the documentary pipeline.

This module provides the main HTTP server that exposes:
- AG-UI protocol endpoint for CopilotKit frontend integration
- Dashboard endpoints for real-time monitoring
- Health check endpoint for service status

The server is built on FastAPI and integrates with Google ADK for
agent orchestration.

Example:
    Run the server directly:
    
    $ poetry run uvicorn server:app --reload --port 8000
    
    Or import for testing:
    
    >>> from server import app
    >>> from fastapi.testclient import TestClient
    >>> client = TestClient(app)
    >>> response = client.get("/health")
    >>> response.json()
    {'status': 'ok', 'model': 'gemini-2.5-flash', 'version': '0.1.0'}

Attributes:
    app (FastAPI): The main FastAPI application instance.
    adk_agent (ADKAgent): The configured ADK agent for AG-UI.
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

# Load environment variables before other imports
load_dotenv()

from ag_ui_adk import ADKAgent, add_adk_fastapi_endpoint
from google.adk.apps import App

from agents.model_config import ADK_MODEL_NAME
from agents.pipeline import pipeline_agent
from dashboard import remove_collector, set_active_collector
from dashboard.collector import PipelineCollector
from dashboard.event_store import init_db, insert_run, finalize_run, insert_snapshot
from dashboard.sse import router as dashboard_router
from agui import router as agui_router
from plugins import build_plugins, setup_otel

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s"
)


def _validate_env() -> None:
    """Validate required environment variables at startup.

    Raises:
        ValueError: If required configuration is missing.

    Checks:
        - ADK_MODEL is set
        - At least one API key is configured (Google or OpenAI)

    Example:
        >>> _validate_env()
        # Raises ValueError if ADK_MODEL not set
    """
    model = ADK_MODEL_NAME
    if not model:
        raise ValueError("ADK_MODEL environment variable is required")

    # Check for at least one API key
    has_google = bool(os.environ.get("GOOGLE_API_KEY"))
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    has_api_base = bool(os.environ.get("OPENAI_API_BASE"))

    if not (has_google or has_openai or has_api_base):
        logger.warning(
            "No API keys configured. Set GOOGLE_API_KEY for Gemini "
            "or OPENAI_API_KEY + OPENAI_API_BASE for LiteLLM routing."
        )

    logger.info(
        "Model configuration: ADK_MODEL=%s, Gemini=%s, LiteLLM=%s",
        model,
        "yes" if has_google else "no",
        "yes" if (has_openai or has_api_base) else "no",
    )


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log request method, path, status, and duration.

    This middleware logs all incoming requests with their processing time
    and response status code for observability.

    Example log output:
        2025-01-15 10:30:00 server INFO GET /health -> 200 (0.01s)
        2025-01-15 10:30:05 server INFO POST / -> 200 (45.23s)

    Attributes:
        None - Configured via FastAPI middleware stack.
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        """Process a request and log details.

        Args:
            request: The incoming HTTP request.
            call_next: The next middleware/handler in the chain.

        Returns:
            The HTTP response from the handler.
        """
        start = time.time()
        response = await call_next(request)
        duration = time.time() - start
        logger.info(
            "%s %s -> %d (%.2fs)",
            request.method,
            request.url.path,
            response.status_code,
            duration,
        )
        return response


class AGUIRunCollectorMiddleware(BaseHTTPMiddleware):
    """Create and manage PipelineCollector for each AG-UI request.

    This middleware intercepts AG-UI requests (POST to /) and creates
    a PipelineCollector instance to track the entire pipeline execution.
    The collector captures events, metrics, and final status for dashboard
    display and post-mortem analysis.

    Attributes:
        None - Configured via FastAPI middleware stack.

    Example:
        When a POST / request arrives:
        1. Creates PipelineCollector with unique run_id
        2. Inserts run record into database
        3. Passes request to handler
        4. On completion, finalizes collector and updates database
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        """Process AG-UI request with collector tracking.

        Args:
            request: The incoming HTTP request.
            call_next: The next middleware/handler in the chain.

        Returns:
            The HTTP response, potentially wrapped for SSE streaming.
        """
        # Only intercept AG-UI endpoint
        if request.url.path != "/" or request.method != "POST":
            return await call_next(request)

        # Create unique run ID and collector
        run_id = f"run_{uuid.uuid4().hex[:8]}"
        collector = PipelineCollector(run_id=run_id)
        set_active_collector(collector)
        insert_run(run_id)

        logger.info("Started pipeline run: %s", run_id)

        try:
            response = await call_next(request)

            # For SSE responses, wrap the body iterator to capture completion
            if hasattr(response, "body_iterator"):
                original_iterator = response.body_iterator

                async def wrapped_iterator() -> AsyncGenerator[bytes, None]:
                    """Wrap iterator to finalize collector on completion."""
                    try:
                        async for chunk in original_iterator:
                            yield chunk
                    finally:
                        # Finalize when stream completes
                        data = collector.finalize()
                        finalize_run(run_id, status=data["status"], metadata=data)
                        insert_snapshot(run_id, data)
                        remove_collector(run_id)
                        logger.info("Pipeline run %s finalized", run_id)

                response.body_iterator = wrapped_iterator()

            return response

        except Exception as e:
            # Capture error state
            collector.finalize(status="error")
            finalize_run(run_id, status="error", metadata={"error": str(e)})
            remove_collector(run_id)
            logger.error("Pipeline run %s failed: %s", run_id, e)
            raise


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan: setup OTel, validate env, init DB.

    This context manager handles startup and shutdown events:
    - Startup: Validates environment, sets up OpenTelemetry, initializes DB
    - Shutdown: Logs shutdown message

    Args:
        app: The FastAPI application instance.

    Yields:
        None - Control passes to application runtime.

    Example:
        Automatically used by FastAPI:
        >>> app = FastAPI(lifespan=lifespan)
    """
    # Startup
    _validate_env()
    setup_otel()
    init_db()
    logger.info("Documentary pipeline server started")
    
    yield
    
    # Shutdown
    logger.info("Documentary pipeline server shutting down")


# Create FastAPI application
app = FastAPI(
    title="Documentary Pipeline",
    description="ADHD-friendly AI documentary pipeline with Google ADK + AG-UI",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add middleware (order matters: last added = first executed)
app.add_middleware(AGUIRunCollectorMiddleware)
app.add_middleware(RequestLoggingMiddleware)

# Include routers
app.include_router(dashboard_router)
app.include_router(agui_router)


# Configure ADK application with plugins
_adk_app = App(
    name="documentary_pipeline",
    root_agent=pipeline_agent,
    plugins=build_plugins(),
)

# Create ADK agent for AG-UI
adk_agent = ADKAgent.from_app(app=_adk_app)

# Add AG-UI endpoint
add_adk_fastapi_endpoint(app, adk_agent, path="/")


@app.get("/health", tags=["Health"])
async def health() -> dict[str, Any]:
    """Health check endpoint.

    Returns the current health status of the pipeline server including
    the configured model and version.

    Returns:
        Dict with status, model, and version information.

    Example:
        >>> import requests
        >>> response = requests.get("http://localhost:8000/health")
        >>> response.json()
        {'status': 'ok', 'model': 'gemini-2.5-flash', 'version': '0.1.0'}
    """
    return {
        "status": "ok",
        "model": ADK_MODEL_NAME,
        "version": "0.1.0",
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
```

---

## Agent Modules

### Scenario Director

```python
"""
Scenario Director Agent - Generates ADHD-compliant documentary scripts.

This module implements an EvaluatorOptimizer pattern agent that:
1. Generates documentary scenarios with V1/V2/V3 voice structure
2. Evaluates scenarios against ADHD compliance criteria
3. Iterates until quality threshold is met

The agent enforces:
- Maximum 45 seconds per scene
- Three distinct voices per scene (Hook, Expert, Storyteller)
- No rhetorical questions
- Dopamine hooks in every scene
"""

from typing import Any
from google.adk.agents import Agent
from google.adk.agents.loop_agent import EvaluatorOptimizer

# Agent instruction with ADHD principles
SCENARIO_DIRECTOR_INSTRUCTION = """
You are the Scenario Director for an ADHD-friendly documentary pipeline.

Your task is to generate documentary scripts that maintain viewer engagement
through specific structural and content patterns.

## Output Format

Generate a JSON scenario with the following structure:
{
    "title": "Documentary title",
    "scenes": [
        {
            "scene_num": 1,
            "title": "Scene title",
            "duration_sec": 42,
            "voices": {
                "V1": "Hook voice text (15s max)",
                "V2": "Expert voice text (20s max)",
                "V3": "Storyteller voice text (10s max)"
            },
            "dopamine_hook": "Description of the attention hook"
        }
    ]
}

## ADHD Compliance Rules

1. MAX 45 SECONDS per scene - enforced strictly
2. THREE VOICES per scene:
   - V1 (Hook): Surprising fact or provocative framing
   - V2 (Expert): Data, mechanisms, analysis
   - V3 (Storyteller): Human context, narrative grounding
3. NO RHETORICAL QUESTIONS - state mechanisms directly
4. DOPAMINE HOOK in every scene
5. VISUAL VARIETY implied - no consecutive same styles

## Evaluation Criteria

The evaluator will rate your scenario as:
- GOOD: Meets all criteria, ready for production
- FAIR: Minor issues, one regeneration allowed
- POOR: Major violations, must regenerate with feedback
"""


def create_scenario_director() -> EvaluatorOptimizer:
    """Create the Scenario Director agent.

    Returns:
        Configured EvaluatorOptimizer agent for scenario generation.

    Example:
        >>> director = create_scenario_director()
        >>> result = await director.run("The Federal Reserve")
    """
    generator = Agent(
        name="scenario_generator",
        instruction=SCENARIO_DIRECTOR_INSTRUCTION,
        model=config.ADK_MODEL,
    )
    
    evaluator = Agent(
        name="scenario_evaluator",
        instruction="""
        Evaluate scenarios for ADHD compliance.
        
        Check:
        1. Scene duration <= 45 seconds
        2. All three voices present
        3. No rhetorical questions
        4. Dopamine hooks present
        5. Total runtime appropriate
        
        Rate: GOOD, FAIR, or POOR with specific feedback.
        """,
        model=config.ADK_MODEL,
    )
    
    return EvaluatorOptimizer(
        name="scenario_director",
        generator=generator,
        evaluator=evaluator,
        max_iterations=3,
    )
```

---

## Dashboard Module

### PipelineCollector

```python
"""
Pipeline event collector for real-time dashboard monitoring.

This module provides the PipelineCollector class that captures events,
metrics, and state changes during pipeline execution for dashboard
visualization and post-mortem analysis.
"""

from typing import Any, Optional
from datetime import datetime
from dataclasses import dataclass, field
import json


@dataclass
class PipelineEvent:
    """A single event in the pipeline execution.
    
    Attributes:
        timestamp: When the event occurred (UTC).
        event_type: Type of event (phase_start, tool_call, etc.).
        phase: Current pipeline phase when event occurred.
        data: Event-specific data payload.
    """
    timestamp: datetime
    event_type: str
    phase: str
    data: dict[str, Any]
    
    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary for serialization."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "event_type": self.event_type,
            "phase": self.phase,
            "data": self.data,
        }


class PipelineCollector:
    """Collects events and metrics for a single pipeline run.
    
    This class is instantiated at the start of each pipeline run and
    captures all relevant events for dashboard display and analysis.
    
    Attributes:
        run_id: Unique identifier for this pipeline run.
        events: List of captured events.
        start_time: When collection started.
        metrics: Aggregated metrics for the run.
    
    Example:
        >>> collector = PipelineCollector(run_id="run_abc123")
        >>> collector.add_event("phase_start", {"phase": "scenario"})
        >>> collector.add_metric("llm_calls", 1)
        >>> data = collector.finalize()
        >>> print(data["status"])
        completed
    """
    
    def __init__(self, run_id: str) -> None:
        """Initialize a new collector.
        
        Args:
            run_id: Unique identifier for this pipeline run.
        """
        self.run_id = run_id
        self.events: list[PipelineEvent] = []
        self.start_time = datetime.utcnow()
        self.metrics: dict[str, Any] = {
            "llm_calls": 0,
            "tool_calls": 0,
            "tokens_used": 0,
            "phases_completed": [],
        }
        self._current_phase: str = "initializing"
        self._finalized: bool = False
    
    def add_event(
        self,
        event_type: str,
        data: dict[str, Any],
        phase: Optional[str] = None
    ) -> None:
        """Add an event to the collection.
        
        Args:
            event_type: Type of event (e.g., 'phase_start', 'tool_call').
            data: Event-specific data payload.
            phase: Override the current phase (uses tracked phase if None).
        
        Raises:
            RuntimeError: If collector has been finalized.
        
        Example:
            >>> collector.add_event("tool_call", {
            ...     "tool": "scenario_director",
            ...     "duration_ms": 1500
            ... })
        """
        if self._finalized:
            raise RuntimeError("Cannot add events to finalized collector")
        
        event = PipelineEvent(
            timestamp=datetime.utcnow(),
            event_type=event_type,
            phase=phase or self._current_phase,
            data=data,
        )
        self.events.append(event)
    
    def add_metric(self, key: str, value: Any) -> None:
        """Add or update a metric.
        
        Args:
            key: Metric name.
            value: Metric value (will be added to existing if numeric).
        
        Example:
            >>> collector.add_metric("llm_calls", 1)  # Increments
            >>> collector.add_metric("topic", "Federal Reserve")  # Sets
        """
        if key in self.metrics and isinstance(self.metrics[key], (int, float)):
            if isinstance(value, (int, float)):
                self.metrics[key] += value
            else:
                self.metrics[key] = value
        else:
            self.metrics[key] = value
    
    def set_phase(self, phase: str) -> None:
        """Set the current pipeline phase.
        
        Args:
            phase: New phase name.
        
        Example:
            >>> collector.set_phase("audio")
            >>> collector.add_event("tts_start", {})
        """
        self._current_phase = phase
        if phase not in self.metrics["phases_completed"]:
            self.metrics["phases_completed"].append(phase)
    
    def finalize(self, status: str = "completed") -> dict[str, Any]:
        """Finalize the collection and return summary data.
        
        Args:
            status: Final run status ('completed', 'error', 'cancelled').
        
        Returns:
            Dictionary with run summary including events, metrics, and timing.
        
        Example:
            >>> data = collector.finalize(status="completed")
            >>> print(f"Run took {data['duration_sec']} seconds")
        """
        self._finalized = True
        duration = (datetime.utcnow() - self.start_time).total_seconds()
        
        return {
            "run_id": self.run_id,
            "status": status,
            "start_time": self.start_time.isoformat(),
            "duration_sec": duration,
            "events": [e.to_dict() for e in self.events],
            "metrics": self.metrics,
            "event_count": len(self.events),
        }
```

---

## Plugin Modules

### ContextFilterPlugin

```python
"""
ContextFilterPlugin - Manages context window size by filtering old invocations.

This plugin automatically removes older context invocations to keep the
context window within configured limits, preventing token overflow errors.
"""

from typing import Any, List
from google.adk.plugins import BasePlugin
from google.adk.artifacts import InvocationContext

from config import CONTEXT_INVOCATIONS_TO_KEEP


class ContextFilterPlugin(BasePlugin):
    """Plugin to filter context invocations and manage window size.
    
    This plugin runs before each model call and removes older invocations
    from the context, keeping only the most recent N invocations as
    configured by CONTEXT_INVOCATIONS_TO_KEEP.
    
    Attributes:
        invocations_to_keep: Number of recent invocations to retain.
    
    Example:
        >>> plugin = ContextFilterPlugin()
        >>> plugins = [plugin, ...]
        >>> app = App(plugins=plugins)
    """
    
    def __init__(self, invocations_to_keep: int = CONTEXT_INVOCATIONS_TO_KEEP):
        """Initialize the plugin.
        
        Args:
            invocations_to_keep: Number of recent invocations to keep.
        """
        self.invocations_to_keep = invocations_to_keep
    
    def before_model(
        self,
        invocation_context: InvocationContext,
        model_request: Any
    ) -> Any:
        """Filter context before model call.
        
        Args:
            invocation_context: Current invocation context.
            model_request: The model request being prepared.
        
        Returns:
            Potentially modified model request.
        """
        invocations = invocation_context.invocations
        
        if len(invocations) > self.invocations_to_keep:
            # Keep only the most recent invocations
            to_remove = len(invocations) - self.invocations_to_keep
            invocation_context.invocations = invocations[to_remove:]
        
        return model_request
```

---

## Tool Modules

### TTS Tool

```python
"""
Text-to-Speech tool for generating narration audio.

This module provides tools for converting script text into spoken audio
using various TTS providers (Qwen3-TTS, OpenAI TTS, etc.).
"""

from pathlib import Path
from typing import Optional
import aiohttp
import asyncio

from config import TTS_OUTPUT_DIR, TTS_CONCURRENCY


class TTSTool:
    """Tool for text-to-speech generation.
    
    Supports multiple TTS providers with automatic fallback.
    
    Attributes:
        output_dir: Directory for audio output files.
        semaphore: Concurrency limiter for TTS requests.
    
    Example:
        >>> tts = TTSTool()
        >>> audio_path = await tts.generate(
        ...     text="Welcome to the documentary",
        ...     voice="alloy",
        ...     output_name="intro"
        ... )
    """
    
    def __init__(
        self,
        output_dir: Path = TTS_OUTPUT_DIR,
        max_concurrency: int = TTS_CONCURRENCY
    ):
        """Initialize TTS tool.
        
        Args:
            output_dir: Directory for audio output.
            max_concurrency: Max concurrent TTS requests.
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.semaphore = asyncio.Semaphore(max_concurrency)
    
    async def generate(
        self,
        text: str,
        voice: str = "alloy",
        output_name: Optional[str] = None,
        provider: str = "openai"
    ) -> Path:
        """Generate audio from text.
        
        Args:
            text: Text to convert to speech.
            voice: Voice identifier (provider-specific).
            output_name: Base name for output file (auto-generated if None).
            provider: TTS provider ('openai', 'qwen3', etc.).
        
        Returns:
            Path to generated audio file.
        
        Raises:
            TTSError: If generation fails.
        
        Example:
            >>> path = await tts.generate(
            ...     text="The Federal Reserve controls monetary policy.",
            ...     voice="echo",
            ...     output_name="scene_01_v2"
            ... )
        """
        async with self.semaphore:
            if provider == "openai":
                return await self._generate_openai(text, voice, output_name)
            elif provider == "qwen3":
                return await self._generate_qwen3(text, voice, output_name)
            else:
                raise ValueError(f"Unknown provider: {provider}")
    
    async def _generate_openai(
        self,
        text: str,
        voice: str,
        output_name: Optional[str]
    ) -> Path:
        """Generate using OpenAI TTS API."""
        from openai import AsyncOpenAI
        
        client = AsyncOpenAI()
        
        if output_name is None:
            output_name = f"tts_{hash(text) % 10000:04d}"
        
        output_path = self.output_dir / f"{output_name}.wav"
        
        response = await client.audio.speech.create(
            model="tts-1",
            voice=voice,
            input=text,
            response_format="wav"
        )
        
        response.stream_to_file(str(output_path))
        
        return output_path
```

---

## Callback Modules

### Timeline Guardian

```python
"""
Timeline Guardian - Validates OTIO timeline after each pipeline phase.

This callback runs after each agent completes to validate that the
timeline remains consistent and ready for the next phase.
"""

from typing import Any
from google.adk.artifacts import InvocationContext
import opentimelineio as otio

from config import TIMELINE_DIR


def timeline_guardian(
    invocation_context: InvocationContext,
    agent_output: Any
) -> Any:
    """Validate timeline after agent execution.
    
    This callback checks:
    1. Timeline file exists and is valid OTIO
    2. No overlapping clips on same track
    3. No gaps in the timeline
    4. All referenced media files exist
    5. Total duration matches expected
    
    Args:
        invocation_context: Current invocation context.
        agent_output: Output from the agent that just ran.
    
    Returns:
        The agent output (unchanged if validation passes).
    
    Raises:
        TimelineValidationError: If timeline validation fails.
    
    Example:
        Configured as after_agent callback:
        >>> agent = Agent(
        ...     callbacks={"after_agent": timeline_guardian}
        ... )
    """
    # Get current phase from context
    phase = invocation_context.state.get("current_phase", "unknown")
    
    # Get timeline path
    timeline_path = invocation_context.state.get("timeline_path")
    
    if not timeline_path:
        # No timeline yet (early phases), skip validation
        return agent_output
    
    timeline_path = Path(timeline_path)
    
    if not timeline_path.exists():
        raise TimelineValidationError(
            f"Timeline file not found: {timeline_path}"
        )
    
    try:
        timeline = otio.adapters.read_from_file(str(timeline_path))
    except Exception as e:
        raise TimelineValidationError(
            f"Failed to read timeline: {e}"
        )
    
    # Validate each track
    for track in timeline.tracks:
        validate_track(track)
    
    return agent_output


def validate_track(track: otio.schema.Track) -> None:
    """Validate a single track for consistency.
    
    Args:
        track: OTIO track to validate.
    
    Raises:
        TimelineValidationError: If validation fails.
    """
    clips = [c for c in track.each_clip()]
    
    if not clips:
        return
    
    # Check for overlaps
    for i in range(len(clips) - 1):
        current_end = clips[i].range_in_parent().end_time_in_parent()
        next_start = clips[i + 1].range_in_parent().start_time_in_parent()
        
        if current_end > next_start:
            raise TimelineValidationError(
                f"Overlapping clips on track {track.name}: "
                f"{clips[i].name} and {clips[i+1].name}"
            )
    
    # Check for gaps (optional - some gaps may be intentional)
    # ...


class TimelineValidationError(Exception):
    """Raised when timeline validation fails."""
    pass
```

---

## Vault Builder Module

### VaultBuilder Class

```python
"""
Obsidian vault builder for documentary research findings.

This module provides the VaultBuilder class for creating and maintaining
an Obsidian-compatible markdown vault from claim verification data.
"""

import json
import re
from pathlib import Path
from collections import defaultdict
from typing import Optional


class VaultBuilder:
    """Maintains an Obsidian vault with real-time claim updates.
    
    This class is designed to be instantiated by the pipeline and called
    after each claim completes. It writes claim pages instantly and
    rebuilds all index files so Obsidian and Quartz see progress in real-time.
    
    Outputs to two locations:
    - Obsidian vault (with .obsidian config)
    - Quartz content dir (for static site generation)
    
    Attributes:
        output: Path to Obsidian vault root.
        quartz: Path to Quartz content directory.
        scenes_data: Dictionary of scene metadata.
        records: List of all claim records.
    
    Example:
        >>> scenes = {1: {"title": "Introduction", "phase": "opening"}}
        >>> builder = VaultBuilder(
        ...     output=Path("/vault"),
        ...     scenes_data=scenes
        ... )
        >>> builder.on_claim(claim_dict, record_dict)
    """
    
    def __init__(
        self,
        output: Path,
        scenes_data: dict[int, dict],
        quartz_content: Optional[Path] = None
    ):
        """Initialize the vault builder.
        
        Args:
            output: Path to Obsidian vault root directory.
            scenes_data: Dictionary mapping scene_num to scene metadata.
            quartz_content: Optional path to Quartz content directory.
        """
        self.output = Path(output)
        self.quartz = quartz_content or self.output / "quartz"
        self.scenes_data = scenes_data
        self.records: list[dict] = []
        self.by_scene: dict[int, list[dict]] = defaultdict(list)
        self.by_topic: dict[str, list[dict]] = defaultdict(list)
        self.all_scene_titles: dict[int, str] = {}
        
        # Initialize scene titles
        for snum, sd in scenes_data.items():
            self.all_scene_titles[snum] = sd.get("title", f"Scene {snum}")
        
        self._create_directories()
        self._setup_obsidian_config()
    
    def _create_directories(self) -> None:
        """Create directory structure for both outputs."""
        for root in [self.output, self.quartz]:
            for d in ["", "Scenes", "Claims", "Topics"]:
                (root / d).mkdir(parents=True, exist_ok=True)
    
    def _setup_obsidian_config(self) -> None:
        """Set up Obsidian configuration files."""
        obsidian_dir = self.output / ".obsidian"
        obsidian_dir.mkdir(exist_ok=True)
        
        # Graph view configuration
        graph_config = {
            "colorGroups": [
                {"query": "path:Scenes", "color": {"a": 1, "rgb": 3066993}},
                {"query": "path:Claims", "color": {"a": 1, "rgb": 15105570}},
                {"query": "path:Topics", "color": {"a": 1, "rgb": 8388736}},
            ],
            "showArrow": True,
            "linkDistance": 250,
            "repelStrength": 10,
        }
        
        with open(obsidian_dir / "graph.json", "w") as f:
            json.dump(graph_config, f, indent=2)
    
    def on_claim(self, claim: dict, rec: dict) -> None:
        """Process a completed claim and update the vault.
        
        This method should be called after each claim verification completes.
        It writes the claim page and rebuilds all index files.
        
        Args:
            claim: The original claim dictionary with id, text, scene_num, etc.
            rec: The stream record dictionary with verification results.
        
        Example:
            >>> claim = {
            ...     "id": "claim_001",
            ...     "text": "The Fed raised rates by 0.25%",
            ...     "scene_num": 1,
            ...     "scene_title": "Rate Decision"
            ... }
            >>> rec = {
            ...     "claim_id": "claim_001",
            ...     "status": "verified",
            ...     "confidence": 0.95,
            ...     "conditions": [...],
            ...     ...
            ... }
            >>> builder.on_claim(claim, rec)
        """
        # Store record
        self.records.append(rec)
        snum = rec["scene_num"]
        self.by_scene[snum].append(rec)
        
        # Update scene title if needed
        if snum not in self.all_scene_titles:
            self.all_scene_titles[snum] = rec.get("scene_title", f"Scene {snum}")
        
        # Assign topics
        for topic in self._assign_topics(rec["claim_text"]):
            self.by_topic[topic].append(rec)
        
        # Write claim page
        cid = rec["claim_id"]
        page = self._build_claim_page(rec)
        self._write(self.output / "Claims" / f"{cid}.md", page)
        
        # Rebuild indexes
        self._rebuild_indexes()
    
    def _build_claim_page(self, rec: dict) -> str:
        """Build markdown content for a claim page.
        
        Args:
            rec: Claim record dictionary.
        
        Returns:
            Markdown content as string.
        """
        cid = rec["claim_id"]
        status = rec["status"]
        conf = rec["confidence"]
        snum = rec["scene_num"]
        stitle = rec.get("scene_title", "")
        
        lines = [
            f"# {cid}",
            "",
            f"**Status:** {self._status_emoji(status)} {status}",
            f"**Confidence:** {conf:.2f}",
            f"**Scene:** [[Scenes/Scene {snum}: {stitle}|Scene {snum}]]",
            "",
            "## Claim",
            "",
            f"> {rec['claim_text']}",
            "",
        ]
        
        # Add conditions if present
        conditions = rec.get("conditions", [])
        if conditions:
            lines.append(f"## Findings ({len(conditions)} conditions)")
            lines.append("")
            for i, c in enumerate(conditions, 1):
                lines.append(f"{i}. {c['fact']}")
            lines.append("")
        
        # Add sources if present
        sources = rec.get("sources", [])
        if sources:
            lines.append(f"## Sources ({len(sources)})")
            lines.append("")
            for s in sources:
                lines.append(f"- [{s}]({s})")
            lines.append("")
        
        return "\n".join(lines)
    
    def _rebuild_indexes(self) -> None:
        """Rebuild all index files from current state."""
        # Implementation for rebuilding Dashboard, Scene Index, Topic Index, etc.
        pass
    
    def _write(self, path: Path, content: str) -> None:
        """Write content to file and mirror to Quartz.
        
        Args:
            path: Target file path.
            content: Content to write.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        
        # Mirror to Quartz
        try:
            rel = path.relative_to(self.output)
            quartz_path = self.quartz / rel
            quartz_path.parent.mkdir(parents=True, exist_ok=True)
            quartz_path.write_text(content, encoding="utf-8")
        except ValueError:
            pass  # Path not under output
    
    @staticmethod
    def _status_emoji(status: str) -> str:
        """Get emoji for claim status.
        
        Args:
            status: Claim status string.
        
        Returns:
            Emoji character for the status.
        """
        return {
            "verified": "✅",
            "partial": "⚠️",
            "disputed": "❌",
            "unverified": "❓",
        }.get(status, "❓")
    
    @staticmethod
    def _assign_topics(text: str) -> list[str]:
        """Assign topics to claim text based on keyword matching.
        
        Args:
            text: Claim text to analyze.
        
        Returns:
            List of matched topic names.
        """
        text_lower = text.lower()
        topics = []
        
        topic_keywords = {
            "Federal Reserve": ["federal reserve", "fed ", "fomc"],
            "Inflation": ["inflation", "cpi", "consumer price"],
            "Cryptocurrency": ["bitcoin", "crypto", "btc"],
        }
        
        for topic, keywords in topic_keywords.items():
            if any(kw in text_lower for kw in keywords):
                topics.append(topic)
        
        return topics
```
