# Deployment Guide

Complete guide for deploying the Documentary Pipeline in various environments.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Local Development Deployment](#local-development-deployment)
3. [Docker Deployment](#docker-deployment)
4. [Cloud Deployment](#cloud-deployment)
5. [Production Deployment](#production-deployment)
6. [GPU Infrastructure Setup](#gpu-infrastructure-setup)
7. [Monitoring and Alerting](#monitoring-and-alerting)
8. [Security Considerations](#security-considerations)
9. [Backup and Recovery](#backup-and-recovery)
10. [Scaling Strategies](#scaling-strategies)

---

## Prerequisites

### System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8+ cores |
| RAM | 16 GB | 32+ GB |
| Disk | 100 GB SSD | 500 GB NVMe |
| GPU | None (test mode) | RTX 4090 or A100 |
| Network | 100 Mbps | 1 Gbps |

### Software Requirements

- Python 3.10+
- Poetry 1.7+
- FFmpeg 4.4+
- SQLite 3.35+
- Git 2.30+

### API Keys Required

| Service | Purpose | Required For |
|---------|---------|--------------|
| Google AI (Gemini) | LLM inference | All deployments |
| OpenAI | Alternative LLM / TTS | Optional |
| Vast.ai | GPU provisioning | Production |
| Perplexity | Web search | Research phase |
| FRED | Economic data | Economy documentaries |
| AgentOps | Observability | Optional |

---

## Local Development Deployment

### Quick Start

```bash
# 1. Clone repository
git clone https://github.com/OrpingtonClose/economy-documentary.git
cd economy-documentary

# 2. Set up Python environment
poetry install

# 3. Configure environment
cd server
cp .env.example .env
# Edit .env with your API keys

# 4. Start server
poetry run uvicorn server:app --reload --port 8000

# 5. Verify deployment
curl http://localhost:8000/health
```

### Development Mode Features

```bash
# Enable hot reload
poetry run uvicorn server:app --reload --port 8000

# Enable debug logging
export ADK_DEBUG=true
export LOG_LEVEL=DEBUG

# Test mode (no GPU required)
export DOCUMENTARY_TEST_MODE=true

# Run test pipeline
python test_run.py --topic "Test Topic"
```

---

## Docker Deployment

### Building the Image

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    ffmpeg \
    git \
    && rm -rf /var/lib/apt/lists/*

# Install Poetry
RUN pip install poetry

# Copy project files
COPY pyproject.toml poetry.lock ./
COPY server/ ./server/
COPY config.py ./

# Install dependencies
RUN poetry config virtualenvs.create false \
    && poetry install --no-dev

# Set environment
ENV PYTHONPATH=/app
ENV DATA_DIR=/app/data

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Start server
CMD ["poetry", "run", "uvicorn", "server.server:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Building and Running

```bash
# Build image
docker build -t documentary-pipeline:latest .

# Run container
docker run -d \
  --name documentary-pipeline \
  -p 8000:8000 \
  -e GOOGLE_API_KEY=$GOOGLE_API_KEY \
  -e VAST_API_KEY=$VAST_API_KEY \
  -v /host/data:/app/data \
  documentary-pipeline:latest

# View logs
docker logs -f documentary-pipeline
```

### Docker Compose

```yaml
# docker-compose.yml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - GOOGLE_API_KEY=${GOOGLE_API_KEY}
      - VAST_API_KEY=${VAST_API_KEY}
      - ADK_MODEL=${ADK_MODEL:-gemini-2.5-flash}
      - DATA_DIR=/app/data
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped

  # Optional: Frontend
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - NEXT_PUBLIC_API_URL=http://api:8000
    depends_on:
      - api
```

```bash
# Start all services
docker-compose up -d

# Scale API instances
docker-compose up -d --scale api=3

# View logs
docker-compose logs -f api
```

---

## Cloud Deployment

### AWS Deployment

#### ECS Fargate

```bash
# 1. Create ECR repository
aws ecr create-repository --repository-name documentary-pipeline

# 2. Build and push image
aws ecr get-login-password | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com

docker build -t documentary-pipeline .
docker tag documentary-pipeline:latest $AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/documentary-pipeline:latest
docker push $AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/documentary-pipeline:latest

# 3. Create ECS task definition
aws ecs register-task-definition --cli-input-json file://ecs-task-definition.json

# 4. Create ECS service
aws ecs create-service \
  --cluster documentary-cluster \
  --service-name documentary-api \
  --task-definition documentary-pipeline \
  --desired-count 2 \
  --launch-type FARGATE
```

**ecs-task-definition.json:**
```json
{
  "family": "documentary-pipeline",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "4096",
  "memory": "16384",
  "containerDefinitions": [{
    "name": "api",
    "image": "${AWS_ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/documentary-pipeline:latest",
    "portMappings": [{"containerPort": 8000}],
    "environment": [
      {"name": "ADK_MODEL", "value": "gemini-2.5-flash"}
    ],
    "secrets": [
      {"name": "GOOGLE_API_KEY", "valueFrom": "arn:aws:secretsmanager:..."}
    ],
    "logConfiguration": {
      "logDriver": "awslogs",
      "options": {
        "awslogs-group": "/ecs/documentary-pipeline",
        "awslogs-region": "us-east-1",
        "awslogs-stream-prefix": "ecs"
      }
    }
  }]
}
```

---

### Google Cloud Run

```bash
# 1. Build and push to GCR
gcloud builds submit --tag gcr.io/$PROJECT_ID/documentary-pipeline

# 2. Deploy to Cloud Run
gcloud run deploy documentary-pipeline \
  --image gcr.io/$PROJECT_ID/documentary-pipeline \
  --platform managed \
  --region us-central1 \
  --memory 16Gi \
  --cpu 4 \
  --concurrency 10 \
  --max-instances 10 \
  --set-env-vars="ADK_MODEL=gemini-2.5-flash" \
  --set-secrets="GOOGLE_API_KEY=google-api-key:latest"

# 3. Get service URL
gcloud run services describe documentary-pipeline --region us-central1 --format 'value(status.url)'
```

---

### Azure Container Instances

```bash
# 1. Create resource group
az group create --name documentary-rg --location eastus

# 2. Create container
az container create \
  --resource-group documentary-rg \
  --name documentary-pipeline \
  --image documentaryregistry.azurecr.io/documentary-pipeline:latest \
  --cpu 4 \
  --memory 16 \
  --ports 8000 \
  --environment-variables ADK_MODEL=gemini-2.5-flash \
  --secure-environment-variables GOOGLE_API_KEY=$GOOGLE_API_KEY

# 3. Get IP address
az container show \
  --resource-group documentary-rg \
  --name documentary-pipeline \
  --query ipAddress.ip \
  --output tsv
```

---

## Production Deployment

### Production Checklist

- [ ] Environment variables configured
- [ ] API keys stored in secrets manager
- [ ] SSL/TLS certificates configured
- [ ] Database backups scheduled
- [ ] Monitoring and alerting enabled
- [ ] Rate limiting configured
- [ ] Log aggregation set up
- [ ] Health checks configured
- [ ] Auto-scaling policies defined
- [ ] Disaster recovery plan documented

### Environment Configuration

```bash
# Production environment variables
export ENVIRONMENT=production
export ADK_MODEL=gemini-2.5-flash
export ADK_DEBUG=false
export LOG_LEVEL=INFO

# Concurrency limits
export MAX_CONCURRENT_LLM=8
export GPU_CONCURRENCY=4
export TTS_CONCURRENCY=6

# Timeouts
export PIPELINE_TIMEOUT=3600
export GPU_STARTUP_TIMEOUT=600

# Storage
export DATA_DIR=/var/lib/documentary-pipeline/data
export TIMELINE_DIR=/var/lib/documentary-pipeline/timelines
export LOG_DIR=/var/log/documentary-pipeline
```

### Reverse Proxy (Nginx)

```nginx
# /etc/nginx/sites-available/documentary-pipeline
upstream documentary_backend {
    server 127.0.0.1:8000;
    keepalive 32;
}

server {
    listen 443 ssl http2;
    server_name api.documentary.example.com;

    ssl_certificate /etc/letsencrypt/live/api.documentary.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.documentary.example.com/privkey.pem;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req zone=api burst=20 nodelay;

    location / {
        proxy_pass http://documentary_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 3600s;  # For SSE streams
    }

    location /health {
        proxy_pass http://documentary_backend/health;
        access_log off;
    }
}
```

---

## GPU Infrastructure Setup

### Vast.ai Configuration

```bash
# Configure Vast.ai CLI
pip install vastai
vastai set api-key $VAST_API_KEY

# Search for suitable instances
vastai search offers 'gpu_name=RTX_4090 num_gpus=1'

# Create instance template
cat > vastai-template.json << 'EOF'
{
  "image": "nvidia/cuda:12.0-devel-ubuntu22.04",
  "runtype": "ssh",
  "disk": 100,
  "label": "documentary-gpu",
  "onstart": "#!/bin/bash\napt-get update && apt-get install -y python3-pip ffmpeg\npip install torch torchvision torchaudio\n# Install LTX-2.3 and other dependencies"
}
EOF

# Create instance
vastai create instance $(vastai search offers 'gpu_name=RTX_4090' --raw | jq -r '.[0].id') \
  --image nvidia/cuda:12.0-devel-ubuntu22.04 \
  --disk 100
```

### GPU Instance Provisioning Script

```python
# scripts/provision_gpu.py
import os
import requests
import time

VAST_API_KEY = os.environ["VAST_API_KEY"]
BASE_URL = "https://console.vast.ai/api/v0"

def provision_gpu(gpu_type="RTX_4090", min_vram_gb=24):
    """Provision a GPU instance on Vast.ai."""
    headers = {"Authorization": f"Bearer {VAST_API_KEY}"}
    
    # Search for offers
    response = requests.post(
        f"{BASE_URL}/bundles",
        headers=headers,
        json={"q": {"gpu_name": gpu_type}}
    )
    offers = response.json()["offers"]
    
    # Filter by VRAM
    suitable = [o for o in offers if o["num_gpus"] * o["gpu_ram"] >= min_vram_gb]
    
    if not suitable:
        raise Exception(f"No suitable {gpu_type} instances available")
    
    # Create instance
    offer = suitable[0]
    response = requests.put(
        f"{BASE_URL}/instances",
        headers=headers,
        json={
            "offer_id": offer["id"],
            "image": "nvidia/cuda:12.0-devel-ubuntu22.04",
            "disk": 100,
            "label": "documentary-gpu"
        }
    )
    
    instance_id = response.json()["new_contract"]
    
    # Wait for instance to be ready
    for _ in range(60):
        response = requests.get(
            f"{BASE_URL}/instances/{instance_id}",
            headers=headers
        )
        status = response.json()["instances"][0]["actual_status"]
        if status == "running":
            return instance_id
        time.sleep(10)
    
    raise Exception("Instance failed to start within timeout")

def destroy_gpu(instance_id):
    """Destroy a GPU instance."""
    headers = {"Authorization": f"Bearer {VAST_API_KEY}"}
    requests.delete(f"{BASE_URL}/instances/{instance_id}", headers=headers)

if __name__ == "__main__":
    instance_id = provision_gpu()
    print(f"Provisioned GPU instance: {instance_id}")
```

---

## Monitoring and Alerting

### Prometheus Metrics

```python
# server/metrics.py
from prometheus_client import Counter, Histogram, Gauge, generate_latest
from fastapi import APIRouter

router = APIRouter()

# Counters
pipeline_runs_total = Counter(
    'pipeline_runs_total',
    'Total pipeline runs',
    ['status', 'topic_category']
)

llm_calls_total = Counter(
    'llm_calls_total',
    'Total LLM API calls',
    ['model', 'status']
)

tool_calls_total = Counter(
    'tool_calls_total',
    'Total tool calls',
    ['tool_name', 'status']
)

# Histograms
pipeline_duration_seconds = Histogram(
    'pipeline_duration_seconds',
    'Pipeline execution duration',
    ['phase']
)

llm_latency_seconds = Histogram(
    'llm_latency_seconds',
    'LLM API latency',
    ['model']
)

# Gauges
active_runs = Gauge(
    'active_pipeline_runs',
    'Number of active pipeline runs'
)

gpu_instances_active = Gauge(
    'gpu_instances_active',
    'Number of active GPU instances'
)

@router.get("/metrics")
async def metrics():
    return generate_latest()
```

### Grafana Dashboard

```json
{
  "dashboard": {
    "title": "Documentary Pipeline",
    "panels": [
      {
        "title": "Pipeline Runs",
        "targets": [{
          "expr": "sum(rate(pipeline_runs_total[5m])) by (status)"
        }],
        "type": "graph"
      },
      {
        "title": "Active Runs",
        "targets": [{
          "expr": "active_pipeline_runs"
        }],
        "type": "stat"
      },
      {
        "title": "Phase Duration",
        "targets": [{
          "expr": "histogram_quantile(0.95, rate(pipeline_duration_seconds_bucket[5m]))"
        }],
        "type": "graph"
      },
      {
        "title": "LLM Calls",
        "targets": [{
          "expr": "sum(rate(llm_calls_total[5m])) by (model)"
        }],
        "type": "graph"
      }
    ]
  }
}
```

### Alerting Rules

```yaml
# alerting-rules.yml
groups:
  - name: documentary-pipeline
    rules:
      - alert: PipelineRunFailed
        expr: increase(pipeline_runs_total{status="failed"}[5m]) > 0
        for: 0m
        labels:
          severity: warning
        annotations:
          summary: "Pipeline run failed"
          description: "A pipeline run has failed in the last 5 minutes"

      - alert: HighErrorRate
        expr: rate(pipeline_runs_total{status="failed"}[15m]) / rate(pipeline_runs_total[15m]) > 0.1
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High pipeline error rate"
          description: "Error rate is above 10% for the last 15 minutes"

      - alert: GPUNotAvailable
        expr: gpu_instances_active == 0
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "No GPU instances available"
          description: "No GPU instances have been available for 5 minutes"

      - alert: PipelineDurationHigh
        expr: histogram_quantile(0.95, rate(pipeline_duration_seconds_bucket[15m])) > 1800
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Pipeline duration is high"
          description: "95th percentile pipeline duration exceeds 30 minutes"
```

---

## Security Considerations

### API Key Management

```bash
# Use secrets manager (AWS)
aws secretsmanager create-secret \
  --name documentary/google-api-key \
  --secret-string "$GOOGLE_API_KEY"

# Use secrets manager (GCP)
echo -n "$GOOGLE_API_KEY" | gcloud secrets create google-api-key --data-file=-

# Use Kubernetes secrets
kubectl create secret generic api-keys \
  --from-literal=google-api-key=$GOOGLE_API_KEY \
  --from-literal=vast-api-key=$VAST_API_KEY
```

### Network Security

```bash
# Configure firewall (UFW)
ufw default deny incoming
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 8000/tcp  # API (if not using reverse proxy)
ufw enable

# Configure fail2ban
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[nginx-http-auth]
enabled = true
EOF

systemctl restart fail2ban
```

### Data Encryption

```python
# Encrypt sensitive data at rest
from cryptography.fernet import Fernet
import os

# Generate key
key = Fernet.generate_key()
cipher = Fernet(key)

# Encrypt data
def encrypt_data(data: str) -> bytes:
    return cipher.encrypt(data.encode())

# Decrypt data
def decrypt_data(token: bytes) -> str:
    return cipher.decrypt(token).decode()

# Store key securely (e.g., in secrets manager)
os.environ["ENCRYPTION_KEY"] = key.decode()
```

---

## Backup and Recovery

### Database Backup

```bash
#!/bin/bash
# scripts/backup.sh

BACKUP_DIR="/backups/documentary-pipeline"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup SQLite databases
sqlite3 /tmp/documentary-pipeline/dashboard/events.db ".backup '$BACKUP_DIR/events_$DATE.db'"

# Backup timelines
tar -czf "$BACKUP_DIR/timelines_$DATE.tar.gz" /tmp/documentary-pipeline/timelines/

# Backup generated content
tar -czf "$BACKUP_DIR/output_$DATE.tar.gz" /tmp/documentary-pipeline/output/

# Upload to S3 (optional)
aws s3 sync "$BACKUP_DIR" s3://documentary-pipeline-backups/

# Clean old backups (keep 7 days)
find "$BACKUP_DIR" -type f -mtime +7 -delete
```

### Recovery Procedure

```bash
#!/bin/bash
# scripts/restore.sh

BACKUP_DATE=$1
BACKUP_DIR="/backups/documentary-pipeline"

# Stop services
docker-compose stop api

# Restore database
cp "$BACKUP_DIR/events_$BACKUP_DATE.db" /tmp/documentary-pipeline/dashboard/events.db

# Restore timelines
tar -xzf "$BACKUP_DIR/timelines_$BACKUP_DATE.tar.gz" -C /

# Restore output
tar -xzf "$BACKUP_DIR/output_$BACKUP_DATE.tar.gz" -C /

# Start services
docker-compose start api

echo "Restore complete from backup: $BACKUP_DATE"
```

---

## Scaling Strategies

### Horizontal Scaling

```yaml
# docker-compose.scale.yml
version: '3.8'

services:
  api:
    build: .
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '4'
          memory: 16G
    environment:
      - REDIS_URL=redis://redis:6379
    depends_on:
      - redis

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - api

volumes:
  redis_data:
```

### Load Balancer Configuration

```nginx
# nginx-scale.conf
upstream api_backend {
    least_conn;
    server api_1:8000;
    server api_2:8000;
    server api_3:8000;
    keepalive 32;
}

server {
    listen 80;
    
    location / {
        proxy_pass http://api_backend;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
    }
}
```

### Auto-scaling (Kubernetes)

```yaml
# k8s-hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: documentary-pipeline-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: documentary-pipeline
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
        - type: Percent
          value: 100
          periodSeconds: 15
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
        - type: Percent
          value: 10
          periodSeconds: 60
```

---

## Deployment Verification

```bash
#!/bin/bash
# scripts/verify-deployment.sh

set -e

API_URL=${API_URL:-"http://localhost:8000"}

echo "=== Deployment Verification ==="

# Health check
echo -n "Health check... "
if curl -sf "$API_URL/health" > /dev/null; then
    echo "OK"
else
    echo "FAILED"
    exit 1
fi

# API endpoints
echo -n "API endpoints... "
if curl -sf "$API_URL/dashboard/runs" > /dev/null; then
    echo "OK"
else
    echo "FAILED"
    exit 1
fi

# Test pipeline (test mode)
echo -n "Test pipeline... "
export DOCUMENTARY_TEST_MODE=true
RESPONSE=$(curl -sf -X POST "$API_URL/" \
    -H "Content-Type: application/json" \
    -d '{"messages": [{"role": "user", "content": "Test topic"}]}' \
    --max-time 30)

if [ -n "$RESPONSE" ]; then
    echo "OK"
else
    echo "FAILED"
    exit 1
fi

# Check logs
echo -n "Log files... "
if [ -f "/var/log/documentary-pipeline/app.log" ]; then
    echo "OK"
else
    echo "WARNING (logs may be in container)"
fi

echo "=== Verification Complete ==="
```
