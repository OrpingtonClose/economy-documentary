# Documentary Pipeline Documentation

Welcome to the comprehensive documentation for the Documentary Pipeline - an AI-powered, ADHD-friendly documentary generation system.

## Quick Navigation

| Document | Description |
|----------|-------------|
| [API_DOCUMENTATION.md](API_DOCUMENTATION.md) | Complete API reference with examples |
| [TROUBLESHOOTING.md](TROUBLESHOOTING.md) | Common issues and solutions |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Deployment guides for all platforms |
| [ARCHITECTURE_DIAGRAMS.md](ARCHITECTURE_DIAGRAMS.md) | Visual architecture documentation |
| [ENVIRONMENT_SETUP.md](ENVIRONMENT_SETUP.md) | Step-by-step setup instructions |
| [CODE_DOCUMENTATION.md](CODE_DOCUMENTATION.md) | Inline code documentation |
| [../CHANGELOG.md](../CHANGELOG.md) | Version history and changes |

## Documentation Overview

### For Developers

1. **Getting Started**
   - Read [ENVIRONMENT_SETUP.md](ENVIRONMENT_SETUP.md) for setup instructions
   - Review [ARCHITECTURE_DIAGRAMS.md](ARCHITECTURE_DIAGRAMS.md) for system understanding
   - Check [CODE_DOCUMENTATION.md](CODE_DOCUMENTATION.md) for implementation details

2. **API Integration**
   - See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for endpoint reference
   - Find SDK examples in Python and JavaScript/TypeScript
   - Learn about authentication and rate limiting

3. **Deployment**
   - Follow [DEPLOYMENT.md](DEPLOYMENT.md) for production deployment
   - Configure monitoring and alerting
   - Set up SSL and security

### For Operators

1. **Troubleshooting**
   - Use [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common issues
   - Reference error codes and solutions
   - Learn debugging techniques

2. **Monitoring**
   - Set up Prometheus metrics
   - Configure Grafana dashboards
   - Enable alerting

## Architecture at a Glance

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (Next.js)                      │
│         CopilotKit Chat │ Dashboard │ Quality Gates          │
└──────────────────────────┬──────────────────────────────────┘
                           │ AG-UI Protocol (SSE)
┌──────────────────────────┴──────────────────────────────────┐
│                    FastAPI Server                            │
│     AG-UI Endpoint │ Dashboard API │ Health Check            │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────┴──────────────────────────────────┐
│              Master SequentialAgent                          │
│                                                              │
│  1. Scenario Director    → Script with V1/V2/V3 voices      │
│  2. Audio Agent          → TTS + WhisperX alignment         │
│  3. Visual Director      → Content analysis → Visuals       │
│  4. Production Supervisor → GPU video generation            │
│  5. Assembler Agent      → ffmpeg timeline assembly         │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Shared State (Blackboard Pattern)                  │    │
│  │  topic, scenes, whisperx_alignment, visual_concepts │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## Key Features

### ADHD-Friendly Design

- **Maximum 45 seconds per scene** - Prevents cognitive fatigue
- **Three distinct voices per scene** - Hook, Expert, Storyteller
- **No rhetorical questions** - Direct, respectful communication
- **Visual variety enforcement** - No consecutive same styles
- **Dopamine hooks** - Surprising facts and visual shifts

### Quality Gates

Three human review points:
1. **Scenario Editor** - Review and edit generated scripts
2. **Prompt Reviewer** - Review visual prompts and LoRA selections
3. **Clip Reviewer** - Approve/reject generated video clips

### Pipeline Phases

| Phase | Agent | Output |
|-------|-------|--------|
| 1 | Scenario Director | ADHD-compliant script |
| 2 | Audio Agent | WAV files + word timing |
| 3 | Visual Director | Visual concepts |
| 4 | Production Supervisor | GPU-generated clips |
| 5 | Assembler Agent | Final MP4 documentary |

## Configuration

### Required Environment Variables

```bash
# Core
ADK_MODEL=gemini-2.5-flash
GOOGLE_API_KEY=your_key_here

# Production GPU
VAST_API_KEY=your_key_here
```

### Optional Environment Variables

```bash
# Development
DOCUMENTARY_TEST_MODE=true  # Skip GPU for testing
ADK_DEBUG=true              # Enable debug logging

# Paths
DATA_DIR=/custom/data/path
TIMELINE_DIR=/custom/timeline/path

# Concurrency
MAX_CONCURRENT_LLM=8
GPU_CONCURRENCY=4
```

See [server/.env.example](../server/.env.example) for the complete list.

## Quick Start

```bash
# 1. Clone and setup
git clone https://github.com/OrpingtonClose/economy-documentary.git
cd economy-documentary
poetry install

# 2. Configure
cd server
cp .env.example .env
# Edit .env with your API keys

# 3. Start server
poetry run uvicorn server:app --reload --port 8000

# 4. Test
curl http://localhost:8000/health
```

## API Quick Reference

### Health Check
```bash
GET /health
```

### Run Pipeline
```bash
POST /
Content-Type: application/json

{
  "messages": [
    {"role": "user", "content": "Your documentary topic"}
  ]
}
```

### Get Run Status
```bash
GET /dashboard/runs/{run_id}
```

### SSE Stream
```bash
GET /dashboard/runs/{run_id}/sse
```

See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for complete reference.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Update documentation
5. Submit a pull request

### Documentation Standards

- Use clear, concise language
- Include code examples
- Add Mermaid diagrams where helpful
- Follow existing formatting

## Support

- **Issues**: https://github.com/OrpingtonClose/economy-documentary/issues
- **Discussions**: https://github.com/OrpingtonClose/economy-documentary/discussions
- **Documentation**: You're reading it!

## License

MIT License - see LICENSE file for details.

---

*This documentation is maintained as part of the Documentary Pipeline project.*
*Last updated: 2025-01-15*
