# API Documentation

Complete API reference for the Documentary Pipeline server.

## Overview

The Documentary Pipeline exposes a FastAPI-based REST API with:
- **AG-UI Protocol** endpoint for CopilotKit frontend integration
- **Dashboard endpoints** for real-time monitoring
- **Health check** endpoint for service status

Base URL: `http://localhost:8000`

---

## Authentication

Currently, the API does not implement authentication. For production deployments:

1. Add API key authentication via middleware
2. Use OAuth2 with JWT tokens
3. Implement rate limiting per API key

Example authentication middleware:

```python
from fastapi import Security, HTTPException
from fastapi.security import APIKeyHeader

api_key_header = APIKeyHeader(name="X-API-Key")

async def verify_api_key(api_key: str = Security(api_key_header)):
    if api_key != os.environ.get("API_KEY"):
        raise HTTPException(status_code=403, detail="Invalid API key")
    return api_key
```

---

## Endpoints

### Health Check

#### GET `/health`

Returns the current health status of the pipeline server.

**Request:**
```bash
curl http://localhost:8000/health
```

**Response (200 OK):**
```json
{
  "status": "ok",
  "model": "gemini-2.5-flash",
  "version": "0.1.0"
}
```

**Error Response (503 Service Unavailable):**
```json
{
  "status": "error",
  "message": "Pipeline agent not initialized"
}
```

---

### AG-UI Endpoint (Main Pipeline)

#### POST `/`

The primary endpoint for running the documentary pipeline. Accepts AG-UI protocol requests from CopilotKit frontend.

**Content-Type:** `application/json` or `text/event-stream` (for SSE)

**Request Body:**
```json
{
  "messages": [
    {
      "role": "user",
      "content": "Create a documentary about the Federal Reserve"
    }
  ],
  "thread_id": "optional-thread-id",
  "run_id": "optional-run-id"
}
```

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `messages` | array | Yes | Array of message objects with `role` and `content` |
| `messages[].role` | string | Yes | Message role: `user`, `assistant`, or `system` |
| `messages[].content` | string | Yes | Message content |
| `thread_id` | string | No | Conversation thread ID for stateful sessions |
| `run_id` | string | No | Unique run identifier (auto-generated if not provided) |

**Response (SSE Stream):**

The endpoint returns Server-Sent Events (SSE) with the following event types:

```
event: agent_message
data: {"type": "agent_message", "content": "Generating scenario..."}

event: tool_call
data: {"type": "tool_call", "tool": "scenario_director", "status": "started"}

event: tool_result
data: {"type": "tool_result", "tool": "scenario_director", "result": {...}}

event: agent_message
data: {"type": "agent_message", "content": "Scenario complete. Moving to audio generation..."}

event: done
data: {"type": "done", "run_id": "run_abc123"}
```

**Error Response (500 Internal Server Error):**
```json
{
  "error": "Pipeline execution failed",
  "message": "Scenario generation exceeded timeout",
  "run_id": "run_abc123"
}
```

**Example Usage:**

```bash
# Using curl with SSE
curl -N -X POST http://localhost:8000/ \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{"role": "user", "content": "Documentary about inflation"}]
  }'

# Using Python requests
import requests
import json

response = requests.post(
    "http://localhost:8000/",
    json={"messages": [{"role": "user", "content": "Your topic"}]},
    stream=True
)

for line in response.iter_lines():
    if line:
        print(line.decode('utf-8'))
```

---

### Dashboard Endpoints

#### GET `/dashboard/runs`

Returns a list of all pipeline runs with their status.

**Request:**
```bash
curl http://localhost:8000/dashboard/runs
```

**Response (200 OK):**
```json
{
  "runs": [
    {
      "run_id": "run_abc123",
      "status": "completed",
      "started_at": "2025-01-15T10:30:00Z",
      "completed_at": "2025-01-15T10:45:00Z",
      "topic": "Federal Reserve",
      "phases_completed": ["scenario", "audio", "visual", "production", "assembly"]
    },
    {
      "run_id": "run_def456",
      "status": "in_progress",
      "started_at": "2025-01-15T11:00:00Z",
      "topic": "Cryptocurrency",
      "current_phase": "visual",
      "phases_completed": ["scenario", "audio"]
    }
  ]
}
```

---

#### GET `/dashboard/runs/{run_id}`

Returns detailed information about a specific pipeline run.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `run_id` | string | Yes | The unique run identifier |

**Request:**
```bash
curl http://localhost:8000/dashboard/runs/run_abc123
```

**Response (200 OK):**
```json
{
  "run_id": "run_abc123",
  "status": "completed",
  "topic": "Federal Reserve",
  "phases": {
    "scenario": {
      "status": "completed",
      "started_at": "2025-01-15T10:30:00Z",
      "completed_at": "2025-01-15T10:32:00Z",
      "scenes_generated": 8
    },
    "audio": {
      "status": "completed",
      "started_at": "2025-01-15T10:32:00Z",
      "completed_at": "2025-01-15T10:38:00Z",
      "clips_generated": 24
    },
    "visual": {
      "status": "completed",
      "started_at": "2025-01-15T10:38:00Z",
      "completed_at": "2025-01-15T10:42:00Z",
      "visual_concepts": 24
    },
    "production": {
      "status": "completed",
      "started_at": "2025-01-15T10:42:00Z",
      "completed_at": "2025-01-15T10:44:00Z",
      "clips_rendered": 24
    },
    "assembly": {
      "status": "completed",
      "started_at": "2025-01-15T10:44:00Z",
      "completed_at": "2025-01-15T10:45:00Z",
      "output_file": "/tmp/documentary-pipeline/output/final.mp4"
    }
  },
  "metrics": {
    "total_duration_seconds": 900,
    "llm_calls": 156,
    "tool_calls": 89,
    "gpu_minutes": 12
  }
}
```

**Error Response (404 Not Found):**
```json
{
  "error": "Run not found",
  "run_id": "run_abc123"
}
```

---

#### GET `/dashboard/runs/{run_id}/sse`

Server-Sent Events stream for real-time pipeline updates.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `run_id` | string | Yes | The unique run identifier |

**Request:**
```bash
curl -N http://localhost:8000/dashboard/runs/run_abc123/sse
```

**SSE Events:**

```
event: phase_start
data: {"phase": "scenario", "timestamp": "2025-01-15T10:30:00Z"}

event: progress
data: {"phase": "scenario", "progress": 0.5, "message": "Generating scene 4 of 8"}

event: phase_complete
data: {"phase": "scenario", "timestamp": "2025-01-15T10:32:00Z"}

event: phase_start
data: {"phase": "audio", "timestamp": "2025-01-15T10:32:00Z"}

event: tool_call
data: {"tool": "tts_generate", "scene": 1, "voice": "V1"}

event: progress
data: {"phase": "audio", "progress": 0.25, "clips_completed": 6}

event: complete
data: {"status": "success", "output_path": "/tmp/output/final.mp4"}
```

---

#### GET `/dashboard/metrics`

Returns aggregated pipeline metrics.

**Request:**
```bash
curl http://localhost:8000/dashboard/metrics
```

**Response (200 OK):**
```json
{
  "total_runs": 42,
  "successful_runs": 38,
  "failed_runs": 4,
  "average_duration_seconds": 847,
  "total_llm_calls": 6543,
  "total_tool_calls": 3876,
  "phase_stats": {
    "scenario": {"avg_duration": 120, "success_rate": 0.98},
    "audio": {"avg_duration": 360, "success_rate": 0.95},
    "visual": {"avg_duration": 240, "success_rate": 0.92},
    "production": {"avg_duration": 120, "success_rate": 0.88},
    "assembly": {"avg_duration": 60, "success_rate": 0.99}
  }
}
```

---

### AG-UI Feedback Endpoints

#### POST `/agui/feedback`

Submit feedback on generated artifacts (scenes, prompts, clips).

**Request Body:**
```json
{
  "run_id": "run_abc123",
  "artifact_type": "scene",
  "artifact_id": "scene_001",
  "feedback": "approve",
  "comments": "Good hook, but tighten the expert section"
}
```

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `run_id` | string | Yes | Pipeline run ID |
| `artifact_type` | string | Yes | Type: `scene`, `prompt`, `clip` |
| `artifact_id` | string | Yes | Unique artifact identifier |
| `feedback` | string | Yes | `approve`, `reject`, or `regenerate` |
| `comments` | string | No | Optional feedback comments |

**Response (200 OK):**
```json
{
  "status": "received",
  "feedback_id": "fb_789",
  "action_taken": "queued_for_regeneration"
}
```

---

#### POST `/agui/regenerate`

Request regeneration of a specific artifact.

**Request Body:**
```json
{
  "run_id": "run_abc123",
  "artifact_type": "scene",
  "artifact_id": "scene_001",
  "modifications": {
    "tone": "more_dramatic",
    "max_duration": 40
  }
}
```

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `run_id` | string | Yes | Pipeline run ID |
| `artifact_type` | string | Yes | Type: `scene`, `prompt`, `clip` |
| `artifact_id` | string | Yes | Unique artifact identifier |
| `modifications` | object | No | Modification parameters |

**Response (202 Accepted):**
```json
{
  "regeneration_id": "reg_456",
  "status": "queued",
  "estimated_completion": "2025-01-15T11:05:00Z"
}
```

---

## Error Handling

### HTTP Status Codes

| Code | Meaning | Description |
|------|---------|-------------|
| 200 | OK | Request successful |
| 202 | Accepted | Request accepted, processing asynchronously |
| 400 | Bad Request | Invalid request parameters |
| 404 | Not Found | Resource not found |
| 422 | Unprocessable Entity | Validation error |
| 500 | Internal Server Error | Server error |
| 503 | Service Unavailable | Service temporarily unavailable |

### Error Response Format

All errors follow this format:

```json
{
  "error": "Error code or type",
  "message": "Human-readable error description",
  "details": {},
  "request_id": "req_abc123"
}
```

### Common Errors

**Pipeline Timeout:**
```json
{
  "error": "PipelineTimeout",
  "message": "Pipeline execution exceeded maximum duration of 30 minutes",
  "details": {
    "phase": "production",
    "elapsed_seconds": 1800
  },
  "request_id": "req_abc123"
}
```

**Invalid Topic:**
```json
{
  "error": "InvalidTopic",
  "message": "Topic must be between 3 and 200 characters",
  "details": {
    "provided_length": 2,
    "min_length": 3,
    "max_length": 200
  },
  "request_id": "req_def456"
}
```

**GPU Unavailable:**
```json
{
  "error": "GPUUnavailable",
  "message": "No GPU instances available on Vast.ai",
  "details": {
    "provider": "vast_ai",
    "retry_after_seconds": 300
  },
  "request_id": "req_ghi789"
}
```

---

## Rate Limiting

Default rate limits:

| Endpoint | Limit | Window |
|----------|-------|--------|
| `POST /` | 5 | per minute |
| `GET /dashboard/*` | 60 | per minute |
| `POST /agui/*` | 30 | per minute |

Rate limit headers:

```
X-RateLimit-Limit: 5
X-RateLimit-Remaining: 3
X-RateLimit-Reset: 1640995200
```

---

## WebSocket Support (Future)

Planned WebSocket endpoint for bidirectional communication:

```
ws://localhost:8000/ws/{run_id}
```

This will enable:
- Real-time bidirectional communication
- Lower latency than SSE
- Better support for interactive feedback

---

## SDK Examples

### Python

```python
import requests
import json

class DocumentaryPipelineClient:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
    
    def health_check(self) -> dict:
        """Check server health status."""
        response = requests.get(f"{self.base_url}/health")
        response.raise_for_status()
        return response.json()
    
    def create_documentary(self, topic: str) -> str:
        """Start a new documentary pipeline run."""
        response = requests.post(
            f"{self.base_url}/",
            json={"messages": [{"role": "user", "content": topic}]},
            stream=True
        )
        response.raise_for_status()
        
        run_id = None
        for line in response.iter_lines():
            if line:
                data = json.loads(line.decode('utf-8').replace('data: ', ''))
                if data.get('type') == 'done':
                    run_id = data.get('run_id')
                    break
        
        return run_id
    
    def get_run_status(self, run_id: str) -> dict:
        """Get the status of a pipeline run."""
        response = requests.get(f"{self.base_url}/dashboard/runs/{run_id}")
        response.raise_for_status()
        return response.json()

# Usage
client = DocumentaryPipelineClient()
print(client.health_check())

run_id = client.create_documentary("The history of Bitcoin")
print(f"Started run: {run_id}")

import time
while True:
    status = client.get_run_status(run_id)
    print(f"Status: {status['status']}")
    if status['status'] in ['completed', 'failed']:
        break
    time.sleep(10)
```

### JavaScript/TypeScript

```typescript
interface PipelineRun {
  run_id: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  topic: string;
}

class DocumentaryPipelineClient {
  private baseUrl: string;
  
  constructor(baseUrl: string = 'http://localhost:8000') {
    this.baseUrl = baseUrl;
  }
  
  async healthCheck(): Promise<{ status: string; model: string }> {
    const response = await fetch(`${this.baseUrl}/health`);
    return response.json();
  }
  
  async createDocumentary(topic: string): Promise<string> {
    const response = await fetch(`${this.baseUrl}/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{ role: 'user', content: topic }]
      })
    });
    
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    
    while (true) {
      const { done, value } = await reader!.read();
      if (done) break;
      
      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');
      
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = JSON.parse(line.slice(6));
          if (data.type === 'done') {
            return data.run_id;
          }
        }
      }
    }
    
    throw new Error('Run ID not received');
  }
  
  async getRunStatus(runId: string): Promise<PipelineRun> {
    const response = await fetch(`${this.baseUrl}/dashboard/runs/${runId}`);
    return response.json();
  }
  
  subscribeToUpdates(runId: string, callback: (event: any) => void): void {
    const eventSource = new EventSource(
      `${this.baseUrl}/dashboard/runs/${runId}/sse`
    );
    
    eventSource.onmessage = (event) => {
      callback(JSON.parse(event.data));
    };
    
    eventSource.onerror = () => {
      eventSource.close();
    };
  }
}

// Usage
const client = new DocumentaryPipelineClient();

async function main() {
  const health = await client.healthCheck();
  console.log('Health:', health);
  
  const runId = await client.createDocumentary('Climate change economics');
  console.log('Started run:', runId);
  
  client.subscribeToUpdates(runId, (event) => {
    console.log('Update:', event);
  });
}

main();
```

---

## OpenAPI Specification

The complete OpenAPI 3.0 specification is available at:

```
http://localhost:8000/openapi.json
```

Interactive documentation (Swagger UI):

```
http://localhost:8000/docs
```

Alternative documentation (ReDoc):

```
http://localhost:8000/redoc
```
