# Architecture Diagrams

Comprehensive visual documentation of the Documentary Pipeline architecture using Mermaid diagrams.

## Table of Contents

1. [System Overview](#system-overview)
2. [Pipeline Flow](#pipeline-flow)
3. [Agent Architecture](#agent-architecture)
4. [Data Flow](#data-flow)
5. [State Management](#state-management)
6. [Infrastructure](#infrastructure)
7. [Sequence Diagrams](#sequence-diagrams)
8. [Component Relationships](#component-relationships)

---

## System Overview

### High-Level Architecture

```mermaid
graph TB
    subgraph Frontend["Frontend Layer"]
        UI[Next.js + CopilotKit]
        CK[CopilotKit Chat]
        DB[Dashboard UI]
        GV[Gate Views]
    end

    subgraph Protocol["Protocol Layer"]
        AGUI[AG-UI Protocol<br/>SSE/WebSocket]
    end

    subgraph Backend["Backend Layer"]
        API[FastAPI Server]
        ADK[Google ADK Runtime]
        CB[Callbacks Stack]
        PL[Plugins Stack]
    end

    subgraph Pipeline["Pipeline Layer"]
        SA[SequentialAgent<br/>Master Orchestrator]
        SD[Scenario Director<br/>EvaluatorOptimizer]
        AA[Audio Agent<br/>TTS + WhisperX]
        VD[Visual Director<br/>LoopAgent × 3]
        PS[Production Supervisor<br/>GPU Orchestration]
        AS[Assembler Agent<br/>ffmpeg]
    end

    subgraph State["State Management"]
        BB[Blackboard Pattern<br/>Session State]
        OTIO[OTIO Timeline<br/>Media Assembly]
    end

    subgraph External["External Services"]
        LLM[LLM APIs<br/>Gemini/OpenAI]
        VAST[Vast.ai<br/>GPU Instances]
        TTS[Qwen3-TTS<br/>Audio Generation]
        LTX[LTX-2.3<br/>Video Generation]
    end

    UI --> AGUI
    CK --> AGUI
    DB --> API
    GV --> API

    AGUI --> API
    API --> ADK
    ADK --> CB
    ADK --> PL
    ADK --> SA

    SA --> SD
    SD --> AA
    AA --> VD
    VD --> PS
    PS --> AS

    SD --> BB
    AA --> BB
    VD --> BB
    PS --> BB
    AS --> BB

    AS --> OTIO

    SD -.-> LLM
    VD -.-> LLM
    AA -.-> TTS
    PS -.-> VAST
    VAST -.-> LTX
```

---

## Pipeline Flow

### Complete Pipeline Sequence

```mermaid
flowchart TD
    Start([User Input<br/>Topic]) --> Gate1{Gate 1<br/>Scenario Editor}
    
    Gate1 -->|Approved| Scenario[Scenario Director<br/>Generate Script]
    Gate1 -->|Rejected| Regen1[Regenerate<br/>with Feedback]
    Regen1 --> Scenario
    
    Scenario --> Audio[Audio Agent<br/>TTS + WhisperX]
    
    Audio --> Gate2{Gate 2<br/>Prompt Reviewer}
    Gate2 -->|Approved| Visual[Visual Director<br/>Content Analysis]
    Gate2 -->|Rejected| Regen2[Regenerate<br/>Prompts]
    Regen2 --> Visual
    
    Visual --> Coherence{Coherence<br/>Evaluator}
    Coherence -->|Pass| Production[Production Supervisor<br/>GPU Video Gen]
    Coherence -->|Fail| Refine[Refine Visual<br/>Concepts]
    Refine --> Visual
    
    Production --> Gate3{Gate 3<br/>Clip Reviewer}
    Gate3 -->|Approved| Assembly[Assembler Agent<br/>ffmpeg Assembly]
    Gate3 -->|Rejected| Regen3[Regenerate<br/>Clips]
    Regen3 --> Production
    
    Assembly --> Output([Final MP4<br/>Documentary])
    
    style Start fill:#90EE90
    style Output fill:#90EE90
    style Gate1 fill:#FFD700
    style Gate2 fill:#FFD700
    style Gate3 fill:#FFD700
    style Coherence fill:#FFA500
```

---

## Agent Architecture

### SequentialAgent Structure

```mermaid
graph TB
    subgraph Master["Master SequentialAgent"]
        direction TB
        
        subgraph Phase1["Phase 1: Scenario"]
            SD[Scenario Director]
            SD_G[Generator Agent]
            SD_E[Evaluator Agent]
            SD --> SD_G
            SD_G --> SD_E
            SD_E -->|POOR| SD_G
            SD_E -->|GOOD| Next1[Next Phase]
        end
        
        subgraph Phase2["Phase 2: Audio"]
            AA[Audio Agent]
            TTS[TTS Generator]
            WX[WhisperX Aligner]
            AA --> TTS
            TTS --> WX
            WX --> Next2[Next Phase]
        end
        
        subgraph Phase3["Phase 3: Visual"]
            VD[Visual Director<br/>LoopAgent]
            CA[Content Analyst]
            VC[Visual Concepter]
            CE[Coherence Evaluator]
            VD --> CA
            CA --> VC
            VC --> CE
            CE -->|LOW| CA
            CE -->|GOOD| Next3[Next Phase]
        end
        
        subgraph Phase4["Phase 4: Production"]
            PS[Production Supervisor]
            GP[GPU Provisioner]
            VG[Video Generator]
            PS --> GP
            GP --> VG
            VG --> Next4[Next Phase]
        end
        
        subgraph Phase5["Phase 5: Assembly"]
            AS[Assembler Agent]
            TL[Timeline Builder]
            FF[ffmpeg Muxer]
            AS --> TL
            TL --> FF
            FF --> Done([Complete])
        end
        
        Phase1 --> Phase2
        Phase2 --> Phase3
        Phase3 --> Phase4
        Phase4 --> Phase5
    end
```

### EvaluatorOptimizer Pattern

```mermaid
sequenceDiagram
    participant User
    participant SD as Scenario Director
    participant G as Generator
    participant E as Evaluator
    participant State

    User->>SD: topic
    SD->>State: Initialize
    
    loop Until GOOD or max attempts
        SD->>G: generate(topic, feedback)
        G->>G: Create script with V1/V2/V3
        G->>State: Store draft
        G->>SD: draft_scenario
        
        SD->>E: evaluate(draft_scenario)
        E->>E: Check ADHD compliance
        E->>E: Validate scene duration
        E->>E: Verify voice distribution
        E->>SD: rating + feedback
        
        alt Rating == GOOD
            SD->>State: Store final
            SD->>User: scenario_complete
        else Rating == POOR
            SD->>G: regenerate with feedback
        end
    end
```

### LoopAgent Pattern (Visual Director)

```mermaid
sequenceDiagram
    participant VD as Visual Director
    participant CA as Content Analyst
    participant VC as Visual Concepter
    participant CE as Coherence Evaluator
    participant State

    VD->>State: Get whisperx_alignment
    
    loop Until coherence >= GOOD
        VD->>CA: analyze(alignment)
        CA->>CA: Identify content shifts
        CA->>CA: Extract visual breakpoints
        CA->>VD: content_analysis
        
        VD->>VC: conceive(analysis)
        VC->>VC: Generate visual concepts
        VC->>VC: Assign camera styles
        VC->>VC: Select LoRAs
        VC->>VD: visual_concepts
        
        VD->>CE: evaluate(concepts)
        CE->>CE: Check visual variety
        CE->>CE: Verify no consecutive repeats
        CE->>VD: coherence_rating
    end
    
    VD->>State: Store final concepts
```

---

## Data Flow

### State Flow Through Pipeline

```mermaid
flowchart LR
    subgraph Inputs["Input State"]
        T[topic: str]
    end
    
    subgraph S1["After Scenario"]
        SC[scenes: List[Scene]]
        SC_D[scenes[].script<br/>scenes[].duration<br/>scenes[].voices]
    end
    
    subgraph S2["After Audio"]
        WA[whisperx_alignment: JSON]
        AF[audio_files: List[Path]]
    end
    
    subgraph S3["After Visual"]
        VA[visual_concepts: List[Concept]]
        CE[coherence_evaluation: Rating]
    end
    
    subgraph S4["After Production"]
        VF[video_files: List[Path]]
        VM[video_metadata: JSON]
    end
    
    subgraph S5["After Assembly"]
        OT[otio_timeline: Timeline]
        OP[output_path: Path]
    end
    
    T --> SC
    SC --> WA
    WA --> VA
    VA --> VF
    VF --> OT
    
    style Inputs fill:#E1F5FE
    style S5 fill:#E8F5E9
```

### Blackboard State Pattern

```mermaid
graph TB
    subgraph Blackboard["Session Blackboard"]
        direction TB
        
        subgraph ReadWrite["Read/Write Access"]
            T[topic]
            SC[scenes]
            WA[whisperx_alignment]
            VA[visual_concepts]
            CE[coherence_evaluation]
            VF[video_files]
            OT[otio_mutations]
        end
        
        subgraph ReadOnly["Read-Only Access"]
            CFG[config]
            PL[plugins]
        end
    end
    
    subgraph Agents["Agent Access Patterns"]
        SD[Scenario Director]
        AA[Audio Agent]
        VD[Visual Director]
        PS[Production Supervisor]
        AS[Assembler Agent]
    end
    
    SD -->|writes| T
    SD -->|writes| SC
    
    AA -->|reads| SC
    AA -->|writes| WA
    AA -->|writes| AF[audio_files]
    
    VD -->|reads| WA
    VD -->|writes| VA
    VD -->|writes| CE
    
    PS -->|reads| VA
    PS -->|writes| VF
    
    AS -->|reads| VF
    AS -->|reads| AF
    AS -->|writes| OT
```

---

## State Management

### OTIO Timeline Structure

```mermaid
graph TB
    subgraph Timeline["OTIO Timeline"]
        direction TB
        
        subgraph Stack["Timeline Stack"]
            direction TB
            
            subgraph V1["V1_Video Track"]
                V1C1[Clip 1<br/>0:00-0:45]
                V1C2[Clip 2<br/>0:45-1:30]
                V1C3[Clip 3<br/>1:30-2:15]
                V1C1 --> V1C2 --> V1C3
            end
            
            subgraph A1["A1_Narration Track"]
                A1C1[Voice V1<br/>0:00-0:15]
                A1C2[Voice V2<br/>0:15-0:35]
                A1C3[Voice V3<br/>0:35-0:45]
                A1C1 --> A1C2 --> A1C3
            end
            
            subgraph A2["A2_Music Track"]
                A2C1[Background<br/>0:00-2:15]
            end
        end
        
        subgraph Metadata["Timeline Metadata"]
            TM[topic: str]
            TC[total_duration: float]
            TS[scene_boundaries: List[float]]
        end
    end
    
    V1 --> Stack
    A1 --> Stack
    A2 --> Stack
```

### Timeline Guardian Validation

```mermaid
flowchart TD
    Start([After Agent]) --> TG[Timeline Guardian]
    
    TG --> Check1{Check<br/>Duration}
    Check1 -->|Invalid| Error1[Error:<br/>Duration Mismatch]
    Check1 -->|Valid| Check2
    
    Check2{Check<br/>Overlaps}
    Check2 -->|Overlap| Error2[Error:<br/>Clip Overlap]
    Check2 -->|Valid| Check3
    
    Check3{Check<br/>Gaps}
    Check3 -->|Gap| Error3[Error:<br/>Timeline Gap]
    Check3 -->|Valid| Check4
    
    Check4{Check<br/>References}
    Check4 -->|Missing| Error4[Error:<br/>Missing File]
    Check4 -->|Valid| Success
    
    Success([Timeline Valid])
    
    Error1 --> Fail([Validation Failed])
    Error2 --> Fail
    Error3 --> Fail
    Error4 --> Fail
    
    style Success fill:#90EE90
    style Fail fill:#FF6B6B
```

---

## Infrastructure

### GPU Provisioning Flow

```mermaid
sequenceDiagram
    participant PS as Production Supervisor
    participant VM as Vast.ai API
    participant GI as GPU Instance
    participant LTX as LTX-2.3
    participant Storage

    PS->>VM: search_offers(gpu_type, min_vram)
    VM->>PS: available_offers
    
    PS->>VM: create_instance(offer_id)
    VM->>GI: provision(gpu, disk)
    VM->>PS: instance_id, ssh_key
    
    loop Until Ready
        PS->>VM: get_status(instance_id)
        VM->>PS: status
    end
    
    PS->>GI: ssh_connect
    PS->>GI: upload_scripts()
    PS->>GI: install_dependencies()
    
    par Generate Videos
        PS->>GI: generate_video(prompt_1)
        GI->>LTX: inference
        LTX->>Storage: save_clip_1
        
        PS->>GI: generate_video(prompt_2)
        GI->>LTX: inference
        LTX->>Storage: save_clip_2
        
        PS->>GI: generate_video(prompt_n)
        GI->>LTX: inference
        LTX->>Storage: save_clip_n
    end
    
    PS->>Storage: download_clips()
    PS->>VM: destroy_instance(instance_id)
    VM->>GI: terminate
```

### Dashboard Architecture

```mermaid
graph TB
    subgraph Dashboard["Dashboard System"]
        direction TB
        
        subgraph Collection["Event Collection"]
            MW[Middleware<br/>Request Interceptor]
            PC[PipelineCollector<br/>Per-Run]
            CB[Callbacks<br/>before/after_model<br/>before/after_tool]
        end
        
        subgraph Storage["Event Storage"]
            ES[Event Store<br/>SQLite + WAL]
            SN[Snapshots<br/>Periodic]
        end
        
        subgraph Streaming["Real-Time Streaming"]
            SSE[SSE Endpoint<br/>/dashboard/runs/{id}/sse]
            EM[Event Manager<br/>Broadcast]
        end
        
        subgraph Reporting["Reporting"]
            HTML[HTML Reports<br/>Self-Contained]
            MET[Metrics<br/>Prometheus Format]
        end
    end
    
    API[FastAPI] --> MW
    ADK[ADK Runtime] --> CB
    
    MW --> PC
    CB --> PC
    
    PC --> ES
    PC --> SN
    
    ES --> EM
    SN --> EM
    
    EM --> SSE
    
    ES --> HTML
    ES --> MET
    
    Client[Dashboard Client] --> SSE
    Prometheus[Prometheus] --> MET
```

---

## Sequence Diagrams

### Complete Pipeline Execution

```mermaid
sequenceDiagram
    actor User
    participant FE as Frontend
    participant API as FastAPI
    participant ADK as ADK Runtime
    participant SA as SequentialAgent
    participant SD as Scenario Director
    participant AA as Audio Agent
    participant VD as Visual Director
    participant PS as Production Supervisor
    participant AS as Assembler Agent
    participant Ext as External APIs

    User->>FE: Enter topic
    FE->>API: POST / (AG-UI)
    API->>ADK: Create session
    ADK->>SA: Run pipeline
    
    Note over SA: Phase 1: Scenario
    SA->>SD: run(topic)
    loop Until GOOD
        SD->>Ext: LLM generate
        Ext->>SD: draft scenario
        SD->>Ext: LLM evaluate
        Ext->>SD: rating + feedback
    end
    SD->>SA: scenario_complete
    
    Note over SA: Phase 2: Audio
    SA->>AA: run(scenario)
    loop For each scene
        AA->>Ext: TTS generate V1
        Ext->>AA: audio_V1.wav
        AA->>Ext: TTS generate V2
        Ext->>AA: audio_V2.wav
        AA->>Ext: TTS generate V3
        Ext->>AA: audio_V3.wav
        AA->>Ext: WhisperX align
        Ext->>AA: word_timings.json
    end
    AA->>SA: audio_complete
    
    Note over SA: Phase 3: Visual
    SA->>VD: run(alignment)
    loop Until coherent
        VD->>Ext: LLM analyze content
        Ext->>VD: content_shifts
        VD->>Ext: LLM conceive visuals
        Ext->>VD: visual_concepts
        VD->>Ext: LLM evaluate coherence
        Ext->>VD: coherence_rating
    end
    VD->>SA: visual_complete
    
    Note over SA: Phase 4: Production
    SA->>PS: run(concepts)
    PS->>Ext: Provision GPU
    Ext->>PS: instance_ready
    loop For each concept
        PS->>Ext: Generate video
        Ext->>PS: video_clip.mp4
    end
    PS->>Ext: Destroy GPU
    PS->>SA: production_complete
    
    Note over SA: Phase 5: Assembly
    SA->>AS: run(videos, audio)
    AS->>AS: Build OTIO timeline
    AS->>AS: ffmpeg trim/mux/concat
    AS->>SA: assembly_complete
    
    SA->>ADK: pipeline_complete
    ADK->>API: result
    API->>FE: SSE: done
    FE->>User: Show final video
```

### Quality Gate Flow

```mermaid
sequenceDiagram
    actor User
    participant FE as Frontend
    participant API as FastAPI
    participant Agent as Pipeline Agent
    participant State as Session State

    Note over User,State: Gate 1: Scenario Editor
    Agent->>State: Store generated scenario
    Agent->>API: Emit: gate_1_pending
    API->>FE: SSE: gate_1_pending
    FE->>User: Show scenario editor
    
    alt User Approves
        User->>FE: Approve
        FE->>API: POST /agui/feedback
        API->>Agent: Continue pipeline
    else User Rejects
        User->>FE: Reject + feedback
        FE->>API: POST /agui/feedback
        API->>Agent: Regenerate with feedback
        Agent->>Agent: Retry scenario generation
    end
    
    Note over User,State: Gate 2: Prompt Reviewer
    Agent->>State: Store visual prompts
    Agent->>API: Emit: gate_2_pending
    API->>FE: SSE: gate_2_pending
    FE->>User: Show prompt reviewer
    
    alt User Approves
        User->>FE: Approve
        FE->>API: POST /agui/feedback
        API->>Agent: Continue to production
    else User Modifies
        User->>FE: Edit prompts
        FE->>API: POST /agui/feedback
        API->>State: Update prompts
        API->>Agent: Continue with modified
    end
    
    Note over User,State: Gate 3: Clip Reviewer
    Agent->>State: Store generated clips
    Agent->>API: Emit: gate_3_pending
    API->>FE: SSE: gate_3_pending
    FE->>User: Show clip reviewer
    
    alt User Approves All
        User->>FE: Approve all
        FE->>API: POST /agui/feedback
        API->>Agent: Continue to assembly
    else User Rejects Some
        User->>FE: Reject specific clips
        FE->>API: POST /agui/feedback
        API->>Agent: Regenerate rejected
    end
```

---

## Component Relationships

### Plugin Stack

```mermaid
graph TB
    subgraph Plugins["Plugin Architecture"]
        direction TB
        
        subgraph Core["Core Plugins"]
            CFP[ContextFilterPlugin<br/>Manage context window]
            RTR[ReflectAndRetryToolPlugin<br/>Auto-retry tools]
            GIP[GlobalInstructionPlugin<br/>Inject instructions]
        end
        
        subgraph Observability["Observability Plugins"]
            LP[LoggingPlugin<br/>Structured logs]
            DLP[DebugLoggingPlugin<br/>Debug traces]
            OT[OpenTelemetryPlugin<br/>Distributed tracing]
        end
    end
    
    subgraph Execution["Execution Flow"]
        Req[Request]
        Chain[Plugin Chain]
        Agent[Agent]
        Resp[Response]
    end
    
    Req --> Chain
    Chain --> CFP
    CFP --> RTR
    RTR --> GIP
    GIP --> LP
    LP --> DLP
    DLP --> OT
    OT --> Agent
    Agent --> Resp
```

### Callback Stack

```mermaid
graph LR
    subgraph Callbacks["Callback Architecture"]
        direction TB
        
        subgraph ModelCallbacks["Model Callbacks"]
            BM[before_model<br/>Concurrency semaphore<br/>Context-length safety]
            AM[after_model<br/>Dashboard tracking]
        end
        
        subgraph ToolCallbacks["Tool Callbacks"]
            BT[before_tool<br/>Rate limiting<br/>Dashboard tracking]
            AT[after_tool<br/>Result truncation<br/>Dashboard tracking]
        end
        
        subgraph AgentCallbacks["Agent Callbacks"]
            BA[before_agent<br/>Phase initialization]
            AA_A[after_agent<br/>Timeline Guardian]
        end
    end
    
    subgraph Flow["Callback Flow"]
        direction LR
        Start[Tool Call] --> BM
        BM --> BT
        BT --> Tool[Tool Execution]
        Tool --> AT
        AT --> AM
        AM --> End[Response]
    end
```

---

## Deployment Architecture

### Production Deployment

```mermaid
graph TB
    subgraph Client["Client Layer"]
        Browser[Web Browser]
        Mobile[Mobile App]
    end
    
    subgraph Edge["Edge Layer"]
        CDN[CDN<br/>Static Assets]
        LB[Load Balancer<br/>SSL Termination]
    end
    
    subgraph App["Application Layer"]
        API1[API Instance 1]
        API2[API Instance 2]
        API3[API Instance 3]
    end
    
    subgraph Data["Data Layer"]
        Redis[(Redis<br/>Session Cache)]
        SQLite[(SQLite<br/>Event Store)]
        S3[S3/MinIO<br/>Media Storage]
    end
    
    subgraph GPU["GPU Layer"]
        VAST[Vast.ai API]
        GI1[GPU Instance 1]
        GI2[GPU Instance 2]
    end
    
    subgraph Monitoring["Monitoring"]
        Prom[Prometheus]
        Graf[Grafana]
        Alert[AlertManager]
    end
    
    Browser --> CDN
    Browser --> LB
    Mobile --> LB
    
    LB --> API1
    LB --> API2
    LB --> API3
    
    API1 --> Redis
    API1 --> SQLite
    API1 --> S3
    API1 --> VAST
    
    VAST --> GI1
    VAST --> GI2
    
    API1 --> Prom
    Prom --> Graf
    Prom --> Alert
```
