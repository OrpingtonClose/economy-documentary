"""
FastAPI + AG-UI server for the documentary pipeline with comprehensive observability.

Enhanced with:
- Structured logging with correlation IDs (structlog)
- Comprehensive health check endpoints (/health, /health/live, /health/ready)
- Prometheus-style metrics endpoint (/metrics)
- Distributed tracing with OpenTelemetry
- Custom metrics for pipeline stages, API calls, errors, VM provisioning
- Log aggregation support

Ported from MiroThinker. Provides:
- POST / -- AG-UI endpoint for CopilotKit frontend
- /dashboard/* -- real-time pipeline dashboard endpoints
- /health/* -- health check endpoints
- /metrics -- Prometheus metrics endpoint
- Request logging middleware with correlation IDs
- Pipeline collector middleware for dashboard integration
"""

from __future__ import annotations

import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse

load_dotenv()

# Import observability modules
try:
    from observability import (
        configure_logging,
        get_logger,
        LogContext,
        get_metrics_collector,
        MetricsCollector,
        PIPELINE_STAGE_DURATION,
        API_CALL_LATENCY,
        ERROR_COUNTER,
        VM_PROVISIONING_TIME,
        LLM_TOKEN_USAGE,
        TOOL_CALL_COUNTER,
        WORKER_HEALTH_STATUS,
        ACTIVE_PIPELINES,
        setup_tracing,
        get_tracer,
        trace_pipeline_stage,
        get_health_checker,
        HealthChecker,
        HealthStatus,
        check_environment_variables,
        check_api_key,
        check_disk_space,
        CorrelationIdMiddleware,
        MetricsMiddleware,
        TracingMiddleware,
        ObservabilityMiddleware,
    )
    OBSERVABILITY_AVAILABLE = True
except ImportError:
    OBSERVABILITY_AVAILABLE = False
    import logging
    logging.basicConfig(level=logging.INFO)

# Import ADK and app modules
try:
    from ag_ui_adk import ADKAgent, add_adk_fastapi_endpoint
    from google.adk.apps import App
    ADK_AVAILABLE = True
except ImportError:
    ADK_AVAILABLE = False

# Import local modules
try:
    from agents.model_config import ADK_MODEL_NAME
    from agents.pipeline import pipeline_agent
    from dashboard import remove_collector, set_active_collector
    from dashboard.collector import PipelineCollector
    from dashboard.event_store import init_db, insert_run, finalize_run, insert_snapshot
    from dashboard.sse import router as dashboard_router
    from agui import router as agui_router
    from plugins import build_plugins, setup_otel
    LOCAL_MODULES_AVAILABLE = True
except ImportError:
    LOCAL_MODULES_AVAILABLE = False
    ADK_MODEL_NAME = os.environ.get("ADK_MODEL", "unknown")

# Configure structured logging
if OBSERVABILITY_AVAILABLE:
    configure_logging(
        log_level=os.environ.get("LOG_LEVEL", "INFO"),
        json_format=os.environ.get("LOG_FORMAT", "json").lower() == "json",
        log_file=os.environ.get("LOG_FILE"),
    )
    logger = get_logger(__name__)
else:
    logger = logging.getLogger(__name__)


def _validate_env() -> None:
    """Validate required environment variables at startup."""
    model = ADK_MODEL_NAME
    if not model:
        raise ValueError("ADK_MODEL environment variable is required")

    # Check for at least one API key
    has_google = bool(os.environ.get("GOOGLE_API_KEY"))
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    has_api_base = bool(os.environ.get("OPENAI_API_BASE"))

    if not (has_google or has_openai or has_api_base):
        logger.warning(
            "No API keys configured. Set GOOGLE_API_KEY for Gemini "
            "or OPENAI_API_KEY + OPENAI_API_BASE for LiteLLM routing."
        )

    logger.info(
        "Model configuration: ADK_MODEL=%s, Gemini=%s, LiteLLM=%s",
        model,
        "yes" if has_google else "no",
        "yes" if (has_openai or has_api_base) else "no",
    )


# Health check setup
def _setup_health_checks(health_checker: HealthChecker) -> None:
    """Register all health check functions."""
    
    # Environment variables check
    def env_check():
        required = ["ADK_MODEL"]
        optional = ["GOOGLE_API_KEY", "OPENAI_API_KEY", "VAST_API_KEY"]
        return check_environment_variables(required + optional)
    
    health_checker.register_check("environment", env_check)
    
    # API key checks
    health_checker.register_check(
        "google_api",
        lambda: check_api_key("GOOGLE_API_KEY", "Google")
    )
    health_checker.register_check(
        "vast_api",
        lambda: check_api_key("VAST_API_KEY", "Vast.ai")
    )
    
    # Disk space check
    health_checker.register_check(
        "disk_space",
        lambda: check_disk_space(min_free_gb=5.0)
    )
    
    # Database check (if available)
    if LOCAL_MODULES_AVAILABLE:
        def db_check():
            import sqlite3
            findings_dir = os.environ.get(
                "FINDINGS_DIR",
                os.path.join(os.path.expanduser("~"), ".documentary-pipeline"),
            )
            db_path = os.path.join(findings_dir, "pipeline.db")
            try:
                conn = sqlite3.connect(db_path, timeout=5)
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                conn.close()
                from observability.health import ComponentHealth, HealthStatus
                return ComponentHealth(
                    name="database",
                    status=HealthStatus.HEALTHY,
                    message="Database connection successful",
                    details={"db_path": db_path},
                )
            except Exception as e:
                from observability.health import ComponentHealth, HealthStatus
                return ComponentHealth(
                    name="database",
                    status=HealthStatus.UNHEALTHY,
                    message=f"Database connection failed: {str(e)}",
                    details={"db_path": db_path, "error": str(e)},
                )
        
        health_checker.register_check("database", db_check)


# Custom middleware for pipeline collection with metrics
class AGUIRunCollectorMiddleware:
    """Create and manage PipelineCollector for each AG-UI request with metrics."""

    def __init__(self, app):
        self.app = app
        if OBSERVABILITY_AVAILABLE:
            self.metrics = get_metrics_collector()
        else:
            self.metrics = None

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["path"] != "/" or scope["method"] != "POST":
            await self.app(scope, receive, send)
            return

        run_id = f"run_{uuid.uuid4().hex[:8]}"
        
        if OBSERVABILITY_AVAILABLE:
            from observability.logging_config import set_correlation_id, LogContext
            from observability.tracing import trace_pipeline_start
            
            correlation_id = set_correlation_id()
            logger.info("Pipeline run started", run_id=run_id, correlation_id=correlation_id)
            
            # Record active pipeline
            if self.metrics:
                self.metrics.set_active_pipelines(1, status="running")
                self.metrics.record_pipeline_run(status="started")
        else:
            logger.info("Pipeline run started: %s", run_id)

        if LOCAL_MODULES_AVAILABLE:
            collector = PipelineCollector(run_id=run_id)
            set_active_collector(collector)
            insert_run(run_id)
        else:
            collector = None

        start_time = time.time()

        try:
            await self.app(scope, receive, send)
            
            duration = time.time() - start_time
            
            if OBSERVABILITY_AVAILABLE and self.metrics:
                self.metrics.record_pipeline_stage(
                    stage="full_pipeline",
                    duration=duration,
                    status="success",
                )
                self.metrics.set_active_pipelines(0, status="running")
                self.metrics.record_pipeline_run(status="success")
            
            logger.info("Pipeline run completed", run_id=run_id, duration_seconds=round(duration, 2))
            
        except Exception as e:
            duration = time.time() - start_time
            
            if OBSERVABILITY_AVAILABLE and self.metrics:
                self.metrics.record_pipeline_stage(
                    stage="full_pipeline",
                    duration=duration,
                    status="error",
                )
                ERROR_COUNTER.inc(type="pipeline_error", stage="full_pipeline", component="orchestrator")
                self.metrics.set_active_pipelines(0, status="running")
                self.metrics.record_pipeline_run(status="error")
            
            logger.error("Pipeline run failed", run_id=run_id, error=str(e))
            raise
        finally:
            if LOCAL_MODULES_AVAILABLE and collector:
                data = collector.finalize()
                finalize_run(run_id, status=data["status"], metadata=data)
                insert_snapshot(run_id, data)
                remove_collector(run_id)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: setup observability, validate env, init DB."""
    # Setup observability
    if OBSERVABILITY_AVAILABLE:
        setup_tracing(
            service_name="documentary-pipeline",
            service_version="0.1.0",
            exporter_type=os.environ.get("TRACING_EXPORTER", "console"),
        )
    
    # Setup ADK OTel if available
    if LOCAL_MODULES_AVAILABLE:
        setup_otel()
    
    # Validate environment
    _validate_env()
    
    # Initialize database
    if LOCAL_MODULES_AVAILABLE:
        init_db()
    
    # Setup health checks
    if OBSERVABILITY_AVAILABLE:
        health_checker = get_health_checker(version="0.1.0")
        _setup_health_checks(health_checker)
    
    logger.info("Documentary pipeline server started with observability")
    yield
    
    logger.info("Documentary pipeline server shutting down")


# Create FastAPI app
app = FastAPI(
    title="Documentary Pipeline",
    description="ADHD-friendly AI documentary pipeline with Google ADK + AG-UI + Observability",
    version="0.1.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Observability middleware (if available)
if OBSERVABILITY_AVAILABLE:
    # Combined observability middleware
    app.add_middleware(ObservabilityMiddleware)
else:
    # Fallback request logging middleware
    from starlette.middleware.base import BaseHTTPMiddleware
    
    class RequestLoggingMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            start = time.time()
            response = await call_next(request)
            duration = time.time() - start
            logger.info(
                "%s %s -> %d (%.2fs)",
                request.method,
                request.url.path,
                response.status_code,
                duration,
            )
            return response
    
    app.add_middleware(RequestLoggingMiddleware)

# Dashboard routes (if available)
if LOCAL_MODULES_AVAILABLE:
    app.include_router(dashboard_router)
    app.include_router(agui_router)

# AG-UI endpoint (if available)
if ADK_AVAILABLE and LOCAL_MODULES_AVAILABLE:
    _adk_app = App(
        name="documentary_pipeline",
        root_agent=pipeline_agent,
        plugins=build_plugins(),
    )
    adk_agent = ADKAgent.from_app(app=_adk_app)
    add_adk_fastapi_endpoint(app, adk_agent, path="/")


# ============================================================================
# Health Check Endpoints
# ============================================================================

@app.get("/health")
async def health():
    """Comprehensive health check endpoint.
    
    Returns overall system health including all components.
    """
    if OBSERVABILITY_AVAILABLE:
        health_checker = get_health_checker()
        health_data = await health_checker.check_full_health()
        
        return JSONResponse(
            content={
                "status": health_data.status.value,
                "version": health_data.version,
                "timestamp": health_data.timestamp,
                "uptime_seconds": health_data.uptime_seconds,
                "message": health_data.message,
                "components": [
                    {
                        "name": c.name,
                        "status": c.status.value,
                        "message": c.message,
                        "response_time_ms": c.response_time_ms,
                        "details": c.details,
                    }
                    for c in health_data.components
                ],
            },
            status_code=200 if health_data.status == HealthStatus.HEALTHY else 503,
        )
    else:
        return JSONResponse(
            content={
                "status": "healthy",
                "version": "0.1.0",
                "model": ADK_MODEL_NAME,
                "observability": "disabled",
            }
        )


@app.get("/health/live")
async def health_live():
    """Liveness probe endpoint.
    
    Returns 200 if the process is running. Used by Kubernetes liveness probes.
    """
    if OBSERVABILITY_AVAILABLE:
        health_checker = get_health_checker()
        health_data = health_checker.check_liveness()
        
        return JSONResponse(
            content={
                "status": health_data.status.value,
                "timestamp": health_data.timestamp,
                "uptime_seconds": health_data.uptime_seconds,
            }
        )
    else:
        return JSONResponse(
            content={
                "status": "healthy",
                "pid": os.getpid(),
            }
        )


@app.get("/health/ready")
async def health_ready():
    """Readiness probe endpoint.
    
    Returns 200 if the service is ready to accept traffic.
    Used by Kubernetes readiness probes.
    """
    if OBSERVABILITY_AVAILABLE:
        health_checker = get_health_checker()
        health_data = await health_checker.check_readiness()
        
        return JSONResponse(
            content={
                "status": health_data.status.value,
                "version": health_data.version,
                "timestamp": health_data.timestamp,
                "message": health_data.message,
                "components": [
                    {
                        "name": c.name,
                        "status": c.status.value,
                        "message": c.message,
                    }
                    for c in health_data.components
                ],
            },
            status_code=200 if health_data.status == HealthStatus.HEALTHY else 503,
        )
    else:
        return JSONResponse(
            content={
                "status": "ready",
                "model": ADK_MODEL_NAME,
            }
        )


# ============================================================================
# Metrics Endpoint
# ============================================================================

@app.get("/metrics")
async def metrics():
    """Prometheus-style metrics endpoint.
    
    Returns metrics in Prometheus text format for scraping by Prometheus.
    """
    if OBSERVABILITY_AVAILABLE:
        metrics_collector = get_metrics_collector()
        metrics_text = metrics_collector.get_all_metrics()
        return PlainTextResponse(
            content=metrics_text,
            media_type="text/plain; version=0.0.4; charset=utf-8",
        )
    else:
        return PlainTextResponse(
            content="# Observability not available\n",
            media_type="text/plain",
        )


# ============================================================================
# Observability Info Endpoint
# ============================================================================

@app.get("/observability/info")
async def observability_info():
    """Get observability configuration and status."""
    if OBSERVABILITY_AVAILABLE:
        from observability import get_tracing_manager
        
        tracing_manager = get_tracing_manager()
        
        return JSONResponse(
            content={
                "observability": {
                    "logging": {
                        "enabled": True,
                        "level": os.environ.get("LOG_LEVEL", "INFO"),
                        "format": os.environ.get("LOG_FORMAT", "json"),
                    },
                    "metrics": {
                        "enabled": True,
                        "endpoint": "/metrics",
                    },
                    "tracing": {
                        "enabled": tracing_manager is not None,
                        "exporter": tracing_manager.exporter_type if tracing_manager else None,
                    },
                    "health_checks": {
                        "enabled": True,
                        "endpoints": ["/health", "/health/live", "/health/ready"],
                    },
                },
                "version": "0.1.0",
            }
        )
    else:
        return JSONResponse(
            content={
                "observability": {
                    "enabled": False,
                    "message": "Observability module not available",
                }
            }
        )


# ============================================================================
# Pipeline Metrics Endpoints
# ============================================================================

@app.get("/observability/pipeline/stats")
async def pipeline_stats():
    """Get current pipeline statistics."""
    if not OBSERVABILITY_AVAILABLE:
        return JSONResponse({"error": "Observability not available"}, status_code=503)
    
    metrics_collector = get_metrics_collector()
    
    return JSONResponse(
        content={
            "active_pipelines": ACTIVE_PIPELINES.get(),
            "pipeline_runs": {
                "success": PIPELINE_RUN_COUNTER.get(status="success"),
                "error": PIPELINE_RUN_COUNTER.get(status="error"),
            },
            "errors": {
                "total": ERROR_COUNTER.get(),
                "by_type": {
                    "pipeline_error": ERROR_COUNTER.get(type="pipeline_error"),
                    "api_error": ERROR_COUNTER.get(type="api_error"),
                    "vm_error": ERROR_COUNTER.get(type="vm_error"),
                },
            },
            "tool_calls": TOOL_CALL_COUNTER.get(),
            "llm_tokens": {
                "input": LLM_TOKEN_USAGE.get(type="input"),
                "output": LLM_TOKEN_USAGE.get(type="output"),
            },
        }
    )


@app.get("/observability/workers/status")
async def workers_status():
    """Get worker health status."""
    if not OBSERVABILITY_AVAILABLE:
        return JSONResponse({"error": "Observability not available"}, status_code=503)
    
    return JSONResponse(
        content={
            "workers": {
                "tts": {
                    "healthy": WORKER_HEALTH_STATUS.get(role="tts", capability="tts") == 1.0,
                },
                "video": {
                    "healthy": WORKER_HEALTH_STATUS.get(role="video", capability="ltx") == 1.0,
                },
            }
        }
    )


# ============================================================================
# Legacy Health Endpoint (for backward compatibility)
# ============================================================================

@app.get("/health/legacy")
async def health_legacy():
    """Legacy health check endpoint for backward compatibility."""
    return JSONResponse(
        content={
            "status": "ok",
            "model": ADK_MODEL_NAME,
            "version": "0.1.0",
        }
    )


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "server_enhanced:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
