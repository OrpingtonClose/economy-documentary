#!/usr/bin/env python3
"""
Security scanning script for the documentary pipeline.

Runs multiple security scanners:
- Bandit (Python security linter)
- Safety (dependency vulnerability scanner)
- Semgrep (static analysis)
- pip-audit (package vulnerability scanner)

Usage:
    python scripts/security_scan.py [--full]

Exit codes:
    0 - No security issues found
    1 - Security issues detected
    2 - Scanner error
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import json
import logging
from pathlib import Path
from typing import List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)


class Severity(Enum):
    """Vulnerability severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class ScanResult:
    """Result of a security scan."""
    scanner: str
    success: bool
    issues_found: int
    severity_counts: dict
    output: str
    error: Optional[str] = None


class SecurityScanner:
    """Runner for security scanning tools."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.results: List[ScanResult] = []
    
    def run_bandit(self) -> ScanResult:
        """Run Bandit security linter."""
        logger.info("Running Bandit security scan...")
        
        cmd = [
            "bandit",
            "-r",  # Recursive
            "-c", str(self.project_root / ".bandit"),
            "-f", "json",  # JSON output for parsing
            "-o", "/dev/stdout",
            str(self.project_root / "server"),
            str(self.project_root / "pipeline"),
            str(self.project_root / "scripts"),
            str(self.project_root / "config.py"),
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
            
            # Bandit returns 1 if issues found, 0 if clean
            output = result.stdout if result.stdout else result.stderr
            
            try:
                data = json.loads(output) if output else {"results": [], "metrics": {}}
                issues = data.get("results", [])
                
                severity_counts = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
                for issue in issues:
                    severity = issue.get("issue_severity", "LOW")
                    severity_counts[severity] = severity_counts.get(severity, 0) + 1
                
                return ScanResult(
                    scanner="Bandit",
                    success=len(issues) == 0,
                    issues_found=len(issues),
                    severity_counts=severity_counts,
                    output=output[:2000] if output else "No output",
                )
            except json.JSONDecodeError:
                return ScanResult(
                    scanner="Bandit",
                    success=False,
                    issues_found=0,
                    severity_counts={},
                    output=output[:1000] if output else "No output",
                    error="Failed to parse Bandit output",
                )
                
        except FileNotFoundError:
            return ScanResult(
                scanner="Bandit",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="Bandit not installed. Run: pip install bandit[toml]",
            )
        except subprocess.TimeoutExpired:
            return ScanResult(
                scanner="Bandit",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="Bandit scan timed out",
            )
    
    def run_safety(self) -> ScanResult:
        """Run Safety dependency vulnerability scanner."""
        logger.info("Running Safety dependency scan...")
        
        cmd = [
            "safety",
            "check",
            "--policy-file", str(self.project_root / ".safety-policy.yml"),
            "--json",
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
            
            output = result.stdout if result.stdout else result.stderr
            
            try:
                data = json.loads(output) if output else {"vulnerabilities": []}
                vulnerabilities = data.get("vulnerabilities", [])
                
                severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
                for vuln in vulnerabilities:
                    severity = vuln.get("severity", "low").lower()
                    severity_counts[severity] = severity_counts.get(severity, 0) + 1
                
                return ScanResult(
                    scanner="Safety",
                    success=len(vulnerabilities) == 0,
                    issues_found=len(vulnerabilities),
                    severity_counts=severity_counts,
                    output=f"Found {len(vulnerabilities)} vulnerable packages",
                )
            except json.JSONDecodeError:
                # Safety might return non-JSON on success with no issues
                if result.returncode == 0:
                    return ScanResult(
                        scanner="Safety",
                        success=True,
                        issues_found=0,
                        severity_counts={},
                        output="No vulnerable packages found",
                    )
                return ScanResult(
                    scanner="Safety",
                    success=False,
                    issues_found=0,
                    severity_counts={},
                    output=output[:1000] if output else "No output",
                    error="Failed to parse Safety output",
                )
                
        except FileNotFoundError:
            return ScanResult(
                scanner="Safety",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="Safety not installed. Run: pip install safety",
            )
        except subprocess.TimeoutExpired:
            return ScanResult(
                scanner="Safety",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="Safety scan timed out",
            )
    
    def run_semgrep(self, full_scan: bool = False) -> ScanResult:
        """Run Semgrep static analysis."""
        logger.info("Running Semgrep static analysis...")
        
        config = ["p/owasp-top-ten", "p/cwe-top-25"]
        if full_scan:
            config.append("p/python")
        
        cmd = [
            "semgrep",
            "--config", ",".join(config),
            "--json",
            "--quiet",
            str(self.project_root / "server"),
            str(self.project_root / "pipeline"),
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600 if full_scan else 300,
            )
            
            output = result.stdout if result.stdout else result.stderr
            
            try:
                data = json.loads(output) if output else {"results": [], "errors": []}
                findings = data.get("results", [])
                errors = data.get("errors", [])
                
                severity_counts = {"ERROR": 0, "WARNING": 0, "INFO": 0}
                for finding in findings:
                    extra = finding.get("extra", {})
                    severity = extra.get("severity", "INFO")
                    severity_counts[severity] = severity_counts.get(severity, 0) + 1
                
                return ScanResult(
                    scanner="Semgrep",
                    success=len(findings) == 0 and len(errors) == 0,
                    issues_found=len(findings),
                    severity_counts=severity_counts,
                    output=f"Found {len(findings)} issues" + (
                        f", {len(errors)} errors" if errors else ""
                    ),
                )
            except json.JSONDecodeError:
                return ScanResult(
                    scanner="Semgrep",
                    success=False,
                    issues_found=0,
                    severity_counts={},
                    output=output[:1000] if output else "No output",
                    error="Failed to parse Semgrep output",
                )
                
        except FileNotFoundError:
            return ScanResult(
                scanner="Semgrep",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="Semgrep not installed. Run: pip install semgrep",
            )
        except subprocess.TimeoutExpired:
            return ScanResult(
                scanner="Semgrep",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="Semgrep scan timed out",
            )
    
    def run_pip_audit(self) -> ScanResult:
        """Run pip-audit for package vulnerability scanning."""
        logger.info("Running pip-audit...")
        
        cmd = [
            "pip-audit",
            "--format=json",
            "--desc",
        ]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
            
            output = result.stdout if result.stdout else result.stderr
            
            try:
                data = json.loads(output) if output else {"dependencies": []}
                dependencies = data.get("dependencies", [])
                
                vuln_count = sum(
                    len(dep.get("vulns", [])) for dep in dependencies
                )
                
                return ScanResult(
                    scanner="pip-audit",
                    success=vuln_count == 0,
                    issues_found=vuln_count,
                    severity_counts={},
                    output=f"Found {vuln_count} vulnerabilities in {len(dependencies)} packages",
                )
            except json.JSONDecodeError:
                return ScanResult(
                    scanner="pip-audit",
                    success=False,
                    issues_found=0,
                    severity_counts={},
                    output=output[:1000] if output else "No output",
                    error="Failed to parse pip-audit output",
                )
                
        except FileNotFoundError:
            return ScanResult(
                scanner="pip-audit",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="pip-audit not installed. Run: pip install pip-audit",
            )
        except subprocess.TimeoutExpired:
            return ScanResult(
                scanner="pip-audit",
                success=False,
                issues_found=0,
                severity_counts={},
                output="",
                error="pip-audit scan timed out",
            )
    
    def run_all(self, full_scan: bool = False) -> Tuple[bool, List[ScanResult]]:
        """Run all security scanners."""
        logger.info("Starting comprehensive security scan...")
        
        scanners = [
            ("Bandit", self.run_bandit),
            ("Safety", self.run_safety),
            ("Semgrep", lambda: self.run_semgrep(full_scan)),
            ("pip-audit", self.run_pip_audit),
        ]
        
        all_passed = True
        for name, scanner_func in scanners:
            try:
                result = scanner_func()
                self.results.append(result)
                if not result.success:
                    all_passed = False
                    logger.warning(f"{name}: Found {result.issues_found} issues")
                else:
                    logger.info(f"{name}: No issues found")
            except Exception as e:
                logger.error(f"{name}: Scanner failed - {e}")
                all_passed = False
                self.results.append(ScanResult(
                    scanner=name,
                    success=False,
                    issues_found=0,
                    severity_counts={},
                    output="",
                    error=str(e),
                ))
        
        return all_passed, self.results
    
    def print_report(self) -> None:
        """Print a formatted security scan report."""
        print("\n" + "=" * 70)
        print("SECURITY SCAN REPORT")
        print("=" * 70)
        
        total_issues = 0
        for result in self.results:
            status = "✓ PASS" if result.success else "✗ FAIL"
            print(f"\n{status} - {result.scanner}")
            print(f"  Issues found: {result.issues_found}")
            
            if result.severity_counts:
                print("  Severity breakdown:")
                for severity, count in sorted(
                    result.severity_counts.items(),
                    key=lambda x: {"CRITICAL": 0, "HIGH": 1, "ERROR": 2, 
                                  "MEDIUM": 3, "WARNING": 4, "LOW": 5, "INFO": 6}.get(x[0], 7)
                ):
                    if count > 0:
                        print(f"    - {severity}: {count}")
            
            if result.error:
                print(f"  Error: {result.error}")
            
            total_issues += result.issues_found
        
        print("\n" + "=" * 70)
        print(f"TOTAL ISSUES: {total_issues}")
        print("=" * 70)
        
        if total_issues == 0:
            print("\n✓ All security checks passed!")
        else:
            print(f"\n✗ Found {total_issues} security issue(s). Please review and fix.")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Run security scans on the documentary pipeline"
    )
    parser.add_argument(
        "--full",
        action="store_true",
        help="Run full scan including all Semgrep rules (slower)"
    )
    parser.add_argument(
        "--scanner",
        choices=["bandit", "safety", "semgrep", "pip-audit", "all"],
        default="all",
        help="Run specific scanner only"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON"
    )
    
    args = parser.parse_args()
    
    project_root = Path(__file__).parent.parent
    scanner = SecurityScanner(project_root)
    
    if args.scanner == "all":
        all_passed, results = scanner.run_all(full_scan=args.full)
    else:
        # Run specific scanner
        scanner_map = {
            "bandit": scanner.run_bandit,
            "safety": scanner.run_safety,
            "semgrep": lambda: scanner.run_semgrep(full_scan=args.full),
            "pip-audit": scanner.run_pip_audit,
        }
        result = scanner_map[args.scanner]()
        scanner.results = [result]
        all_passed = result.success
        results = [result]
    
    if args.json:
        output = {
            "success": all_passed,
            "results": [
                {
                    "scanner": r.scanner,
                    "success": r.success,
                    "issues_found": r.issues_found,
                    "severity_counts": r.severity_counts,
                    "error": r.error,
                }
                for r in results
            ]
        }
        print(json.dumps(output, indent=2))
    else:
        scanner.print_report()
    
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
