# Security Guide for Economy Documentary Pipeline

This document outlines the security measures implemented in the documentary pipeline and provides guidance for secure deployment and operation.

## Table of Contents

1. [Security Features](#security-features)
2. [Configuration](#configuration)
3. [Secrets Management](#secrets-management)
4. [Input Validation](#input-validation)
5. [Rate Limiting](#rate-limiting)
6. [Security Headers](#security-headers)
7. [Path Traversal Protection](#path-traversal-protection)
8. [Command Injection Prevention](#command-injection-prevention)
9. [Security Scanning](#security-scanning)
10. [Deployment Security](#deployment-security)

## Security Features

The pipeline includes comprehensive security measures:

- **Input Validation**: All user inputs are validated and sanitized
- **Secrets Management**: Secure handling of API keys and credentials
- **Rate Limiting**: Protection against abuse and DoS attacks
- **Security Headers**: OWASP-recommended HTTP security headers
- **Path Traversal Protection**: Prevents unauthorized file system access
- **Command Injection Prevention**: Safe subprocess execution
- **Request Size Limits**: Prevents large payload attacks
- **CORS Protection**: Configurable cross-origin resource sharing

## Configuration

### Environment Variables

All configuration is done through environment variables. Never hardcode secrets in the codebase.

```bash
# Required Secrets
export GOOGLE_API_KEY="your-google-api-key"
export OPENAI_API_KEY="your-openai-api-key"

# Optional Secrets
export GEMINI_API_KEY="your-gemini-api-key"
export VAST_API_KEY="your-vast-api-key"
# ... (see config_secure.py for full list)

# Security Settings
export ENABLE_RATE_LIMITING="true"
export ENABLE_SECURITY_HEADERS="true"
export RATE_LIMIT_RPM="60"
export MAX_REQUEST_BODY_SIZE="10485760"  # 10MB
export ALLOWED_ORIGINS="http://localhost:3000,http://127.0.0.1:3000"
export REQUIRE_HTTPS="false"

# SSL Configuration (for production)
export SSL_KEYFILE="/path/to/key.pem"
export SSL_CERTFILE="/path/to/cert.pem"
```

### Security Configuration File

Create a `.env` file (not committed to git):

```bash
# Copy the example
 cp .env.example .env

# Edit with your secrets
nano .env
```

## Secrets Management

### Never Commit Secrets

- All secrets are loaded from environment variables
- The `.gitignore` file excludes `.env` files
- Pre-commit hooks can scan for secrets

### Secret Validation

The pipeline validates secrets at startup:

```python
from server.security.secrets import validate_required_secrets

is_valid, issues = validate_required_secrets()
if not is_valid:
    print(f"Missing secrets: {issues}")
```

### Secret Strength Checking

Secrets are checked for strength:

- Minimum length: 16 characters
- Character diversity required
- Common weak patterns detected
- Hardcoded values flagged

### Masking in Logs

All secrets are automatically masked in logs:

```python
from server.security.secrets import mask_secret

# Output: "sk-...abcd"
print(mask_secret("sk-abcdefghijklmnopqrstuvwxyzabcd"))
```

## Input Validation

### Topic Sanitization

```python
from server.security.validation import sanitize_topic

try:
    clean_topic = sanitize_topic(user_input)
except ValidationError as e:
    # Handle invalid input
    pass
```

Validation includes:
- Length limits (max 200 characters)
- Unicode normalization
- Control character removal
- HTML/script tag stripping
- Path traversal pattern detection

### Path Validation

```python
from server.security.validation import validate_path_within_base

try:
    safe_path = validate_path_within_base(
        user_provided_path,
        base_dir="/tmp/documentary-pipeline"
    )
except ValidationError as e:
    # Path escapes base directory
    pass
```

### Filename Sanitization

```python
from server.security.validation import sanitize_filename

safe_name = sanitize_filename("../../../etc/passwd")
# Result: "etc_passwd"
```

## Rate Limiting

### Configuration

```bash
# Requests per minute per client
export RATE_LIMIT_RPM="60"

# Burst size (immediate requests allowed)
# Default is 10
```

### Response Headers

Rate limit information is included in responses:

```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Window: 60
```

### Rate Limit Exceeded

When rate limit is exceeded:

```json
{
  "error": "Rate limit exceeded",
  "message": "Too many requests. Please retry after 60 seconds."
}
```

Response headers:

```
Retry-After: 60
```

## Security Headers

The following security headers are added to all responses:

| Header | Value | Purpose |
|--------|-------|---------|
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains` | Enforce HTTPS |
| `Content-Security-Policy` | Restrictive policy | Prevent XSS |
| `X-Content-Type-Options` | `nosniff` | Prevent MIME sniffing |
| `X-Frame-Options` | `DENY` | Prevent clickjacking |
| `X-XSS-Protection` | `1; mode=block` | XSS protection (legacy) |
| `Referrer-Policy` | `strict-origin-when-cross-origin` | Control referrer |
| `Permissions-Policy` | Restrictive | Limit browser features |

### Custom CSP

To customize the Content Security Policy:

```python
from server.security.middleware import SecurityHeadersMiddleware

app.add_middleware(
    SecurityHeadersMiddleware,
    csp_policy="default-src 'self'; script-src 'self' 'unsafe-inline';"
)
```

## Path Traversal Protection

All file operations validate paths:

```python
from server.tools.secure_wrappers import validate_file_path

# This will raise ValidationError if path escapes base directory
safe_path = validate_file_path(
    "../../../etc/passwd",
    base_dir="/tmp/documentary-pipeline",
    must_exist=False
)
```

### Tool Wrappers

Pre-configured wrappers for common directories:

```python
from server.tools.secure_wrappers import video_tool, audio_tool, timeline_tool

@video_tool
def generate_video(output_path: str, ...):
    # output_path is automatically validated
    pass
```

## Command Injection Prevention

### Secure Subprocess Execution

```python
from server.tools.secure_wrappers import secure_subprocess_run

result = secure_subprocess_run(
    ["ffmpeg", "-i", input_file, output_file],
    timeout=60,
    sanitize_args=True
)

if not result.success:
    print(f"Error: {result.stderr}")
```

### FFmpeg Wrapper

```python
from server.tools.secure_wrappers import safe_ffmpeg_command

result = safe_ffmpeg_command(
    input_paths=["input.mp4"],
    output_path="output.mp4",
    options=["-c:v", "libx264", "-crf", "18"],
    base_dir="/tmp/documentary-pipeline/video"
)
```

### Argument Sanitization

Command arguments are automatically sanitized:

- Dangerous shell characters blocked: `;|&$`\n\r<>{}()'"\`
- Command substitution patterns detected: `$(...)`, `` `...` ``
- Path traversal patterns blocked

## Security Scanning

### Running Security Scans

```bash
# Run all security scanners
python scripts/security_scan.py

# Run specific scanner
python scripts/security_scan.py --scanner bandit
python scripts/security_scan.py --scanner safety
python scripts/security_scan.py --scanner semgrep
python scripts/security_scan.py --scanner pip-audit

# Full scan (includes all Semgrep rules)
python scripts/security_scan.py --full

# Output as JSON
python scripts/security_scan.py --json
```

### Scanners Included

1. **Bandit**: Python security linter
   - Detects common security issues in Python code
   - Configuration: `.bandit`

2. **Safety**: Dependency vulnerability scanner
   - Checks installed packages against vulnerability database
   - Configuration: `.safety-policy.yml`

3. **Semgrep**: Static analysis
   - OWASP Top 10 detection
   - CWE Top 25 detection
   - Python-specific rules

4. **pip-audit**: Package vulnerability scanner
   - Audits Python packages for known vulnerabilities

### CI/CD Integration

Add to your CI pipeline:

```yaml
# .github/workflows/security.yml
name: Security Scan

on: [push, pull_request]

jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: pip install bandit safety semgrep pip-audit
      - run: python scripts/security_scan.py
```

## Deployment Security

### Production Checklist

- [ ] All secrets stored in environment variables
- [ ] HTTPS enabled with valid certificates
- [ ] `REQUIRE_HTTPS=true` set
- [ ] `ENABLE_DOCS=false` set (disable API docs in production)
- [ ] Rate limiting enabled
- [ ] Security headers enabled
- [ ] CORS origins restricted to known domains
- [ ] Request size limits configured
- [ ] Logging configured (no secret exposure)
- [ ] Security scanning in CI/CD pipeline

### Docker Security

```dockerfile
# Use non-root user
RUN useradd -m -u 1000 appuser
USER appuser

# Don't copy .env file
COPY --chown=appuser:appuser . /app

# Run with minimal privileges
CMD ["python", "-m", "server.server_secure"]
```

### Kubernetes Security

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: documentary-secrets
type: Opaque
stringData:
  GOOGLE_API_KEY: "..."
  OPENAI_API_KEY: "..."
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: documentary-pipeline
spec:
  template:
    spec:
      containers:
        - name: pipeline
          image: documentary-pipeline:latest
          securityContext:
            runAsNonRoot: true
            runAsUser: 1000
            readOnlyRootFilesystem: true
          envFrom:
            - secretRef:
                name: documentary-secrets
```

## Security Contacts

If you discover a security vulnerability:

1. **DO NOT** open a public issue
2. Email security concerns to the project maintainers
3. Provide detailed information about the vulnerability
4. Allow time for remediation before public disclosure

## Security Updates

Stay informed about security updates:

- Watch the repository for security advisories
- Subscribe to security notifications
- Keep dependencies updated (`pip-audit`, `safety`)

## License

This security documentation is provided under the same license as the project.
