"""
Central configuration with security enhancements.

SECURITY FEATURES:
- All settings from environment variables only
- Secrets validation and strength checking
- Path validation and sanitization
- Input length limits (DoS prevention)
- Type validation for all configuration values

This is the single source of truth for runtime configuration.
Import from here rather than reading env vars directly.
"""

from __future__ import annotations

import os
import re
import logging
from pathlib import Path
from typing import Optional, List, Set
from dataclasses import dataclass

# Import security validation
from server.security.validation import (
    sanitize_filename,
    validate_path_within_base,
    validate_integer_range,
    validate_float_range,
    ValidationError,
)
from server.security.secrets import get_secrets_manager, mask_secret

logger = logging.getLogger(__name__)


class ConfigValidationError(Exception):
    """Raised when configuration validation fails."""
    pass


@dataclass
class SecurityConfig:
    """Security-related configuration."""
    enable_rate_limiting: bool = True
    enable_security_headers: bool = True
    rate_limit_requests_per_minute: int = 60
    max_request_body_size: int = 10 * 1024 * 1024  # 10MB
    allowed_origins: List[str] = None
    require_https: bool = False
    
    def __post_init__(self):
        if self.allowed_origins is None:
            self.allowed_origins = ["http://localhost:3000"]


@dataclass
class PathConfig:
    """Path-related configuration with validation."""
    project_root: Path = None
    data_dir: Path = None
    corpus_dir: Path = None
    transcript_dir: Path = None
    enrichment_dir: Path = None
    timeline_dir: Path = None
    tts_output_dir: Path = None
    video_output_dir: Path = None
    findings_dir: Path = None
    dashboard_db_dir: Path = None
    
    def __post_init__(self):
        if self.project_root is None:
            self.project_root = Path(__file__).resolve().parent


def _get_env_str(key: str, default: str = "", max_length: int = 1000) -> str:
    """Safely get a string environment variable."""
    value = os.environ.get(key, default)
    if len(value) > max_length:
        logger.warning("Environment variable %s exceeds max length, truncating", key)
        value = value[:max_length]
    return value


def _get_env_int(
    key: str,
    default: int = 0,
    min_val: Optional[int] = None,
    max_val: Optional[int] = None
) -> int:
    """Safely get an integer environment variable."""
    value_str = os.environ.get(key, str(default))
    try:
        value = int(value_str)
    except ValueError:
        logger.warning("Invalid integer for %s: %s, using default %d", key, value_str, default)
        value = default
    
    if min_val is not None and value < min_val:
        logger.warning("%s below minimum %d, using minimum", key, min_val)
        value = min_val
    if max_val is not None and value > max_val:
        logger.warning("%s above maximum %d, using maximum", key, max_val)
        value = max_val
    
    return value


def _get_env_float(
    key: str,
    default: float = 0.0,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None
) -> float:
    """Safely get a float environment variable."""
    value_str = os.environ.get(key, str(default))
    try:
        value = float(value_str)
    except ValueError:
        logger.warning("Invalid float for %s: %s, using default %f", key, value_str, default)
        value = default
    
    if min_val is not None and value < min_val:
        logger.warning("%s below minimum %f, using minimum", key, min_val)
        value = min_val
    if max_val is not None and value > max_val:
        logger.warning("%s above maximum %f, using maximum", key, max_val)
        value = max_val
    
    return value


def _get_env_bool(key: str, default: bool = False) -> bool:
    """Safely get a boolean environment variable."""
    value = os.environ.get(key, str(default).lower())
    return value.strip().lower() in ("true", "1", "yes", "on")


def _get_env_list(key: str, default: Optional[List[str]] = None, separator: str = ",") -> List[str]:
    """Safely get a list environment variable."""
    value = os.environ.get(key, "")
    if not value:
        return default or []
    return [item.strip() for item in value.split(separator) if item.strip()]


def _get_safe_path(env_key: str, default: str, base_dir: Path) -> Path:
    """Get a path from environment with validation."""
    path_str = os.environ.get(env_key, default)
    
    # Expand user and environment variables
    path_str = os.path.expanduser(os.path.expandvars(path_str))
    
    # If relative, make it relative to base
    path = Path(path_str)
    if not path.is_absolute():
        path = base_dir / path
    
    # Create directory if it doesn't exist
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        logger.warning("Could not create directory %s: %s", path, e)
    
    return path


# ── Topic Configuration ──────────────────────────────────────
# The documentary topic — set dynamically per run
DOCUMENTARY_TOPIC = _get_env_str("DOCUMENTARY_TOPIC", "", max_length=200)

# ── Paths ────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent

# Validate and create data directories
DATA_DIR = _get_safe_path("DATA_DIR", "/tmp/documentary-pipeline", PROJECT_ROOT)
CORPUS_DIR = DATA_DIR / "corpus"
TRANSCRIPT_DIR = CORPUS_DIR / "transcripts"
ENRICHMENT_DIR = DATA_DIR / "enrichment"
TIMELINE_DIR = _get_safe_path("TIMELINE_DIR", str(DATA_DIR / "timelines"), PROJECT_ROOT)
TTS_OUTPUT_DIR = _get_safe_path("TTS_OUTPUT_DIR", str(DATA_DIR / "audio"), PROJECT_ROOT)
VIDEO_OUTPUT_DIR = _get_safe_path("VIDEO_OUTPUT_DIR", str(DATA_DIR / "video"), PROJECT_ROOT)
FINDINGS_DIR = _get_safe_path("FINDINGS_DIR", str(DATA_DIR / "findings"), PROJECT_ROOT)
DASHBOARD_DB_DIR = _get_safe_path("DASHBOARD_DB_DIR", str(DATA_DIR / "dashboard"), PROJECT_ROOT)

# ── Security Configuration ───────────────────────────────────
SECURITY = SecurityConfig(
    enable_rate_limiting=_get_env_bool("ENABLE_RATE_LIMITING", True),
    enable_security_headers=_get_env_bool("ENABLE_SECURITY_HEADERS", True),
    rate_limit_requests_per_minute=_get_env_int(
        "RATE_LIMIT_RPM", 60, min_val=1, max_val=10000
    ),
    max_request_body_size=_get_env_int(
        "MAX_REQUEST_BODY_SIZE", 10 * 1024 * 1024, min_val=1024, max_val=100 * 1024 * 1024
    ),
    allowed_origins=_get_env_list(
        "ALLOWED_ORIGINS",
        ["http://localhost:3000", "http://127.0.0.1:3000"]
    ),
    require_https=_get_env_bool("REQUIRE_HTTPS", False),
)

# ── API Keys (env vars only — no file-based keys) ───────────
# Use the secure secrets manager
_secrets_mgr = get_secrets_manager()

# LLM Providers
MINMAX_API = _secrets_mgr.get_secret("MINMAX_API", "")
DEEPSEEK_API = _secrets_mgr.get_secret("DEEPSEEK_API", "")
PERPLEXITY_API_KEY = _secrets_mgr.get_secret("PERPLEXITY_API_KEY", "")
GEMINI_API_KEY = _secrets_mgr.get_secret("GEMINI_API_KEY", "")
GROK_API = _secrets_mgr.get_secret("GROK_API", "")
OPENROUTER_API = _secrets_mgr.get_secret("OPENROUTER_API", "")
GROQ_API = _secrets_mgr.get_secret("GROQ_API", "")
MISTRAL_API_KEY = _secrets_mgr.get_secret("MISTRAL_API_KEY", "")
OPENAI_API_KEY = _secrets_mgr.get_secret("OPENAI_API_KEY", "")
ANTHROPIC_API = _secrets_mgr.get_secret("ANTHROPIC_API", "")

# Search Providers
EXA_API_KEY = _secrets_mgr.get_secret("EXA_API_KEY", "")
TAVILY_API_KEY = _secrets_mgr.get_secret("TAVILY_API_KEY", "")
BRAVE_SEARCH_API_KEY = _secrets_mgr.get_secret("BRAVE_SEARCH_API_KEY", "")
GOOGLE_SEARCH_API = _secrets_mgr.get_secret("GOOGLE_SEARCH_API", "")
GOOGLE_SEARCH_ENGINE_ID = _secrets_mgr.get_secret("GOOGLE_SEARCH_ENGINE_ID", "")

# Data APIs
FRED_API_KEY = _secrets_mgr.get_secret("FRED_API_KEY", "")
WOLFRAM_ALPHA_API = _secrets_mgr.get_secret("WOLFRAM_ALPHA_API", "")
JINA_API_KEY = _secrets_mgr.get_secret("JINA_API_KEY", "")

# GPU / Infrastructure
VAST_API_KEY = _secrets_mgr.get_secret("VAST_API_KEY", "")

# Proxy Services
BRIGHTDATA_KEY = _secrets_mgr.get_secret("BRIGHTDATA_KEY", "")
BRIGHTDATA_CUSTOMER_ID = _secrets_mgr.get_secret("BRIGHTDATA_CUSTOMER_ID", "hl_dc044bf4")
BRIGHTDATA_ZONE = _secrets_mgr.get_secret("BRIGHTDATA_ZONE", "mcp_unlocker")
OXYLABS_USERNAME = _secrets_mgr.get_secret("OXYLABS_USERNAME", "")
OXYLABS_PASSWORD = _secrets_mgr.get_secret("OXYLABS_PASSWORD", "")

# Observability
AGENTOPS_API_KEY = _secrets_mgr.get_secret("AGENTOPS_API_KEY", "")

# ── ADK Model Configuration ─────────────────────────────────
ADK_MODEL = _get_env_str("ADK_MODEL", "gemini-2.5-flash")
ADK_SYNTHESIS_MODEL = _get_env_str("ADK_SYNTHESIS_MODEL", "")
ADK_THINKER_MODEL = _get_env_str("ADK_THINKER_MODEL", "")
ADK_VISION_MODEL = _get_env_str("ADK_VISION_MODEL", "")
OPENAI_API_BASE = _get_env_str("OPENAI_API_BASE", "")

# ── Concurrency ──────────────────────────────────────────────
MAX_CONCURRENT_LLM = _get_env_int("MAX_CONCURRENT_LLM", 4, min_val=1, max_val=100)
MAX_CONTEXT_TOKENS = _get_env_int("MAX_CONTEXT_TOKENS", 120000, min_val=1000, max_val=500000)
HARD_CONTEXT_LIMIT = _get_env_int("HARD_CONTEXT_LIMIT", 180000, min_val=1000, max_val=1000000)
TOOL_RESULT_MAX_CHARS = _get_env_int("TOOL_RESULT_MAX_CHARS", 30000, min_val=1000, max_val=100000)
GPU_CONCURRENCY = _get_env_int("GPU_CONCURRENCY", 2, min_val=1, max_val=20)
TTS_CONCURRENCY = _get_env_int("TTS_CONCURRENCY", 3, min_val=1, max_val=20)
VASTAI_CONCURRENCY = _get_env_int("VASTAI_CONCURRENCY", 2, min_val=1, max_val=10)
TREE_MAX_CONCURRENT = _get_env_int("TREE_MAX_CONCURRENT", 4, min_val=1, max_val=50)
MAX_SUBAGENT_TURNS = _get_env_int("MAX_SUBAGENT_TURNS", 12, min_val=1, max_val=100)

# ── Feature Flags ────────────────────────────────────────────
DOCUMENTARY_TEST_MODE = _get_env_bool("DOCUMENTARY_TEST_MODE", False)
ADK_DEBUG = _get_env_bool("ADK_DEBUG", False)
PHOENIX_ENABLED = _get_env_bool("PHOENIX_ENABLED", False)
PHOENIX_COLLECTOR_ENDPOINT = _get_env_str("PHOENIX_COLLECTOR_ENDPOINT", "")

# ── Plugin Configuration ─────────────────────────────────────
CONTEXT_INVOCATIONS_TO_KEEP = _get_env_int("CONTEXT_INVOCATIONS_TO_KEEP", 10, min_val=1, max_val=100)
TOOL_MAX_RETRIES = _get_env_int("TOOL_MAX_RETRIES", 2, min_val=0, max_val=10)

# ── Server Configuration ─────────────────────────────────────
SERVER_HOST = _get_env_str("SERVER_HOST", "0.0.0.0")
SERVER_PORT = _get_env_int("SERVER_PORT", 8000, min_val=1, max_val=65535)
SERVER_RELOAD = _get_env_bool("SERVER_RELOAD", False)
ENABLE_DOCS = _get_env_bool("ENABLE_DOCS", False)

# SSL Configuration
SSL_KEYFILE = _get_env_str("SSL_KEYFILE", "")
SSL_CERTFILE = _get_env_str("SSL_CERTFILE", "")


def _read_key(filename: str) -> str:
    """
    Read an API key from environment variable.
    
    This is a compatibility shim for existing code that used file-based keys.
    The filename is converted to an env var name by stripping the extension
    and uppercasing:
    
        'minmax_api.txt' -> MINMAX_API
        'deepseek_api.txt' -> DEEPSEEK_API
        'exa_api_key.json' -> EXA_API_KEY
    
    SECURITY NOTE: This function NEVER reads from files, only environment.
    
    Args:
        filename: Original key filename (e.g., 'deepseek_api.txt').
    
    Returns:
        The API key string, or empty string if not set.
    """
    # Strip any common extension, not just .txt
    base = filename.rsplit(".", 1)[0] if "." in filename else filename
    env_name = base.upper()
    
    # Use secure secrets manager
    value = _secrets_mgr.get_secret(env_name, "")
    
    if value:
        logger.debug("Read key %s from environment (masked: %s)", 
                    filename, mask_secret(value))
    else:
        logger.debug("Key %s not found in environment", filename)
    
    return value


def validate_config() -> tuple[bool, List[str]]:
    """
    Validate the entire configuration.
    
    Returns:
        Tuple of (is_valid, list_of_issues)
    """
    issues = []
    
    # Check required secrets
    required_secrets = ["GOOGLE_API_KEY", "OPENAI_API_KEY"]
    for secret in required_secrets:
        value = _secrets_mgr.get_secret(secret)
        if not value:
            issues.append(f"Missing required secret: {secret}")
    
    # Validate paths exist and are writable
    paths_to_check = [
        ("DATA_DIR", DATA_DIR),
        ("TIMELINE_DIR", TIMELINE_DIR),
        ("TTS_OUTPUT_DIR", TTS_OUTPUT_DIR),
        ("VIDEO_OUTPUT_DIR", VIDEO_OUTPUT_DIR),
    ]
    
    for name, path in paths_to_check:
        try:
            path.mkdir(parents=True, exist_ok=True)
            # Try to write a test file
            test_file = path / ".write_test"
            test_file.touch()
            test_file.unlink()
        except OSError as e:
            issues.append(f"Path {name} ({path}) is not writable: {e}")
    
    # Validate security configuration
    if SECURITY.require_https and not (SSL_KEYFILE and SSL_CERTFILE):
        issues.append("REQUIRE_HTTPS is enabled but SSL certificates not configured")
    
    # Validate model configuration
    if not ADK_MODEL:
        issues.append("ADK_MODEL must be set")
    
    is_valid = len(issues) == 0
    return is_valid, issues


def get_config_summary(mask_secrets: bool = True) -> dict:
    """
    Get a summary of the current configuration.
    
    Args:
        mask_secrets: Whether to mask secret values
        
    Returns:
        Dictionary with configuration summary
    """
    secrets_summary = _secrets_mgr.get_secrets_summary(mask=mask_secrets)
    
    return {
        "topic": DOCUMENTARY_TOPIC[:50] if DOCUMENTARY_TOPIC else "(not set)",
        "paths": {
            "data_dir": str(DATA_DIR),
            "timeline_dir": str(TIMELINE_DIR),
            "tts_output_dir": str(TTS_OUTPUT_DIR),
            "video_output_dir": str(VIDEO_OUTPUT_DIR),
        },
        "security": {
            "rate_limiting": SECURITY.enable_rate_limiting,
            "security_headers": SECURITY.enable_security_headers,
            "rate_limit_rpm": SECURITY.rate_limit_requests_per_minute,
            "max_body_size": SECURITY.max_request_body_size,
            "require_https": SECURITY.require_https,
        },
        "model": ADK_MODEL,
        "concurrency": {
            "max_concurrent_llm": MAX_CONCURRENT_LLM,
            "gpu_concurrency": GPU_CONCURRENCY,
            "tts_concurrency": TTS_CONCURRENCY,
        },
        "secrets": {
            "total_configured": sum(1 for v in secrets_summary.values() if v.get("present")),
            "total_available": len(secrets_summary),
        },
        "test_mode": DOCUMENTARY_TEST_MODE,
        "debug": ADK_DEBUG,
    }


# Run validation on import (in production, this should be explicit)
if __name__ == "__main__":
    is_valid, issues = validate_config()
    
    print("Configuration Validation:")
    print(f"  Valid: {is_valid}")
    
    if issues:
        print("  Issues:")
        for issue in issues:
            print(f"    - {issue}")
    
    print("\nConfiguration Summary:")
    import json
    print(json.dumps(get_config_summary(), indent=2))
