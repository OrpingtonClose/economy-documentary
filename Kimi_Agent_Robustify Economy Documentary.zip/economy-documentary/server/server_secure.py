"""
FastAPI + AG-UI server for the documentary pipeline with comprehensive security.

SECURITY FEATURES:
- Input validation and sanitization
- Rate limiting (60 requests/minute per client)
- Security headers (HSTS, CSP, X-Frame-Options, etc.)
- Path traversal protection
- Request size limiting (10MB)
- CORS with restricted origins
- Secrets validation at startup
- Secure logging (no secret exposure)

Ported from MiroThinker. Provides:
- POST / -- AG-UI endpoint for CopilotKit frontend
- /dashboard/* -- real-time pipeline dashboard endpoints
- Request logging middleware
- Pipeline collector middleware for dashboard integration
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

# Load environment variables first
load_dotenv()

# Import security modules
from security import (
    sanitize_topic,
    validate_topic_length,
    ValidationError,
    setup_security_middleware,
    validate_required_secrets,
    get_secrets_manager,
)

# Import existing modules
from ag_ui_adk import ADKAgent, add_adk_fastapi_endpoint
from google.adk.apps import App

from agents.model_config import ADK_MODEL_NAME
from agents.pipeline import pipeline_agent
from dashboard import remove_collector, set_active_collector
from dashboard.collector import PipelineCollector
from dashboard.event_store import init_db, insert_run, finalize_run, insert_snapshot
from dashboard.sse import router as dashboard_router
from agui import router as agui_router
from plugins import build_plugins, setup_otel

# Configure secure logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s"
)

# Security configuration
SECURITY_CONFIG = {
    "rate_limit_requests_per_minute": int(os.environ.get("RATE_LIMIT_RPM", "60")),
    "max_request_body_size": int(os.environ.get("MAX_REQUEST_BODY_SIZE", "10485760")),  # 10MB
    "enable_security_headers": os.environ.get("ENABLE_SECURITY_HEADERS", "true").lower() == "true",
    "enable_rate_limiting": os.environ.get("ENABLE_RATE_LIMITING", "true").lower() == "true",
    "allowed_origins": os.environ.get("ALLOWED_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(","),
    "require_https": os.environ.get("REQUIRE_HTTPS", "false").lower() == "true",
}


def _validate_env() -> None:
    """
    Validate required environment variables at startup.
    
    Performs security checks on:
    - Required API keys presence
    - Secret strength validation
    - Model configuration
    """
    secrets_mgr = get_secrets_manager()
    
    # Validate required secrets
    all_valid, issues = validate_required_secrets()
    if not all_valid:
        logger.error("Missing required secrets: %s", issues)
        raise ValueError(f"Missing required environment variables: {issues}")
    
    # Check model configuration
    model = ADK_MODEL_NAME
    if not model:
        raise ValueError("ADK_MODEL environment variable is required")
    
    # Log configuration (with masked secrets)
    has_google = bool(os.environ.get("GOOGLE_API_KEY"))
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    has_api_base = bool(os.environ.get("OPENAI_API_BASE"))
    
    if not (has_google or has_openai or has_api_base):
        logger.warning(
            "No API keys configured. Set GOOGLE_API_KEY for Gemini "
            "or OPENAI_API_KEY + OPENAI_API_BASE for LiteLLM routing."
        )
    
    # Log secrets summary (masked)
    secrets_summary = secrets_mgr.get_secrets_summary(mask=True)
    present_secrets = [k for k, v in secrets_summary.items() if v.get("present")]
    logger.info(
        "Model configuration: ADK_MODEL=%s, Gemini=%s, LiteLLM=%s, Secrets=%d/%d",
        model,
        "yes" if has_google else "no",
        "yes" if (has_openai or has_api_base) else "no",
        len(present_secrets),
        len(secrets_summary),
    )
    
    # Check for weak secrets
    weak_secrets = [
        k for k, v in secrets_summary.items()
        if v.get("present") and v.get("strength") == "weak"
    ]
    if weak_secrets:
        logger.warning("Weak secrets detected for: %s", ", ".join(weak_secrets))


class SecureRequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Log request method, path, status, and duration with security considerations.
    
    - Never logs sensitive headers or body content
    - Masks IP addresses in logs
    - Sanitizes user agent strings
    """
    
    SENSITIVE_HEADERS = {
        'authorization', 'cookie', 'x-api-key', 'x-auth-token',
        'proxy-authorization', 'set-cookie'
    }
    
    async def dispatch(self, request: Request, call_next):
        start = time.time()
        
        # Get client info (safely)
        client_ip = request.client.host if request.client else "unknown"
        forwarded_for = request.headers.get("X-Forwarded-For", "")
        
        # Use forwarded IP if available (behind proxy)
        if forwarded_for:
            client_ip = forwarded_for.split(",")[0].strip()
        
        # Mask IP for privacy (last octet)
        masked_ip = self._mask_ip(client_ip)
        
        response = await call_next(request)
        duration = time.time() - start
        
        # Log without sensitive data
        logger.info(
            "%s %s -> %d (%.2fs) [client: %s]",
            request.method,
            request.url.path,
            response.status_code,
            duration,
            masked_ip,
        )
        
        return response
    
    def _mask_ip(self, ip: str) -> str:
        """Mask the last octet of an IP address for privacy."""
        if ":" in ip:  # IPv6
            parts = ip.split(":")
            if len(parts) > 2:
                return ":".join(parts[:3]) + ":***"
            return ip[:10] + "***"
        else:  # IPv4
            parts = ip.split(".")
            if len(parts) == 4:
                return ".".join(parts[:3]) + ".***"
            return ip[:ip.rfind(".")+1] + "***" if "." in ip else ip


class AGUIRunCollectorMiddleware(BaseHTTPMiddleware):
    """Create and manage PipelineCollector for each AG-UI request."""
    
    async def dispatch(self, request: Request, call_next):
        if request.url.path != "/" or request.method != "POST":
            return await call_next(request)
        
        run_id = f"run_{uuid.uuid4().hex[:8]}"
        collector = PipelineCollector(run_id=run_id)
        set_active_collector(collector)
        insert_run(run_id)
        
        try:
            response = await call_next(request)
            
            # For SSE responses, we need to wrap the body iterator
            if hasattr(response, "body_iterator"):
                original_iterator = response.body_iterator
                
                async def wrapped_iterator():
                    try:
                        async for chunk in original_iterator:
                            yield chunk
                    finally:
                        data = collector.finalize()
                        finalize_run(run_id, status=data["status"], metadata=data)
                        insert_snapshot(run_id, data)
                        remove_collector(run_id)
                        logger.info("Pipeline run %s finalized", run_id)
                
                response.body_iterator = wrapped_iterator()
            
            return response
        except Exception:
            collector.finalize(status="error")
            finalize_run(run_id, status="error")
            remove_collector(run_id)
            raise


class TopicValidationMiddleware(BaseHTTPMiddleware):
    """
    Validate and sanitize documentary topic input.
    
    Prevents:
    - Path traversal via topic
    - XSS injection
    - Overly long topics (DoS)
    """
    
    async def dispatch(self, request: Request, call_next):
        # Only validate POST requests to the main endpoint
        if request.method == "POST" and request.url.path == "/":
            try:
                # Read and validate the request body
                body = await request.body()
                
                # Check body size
                if len(body) > SECURITY_CONFIG["max_request_body_size"]:
                    return JSONResponse(
                        status_code=413,
                        content={
                            "error": "Request body too large",
                            "max_size": SECURITY_CONFIG["max_request_body_size"],
                        }
                    )
                
                # Try to parse and validate topic if present
                import json
                try:
                    data = json.loads(body)
                    if "topic" in data:
                        sanitized_topic = sanitize_topic(data["topic"])
                        validate_topic_length(sanitized_topic)
                        logger.info("Validated topic: %s...", sanitized_topic[:50])
                except (json.JSONDecodeError, ValidationError) as e:
                    logger.warning("Topic validation failed: %s", str(e))
                    return JSONResponse(
                        status_code=400,
                        content={"error": f"Invalid topic: {str(e)}"}
                    )
                
            except Exception as e:
                logger.error("Error in topic validation: %s", e)
        
        return await call_next(request)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: setup OTel, validate env, init DB."""
    try:
        _validate_env()
        setup_otel()
        init_db()
        logger.info("Documentary pipeline server started with security features")
        
        # Log security configuration
        logger.info(
            "Security config: rate_limit=%s, security_headers=%s, max_body=%d",
            SECURITY_CONFIG["enable_rate_limiting"],
            SECURITY_CONFIG["enable_security_headers"],
            SECURITY_CONFIG["max_request_body_size"],
        )
    except Exception as e:
        logger.error("Failed to start server: %s", e)
        raise
    
    yield
    
    logger.info("Documentary pipeline server shutting down")


# Create FastAPI app with security
app = FastAPI(
    title="Documentary Pipeline",
    description="ADHD-friendly AI documentary pipeline with Google ADK + AG-UI (SECURED)",
    version="0.2.0-secure",
    lifespan=lifespan,
    docs_url="/docs" if os.environ.get("ENABLE_DOCS", "false").lower() == "true" else None,
    redoc_url="/redoc" if os.environ.get("ENABLE_DOCS", "false").lower() == "true" else None,
)

# Setup security middleware
app = setup_security_middleware(
    app,
    enable_security_headers=SECURITY_CONFIG["enable_security_headers"],
    enable_rate_limiting=SECURITY_CONFIG["enable_rate_limiting"],
    enable_request_size_limit=True,
    enable_logging=True,
    rate_limit_requests_per_minute=SECURITY_CONFIG["rate_limit_requests_per_minute"],
    max_request_body_size=SECURITY_CONFIG["max_request_body_size"],
    allowed_origins=SECURITY_CONFIG["allowed_origins"],
)

# Custom middleware stack (order matters: last added = first executed)
app.add_middleware(TopicValidationMiddleware)
app.add_middleware(AGUIRunCollectorMiddleware)
app.add_middleware(SecureRequestLoggingMiddleware)

# Dashboard routes
app.include_router(dashboard_router)

# AG-UI routes (artifact feedback, escalations, regeneration)
app.include_router(agui_router)


# AG-UI endpoint -- uses App + ADKAgent.from_app() to preserve plugins
_adk_app = App(
    name="documentary_pipeline",
    root_agent=pipeline_agent,
    plugins=build_plugins(),
)
adk_agent = ADKAgent.from_app(app=_adk_app)
add_adk_fastapi_endpoint(app, adk_agent, path="/")


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {
        "status": "ok",
        "model": ADK_MODEL_NAME,
        "version": "0.2.0-secure",
        "security": {
            "rate_limiting": SECURITY_CONFIG["enable_rate_limiting"],
            "security_headers": SECURITY_CONFIG["enable_security_headers"],
        },
    }


@app.get("/security/status")
async def security_status():
    """
    Get current security status.
    
    Returns information about security configuration without exposing secrets.
    """
    secrets_mgr = get_secrets_manager()
    secrets_summary = secrets_mgr.get_secrets_summary(mask=True)
    
    present_secrets = sum(1 for v in secrets_summary.values() if v.get("present"))
    strong_secrets = sum(
        1 for v in secrets_summary.values()
        if v.get("present") and v.get("strength") == "strong"
    )
    
    return {
        "security_features": {
            "rate_limiting": SECURITY_CONFIG["enable_rate_limiting"],
            "security_headers": SECURITY_CONFIG["enable_security_headers"],
            "request_size_limit": SECURITY_CONFIG["max_request_body_size"],
        },
        "secrets": {
            "total_configured": present_secrets,
            "strong_secrets": strong_secrets,
            "status": "healthy" if present_secrets > 0 else "missing_secrets",
        },
        "cors_origins": len(SECURITY_CONFIG["allowed_origins"]),
    }


@app.exceptionHandler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    """Handle validation errors with appropriate response."""
    return JSONResponse(
        status_code=400,
        content={"error": "Validation error", "message": str(exc)},
    )


@app.exceptionHandler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions without exposing internal details."""
    logger.exception("Unhandled exception: %s", exc)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"},
    )


if __name__ == "__main__":
    import uvicorn
    
    # Get server configuration from environment
    host = os.environ.get("SERVER_HOST", "0.0.0.0")
    port = int(os.environ.get("SERVER_PORT", "8000"))
    reload = os.environ.get("SERVER_RELOAD", "false").lower() == "true"
    
    # SSL configuration
    ssl_keyfile = os.environ.get("SSL_KEYFILE")
    ssl_certfile = os.environ.get("SSL_CERTFILE")
    
    uvicorn_config = {
        "host": host,
        "port": port,
        "reload": reload,
        "log_level": "info",
    }
    
    if ssl_keyfile and ssl_certfile:
        uvicorn_config["ssl_keyfile"] = ssl_keyfile
        uvicorn_config["ssl_certfile"] = ssl_certfile
        logger.info("SSL enabled with cert: %s", ssl_certfile)
    
    uvicorn.run("server_secure:app", **uvicorn_config)
