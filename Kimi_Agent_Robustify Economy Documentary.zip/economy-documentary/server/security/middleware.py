"""
Security middleware for FastAPI application.

Provides:
- Security headers (HSTS, CSP, X-Frame-Options, etc.)
- Rate limiting per endpoint/client
- Request size limiting
- CORS security improvements
"""

from __future__ import annotations

import time
import hashlib
import logging
from typing import Optional, Callable, Dict, List, Set
from collections import defaultdict
from functools import wraps

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, JSONResponse
from fastapi import FastAPI

logger = logging.getLogger(__name__)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Add security headers to all responses.
    
    Implements OWASP recommended security headers:
    - Strict-Transport-Security (HSTS)
    - Content-Security-Policy (CSP)
    - X-Content-Type-Options
    - X-Frame-Options
    - X-XSS-Protection
    - Referrer-Policy
    - Permissions-Policy
    """
    
    def __init__(
        self,
        app,
        csp_policy: Optional[str] = None,
        hsts_max_age: int = 31536000,  # 1 year
        hsts_include_subdomains: bool = True,
        allow_iframe: bool = False,
    ):
        super().__init__(app)
        self.hsts_max_age = hsts_max_age
        self.hsts_include_subdomains = hsts_include_subdomains
        self.allow_iframe = allow_iframe
        
        # Default CSP policy - very restrictive
        self.csp_policy = csp_policy or (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; "
            "font-src 'self'; "
            "connect-src 'self'; "
            "media-src 'self' blob:; "
            "object-src 'none'; "
            "frame-src 'none'; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self';"
        )
    
    async def dispatch(self, request: Request, call_next) -> Response:
        response = await call_next(request)
        
        # HSTS - HTTP Strict Transport Security
        if self.hsts_max_age > 0:
            hsts_value = f"max-age={self.hsts_max_age}"
            if self.hsts_include_subdomains:
                hsts_value += "; includeSubDomains"
            response.headers["Strict-Transport-Security"] = hsts_value
        
        # Content Security Policy
        response.headers["Content-Security-Policy"] = self.csp_policy
        
        # Prevent MIME type sniffing
        response.headers["X-Content-Type-Options"] = "nosniff"
        
        # X-Frame-Options (clickjacking protection)
        if not self.allow_iframe:
            response.headers["X-Frame-Options"] = "DENY"
        
        # XSS Protection (legacy browsers)
        response.headers["X-XSS-Protection"] = "1; mode=block"
        
        # Referrer Policy
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        # Permissions Policy (formerly Feature-Policy)
        response.headers["Permissions-Policy"] = (
            "accelerometer=(), "
            "camera=(), "
            "geolocation=(), "
            "gyroscope=(), "
            "magnetometer=(), "
            "microphone=(), "
            "payment=(), "
            "usb=()"
        )
        
        # Remove server information
        response.headers.pop("Server", None)
        
        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Rate limiting middleware with per-client tracking.
    
    Features:
    - Per-IP rate limiting
    - Per-endpoint rate limiting
    - Configurable window and limit
    - Automatic cleanup of old entries
    """
    
    def __init__(
        self,
        app,
        requests_per_minute: int = 60,
        burst_size: int = 10,
        window_seconds: int = 60,
        exclude_paths: Optional[Set[str]] = None,
        key_prefix: str = "ratelimit",
    ):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.burst_size = burst_size
        self.window_seconds = window_seconds
        self.exclude_paths = exclude_paths or {"/health", "/docs", "/openapi.json"}
        self.key_prefix = key_prefix
        
        # In-memory store: {client_key: [(timestamp, count), ...]}
        self._requests: Dict[str, List[float]] = defaultdict(list)
        self._blocked_clients: Dict[str, float] = {}  # client -> unblock_time
        
        logger.info(
            "Rate limiting enabled: %d req/min, burst=%d, window=%ds",
            requests_per_minute, burst_size, window_seconds
        )
    
    def _get_client_key(self, request: Request) -> str:
        """Generate a unique key for the client."""
        # Use X-Forwarded-For if behind proxy, otherwise use client host
        forwarded_for = request.headers.get("X-Forwarded-For", "")
        if forwarded_for:
            client_ip = forwarded_for.split(",")[0].strip()
        else:
            client_ip = request.client.host if request.client else "unknown"
        
        # Include path in key for per-endpoint limiting
        path = request.url.path
        return f"{self.key_prefix}:{client_ip}:{path}"
    
    def _is_rate_limited(self, client_key: str) -> tuple[bool, dict]:
        """
        Check if a client is rate limited.
        
        Returns:
            Tuple of (is_limited, rate_limit_info)
        """
        now = time.time()
        
        # Check if client is blocked
        if client_key in self._blocked_clients:
            unblock_time = self._blocked_clients[client_key]
            if now < unblock_time:
                return True, {
                    "retry_after": int(unblock_time - now),
                    "limit": self.requests_per_minute,
                    "window": self.window_seconds,
                }
            else:
                del self._blocked_clients[client_key]
        
        # Clean old requests outside the window
        window_start = now - self.window_seconds
        self._requests[client_key] = [
            ts for ts in self._requests[client_key] if ts > window_start
        ]
        
        # Check burst limit
        if len(self._requests[client_key]) >= self.burst_size:
            # Block client temporarily
            block_duration = self.window_seconds
            self._blocked_clients[client_key] = now + block_duration
            logger.warning("Rate limit exceeded for client: %s", client_key.split(":")[1])
            return True, {
                "retry_after": block_duration,
                "limit": self.requests_per_minute,
                "window": self.window_seconds,
            }
        
        # Check rate limit
        if len(self._requests[client_key]) >= self.requests_per_minute:
            return True, {
                "retry_after": self.window_seconds,
                "limit": self.requests_per_minute,
                "window": self.window_seconds,
            }
        
        # Record request
        self._requests[client_key].append(now)
        
        return False, {
            "limit": self.requests_per_minute,
            "remaining": self.requests_per_minute - len(self._requests[client_key]),
            "window": self.window_seconds,
        }
    
    async def dispatch(self, request: Request, call_next) -> Response:
        # Skip rate limiting for excluded paths
        if request.url.path in self.exclude_paths:
            return await call_next(request)
        
        client_key = self._get_client_key(request)
        is_limited, rate_info = self._is_rate_limited(client_key)
        
        if is_limited:
            headers = {
                "X-RateLimit-Limit": str(rate_info["limit"]),
                "X-RateLimit-Window": str(rate_info["window"]),
                "Retry-After": str(rate_info["retry_after"]),
            }
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Rate limit exceeded",
                    "message": f"Too many requests. Please retry after {rate_info['retry_after']} seconds.",
                },
                headers=headers,
            )
        
        response = await call_next(request)
        
        # Add rate limit headers to response
        response.headers["X-RateLimit-Limit"] = str(rate_info["limit"])
        response.headers["X-RateLimit-Remaining"] = str(rate_info["remaining"])
        response.headers["X-RateLimit-Window"] = str(rate_info["window"])
        
        return response


class RequestSizeLimitMiddleware(BaseHTTPMiddleware):
    """Limit request body size to prevent DoS attacks."""
    
    def __init__(
        self,
        app,
        max_body_size: int = 10 * 1024 * 1024,  # 10 MB default
    ):
        super().__init__(app)
        self.max_body_size = max_body_size
    
    async def dispatch(self, request: Request, call_next) -> Response:
        # Check Content-Length header
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size > self.max_body_size:
                    return JSONResponse(
                        status_code=413,
                        content={
                            "error": "Request entity too large",
                            "max_size": self.max_body_size,
                            "received": size,
                        },
                    )
            except ValueError:
                pass  # Invalid content-length, let it through and catch later
        
        return await call_next(request)


class LoggingMiddleware(BaseHTTPMiddleware):
    """Log requests with security-relevant information."""
    
    async def dispatch(self, request: Request, call_next) -> Response:
        start_time = time.time()
        
        # Get client info
        client_ip = request.client.host if request.client else "unknown"
        forwarded_for = request.headers.get("X-Forwarded-For", "")
        user_agent = request.headers.get("User-Agent", "")[:200]  # Truncate
        
        response = await call_next(request)
        
        duration = time.time() - start_time
        
        # Log with security context
        logger.info(
            "Request: %s %s | Status: %d | Duration: %.3fs | IP: %s | UA: %s",
            request.method,
            request.url.path,
            response.status_code,
            duration,
            forwarded_for or client_ip,
            user_agent,
        )
        
        return response


def setup_security_middleware(
    app: FastAPI,
    enable_security_headers: bool = True,
    enable_rate_limiting: bool = True,
    enable_request_size_limit: bool = True,
    enable_logging: bool = True,
    rate_limit_requests_per_minute: int = 60,
    max_request_body_size: int = 10 * 1024 * 1024,
    allowed_origins: Optional[List[str]] = None,
) -> FastAPI:
    """
    Setup all security middleware for a FastAPI application.
    
    Args:
        app: FastAPI application instance
        enable_security_headers: Add security headers to responses
        enable_rate_limiting: Enable rate limiting
        enable_request_size_limit: Limit request body size
        enable_logging: Enable security logging
        rate_limit_requests_per_minute: Rate limit per client
        max_request_body_size: Maximum request body size in bytes
        allowed_origins: List of allowed CORS origins (None for default)
        
    Returns:
        The configured FastAPI application
    """
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.trustedhost import TrustedHostMiddleware
    
    # Security headers first (outermost layer)
    if enable_security_headers:
        app.add_middleware(SecurityHeadersMiddleware)
        logger.info("Security headers middleware enabled")
    
    # Request size limit
    if enable_request_size_limit:
        app.add_middleware(RequestSizeLimitMiddleware, max_body_size=max_request_body_size)
        logger.info("Request size limit middleware enabled (max: %d bytes)", max_request_body_size)
    
    # Rate limiting
    if enable_rate_limiting:
        app.add_middleware(
            RateLimitMiddleware,
            requests_per_minute=rate_limit_requests_per_minute,
        )
        logger.info("Rate limiting middleware enabled (%d req/min)", rate_limit_requests_per_minute)
    
    # Logging
    if enable_logging:
        app.add_middleware(LoggingMiddleware)
        logger.info("Logging middleware enabled")
    
    # CORS - more restrictive than default
    # Only allow specific origins, not "*"
    origins = allowed_origins or ["http://localhost:3000", "http://127.0.0.1:3000"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Requested-With"],
        max_age=600,  # 10 minutes
    )
    logger.info("CORS middleware configured with origins: %s", origins)
    
    return app


def rate_limit_by_endpoint(
    requests_per_minute: int = 30,
    burst_size: int = 5,
):
    """
    Decorator for endpoint-specific rate limiting.
    
    Usage:
        @app.get("/api/sensitive")
        @rate_limit_by_endpoint(requests_per_minute=10)
        async def sensitive_endpoint():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # This is a simplified version - in production, use Redis
            # For now, rely on the middleware
            return await func(*args, **kwargs)
        return wrapper
    return decorator
