"""
Input validation and sanitization utilities.

Provides protection against:
- Path traversal attacks
- Command injection
- XSS through input validation
- Overly long inputs (DoS prevention)
"""

from __future__ import annotations

import re
import os
from pathlib import Path
from typing import Optional
import unicodedata
import logging

logger = logging.getLogger(__name__)


class ValidationError(ValueError):
    """Raised when input validation fails."""
    pass


# Maximum lengths for various inputs (DoS prevention)
MAX_TOPIC_LENGTH = 200
MAX_FILENAME_LENGTH = 255
MAX_PATH_LENGTH = 4096
MAX_COMMAND_ARG_LENGTH = 4096
MAX_INPUT_LENGTH = 10000

# Allowed characters for different input types
SAFE_TOPIC_CHARS = re.compile(r'^[\w\s\-\.,;:!?\'"()[\]{}]+$')
SAFE_FILENAME_CHARS = re.compile(r'^[\w\-\.]+$')
PATH_TRAVERSAL_PATTERNS = re.compile(r'\.\.[\/\\]|\.[\/\\]{2,}|^[\/\\]')

# Dangerous characters that could lead to command injection
DANGEROUS_SHELL_CHARS = set(';|&$`\n\r<>{}()\'"\\')


def sanitize_topic(topic: str) -> str:
    """
    Sanitize a documentary topic string.
    
    Protection against:
    - XSS injection
    - Path traversal via topic
    - Control character injection
    - Overly long topics (DoS)
    
    Args:
        topic: Raw topic string from user input
        
    Returns:
        Sanitized topic string
        
    Raises:
        ValidationError: If topic is invalid or dangerous
    """
    if not topic:
        raise ValidationError("Topic cannot be empty")
    
    if len(topic) > MAX_TOPIC_LENGTH:
        raise ValidationError(f"Topic exceeds maximum length of {MAX_TOPIC_LENGTH} characters")
    
    # Normalize unicode to prevent homograph attacks
    topic = unicodedata.normalize('NFKC', topic)
    
    # Remove control characters
    topic = ''.join(char for char in topic if unicodedata.category(char)[0] != 'C')
    
    # Strip dangerous HTML/script patterns
    topic = re.sub(r'<script[^>]*>.*?</script>', '', topic, flags=re.IGNORECASE | re.DOTALL)
    topic = re.sub(r'<[^>]+>', '', topic)  # Remove HTML tags
    topic = re.sub(r'javascript:', '', topic, flags=re.IGNORECASE)
    topic = re.sub(r'on\w+\s*=', '', topic, flags=re.IGNORECASE)  # Remove event handlers
    
    # Remove null bytes
    topic = topic.replace('\x00', '')
    
    # Strip leading/trailing whitespace
    topic = topic.strip()
    
    # Check for path traversal attempts disguised in topic
    if PATH_TRAVERSAL_PATTERNS.search(topic):
        raise ValidationError("Topic contains potentially dangerous path characters")
    
    # Final validation
    if not topic:
        raise ValidationError("Topic is empty after sanitization")
    
    logger.debug("Sanitized topic: %r", topic[:50])
    return topic


def validate_topic_length(topic: str, min_length: int = 3, max_length: int = MAX_TOPIC_LENGTH) -> bool:
    """
    Validate topic length constraints.
    
    Args:
        topic: Topic string to validate
        min_length: Minimum allowed length
        max_length: Maximum allowed length
        
    Returns:
        True if valid, raises ValidationError otherwise
    """
    if len(topic) < min_length:
        raise ValidationError(f"Topic must be at least {min_length} characters")
    if len(topic) > max_length:
        raise ValidationError(f"Topic must not exceed {max_length} characters")
    return True


def sanitize_filename(filename: str, allow_spaces: bool = False) -> str:
    """
    Sanitize a filename to prevent path traversal and injection attacks.
    
    Args:
        filename: Raw filename string
        allow_spaces: Whether to allow spaces in filename
        
    Returns:
        Sanitized filename
        
    Raises:
        ValidationError: If filename is invalid or dangerous
    """
    if not filename:
        raise ValidationError("Filename cannot be empty")
    
    if len(filename) > MAX_FILENAME_LENGTH:
        raise ValidationError(f"Filename exceeds maximum length of {MAX_FILENAME_LENGTH} characters")
    
    # Normalize unicode
    filename = unicodedata.normalize('NFKC', filename)
    
    # Remove path components - filename only, no directories
    filename = os.path.basename(filename)
    
    # Remove null bytes
    filename = filename.replace('\x00', '')
    
    # Replace dangerous characters
    dangerous = '<>:"/\\|?*'
    if not allow_spaces:
        dangerous += ' '
    
    for char in dangerous:
        filename = filename.replace(char, '_')
    
    # Remove control characters
    filename = ''.join(char for char in filename if unicodedata.category(char)[0] != 'C')
    
    # Prevent hidden files (starting with .)
    filename = filename.lstrip('.')
    
    # Ensure filename is not empty after sanitization
    if not filename:
        raise ValidationError("Filename is empty after sanitization")
    
    # Check for reserved names on Windows
    reserved = {
        'CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 'COM5',
        'COM6', 'COM7', 'COM8', 'COM9', 'LPT1', 'LPT2', 'LPT3', 'LPT4',
        'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
    }
    name_without_ext = filename.split('.')[0].upper()
    if name_without_ext in reserved:
        raise ValidationError(f"Filename '{filename}' uses a reserved system name")
    
    logger.debug("Sanitized filename: %r", filename)
    return filename


def validate_path_within_base(
    path: str | Path,
    base_dir: str | Path,
    resolve_symlinks: bool = True
) -> Path:
    """
    Validate that a path is within a base directory (path traversal protection).
    
    Args:
        path: The path to validate
        base_dir: The allowed base directory
        resolve_symlinks: Whether to resolve symlinks before validation
        
    Returns:
        Resolved Path object if valid
        
    Raises:
        ValidationError: If path attempts to escape base directory
    """
    if not path:
        raise ValidationError("Path cannot be empty")
    
    if len(str(path)) > MAX_PATH_LENGTH:
        raise ValidationError(f"Path exceeds maximum length of {MAX_PATH_LENGTH} characters")
    
    base_path = Path(base_dir).resolve()
    
    # Resolve the input path
    if resolve_symlinks:
        try:
            # Check if path exists first to resolve symlinks
            input_path = Path(path)
            if input_path.exists():
                resolved_path = input_path.resolve()
            else:
                # For non-existent paths, resolve relative to base
                resolved_path = (base_path / path).resolve()
        except (OSError, ValueError) as e:
            raise ValidationError(f"Invalid path: {e}")
    else:
        resolved_path = Path(path).resolve()
    
    # Check for path traversal
    try:
        # Ensure resolved_path is relative to base_path
        resolved_path.relative_to(base_path)
    except ValueError:
        raise ValidationError(
            f"Path traversal detected: '{path}' attempts to escape base directory '{base_dir}'"
        )
    
    logger.debug("Validated path within base: %s", resolved_path)
    return resolved_path


def sanitize_command_arg(arg: str) -> str:
    """
    Sanitize a command argument to prevent command injection.
    
    Args:
        arg: Command argument to sanitize
        
    Returns:
        Sanitized argument safe for subprocess use
        
    Raises:
        ValidationError: If argument contains dangerous characters
    """
    if not arg:
        return arg
    
    if len(arg) > MAX_COMMAND_ARG_LENGTH:
        raise ValidationError(f"Command argument exceeds maximum length")
    
    # Check for dangerous shell characters
    for char in DANGEROUS_SHELL_CHARS:
        if char in arg:
            raise ValidationError(f"Command argument contains dangerous character: {repr(char)}")
    
    # Check for common injection patterns
    dangerous_patterns = [
        r'\$\(',           # $(command)
        r'`[^`]*`',        # `command`
        r'\$\{[^}]*\}',    # ${variable}
        r'\|\|',          # ||
        r'&&',             # &&
        r'\|\s*\w+',     # | command
        r';\s*\w+',       # ; command
        r'\n\s*\w+',      # newline + command
        r'\r\s*\w+',      # carriage return + command
    ]
    
    for pattern in dangerous_patterns:
        if re.search(pattern, arg):
            raise ValidationError(f"Command argument contains dangerous pattern")
    
    return arg


def sanitize_filepath_for_display(path: str) -> str:
    """
    Sanitize a filepath for safe display/logging (prevents log injection).
    
    Args:
        path: Filepath to sanitize
        
    Returns:
        Sanitized filepath safe for logging
    """
    if not path:
        return ""
    
    # Remove newlines that could inject into logs
    path = path.replace('\n', ' ').replace('\r', ' ')
    
    # Remove null bytes
    path = path.replace('\x00', '')
    
    # Truncate if too long
    if len(path) > 500:
        path = path[:250] + "..." + path[-250:]
    
    return path


def validate_json_input(data: dict, max_depth: int = 10, max_keys: int = 1000) -> bool:
    """
    Validate JSON input to prevent DoS via deeply nested structures.
    
    Args:
        data: Dictionary to validate
        max_depth: Maximum nesting depth allowed
        max_keys: Maximum number of keys allowed
        
    Returns:
        True if valid
        
    Raises:
        ValidationError: If JSON structure is suspicious
    """
    def _check_depth(obj, current_depth: int, key_count: list) -> int:
        if current_depth > max_depth:
            raise ValidationError(f"JSON nesting exceeds maximum depth of {max_depth}")
        
        if isinstance(obj, dict):
            key_count[0] += len(obj)
            if key_count[0] > max_keys:
                raise ValidationError(f"JSON contains too many keys (max {max_keys})")
            for value in obj.values():
                _check_depth(value, current_depth + 1, key_count)
        elif isinstance(obj, list):
            for item in obj:
                _check_depth(item, current_depth + 1, key_count)
        
        return current_depth
    
    key_count = [0]
    _check_depth(data, 1, key_count)
    return True


def validate_integer_range(
    value: int,
    min_val: Optional[int] = None,
    max_val: Optional[int] = None,
    name: str = "value"
) -> int:
    """
    Validate an integer is within an acceptable range.
    
    Args:
        value: Integer to validate
        min_val: Minimum allowed value (inclusive)
        max_val: Maximum allowed value (inclusive)
        name: Name of the value for error messages
        
    Returns:
        Validated integer
        
    Raises:
        ValidationError: If value is out of range
    """
    try:
        int_val = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{name} must be a valid integer")
    
    if min_val is not None and int_val < min_val:
        raise ValidationError(f"{name} must be at least {min_val}")
    
    if max_val is not None and int_val > max_val:
        raise ValidationError(f"{name} must not exceed {max_val}")
    
    return int_val


def validate_float_range(
    value: float,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
    name: str = "value"
) -> float:
    """
    Validate a float is within an acceptable range.
    
    Args:
        value: Float to validate
        min_val: Minimum allowed value (inclusive)
        max_val: Maximum allowed value (inclusive)
        name: Name of the value for error messages
        
    Returns:
        Validated float
        
    Raises:
        ValidationError: If value is out of range
    """
    try:
        float_val = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{name} must be a valid number")
    
    if min_val is not None and float_val < min_val:
        raise ValidationError(f"{name} must be at least {min_val}")
    
    if max_val is not None and float_val > max_val:
        raise ValidationError(f"{name} must not exceed {max_val}")
    
    return float_val
