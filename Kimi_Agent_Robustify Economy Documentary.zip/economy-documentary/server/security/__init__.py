"""
Security module for the documentary pipeline.

Provides:
- Input validation and sanitization
- Path traversal protection
- Rate limiting
- Security headers middleware
- Secrets validation
"""

from .validation import (
    sanitize_topic,
    sanitize_filename,
    validate_path_within_base,
    sanitize_command_arg,
    validate_topic_length,
    ValidationError,
)

from .middleware import (
    SecurityHeadersMiddleware,
    RateLimitMiddleware,
    setup_security_middleware,
)

from .secrets import (
    validate_required_secrets,
    check_secret_strength,
    rotate_secret,
    SecureSecretsManager,
)

__all__ = [
    # Validation
    "sanitize_topic",
    "sanitize_filename",
    "validate_path_within_base",
    "sanitize_command_arg",
    "validate_topic_length",
    "ValidationError",
    # Middleware
    "SecurityHeadersMiddleware",
    "RateLimitMiddleware",
    "setup_security_middleware",
    # Secrets
    "validate_required_secrets",
    "check_secret_strength",
    "rotate_secret",
    "SecureSecretsManager",
]
