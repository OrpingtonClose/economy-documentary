"""
Secure secrets management for the documentary pipeline.

Provides:
- Secrets validation
- Secure secrets storage patterns
- Secret rotation helpers
- Environment variable security checks
"""

from __future__ import annotations

import os
import re
import hashlib
import logging
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class SecretStrength(Enum):
    """Secret strength rating."""
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"


@dataclass
class SecretValidationResult:
    """Result of secret validation."""
    is_valid: bool
    strength: SecretStrength
    issues: List[str]
    warnings: List[str]


class SecureSecretsManager:
    """
    Manager for secure handling of API secrets.
    
    Features:
    - Validates secrets are from environment (not hardcoded)
    - Checks secret strength
    - Prevents secret logging
    - Tracks required vs optional secrets
    """
    
    # Secrets that should never be logged
    SENSITIVE_PATTERNS = [
        r'api[_-]?key',
        r'apikey',
        r'secret',
        r'token',
        r'password',
        r'credential',
        r'private[_-]?key',
        r'access[_-]?key',
        r'auth',
    ]
    
    # Required secrets for the pipeline to function
    REQUIRED_SECRETS = [
        "GOOGLE_API_KEY",
        "OPENAI_API_KEY",
    ]
    
    # Optional but recommended secrets
    OPTIONAL_SECRETS = [
        "GEMINI_API_KEY",
        "PERPLEXITY_API_KEY",
        "VAST_API_KEY",
        "EXA_API_KEY",
        "TAVILY_API_KEY",
        "BRAVE_SEARCH_API_KEY",
        "FRED_API_KEY",
        "ANTHROPIC_API",
        "DEEPSEEK_API",
        "AGENTOPS_API_KEY",
    ]
    
    def __init__(self):
        self._secret_cache: Dict[str, str] = {}
        self._validation_results: Dict[str, SecretValidationResult] = {}
    
    def is_sensitive_key(self, key: str) -> bool:
        """Check if a key name indicates sensitive content."""
        key_lower = key.lower()
        for pattern in self.SENSITIVE_PATTERNS:
            if re.search(pattern, key_lower):
                return True
        return False
    
    def mask_secret(self, value: str, visible_chars: int = 4) -> str:
        """
        Mask a secret value for safe logging.
        
        Args:
            value: Secret value to mask
            visible_chars: Number of characters to show at start/end
            
        Returns:
            Masked secret string
        """
        if not value:
            return ""
        if len(value) <= visible_chars * 2 + 3:
            return "***"
        return f"{value[:visible_chars]}...{value[-visible_chars:]}"
    
    def get_secret(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """
        Securely retrieve a secret from environment.
        
        Args:
            key: Environment variable name
            default: Default value if not found
            
        Returns:
            Secret value or default
        """
        # Check cache first
        if key in self._secret_cache:
            return self._secret_cache[key]
        
        # Get from environment
        value = os.environ.get(key, default)
        
        # Validate if it's a sensitive key
        if value and self.is_sensitive_key(key):
            result = self.check_secret_strength(key, value)
            self._validation_results[key] = result
            
            if result.strength == SecretStrength.WEAK:
                logger.warning("Weak secret detected for %s: %s", key, ", ".join(result.issues))
        
        return value
    
    def check_secret_strength(self, name: str, value: str) -> SecretValidationResult:
        """
        Check the strength of a secret.
        
        Args:
            name: Secret name (for context)
            value: Secret value to check
            
        Returns:
            Validation result with strength rating
        """
        issues = []
        warnings = []
        
        if not value:
            return SecretValidationResult(
                is_valid=False,
                strength=SecretStrength.WEAK,
                issues=["Secret is empty"],
                warnings=[],
            )
        
        # Check length
        if len(value) < 16:
            issues.append(f"Secret is too short ({len(value)} chars, minimum 16)")
        elif len(value) < 32:
            warnings.append(f"Secret length could be improved ({len(value)} chars, recommended 32+)")
        
        # Check for common weak patterns
        weak_patterns = [
            (r'^[a-z]+$', "Only lowercase letters"),
            (r'^[A-Z]+$', "Only uppercase letters"),
            (r'^[0-9]+$', "Only numbers"),
            (r'^test', "Starts with 'test'"),
            (r'demo$', "Ends with 'demo'"),
            (r'example', "Contains 'example'"),
            (r'password', "Contains 'password'"),
            (r'secret', "Contains 'secret'"),
            (r'123456', "Contains common sequence '123456'"),
            (r'qwerty', "Contains common sequence 'qwerty'"),
        ]
        
        value_lower = value.lower()
        for pattern, description in weak_patterns:
            if re.search(pattern, value_lower):
                issues.append(f"Weak pattern detected: {description}")
        
        # Check entropy (simple heuristic)
        unique_chars = len(set(value))
        if unique_chars < 10:
            issues.append(f"Low character diversity ({unique_chars} unique chars)")
        
        # Determine strength
        if issues:
            strength = SecretStrength.WEAK
        elif warnings:
            strength = SecretStrength.MODERATE
        else:
            strength = SecretStrength.STRONG
        
        return SecretValidationResult(
            is_valid=len(issues) == 0,
            strength=strength,
            issues=issues,
            warnings=warnings,
        )
    
    def validate_required_secrets(self) -> Tuple[bool, List[str]]:
        """
        Validate that all required secrets are present and valid.
        
        Returns:
            Tuple of (all_valid, list_of_missing_or_invalid)
        """
        missing = []
        weak_secrets = []
        
        for secret_name in self.REQUIRED_SECRETS:
            value = os.environ.get(secret_name)
            if not value:
                missing.append(secret_name)
            else:
                result = self.check_secret_strength(secret_name, value)
                if result.strength == SecretStrength.WEAK:
                    weak_secrets.append(f"{secret_name}: {', '.join(result.issues)}")
        
        # Check optional secrets
        for secret_name in self.OPTIONAL_SECRETS:
            value = os.environ.get(secret_name)
            if value:
                result = self.check_secret_strength(secret_name, value)
                if result.strength == SecretStrength.WEAK:
                    weak_secrets.append(f"{secret_name} (optional): {', '.join(result.issues)}")
        
        all_issues = missing + weak_secrets
        
        if missing:
            logger.error("Missing required secrets: %s", ", ".join(missing))
        if weak_secrets:
            logger.warning("Weak secrets detected: %s", "; ".join(weak_secrets))
        
        return len(missing) == 0, all_issues
    
    def check_environment_security(self) -> Dict[str, List[str]]:
        """
        Check environment for security issues.
        
        Returns:
            Dictionary of issue categories and their findings
        """
        issues = {
            "dangerous_vars": [],
            "exposed_in_code": [],
            "file_based_secrets": [],
        }
        
        # Check for secrets in environment that might be file-based
        for key, value in os.environ.items():
            if self.is_sensitive_key(key):
                # Check if value looks like a file path
                if value.startswith('/') or value.startswith('./') or value.startswith('~/'):
                    issues["file_based_secrets"].append(f"{key} appears to be a file path: {value}")
                
                # Check for common hardcoded patterns
                if value in ['test', 'demo', 'example', 'password', 'secret', '123456']:
                    issues["dangerous_vars"].append(f"{key} has a suspicious hardcoded value")
        
        return issues
    
    def rotate_secret(self, key: str) -> bool:
        """
        Mark a secret as needing rotation.
        
        In production, this would integrate with a secrets manager
        like AWS Secrets Manager, HashiCorp Vault, etc.
        
        Args:
            key: Secret name that needs rotation
            
        Returns:
            True if rotation was initiated
        """
        logger.warning("Secret rotation requested for: %s", key)
        # In a real implementation, this would:
        # 1. Generate a new secret
        # 2. Update the secrets manager
        # 3. Update environment or notify admin
        return True
    
    def get_secrets_summary(self, mask: bool = True) -> Dict[str, Dict]:
        """
        Get a summary of all secrets status.
        
        Args:
            mask: Whether to mask secret values
            
        Returns:
            Dictionary with secrets status
        """
        summary = {}
        
        all_secrets = self.REQUIRED_SECRETS + self.OPTIONAL_SECRETS
        
        for secret_name in all_secrets:
            value = os.environ.get(secret_name)
            if value:
                result = self.check_secret_strength(secret_name, value)
                summary[secret_name] = {
                    "present": True,
                    "strength": result.strength.value,
                    "issues": result.issues,
                    "warnings": result.warnings,
                    "value_preview": self.mask_secret(value) if mask else None,
                }
            else:
                is_required = secret_name in self.REQUIRED_SECRETS
                summary[secret_name] = {
                    "present": False,
                    "required": is_required,
                }
        
        return summary


# Global instance
_secrets_manager: Optional[SecureSecretsManager] = None


def get_secrets_manager() -> SecureSecretsManager:
    """Get the global secrets manager instance."""
    global _secrets_manager
    if _secrets_manager is None:
        _secrets_manager = SecureSecretsManager()
    return _secrets_manager


def validate_required_secrets() -> Tuple[bool, List[str]]:
    """Validate all required secrets are present."""
    return get_secrets_manager().validate_required_secrets()


def check_secret_strength(name: str, value: str) -> SecretValidationResult:
    """Check the strength of a secret."""
    return get_secrets_manager().check_secret_strength(name, value)


def rotate_secret(key: str) -> bool:
    """Mark a secret for rotation."""
    return get_secrets_manager().rotate_secret(key)


def mask_secret(value: str, visible_chars: int = 4) -> str:
    """Mask a secret for safe logging."""
    return get_secrets_manager().mask_secret(value, visible_chars)


def check_for_hardcoded_secrets(file_path: str) -> List[Tuple[int, str, str]]:
    """
    Scan a file for potentially hardcoded secrets.
    
    Args:
        file_path: Path to file to scan
        
    Returns:
        List of (line_number, line_content, issue_description) tuples
    """
    findings = []
    
    secret_patterns = [
        (r'["\']?[a-zA-Z_]*(?:api[_-]?key|apikey|secret|token|password)["\']?\s*[=:]\s*["\'][^"\']{8,}["\']', "Potential hardcoded secret"),
        (r'["\']sk-[a-zA-Z0-9]{20,}["\']', "Potential OpenAI API key"),
        (r'["\']AIza[0-9A-Za-z_-]{35,}["\']', "Potential Google API key"),
        (r'["\']gh[pousr]_[A-Za-z0-9_]{36,}["\']', "Potential GitHub token"),
    ]
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line_num, line in enumerate(f, 1):
                for pattern, description in secret_patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        findings.append((line_num, line.strip(), description))
    except Exception as e:
        logger.error("Failed to scan file %s: %s", file_path, e)
    
    return findings
