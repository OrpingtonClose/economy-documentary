"""
Secure wrappers for tool functions.

Provides:
- Path validation for all file operations
- Command argument sanitization
- Input validation decorators
- Secure subprocess execution
"""

from __future__ import annotations

import os
import subprocess
import logging
from pathlib import Path
from functools import wraps
from typing import Callable, List, Optional, Union, Any
from dataclasses import dataclass

from server.security.validation import (
    sanitize_filename,
    validate_path_within_base,
    sanitize_command_arg,
    ValidationError,
)

logger = logging.getLogger(__name__)


@dataclass
class SecureSubprocessResult:
    """Result of a secure subprocess execution."""
    returncode: int
    stdout: str
    stderr: str
    success: bool
    error_message: Optional[str] = None


class SecureToolWrapper:
    """
    Wrapper class that adds security to tool functions.
    
    Usage:
        @secure_tool(base_dir="/tmp/documentary-pipeline")
        def my_tool(output_path: str, ...):
            ...
    """
    
    def __init__(
        self,
        base_dir: Optional[Union[str, Path]] = None,
        validate_paths: bool = True,
        max_path_length: int = 4096,
        allowed_extensions: Optional[List[str]] = None,
    ):
        self.base_dir = Path(base_dir) if base_dir else None
        self.validate_paths = validate_paths
        self.max_path_length = max_path_length
        self.allowed_extensions = allowed_extensions or []
    
    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Validate paths in arguments
            if self.validate_paths and self.base_dir:
                for arg_name, arg_value in kwargs.items():
                    if isinstance(arg_value, str) and (
                        "path" in arg_name.lower() or 
                        "file" in arg_name.lower() or
                        "dir" in arg_name.lower()
                    ):
                        try:
                            validated_path = self._validate_path(arg_value)
                            kwargs[arg_name] = str(validated_path)
                        except ValidationError as e:
                            logger.error("Path validation failed for %s: %s", arg_name, e)
                            raise
            
            return func(*args, **kwargs)
        
        return wrapper
    
    def _validate_path(self, path: str) -> Path:
        """Validate a path is within the base directory."""
        if not self.base_dir:
            return Path(path)
        
        # Check path length
        if len(path) > self.max_path_length:
            raise ValidationError(f"Path exceeds maximum length of {self.max_path_length}")
        
        # Validate path is within base
        validated = validate_path_within_base(path, self.base_dir)
        
        # Check extension if specified
        if self.allowed_extensions:
            ext = Path(path).suffix.lower()
            if ext and ext not in self.allowed_extensions:
                raise ValidationError(
                    f"File extension '{ext}' not allowed. Allowed: {self.allowed_extensions}"
                )
        
        return validated


def secure_tool(
    base_dir: Optional[Union[str, Path]] = None,
    validate_paths: bool = True,
    allowed_extensions: Optional[List[str]] = None,
):
    """
    Decorator to add security validation to tool functions.
    
    Args:
        base_dir: Base directory for path validation
        validate_paths: Whether to validate paths
        allowed_extensions: List of allowed file extensions
        
    Usage:
        @secure_tool(base_dir="/tmp/documentary-pipeline")
        def generate_video(output_path: str, ...):
            ...
    """
    wrapper = SecureToolWrapper(
        base_dir=base_dir,
        validate_paths=validate_paths,
        allowed_extensions=allowed_extensions,
    )
    return wrapper


def validate_file_path(
    path: str,
    base_dir: Optional[Union[str, Path]] = None,
    must_exist: bool = False,
    allowed_extensions: Optional[List[str]] = None,
) -> Path:
    """
    Validate a file path for security.
    
    Args:
        path: Path to validate
        base_dir: Base directory that path must be within
        must_exist: Whether the file must already exist
        allowed_extensions: List of allowed file extensions
        
    Returns:
        Validated Path object
        
    Raises:
        ValidationError: If path is invalid
    """
    # Sanitize the path
    path = os.path.expanduser(os.path.expandvars(path))
    
    # Check for null bytes
    if '\x00' in path:
        raise ValidationError("Path contains null bytes")
    
    # Convert to Path object
    path_obj = Path(path)
    
    # Validate against base directory
    if base_dir:
        path_obj = validate_path_within_base(path, base_dir)
    
    # Check if file must exist
    if must_exist and not path_obj.exists():
        raise ValidationError(f"File does not exist: {path}")
    
    # Check extension
    if allowed_extensions:
        ext = path_obj.suffix.lower()
        if ext and ext not in allowed_extensions:
            raise ValidationError(
                f"File extension '{ext}' not allowed. Allowed: {allowed_extensions}"
            )
    
    return path_obj


def secure_subprocess_run(
    cmd: List[str],
    *,
    timeout: int = 60,
    capture_output: bool = True,
    text: bool = True,
    check: bool = False,
    cwd: Optional[Union[str, Path]] = None,
    env: Optional[dict] = None,
    sanitize_args: bool = True,
) -> SecureSubprocessResult:
    """
    Run a subprocess with security validations.
    
    Args:
        cmd: Command and arguments as list
        timeout: Maximum execution time in seconds
        capture_output: Whether to capture stdout/stderr
        text: Whether to return text instead of bytes
        check: Whether to raise on non-zero exit
        cwd: Working directory for the subprocess
        env: Environment variables for the subprocess
        sanitize_args: Whether to sanitize command arguments
        
    Returns:
        SecureSubprocessResult with execution results
    """
    if not cmd:
        return SecureSubprocessResult(
            returncode=-1,
            stdout="",
            stderr="No command provided",
            success=False,
            error_message="Empty command list",
        )
    
    # Sanitize command arguments
    if sanitize_args:
        sanitized_cmd = []
        for i, arg in enumerate(cmd):
            if i == 0:
                # First argument is the command - validate it's a known safe command
                sanitized_cmd.append(arg)
            else:
                try:
                    sanitized_cmd.append(sanitize_command_arg(arg))
                except ValidationError as e:
                    return SecureSubprocessResult(
                        returncode=-1,
                        stdout="",
                        stderr=f"Command argument validation failed: {e}",
                        success=False,
                        error_message=str(e),
                    )
        cmd = sanitized_cmd
    
    # Validate timeout
    if timeout <= 0 or timeout > 3600:
        timeout = 60  # Default to 60 seconds
    
    # Validate working directory
    if cwd:
        cwd = str(cwd)
        if not os.path.isdir(cwd):
            return SecureSubprocessResult(
                returncode=-1,
                stdout="",
                stderr=f"Working directory does not exist: {cwd}",
                success=False,
                error_message="Invalid working directory",
            )
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=capture_output,
            text=text,
            timeout=timeout,
            cwd=cwd,
            env=env,
            check=False,  # We handle this ourselves
        )
        
        return SecureSubprocessResult(
            returncode=result.returncode,
            stdout=result.stdout if result.stdout else "",
            stderr=result.stderr if result.stderr else "",
            success=result.returncode == 0,
        )
        
    except subprocess.TimeoutExpired:
        logger.error("Subprocess timed out after %d seconds: %s", timeout, cmd[0])
        return SecureSubprocessResult(
            returncode=-1,
            stdout="",
            stderr=f"Command timed out after {timeout} seconds",
            success=False,
            error_message="Timeout",
        )
    except FileNotFoundError:
        logger.error("Command not found: %s", cmd[0])
        return SecureSubprocessResult(
            returncode=-1,
            stdout="",
            stderr=f"Command not found: {cmd[0]}",
            success=False,
            error_message="Command not found",
        )
    except Exception as e:
        logger.exception("Subprocess execution failed: %s", e)
        return SecureSubprocessResult(
            returncode=-1,
            stdout="",
            stderr=str(e),
            success=False,
            error_message=str(e),
        )


def safe_ffmpeg_command(
    input_paths: List[str],
    output_path: str,
    options: List[str],
    base_dir: Optional[Union[str, Path]] = None,
    timeout: int = 120,
) -> SecureSubprocessResult:
    """
    Build and execute a safe ffmpeg command.
    
    Args:
        input_paths: List of input file paths
        output_path: Output file path
        options: ffmpeg options (e.g., ["-c:v", "libx264"])
        base_dir: Base directory for path validation
        timeout: Command timeout in seconds
        
    Returns:
        SecureSubprocessResult
    """
    # Validate all paths
    validated_inputs = []
    for path in input_paths:
        try:
            validated = validate_file_path(
                path,
                base_dir=base_dir,
                must_exist=True,
                allowed_extensions=[".mp4", ".wav", ".avi", ".mov", ".mkv", ".webm"],
            )
            validated_inputs.append(str(validated))
        except ValidationError as e:
            return SecureSubprocessResult(
                returncode=-1,
                stdout="",
                stderr=f"Input path validation failed: {e}",
                success=False,
            )
    
    try:
        output_validated = validate_file_path(
            output_path,
            base_dir=base_dir,
            must_exist=False,
            allowed_extensions=[".mp4", ".wav", ".avi", ".mov", ".mkv", ".webm"],
        )
        output_path = str(output_validated)
    except ValidationError as e:
        return SecureSubprocessResult(
            returncode=-1,
            stdout="",
            stderr=f"Output path validation failed: {e}",
            success=False,
        )
    
    # Build command
    cmd = ["ffmpeg", "-y"]  # -y to overwrite output
    
    # Add inputs
    for input_path in validated_inputs:
        cmd.extend(["-i", input_path])
    
    # Add options
    cmd.extend(options)
    
    # Add output
    cmd.append(output_path)
    
    # Execute
    return secure_subprocess_run(cmd, timeout=timeout)


def safe_ffprobe(
    media_path: str,
    base_dir: Optional[Union[str, Path]] = None,
    timeout: int = 30,
) -> SecureSubprocessResult:
    """
    Run ffprobe on a media file safely.
    
    Args:
        media_path: Path to media file
        base_dir: Base directory for path validation
        timeout: Command timeout in seconds
        
    Returns:
        SecureSubprocessResult with JSON output
    """
    try:
        validated = validate_file_path(
            media_path,
            base_dir=base_dir,
            must_exist=True,
            allowed_extensions=[".mp4", ".wav", ".avi", ".mov", ".mkv", ".webm"],
        )
    except ValidationError as e:
        return SecureSubprocessResult(
            returncode=-1,
            stdout="",
            stderr=f"Path validation failed: {e}",
            success=False,
        )
    
    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        str(validated),
    ]
    
    return secure_subprocess_run(cmd, timeout=timeout)


# Pre-configured wrappers for common base directories
video_tool = secure_tool(
    base_dir=os.environ.get("VIDEO_OUTPUT_DIR", "/tmp/documentary-pipeline/video"),
    allowed_extensions=[".mp4", ".avi", ".mov", ".mkv", ".webm"],
)

audio_tool = secure_tool(
    base_dir=os.environ.get("TTS_OUTPUT_DIR", "/tmp/documentary-pipeline/audio"),
    allowed_extensions=[".wav", ".mp3", ".flac", ".ogg"],
)

timeline_tool = secure_tool(
    base_dir=os.environ.get("TIMELINE_DIR", "/tmp/documentary-pipeline/timelines"),
    allowed_extensions=[".otio", ".json"],
)

data_tool = secure_tool(
    base_dir=os.environ.get("DATA_DIR", "/tmp/documentary-pipeline"),
)
