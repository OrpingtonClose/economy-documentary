# CI/CD Setup Documentation

## Overview

This document describes the comprehensive CI/CD automation setup for the Economy Documentary project.

## 📁 Files Created

### GitHub Actions Workflows

| File | Purpose |
|------|---------|
| `.github/workflows/ci.yml` | Main CI pipeline - tests, linting, type checking |
| `.github/workflows/security-scan.yml` | Security scanning - bandit, safety, CodeQL |
| `.github/workflows/docker-build.yml` | Docker image building and pushing |

### Configuration Files

| File | Purpose |
|------|---------|
| `.pre-commit-config.yaml` | Pre-commit hooks for code quality |
| `.github/dependabot.yml` | Automated dependency updates |
| `.github/PULL_REQUEST_TEMPLATE.md` | PR template for consistent contributions |
| `Makefile` | Common development tasks |

### Project Configuration

| File | Purpose |
|------|---------|
| `server/pyproject.toml` | Python project config with dev dependencies |
| `frontend/package.json` | Frontend dependencies and scripts |
| `frontend/eslint.config.mjs` | ESLint configuration |
| `frontend/.prettierrc` | Prettier formatting config |

### Docker Configuration

| File | Purpose |
|------|---------|
| `server/Dockerfile` | Multi-stage backend Docker image |
| `frontend/Dockerfile` | Multi-stage frontend Docker image |
| `docker-compose.yml` | Local development environment |

## 🔄 CI/CD Pipeline Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        Pull Request                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    GitHub Actions Triggered                      │
└─────────────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│   CI Workflow   │ │Security Workflow│ │ Docker Workflow │
└─────────────────┘ └─────────────────┘ └─────────────────┘
          │                   │                   │
    ┌─────┴─────┐       ┌─────┴─────┐       ┌─────┴─────┐
    ▼           ▼       ▼           ▼       ▼           ▼
┌───────┐  ┌───────┐ ┌───────┐  ┌───────┐ ┌───────┐  ┌───────┐
│ Python│  │Python │ │Bandit │  │Safety │ │Backend│  │Frontend│
│ Lint  │  │Test   │ │Scan   │  │Scan   │ │Image  │  │Image   │
└───────┘  └───────┘ └───────┘  └───────┘ └───────┘  └───────┘
    │           │       │           │       │           │
┌───────┐  ┌───────┐ ┌───────┐  ┌───────┐ └───────┘  └───────┘
│Python │  │Python │ │CodeQL │  │Secret │       │           │
│Type   │  │Frontend│ │Analysis│  │Scan   │       ▼           ▼
│Check  │  │Checks  │ │       │  │       │  ┌───────────────┐
└───────┘  └───────┘ └───────┘  └───────┘  │ Trivy Scan    │
                                            └───────────────┘
```

## 🚀 Workflows Detail

### 1. CI Workflow (`ci.yml`)

**Triggers:** Push to main/develop, Pull Requests

**Jobs:**
- **python-lint**: Ruff linting and formatting checks
- **python-typecheck**: MyPy type checking
- **python-test**: Pytest with coverage reporting
- **frontend-lint**: ESLint checks
- **frontend-typecheck**: TypeScript type checking
- **frontend-build**: Next.js build verification
- **ci-summary**: Aggregates all job results

**Features:**
- Parallel job execution for fast feedback
- Poetry virtual environment caching
- Codecov integration for coverage reports
- Automatic cancellation of stale runs

### 2. Security Scan Workflow (`security-scan.yml`)

**Triggers:** Push, PRs, Daily schedule (2 AM UTC)

**Jobs:**
- **bandit-scan**: Python security vulnerability scanning
- **safety-scan**: Dependency vulnerability checking
- **pip-audit**: PyPA security audit
- **secret-scan**: GitLeaks and TruffleHog secret detection
- **dependency-review**: PR dependency review
- **codeql-analysis**: GitHub CodeQL static analysis

**Features:**
- Multiple security scanners for comprehensive coverage
- Artifact upload for security reports
- Scheduled daily scans
- GitHub Security tab integration

### 3. Docker Build Workflow (`docker-build.yml`)

**Triggers:** Push to main, Tags, PRs (path-filtered)

**Jobs:**
- **build-backend**: Build and push backend Docker image
- **build-frontend**: Build and push frontend Docker image
- **build-test**: Test Docker builds on PRs
- **docker-summary**: Build status aggregation

**Features:**
- Multi-platform builds (amd64, arm64)
- GitHub Container Registry (ghcr.io)
- Trivy vulnerability scanning
- Build caching with GitHub Actions cache
- Semantic versioning support

## 🛠️ Pre-commit Hooks

### Installed Hooks

| Hook | Purpose |
|------|---------|
| `trailing-whitespace` | Remove trailing whitespace |
| `end-of-file-fixer` | Ensure files end with newline |
| `check-yaml` | Validate YAML syntax |
| `check-json` | Validate JSON syntax |
| `check-added-large-files` | Prevent large file commits |
| `ruff-lint` | Python linting |
| `ruff-format` | Python formatting |
| `mypy-typecheck` | Python type checking |
| `bandit-security` | Security scanning |
| `isort-imports` | Import sorting |
| `eslint-frontend` | JavaScript/TypeScript linting |
| `prettier-frontend` | Frontend formatting |
| `hadolint-docker` | Dockerfile linting |
| `conventional-commit` | Commit message validation |
| `detect-secrets` | Secret detection |
| `codespell-check` | Spell checking |

### Usage

```bash
# Install pre-commit hooks
make install-dev

# Run on all files
make precommit

# Run specific hook
pre-commit run ruff-lint --all-files

# Update hooks
make precommit-update
```

## 📦 Makefile Commands

### Installation
```bash
make install          # Install all dependencies
make install-server   # Install Python dependencies
make install-frontend # Install frontend dependencies
make install-dev      # Install development dependencies
```

### Code Quality
```bash
make lint             # Run all linters
make lint-server      # Run Python linters
make lint-frontend    # Run frontend linters
make format           # Format all code
make format-server    # Format Python code
make format-frontend  # Format frontend code
make typecheck        # Run all type checkers
make typecheck-server # Run Python type checking
```

### Testing
```bash
make test             # Run all tests
make test-server      # Run Python tests
make test-server-watch # Run Python tests in watch mode
make test-frontend    # Run frontend tests
```

### Security
```bash
make security         # Run all security scans
make security-server  # Run Python security scans
make secrets-scan     # Scan for secrets
```

### Docker
```bash
make docker-build          # Build all Docker images
make docker-build-backend  # Build backend Docker image
make docker-build-frontend # Build frontend Docker image
make docker-run            # Run Docker containers
make docker-stop           # Stop Docker containers
make docker-clean          # Clean Docker resources
```

### Development
```bash
make dev-server       # Start development server
make dev-frontend     # Start development frontend
make dev              # Start all development servers
```

### CI/CD
```bash
make ci               # Run all CI checks locally
make clean            # Clean generated files
make clean-all        # Deep clean everything
```

## 🔧 Python Project Configuration

### Development Dependencies

```toml
[tool.poetry.group.dev.dependencies]
pytest = "^8.0.0"
pytest-asyncio = "^0.23.0"
pytest-cov = "^5.0.0"
pytest-mock = "^3.14.0"
pytest-xdist = "^3.6.0"
httpx = "^0.27.0"
ruff = "^0.8.0"
mypy = "^1.13.0"
isort = "^5.13.0"
bandit = {extras = ["toml"], version = "^1.8.0"}
safety = "^3.0.0"
pip-audit = "^2.7.0"
```

### Ruff Configuration
- Target: Python 3.12+
- Line length: 100
- Enabled: Flake8, isort, pydocstyle, pyupgrade, bandit, pylint rules
- Disabled: Some docstring and annotation rules (enable gradually)

### MyPy Configuration
- Strict mode with gradual adoption
- Missing imports ignored (for third-party libs)
- Error codes displayed

## 📝 Pull Request Template

The PR template includes:
- Description section
- Type of change checklist
- Changes made list
- Testing checklist
- Code quality checklist
- Documentation checklist
- Security considerations
- Performance impact

## 🔄 Dependabot Configuration

### Update Schedules

| Ecosystem | Schedule | Open PRs |
|-----------|----------|----------|
| pip (Poetry) | Weekly (Monday 9 AM UTC) | 10 |
| npm | Weekly (Monday 9 AM UTC) | 10 |
| GitHub Actions | Weekly (Monday 9 AM UTC) | 10 |
| Docker | Weekly (Monday 9 AM UTC) | 5 |

### Grouping
- Production dependencies (minor/patch)
- Development dependencies (minor/patch)
- GitHub Actions (all)

### Ignored Updates
- FastAPI major versions
- Pydantic major versions
- Next.js major versions
- React major versions

## 🐳 Docker Configuration

### Backend Dockerfile

**Stages:**
1. **Builder**: Install dependencies with Poetry
2. **Production**: Minimal runtime image
3. **Development**: Full dev environment with auto-reload

**Features:**
- Multi-stage build for optimization
- Non-root user for security
- Health checks
- Multi-platform support

### Frontend Dockerfile

**Stages:**
1. **Deps**: Install npm dependencies
2. **Builder**: Build Next.js application
3. **Production**: Serve static files
4. **Development**: Dev server with hot reload

**Features:**
- Standalone output for production
- Non-root user
- Health checks
- Multi-platform support

### Docker Compose

**Services:**
- `backend`: FastAPI development server
- `frontend`: Next.js development server
- `redis`: Cache (optional)
- `postgres`: Database (optional)

## 🔐 Security Features

### Code Security
- Bandit: Python security linter
- Safety: Dependency vulnerability scanner
- pip-audit: PyPA security audit
- CodeQL: GitHub static analysis

### Secret Detection
- GitLeaks: Git history scanning
- TruffleHog: Deep secret detection
- detect-secrets: Pre-commit hook
- detect-private-key: Pre-commit hook

### Container Security
- Trivy: Container vulnerability scanner
- Hadolint: Dockerfile linter
- Non-root users in containers
- Minimal base images

## 📊 Coverage Reporting

### Codecov Integration
- Automatic coverage upload
- PR coverage comments
- Coverage badges
- Historical tracking

### Coverage Configuration
- Python: pytest-cov
- Frontend: jest coverage
- Minimum threshold: Configurable

## 🚀 Deployment

### GitHub Container Registry
- Images pushed on main branch
- Semantic versioning support
- Multi-platform images
- Vulnerability scanning

### Image Tags
- `latest`: Latest main branch build
- `v{version}`: Semantic version tags
- `sha-{short}`: Git SHA for traceability
- `pr-{number}`: Pull request builds

## 📋 Setup Instructions

### Initial Setup

```bash
# Clone repository
git clone https://github.com/OrpingtonClose/economy-documentary.git
cd economy-documentary

# Install dependencies
make install-dev

# Setup pre-commit hooks
pre-commit install

# Copy environment files
cp server/.env.example server/.env
cp frontend/.env.local.example frontend/.env.local

# Start development servers
make dev
```

### Docker Setup

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

## 🔍 Troubleshooting

### Common Issues

**Pre-commit hooks failing:**
```bash
pre-commit clean
pre-commit install --force
```

**Poetry lock file out of sync:**
```bash
cd server && poetry lock --no-update
```

**Docker build cache issues:**
```bash
docker-compose build --no-cache
```

**Node modules issues:**
```bash
cd frontend && rm -rf node_modules && npm ci
```

## 📚 Additional Resources

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Pre-commit Documentation](https://pre-commit.com/)
- [Poetry Documentation](https://python-poetry.org/docs/)
- [Ruff Documentation](https://docs.astral.sh/ruff/)
- [MyPy Documentation](https://mypy.readthedocs.io/)
