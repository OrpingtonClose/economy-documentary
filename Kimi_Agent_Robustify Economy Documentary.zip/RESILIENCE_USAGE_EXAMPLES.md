# Resilience Module Usage Examples

## Basic Usage

### 1. Import the Resilience Module

```python
from server.resilience import (
    with_retry, circuit_breaker, graceful_degradation,
    timeout, resilient_context, managed_resource,
    VastAIError, GPUWorkerError, TimeoutError,
    retry_with_backoff, safe_execute,
    health_checker,
)
```

### 2. Retry with Exponential Backoff

```python
from server.resilience import with_retry

@with_retry(
    max_attempts=3,
    min_wait=1.0,
    max_wait=60.0,
    exceptions=(ConnectionError, TimeoutError),
)
def call_external_api(url: str) -> dict:
    """Call external API with automatic retry on failure."""
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    return response.json()
```

### 3. Circuit Breaker Pattern

```python
from server.resilience import circuit_breaker

@circuit_breaker(
    name="vastai_api",
    failure_threshold=5,
    recovery_timeout=120.0,
)
def provision_gpu_vm(spec: WorkerSpec) -> str:
    """Provision GPU VM with circuit breaker protection.
    
    After 5 failures, circuit opens and calls fail fast
    for 2 minutes before trying again.
    """
    return _vast_cmd(["create", "instance", ...])
```

### 4. Graceful Degradation

```python
from server.resilience import graceful_degradation

def generate_silent_audio(*args, **kwargs):
    """Fallback: generate silent audio."""
    return {"status": "fallback", "audio": silence}

@graceful_degradation(
    fallback=generate_silent_audio,
    exceptions=(GPUWorkerError,),
)
def generate_tts(text: str) -> dict:
    """Generate TTS with fallback to silent audio on failure."""
    return call_tts_worker(text)
```

### 5. Timeout Handling

```python
from server.resilience import timeout

@timeout(seconds=300, operation_name="TTS generation")
def generate_narration(text: str) -> str:
    """Generate narration with 5-minute timeout."""
    return call_tts_worker(text)
```

### 6. Combined Resilience

```python
from server.resilience import resilient

@resilient(
    max_retries=3,
    retry_exceptions=(ConnectionError,),
    circuit_breaker_name="api_service",
    circuit_failure_threshold=5,
    fallback=default_response,
    timeout_seconds=60,
)
def call_api_service(data: dict) -> dict:
    """Call API with retry, circuit breaker, fallback, and timeout."""
    return requests.post(API_URL, json=data).json()
```

### 7. Resource Cleanup

```python
from server.resilience import resilient_context

def cleanup_resources():
    """Cleanup function called on exit."""
    release_locks()
    close_connections()

with resilient_context(
    cleanup_callback=cleanup_resources,
    error_callback=log_error,
):
    do_work_that_might_fail()
```

### 8. Managed Resource Lifecycle

```python
from server.resilience import managed_resource

def acquire_db():
    return create_database_connection()

def release_db(conn):
    conn.close()

with managed_resource(acquire_db, release_db) as db:
    db.query("SELECT * FROM table")
```

### 9. Health Checking

```python
from server.resilience import health_checker

def check_my_service() -> dict:
    """Check service health."""
    try:
        response = requests.get(HEALTH_URL, timeout=5)
        return {
            "status": "healthy" if response.status_code == 200 else "unhealthy",
            "response_time_ms": response.elapsed.total_seconds() * 1000,
        }
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}

# Register health check
health_checker.register("my_service", check_my_service)

# Check all services
all_health = health_checker.check()

# Check specific service
my_health = health_checker.check("my_service")
```

### 10. Safe Execution

```python
from server.resilience import safe_execute

# Execute function, return default on failure
result = safe_execute(
    risky_function,
    arg1, arg2,
    default={"status": "failed"},
    log_errors=True,
)
```

### 11. Manual Retry

```python
from server.resilience import retry_with_backoff

def call_api():
    return requests.get(API_URL).json()

result = retry_with_backoff(
    call_api,
    max_attempts=5,
    min_wait=2.0,
    max_wait=30.0,
    exceptions=(ConnectionError,),
)
```

## Advanced Patterns

### Custom Exception Handling

```python
from server.resilience import DocumentaryError

class MyServiceError(DocumentaryError):
    def __init__(self, message: str, service_id: str = ""):
        super().__init__(message, error_code="MY_SERVICE_ERROR")
        self.service_id = service_id

# Use in your code
raise MyServiceError("Service failed", service_id="svc-123")
```

### Circuit Breaker Inspection

```python
from server.resilience import CircuitBreaker

# Get circuit breaker instance
breaker = CircuitBreaker("vastai_api")

# Check state
print(breaker.state)  # CircuitState.CLOSED, OPEN, or HALF_OPEN

# Check stats
stats = breaker.stats
print(f"Failures: {stats.failures}")
print(f"Successes: {stats.successes}")

# Manual control
breaker.force_open("maintenance")
breaker.force_close("service restored")
```

### Degradation Tracking

```python
from server.resilience import graceful_degradation

@graceful_degradation(
    fallback=fallback_function,
    track_degradation=True,
)
def main_function():
    ...

# Check degradation stats
stats = main_function._degradation_stats()
print(f"Degradation count: {stats.get('count', 0)}")
```

## Integration with FastAPI

```python
from fastapi import FastAPI, HTTPException
from server.resilience import health_checker, VastAIError

app = FastAPI()

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    results = health_checker.check()
    
    # Check if any critical services are unhealthy
    unhealthy = [k for k, v in results.items() if v.get("status") != "healthy"]
    
    if unhealthy:
        raise HTTPException(
            status_code=503,
            detail={"status": "unhealthy", "services": unhealthy},
        )
    
    return {"status": "healthy", "services": results}

@app.exception_handler(VastAIError)
async def vastai_error_handler(request, exc):
    """Handle VastAI errors."""
    return JSONResponse(
        status_code=503,
        content={
            "error": str(exc),
            "error_code": exc.error_code,
            "trace_id": exc.trace_id,
        },
    )
```

## Testing Resilience

```python
import pytest
from unittest.mock import patch, MagicMock
from server.resilience import CircuitBreaker, CircuitState

def test_circuit_breaker_opens_after_failures():
    """Test circuit breaker opens after threshold failures."""
    breaker = CircuitBreaker("test", failure_threshold=3)
    
    @breaker
    def failing_func():
        raise ValueError("Always fails")
    
    # First 3 calls should raise ValueError
    for _ in range(3):
        with pytest.raises(ValueError):
            failing_func()
    
    # 4th call should raise CircuitBreakerOpenError
    with pytest.raises(CircuitBreakerOpenError):
        failing_func()
    
    assert breaker.state == CircuitState.OPEN

def test_retry_with_backoff():
    """Test retry with exponential backoff."""
    call_count = 0
    
    @with_retry(max_attempts=3, min_wait=0.1, max_wait=1.0)
    def eventually_succeeds():
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise ConnectionError("Transient error")
        return "success"
    
    result = eventually_succeeds()
    assert result == "success"
    assert call_count == 3
```
