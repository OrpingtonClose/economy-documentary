# Documentary Pipeline Observability Implementation

## Overview

This document summarizes the comprehensive observability and monitoring implementation for the economy-documentary project. The implementation adds structured logging, health checks, metrics, distributed tracing, and log aggregation to the existing FastAPI + Google ADK pipeline.

## Files Created

### 1. Observability Module (`/observability/`)

#### `__init__.py`
Main module exports for the observability package.

#### `logging_config.py`
Structured logging configuration using `structlog` with:
- **Correlation ID propagation** across async boundaries via context variables
- **JSON-formatted logs** for production environments
- **Console-formatted logs** for development
- **Context-aware logging** with bound fields
- **Integration** with standard library logging

Key features:
```python
# Set correlation ID for a request
correlation_id = set_correlation_id()

# Use context manager for additional fields
with LogContext(pipeline_id="abc", stage="scenario"):
    logger.info("Processing started")  # Includes pipeline_id and stage

# Pipeline-specific helpers
start_pipeline_logging(run_id, topic)
end_pipeline_logging()
```

#### `metrics.py`
Prometheus-style metrics collection with custom metric types:

**Metrics Defined:**
| Metric | Type | Description |
|--------|------|-------------|
| `documentary_pipeline_stage_duration_seconds` | Histogram | Duration of pipeline stages |
| `documentary_api_call_latency_seconds` | Histogram | API call latency |
| `documentary_errors_total` | Counter | Total number of errors |
| `documentary_vm_provisioning_duration_seconds` | Histogram | VM provisioning time |
| `documentary_llm_tokens_total` | Counter | LLM token usage |
| `documentary_tool_calls_total` | Counter | Tool call count |
| `documentary_worker_health` | Gauge | Worker health status (1=healthy) |
| `documentary_active_pipelines` | Gauge | Active pipeline count |
| `documentary_pipeline_runs_total` | Counter | Pipeline run count |
| `documentary_approval_wait_seconds` | Histogram | Human approval wait time |
| `documentary_documents_generated_total` | Counter | Document generation count |

**Decorators for easy instrumentation:**
```python
@timed(PIPELINE_STAGE_DURATION, stage="scenario")
def process_scenario():
    pass

@counted(TOOL_CALL_COUNTER, tool="tts_generate")
def generate_tts():
    pass

with timed_context(PIPELINE_STAGE_DURATION, stage="scenario"):
    process_scenario()
```

#### `tracing.py`
OpenTelemetry distributed tracing with:
- **Automatic span creation** for pipeline stages
- **Context propagation** across async boundaries
- **Integration** with external trace collectors (Jaeger, OTLP, SQLite)
- **Custom span attributes** for pipeline context

Key features:
```python
# Setup tracing
setup_tracing(service_name="documentary-pipeline", exporter_type="otlp")

# Trace functions
@traced(span_name="process_scenario", attributes={"stage": "scenario"})
def process_scenario():
    pass

# Context managers for tracing
with trace_pipeline_stage("scenario", run_id="abc"):
    process_scenario()

with trace_tool_call("tts_generate", agent="audio_agent"):
    generate_tts()

with trace_vm_operation("provision", role="tts"):
    provision_vm()
```

#### `health.py`
Comprehensive health check system with:
- **Liveness probe** (`/health/live`) - Is the process running?
- **Readiness probe** (`/health/ready`) - Is the service ready?
- **Full health check** (`/health`) - Complete system status
- **Custom health checkers** for components

Pre-built checkers:
- `check_environment_variables()` - Verify required env vars
- `check_api_key()` - Verify API key configuration
- `check_worker_health()` - Check worker health via HTTP
- `check_database_connection()` - Check database connectivity
- `check_disk_space()` - Check available disk space

#### `middleware.py`
FastAPI middleware for observability:
- **CorrelationIdMiddleware** - Extract/generate and propagate correlation IDs
- **MetricsMiddleware** - Collect request/response metrics
- **TracingMiddleware** - Create spans for HTTP requests
- **LoggingMiddleware** - Log request/response details
- **ObservabilityMiddleware** - Combined middleware (recommended)

### 2. Enhanced Server (`server_enhanced.py`)

Enhanced FastAPI server with integrated observability:

**New Endpoints:**
| Endpoint | Description |
|----------|-------------|
| `GET /health` | Comprehensive health check with all components |
| `GET /health/live` | Liveness probe (Kubernetes) |
| `GET /health/ready` | Readiness probe (Kubernetes) |
| `GET /health/legacy` | Backward-compatible health endpoint |
| `GET /metrics` | Prometheus metrics in text format |
| `GET /observability/info` | Observability configuration info |
| `GET /observability/pipeline/stats` | Pipeline statistics |
| `GET /observability/workers/status` | Worker health status |

**Health Check Components:**
- Environment variables (ADK_MODEL, API keys)
- Google API key
- Vast.ai API key
- Disk space
- Database connectivity

### 3. Enhanced Worker Provisioner (`worker_provisioner_enhanced.py`)

Enhanced VM provisioning with observability:
- **Metrics collection** for VM provisioning time
- **Distributed tracing** for VM operations
- **Structured logging** with correlation IDs
- **Health status reporting** to metrics

### 4. Log Aggregation Configuration (`/logging/`)

#### `fluentd.conf`
Fluentd configuration for log aggregation supporting:
- File-based log collection
- Journald integration
- Elasticsearch output
- Loki output (optional)
- CloudWatch output (optional)

#### `logrotate.conf`
Logrotate configuration with:
- Daily rotation for application logs (14 days retention)
- Daily rotation for error logs (30 days retention)
- Weekly rotation for audit logs (52 weeks retention)
- Compression and delaycompress
- Pre/post rotation scripts

### 5. Observability Stack (`docker-compose.observability.yml`)

Complete observability stack with Docker Compose:

| Service | Port | Description |
|---------|------|-------------|
| Prometheus | 9090 | Metrics collection and alerting |
| Grafana | 3000 | Metrics and logs visualization |
| Loki | 3100 | Log aggregation |
| Promtail | 9080 | Log collection |
| Jaeger | 16686 | Distributed tracing UI |
| Alertmanager | 9093 | Alert routing |
| Node Exporter | 9100 | Host metrics |
| Cadvisor | 8080 | Container metrics |

### 6. Prometheus Configuration (`/observability/prometheus/`)

#### `prometheus.yml`
Scrape configuration for:
- Prometheus self-monitoring
- Documentary Pipeline API
- Node Exporter
- Cadvisor
- GPU Workers (TTS and Video)

#### `alerts.yml`
Alerting rules for:
- **Pipeline Health**: High error rate, slow stages, run failures
- **Worker Health**: Unhealthy workers, slow provisioning, failures
- **API Health**: High latency, API errors
- **Resource Alerts**: Memory, disk, CPU usage
- **LLM Usage**: High token usage, usage spikes

### 7. Loki Configuration (`/observability/loki/`)

#### `loki.yml`
Log aggregation configuration with:
- Filesystem storage
- 30-day retention
- Query caching
- Compaction settings

### 8. Promtail Configuration (`/observability/promtail/`)

#### `promtail.yml`
Log collection configuration for:
- Documentary Pipeline application logs (JSON parsing)
- Docker container logs
- System logs (syslog)
- Journald logs

### 9. Alertmanager Configuration (`/observability/alertmanager/`)

#### `alertmanager.yml`
Alert routing configuration with:
- Slack notifications for warnings
- PagerDuty for critical alerts
- Email notifications
- Webhook integrations
- Inhibition rules

### 10. Grafana Dashboard (`/observability/grafana/dashboards/`)

#### `documentary-pipeline.json`
Complete Grafana dashboard with:
- **Overview Panel**: Worker health, active pipelines, error rate
- **Pipeline Performance**: Stage duration, VM provisioning time
- **API Performance**: API latency, tool call rate
- **Logs Panel**: Integrated Loki logs with filtering

### 11. Requirements (`requirements-observability.txt`)

Dependencies for observability:
- structlog (structured logging)
- opentelemetry-* (distributed tracing)
- prometheus-client (metrics)
- psutil (system metrics)
- aiohttp (async health checks)

## Integration Guide

### 1. Install Dependencies

```bash
pip install -r requirements-observability.txt
```

### 2. Copy Observability Module

```bash
cp -r /mnt/okcomputer/output/observability ./server/
```

### 3. Update server.py

Replace the existing `server.py` with the enhanced version:

```bash
cp /mnt/okcomputer/output/server_enhanced.py ./server/server.py
```

Or manually integrate by:
1. Importing the observability module
2. Adding the middleware
3. Adding the health check endpoints
4. Adding the metrics endpoint

### 4. Update worker_provisioner.py

Replace or enhance with observability:

```bash
cp /mnt/okcomputer/output/worker_provisioner_enhanced.py ./server/worker_provisioner.py
```

### 5. Configure Environment Variables

```bash
# Logging
export LOG_LEVEL=INFO
export LOG_FORMAT=json  # or console for development
export LOG_FILE=/var/log/documentary-pipeline/app.log

# Tracing
export TRACING_EXPORTER=otlp  # or console, sqlite
export OTEL_EXPORTER_OTLP_ENDPOINT=http://jaeger:4318/v1/traces

# Environment
export ENVIRONMENT=production
export SERVICE_VERSION=0.1.0
```

### 6. Start Observability Stack

```bash
cd /mnt/okcomputer/output
docker-compose -f docker-compose.observability.yml up -d
```

### 7. Access Dashboards

- **Grafana**: http://localhost:3000 (admin/admin)
- **Prometheus**: http://localhost:9090
- **Jaeger**: http://localhost:16686
- **Alertmanager**: http://localhost:9093

## Usage Examples

### Adding Correlation IDs to Existing Code

```python
from observability import get_logger, LogContext, set_correlation_id

logger = get_logger(__name__)

async def my_endpoint(request: Request):
    # Correlation ID is automatically set by middleware
    correlation_id = request.state.correlation_id
    
    with LogContext(endpoint="my_endpoint", user_id=user_id):
        logger.info("Processing request")
        # Logs will include correlation_id, endpoint, and user_id
```

### Instrumenting Pipeline Stages

```python
from observability import (
    timed_context,
    get_metrics_collector,
    trace_pipeline_stage,
)

metrics = get_metrics_collector()

async def process_scenario(run_id: str):
    with trace_pipeline_stage("scenario", run_id=run_id):
        with timed_context(PIPELINE_STAGE_DURATION, stage="scenario"):
            # Your scenario processing code
            result = await generate_scenario()
            
            # Record custom metrics
            metrics.record_llm_tokens(
                model="gemini-1.5-pro",
                input_tokens=1000,
                output_tokens=500,
            )
            
            return result
```

### Custom Health Checks

```python
from observability import get_health_checker, HealthStatus, ComponentHealth

health_checker = get_health_checker()

def check_my_service():
    try:
        # Check your service
        if healthy:
            return ComponentHealth(
                name="my_service",
                status=HealthStatus.HEALTHY,
                message="Service is healthy",
            )
    except Exception as e:
        return ComponentHealth(
            name="my_service",
            status=HealthStatus.UNHEALTHY,
            message=f"Service check failed: {e}",
        )

health_checker.register_check("my_service", check_my_service)
```

## Monitoring Checklist

### Metrics to Watch

- [ ] Pipeline stage durations (p50, p95, p99)
- [ ] VM provisioning time
- [ ] API latency
- [ ] Error rates by type and component
- [ ] Worker health status
- [ ] Active pipeline count
- [ ] LLM token usage
- [ ] Disk space usage
- [ ] Memory usage
- [ ] CPU usage

### Alerts to Configure

- [ ] High error rate (> 0.1 errors/sec for 5 min)
- [ ] Pipeline stage slow (< 95% complete within 10 min)
- [ ] Worker unhealthy (for 2 min)
- [ ] VM provisioning failures (> 2 in 1 hour)
- [ ] High API latency (p95 > 5s for 5 min)
- [ ] High disk usage (> 85%)
- [ ] High memory usage (> 85%)
- [ ] High CPU usage (> 80% for 10 min)

### Dashboards to Review

- [ ] Pipeline Overview (worker health, active pipelines, errors)
- [ ] Pipeline Performance (stage durations, VM provisioning)
- [ ] API Performance (latency, tool calls)
- [ ] Resource Usage (CPU, memory, disk)
- [ ] Logs (filtered by correlation ID, run ID)

## Troubleshooting

### No Metrics in Prometheus

1. Check if `/metrics` endpoint is accessible
2. Verify Prometheus scrape configuration
3. Check Prometheus targets page for errors

### Missing Traces in Jaeger

1. Verify `OTEL_EXPORTER_OTLP_ENDPOINT` is set correctly
2. Check application logs for tracing errors
3. Ensure Jaeger collector is running

### Logs Not in Loki

1. Check Promtail is running and configured
2. Verify log file paths in promtail.yml
3. Check Promtail positions file

### Health Checks Failing

1. Check individual component health at `/health`
2. Review component-specific error messages
3. Verify environment variables are set

## Future Enhancements

1. **Synthetic Monitoring**: Add periodic health check probes
2. **SLO Tracking**: Define and track service level objectives
3. **Cost Metrics**: Track cloud spend per pipeline run
4. **User Analytics**: Track pipeline usage patterns
5. **AIOps Integration**: Anomaly detection on metrics
6. **Chaos Engineering**: Test resilience with controlled failures

## References

- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [OpenTelemetry Documentation](https://opentelemetry.io/docs/)
- [Loki Documentation](https://grafana.com/docs/loki/)
- [Structlog Documentation](https://www.structlog.org/)
- [FastAPI Middleware](https://fastapi.tiangolo.com/tutorial/middleware/)
