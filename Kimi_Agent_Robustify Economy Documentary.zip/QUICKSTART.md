# Quick Start Guide - Documentary Pipeline Observability

## 1-Minute Setup

### Step 1: Copy Files

```bash
# Copy observability module
cp -r /mnt/okcomputer/output/observability ./server/

# Copy enhanced server
cp /mnt/okcomputer/output/server_enhanced.py ./server/server.py

# Copy enhanced worker provisioner
cp /mnt/okcomputer/output/worker_provisioner_enhanced.py ./server/worker_provisioner.py
```

### Step 2: Install Dependencies

```bash
pip install -r /mnt/okcomputer/output/requirements-observability.txt
```

### Step 3: Start the Observability Stack

```bash
cd /mnt/okcomputer/output
docker-compose -f docker-compose.observability.yml up -d
```

### Step 4: Start Your Application

```bash
cd /path/to/economy-documentary/server
python server.py
```

### Step 5: Access Dashboards

| Service | URL | Credentials |
|---------|-----|-------------|
| Grafana | http://localhost:3000 | admin/admin |
| Prometheus | http://localhost:9090 | - |
| Jaeger | http://localhost:16686 | - |
| Application | http://localhost:8000 | - |

## Key Endpoints

| Endpoint | Description |
|----------|-------------|
| http://localhost:8000/health | Full health check |
| http://localhost:8000/health/live | Liveness probe |
| http://localhost:8000/health/ready | Readiness probe |
| http://localhost:8000/metrics | Prometheus metrics |
| http://localhost:8000/observability/info | Observability info |

## Environment Variables

```bash
# Required
export LOG_LEVEL=INFO
export LOG_FORMAT=json

# Optional - for tracing
export TRACING_EXPORTER=otlp
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318/v1/traces

# Optional - for production
export ENVIRONMENT=production
export SERVICE_VERSION=0.1.0
```

## Testing the Setup

### Test Health Endpoints

```bash
curl http://localhost:8000/health
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
```

### View Metrics

```bash
curl http://localhost:8000/metrics
```

### Check Logs

```bash
# View structured logs
docker logs documentary-pipeline

# Or check log file
tail -f /var/log/documentary-pipeline/app.log | jq .
```

## Troubleshooting

### Port Conflicts

If ports are already in use, modify `docker-compose.observability.yml`:

```yaml
ports:
  - "9091:9090"  # Change host port
```

### Missing Dependencies

```bash
# If structlog fails to install
pip install --upgrade pip setuptools

# If OpenTelemetry fails
pip install opentelemetry-api opentelemetry-sdk --force-reinstall
```

### No Metrics Showing

1. Check if the application is running
2. Verify Prometheus targets at http://localhost:9090/targets
3. Check application logs for errors

## Next Steps

1. Read the full [OBSERVABILITY_SUMMARY.md](OBSERVABILITY_SUMMARY.md)
2. Configure alerting in `observability/alertmanager/alertmanager.yml`
3. Customize the Grafana dashboard
4. Add custom metrics for your specific needs
