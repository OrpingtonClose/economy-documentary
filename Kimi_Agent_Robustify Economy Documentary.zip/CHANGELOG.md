# Changelog

All notable changes to the Documentary Pipeline project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Comprehensive API documentation with OpenAPI/Swagger annotations
- Troubleshooting guide covering common issues and solutions
- Deployment guide for local, Docker, and cloud environments
- Architecture diagrams using Mermaid for visual documentation
- Environment setup guide with step-by-step instructions
- Code documentation with detailed docstrings for all modules
- This CHANGELOG file to track project changes

### Documentation

- Added `docs/API_DOCUMENTATION.md` with complete endpoint reference
- Added `docs/TROUBLESHOOTING.md` with error codes and solutions
- Added `docs/DEPLOYMENT.md` with multi-platform deployment strategies
- Added `docs/ARCHITECTURE_DIAGRAMS.md` with Mermaid visualizations
- Added `docs/ENVIRONMENT_SETUP.md` with setup instructions
- Added `docs/CODE_DOCUMENTATION.md` with inline code documentation

---

## [0.1.0] - 2025-01-15

### Added

- Initial release of the Documentary Pipeline
- FastAPI server with AG-UI protocol support
- Google ADK integration for agent orchestration
- SequentialAgent pipeline with 5 phases:
  - Scenario Director (EvaluatorOptimizer pattern)
  - Audio Agent (TTS + WhisperX alignment)
  - Visual Director (LoopAgent with coherence checking)
  - Production Supervisor (GPU orchestration via Vast.ai)
  - Assembler Agent (ffmpeg timeline assembly)
- Real-time dashboard with SSE streaming
- SQLite-backed event store for monitoring
- HTML report generation for post-mortem analysis
- Three quality gates for human review:
  - Gate 1: Scenario Editor
  - Gate 2: Prompt Reviewer
  - Gate 3: Clip Reviewer
- OTIO timeline integration for media assembly
- Plugin architecture with:
  - ContextFilterPlugin for context window management
  - ReflectAndRetryToolPlugin for automatic retries
  - GlobalInstructionPlugin for documentary-specific instructions
  - LoggingPlugin and DebugLoggingPlugin for observability
- Callback stack for:
  - before_model: LLM concurrency semaphore
  - after_model: Dashboard tracking
  - before_tool: Rate limiting
  - after_tool: Result truncation
  - timeline_guardian: OTIO validation
- Central configuration module (`config.py`)
- Vault builder for Obsidian/Quartz research output
- Test mode for development without GPU
- Multi-provider LLM fallback chain
- 40+ research tools for claim verification
- ADHD-friendly documentary principles enforcement
- Frontend integration with CopilotKit

### Infrastructure

- Poetry for dependency management
- Docker support with multi-stage builds
- Docker Compose for local orchestration
- Environment-based configuration
- Structured logging with configurable levels
- OpenTelemetry integration for distributed tracing

### Security

- Environment variable-based API key management
- No hardcoded secrets in codebase
- CORS middleware configuration
- Request logging middleware

---

## [0.0.5] - 2024-12-20

### Added

- GPU instance provisioning via Vast.ai API
- LTX-2.3 video generation integration
- WhisperX word-level alignment
- Qwen3-TTS audio generation
- Multi-voice scene structure (V1/V2/V3)

### Changed

- Improved scenario evaluator criteria
- Enhanced visual variety checking
- Optimized context window management

### Fixed

- Context length overflow in long documentaries
- Race condition in concurrent GPU operations
- Memory leak in dashboard event collection

---

## [0.0.4] - 2024-12-01

### Added

- Dashboard UI with real-time updates
- SSE streaming for pipeline events
- PipelineCollector for event tracking
- HTML report generation
- Metrics aggregation

### Changed

- Refactored agent architecture to use ADK patterns
- Improved error handling and recovery
- Enhanced logging with structured output

### Fixed

- Timeline validation false positives
- Audio sync issues in final assembly
- Missing tool call retries

---

## [0.0.3] - 2024-11-15

### Added

- OTIO timeline integration
- ffmpeg assembly pipeline
- Track-based media organization (V1_Video, A1_Narration, A2_Music)
- Timeline Guardian validation
- Clip trimming and concatenation

### Changed

- Replaced custom timeline format with OTIO
- Improved media file organization

### Fixed

- Overlapping clip detection
- Gap handling in timeline
- Audio/video synchronization

---

## [0.0.2] - 2024-11-01

### Added

- Visual Director with LoopAgent pattern
- Content Analyst sub-agent
- Visual Concepter sub-agent
- Coherence Evaluator sub-agent
- LoRA style selection
- Camera angle variety enforcement

### Changed

- Enhanced visual prompt generation
- Improved scene-to-visual mapping

### Fixed

- Visual concept duplication
- Inconsistent lighting descriptions
- Missing camera specifications

---

## [0.0.1] - 2024-10-15

### Added

- Initial project structure
- FastAPI server foundation
- Basic agent framework
- Scenario generation prototype
- Audio generation prototype
- Configuration system

### Technical Details

- Python 3.11+ requirement
- FastAPI 0.100+ for web framework
- Google ADK for agent orchestration
- Poetry for dependency management

---

## Release Notes Template

When creating a new release, use this template:

```markdown
## [X.Y.Z] - YYYY-MM-DD

### Added
- New features

### Changed
- Changes to existing functionality

### Deprecated
- Soon-to-be removed features

### Removed
- Removed features

### Fixed
- Bug fixes

### Security
- Security improvements
```

---

## Version Numbering

This project follows [Semantic Versioning](https://semver.org/):

- **MAJOR** version for incompatible API changes
- **MINOR** version for backwards-compatible functionality additions
- **PATCH** version for backwards-compatible bug fixes

### Pre-release Versions

- `0.x.x` - Initial development, API may change
- `1.0.0-rc.1` - Release candidate
- `1.0.0-beta.1` - Beta release

---

## Migration Guides

### Upgrading to 0.2.0 (Future)

When 0.2.0 is released, migration steps will be documented here.

### Upgrading to 0.1.0

From 0.0.x versions:

1. Update environment variables:
   ```bash
   # Old
   export MODEL=gemini-1.5-flash
   
   # New
   export ADK_MODEL=gemini-2.5-flash
   ```

2. Update configuration imports:
   ```python
   # Old
   from server.config import MODEL
   
   # New
   from config import ADK_MODEL
   ```

3. Review new plugin configuration options

---

## Contributors

Thank you to all contributors who have helped shape this project!

To add your contribution, please submit a pull request with:
- Clear description of changes
- Updated tests
- Updated documentation
- CHANGELOG entry

---

## License

This project is licensed under the MIT License - see the LICENSE file for details.

---

## Links

- Repository: https://github.com/OrpingtonClose/economy-documentary
- Documentation: https://github.com/OrpingtonClose/economy-documentary/tree/main/docs
- Issues: https://github.com/OrpingtonClose/economy-documentary/issues
- Discussions: https://github.com/OrpingtonClose/economy-documentary/discussions

---

*Note: This CHANGELOG was initialized retroactively for versions prior to 0.1.0.
Future versions will be documented in real-time as changes are made.*
