# Configuration Management Improvements

## Executive Summary

This document summarizes the comprehensive improvements made to the configuration management system for the economy-documentary project. The new system replaces the legacy `os.environ.get()` approach with a modern, type-safe, validated configuration system using **pydantic-settings**.

## Key Improvements

### 1. Type-Safe Configuration with pydantic-settings

**Before (Legacy):**
```python
# config.py - Legacy approach
MAX_CONCURRENT_LLM = int(os.environ.get("MAX_CONCURRENT_LLM", "4"))
DOCUMENTARY_TEST_MODE = os.environ.get("DOCUMENTARY_TEST_MODE", "false").strip().lower() in ("true", "1")
```

**After (New System):**
```python
# config/settings.py - Type-safe approach
from pydantic import Field
from pydantic_settings import BaseSettings

class ConcurrencySettings(BaseSettings):
    max_concurrent_llm: int = Field(
        default=4,
        ge=1,
        le=100,
        description="Maximum concurrent LLM requests",
    )
```

**Benefits:**
- Automatic type conversion and validation
- Clear default values with constraints
- Self-documenting field descriptions
- IDE autocomplete support

### 2. Environment-Specific Configuration Files

Created three environment-specific templates:

| File | Purpose | Key Characteristics |
|------|---------|---------------------|
| `.env.development` | Local development | Test mode enabled, lower concurrency, local paths |
| `.env.staging` | Pre-production | Production-like, moderate resources, staging buckets |
| `.env.production` | Production | Full resources, high concurrency, secrets from manager |

### 3. Comprehensive Validation at Startup

**New Validation System:**
```python
from config.startup import StartupValidator, validate_startup

# In your application startup
validator = StartupValidator()
result = await validator.validate_all()

if not result.can_start():
    # Log critical errors and exit
    sys.exit(1)
```

**Validations Include:**
- Required API keys present
- Path accessibility and permissions
- Context limit relationships (hard > max)
- Service connectivity checks
- Production-specific requirements

### 4. Feature Flags System

**Implementation:**
```python
from config.feature_flags import get_feature_flags, feature_flag_required

# Check feature flags
flags = get_feature_flags()
if flags.is_enabled("ENABLE_GPU_WORKERS"):
    provision_gpu()

# Use decorator for conditional execution
@feature_flag_required("EXPERIMENTAL_FEATURE")
def experimental_function():
    pass
```

**Supported Flag Types:**
- **Boolean**: Simple on/off
- **Percentage**: Gradual rollout (e.g., 10% of users)
- **User Segment**: Target specific user groups
- **Time-based**: Enable during specific windows
- **Dependency**: Depends on other flags

### 5. Secrets Rotation Support

**Pattern Implementation:**
```python
from config.secrets import (
    SecretsRotationManager,
    RotationStrategy,
    SecretStr,
)

# Initialize manager
manager = SecretsRotationManager()

# Register secret with rotation
secret = manager.register_secret(
    name="api_key",
    initial_value=SecretStr("secret-value"),
    rotation_interval=86400,  # Daily rotation
)

# Rotate with graceful transition
await manager.rotate_secret(
    "api_key",
    SecretStr("new-secret"),
    strategy=RotationStrategy.GRACEFUL,
)
```

**Features:**
- Multiple secret versions (active, pending, previous)
- Automatic failover to backup secrets
- Health checking
- Audit logging
- Integration stubs for AWS Secrets Manager and HashiCorp Vault

### 6. Configuration Documentation Generator

**Usage:**
```python
from config.documentation import generate_all_documentation

# Generate all documentation
generate_all_documentation(
    DocumentarySettings,
    output_dir="docs/config"
)
```

**Generated Files:**
- `CONFIGURATION.md` - Full configuration reference
- `config-schema.json` - JSON schema for validation
- `.env.{environment}.example` - Environment templates
- `FEATURE_FLAGS.md` - Feature flag documentation

## File Structure

```
config/
├── __init__.py           # Main exports and convenience functions
├── settings.py           # Pydantic settings with all configuration
├── feature_flags.py      # Feature flag system
├── secrets.py            # Secrets rotation support
├── validators.py         # Custom validators
├── documentation.py      # Documentation generator
└── startup.py            # Startup validation

Environment Files:
├── .env.development      # Development environment
├── .env.staging          # Staging environment
├── .env.production       # Production environment

Updated Files:
├── pyproject.toml        # Updated with pydantic-settings dependency
└── server_config.py      # Updated server configuration
```

## Migration Guide

### Step 1: Update Dependencies

Add to `pyproject.toml`:
```toml
dependencies = [
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "python-dotenv>=1.0.0",
]
```

### Step 2: Replace Legacy Config Usage

**Before:**
```python
from config import MAX_CONCURRENT_LLM, DOCUMENTARY_TEST_MODE
```

**After:**
```python
from config import get_settings

settings = get_settings()
max_concurrent = settings.concurrency.max_concurrent_llm
test_mode = settings.documentary_test_mode
```

### Step 3: Update Server Startup

**Before:**
```python
def _validate_env() -> None:
    model = os.environ.get("ADK_MODEL")
    if not model:
        raise ValueError("ADK_MODEL required")
```

**After:**
```python
from config import validate_startup

@app.on_event("startup")
async def on_startup():
    await validate_startup()
```

### Step 4: Create Environment File

Copy the appropriate template:
```bash
# For development
cp .env.development .env

# For staging
cp .env.staging .env

# For production
cp .env.production .env
```

Then fill in your actual values.

## Configuration Reference

### Core Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ENVIRONMENT` | string | `development` | Deployment environment |
| `DEBUG` | boolean | `false` | Enable debug mode |
| `LOG_LEVEL` | string | `INFO` | Logging level |
| `ADK_MODEL` | string | `gemini-2.5-flash` | Primary LLM model |

### API Keys

| Variable | Type | Required | Description |
|----------|------|----------|-------------|
| `GOOGLE_API_KEY` | Secret | Recommended | Google/Gemini API key |
| `OPENAI_API_KEY` | Secret | Recommended | OpenAI API key |
| `OPENAI_API_BASE` | string | Optional | OpenAI-compatible endpoint |
| `DEEPSEEK_API` | Secret | Optional | DeepSeek API key |
| `GROQ_API` | Secret | Optional | Groq API key |

### Concurrency Settings

| Variable | Type | Default | Range | Description |
|----------|------|---------|-------|-------------|
| `MAX_CONCURRENT_LLM` | int | 4 | 1-100 | Max concurrent LLM requests |
| `MAX_CONTEXT_TOKENS` | int | 120000 | 1000-2M | Max context tokens |
| `HARD_CONTEXT_LIMIT` | int | 180000 | 1000-2M | Emergency cutoff |
| `GPU_CONCURRENCY` | int | 2 | 1-50 | Max concurrent GPU ops |

### Path Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `DATA_DIR` | Path | `/tmp/documentary-pipeline` | Base data directory |
| `TIMELINE_DIR` | Path | `DATA_DIR/timelines` | Timeline outputs |
| `TTS_OUTPUT_DIR` | Path | `DATA_DIR/audio` | TTS audio outputs |
| `VIDEO_OUTPUT_DIR` | Path | `DATA_DIR/video` | Video outputs |

## Feature Flags Reference

### Pipeline Features

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `ENABLE_GPU_WORKERS` | boolean | `true` | GPU worker provisioning |
| `ENABLE_TTS_GENERATION` | boolean | `true` | Text-to-speech generation |
| `ENABLE_VIDEO_GENERATION` | boolean | `true` | LTX video generation |
| `ENABLE_ENRICHMENT` | boolean | `true` | Data enrichment pipeline |

### Observability Features

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `ENABLE_PHOENIX_TRACING` | boolean | `false` | Phoenix tracing |
| `ENABLE_AGENTOPS_MONITORING` | boolean | `false` | AgentOps monitoring |
| `ENABLE_DETAILED_SPANS` | boolean | `false` | Detailed span content |

### Experimental Features

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `EXPERIMENTAL_SCENE_SPLITTING` | percentage | `10%` | AI scene splitting |
| `EXPERIMENTAL_VOICE_CLONING` | percentage | `5%` | Voice cloning |

## Validation Rules

The new system enforces these validation rules:

1. **Context Limits**: `HARD_CONTEXT_LIMIT` must be greater than `MAX_CONTEXT_TOKENS`
2. **API Keys**: At least one LLM provider required in production
3. **Redundancy**: Production requires 2+ LLM providers
4. **Paths**: Data directories must be writable
5. **Concurrency**: Values must be within specified ranges

## Security Improvements

### Secret Handling

- All API keys use `SecretStr` type (masked in logs)
- Secrets rotation support with version management
- Graceful transition during rotation
- Audit logging of secret access

### Environment Isolation

- Separate configurations per environment
- Production-specific validation rules
- Feature flags for gradual rollouts

## Performance Benefits

1. **Cached Settings**: `get_settings()` uses `@lru_cache` for efficiency
2. **Lazy Loading**: Sub-configurations loaded on demand
3. **Validation at Startup**: Issues caught early, not at runtime
4. **Type Safety**: Fewer runtime errors from type mismatches

## Testing

### Unit Tests

```python
from config import get_settings, Environment

def test_development_settings():
    settings = get_settings_for_environment(Environment.DEVELOPMENT)
    assert settings.debug is True
    assert settings.documentary_test_mode is True
```

### Feature Flag Tests

```python
from config.feature_flags import get_feature_flags

def test_feature_flag():
    flags = get_feature_flags()
    flags.set_flag("TEST_FLAG", True)
    assert flags.is_enabled("TEST_FLAG") is True
```

## Troubleshooting

### Common Issues

**Issue**: "No LLM provider API key configured"
- **Solution**: Set `GOOGLE_API_KEY` or `OPENAI_API_KEY`

**Issue**: "Path does not exist"
- **Solution**: Create the directory: `mkdir -p /path/to/data`

**Issue**: "HARD_CONTEXT_LIMIT must be greater than MAX_CONTEXT_TOKENS"
- **Solution**: Increase `HARD_CONTEXT_LIMIT` or decrease `MAX_CONTEXT_TOKENS`

### Debug Mode

Enable debug logging:
```python
from config import get_settings
import logging

settings = get_settings()
settings.debug = True
logging.basicConfig(level=logging.DEBUG)
```

## Future Enhancements

1. **Remote Configuration**: Integration with Consul, etcd
2. **Dynamic Updates**: Hot-reload configuration without restart
3. **A/B Testing**: Enhanced feature flag targeting
4. **Metrics**: Configuration usage analytics
5. **Cost Tracking**: Per-feature cost attribution

## Conclusion

The new configuration management system provides:
- ✅ Type safety with pydantic validation
- ✅ Environment-specific configurations
- ✅ Comprehensive startup validation
- ✅ Feature flags for gradual rollouts
- ✅ Secrets rotation support
- ✅ Auto-generated documentation
- ✅ Better developer experience

This represents a significant improvement over the legacy `os.environ.get()` approach, providing robustness, maintainability, and scalability for the documentary pipeline project.
